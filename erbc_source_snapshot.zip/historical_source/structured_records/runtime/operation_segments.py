"""Derive deterministic map/reduce SFT data for the task-B segmentation experiment E2."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
import re
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
SOURCE_HASHES = {'train': '875765475cf5229803636e81a3ae1fd2a38a97d018abdac76d19d473daeed104', 'validation': '32e2d1660fc9519d092b34d6dd63fcde2d457cd7ef5956bb9e97474c08338a0a'}
EXPECTED_SOURCE_ROWS = {'train': 796, 'validation': 109}
EXPECTED_OPERATIONS = {'train': 4764, 'validation': 573}
SEED = 20260920
QUESTION_CHUNK_TOKENS = 2048
QUESTION_OVERLAP_TOKENS = 128
QUESTION_CONTEXT_TOKENS_MAP = 6144
QUESTION_CONTEXT_TOKENS_REDUCE = 4096
EVIDENCE_CHUNK_TOKENS = 8192
EVIDENCE_OVERLAP_TOKENS = 256
REDUCE_EVIDENCE_PER_SOURCE_TOKENS = 4096
REDUCE_EVIDENCE_TOTAL_TOKENS = 16384
MAX_CHAT_TOKENS = 49152
MAP_SYSTEM = '\u4f60\u6267\u884c\u4efb\u52a1B\u7684\u5c40\u90e8\u8bc1\u636e\u6620\u5c04\u3002\u8f93\u5165\u53ea\u5305\u542b\u4e00\u6bb5\u8bc1\u636e\u4ee5\u53ca\u7ecf\u8f93\u5165\u68c0\u7d22\u5f97\u5230\u7684\u9898\u76ee\u4e0a\u4e0b\u6587\u3002\u8bc6\u522b\u8be5\u8bc1\u636e\u4e2d\u76f4\u63a5\u652f\u6301\u7684\u5b66\u4e60\u76f8\u5173\u64cd\u4f5c\uff1b\u6ca1\u6709\u64cd\u4f5c\u65f6\u5fc5\u987b\u8fd4\u56de\u7a7a\u6570\u7ec4\u3002\u4e0d\u8981\u5728\u672c\u9636\u6bb5\u5224\u65ad\u6700\u7ec8\u76f8\u5173\u6027\u3001KU\u6216\u8d23\u4efb\u5f52\u5c5e\u3002\u4e25\u683c\u8fd4\u56de\u7b26\u5408output_json_schema\u7684JSON\uff0c\u4e0d\u8981\u8f93\u51fa\u89e3\u91ca\u6216Markdown\u3002'
REDUCE_SYSTEM = '\u4f60\u6267\u884c\u4efb\u52a1B\u7684\u8bc1\u636e\u5f52\u5e76\u3002\u8f93\u5165\u5305\u542b\u4e00\u4e2a\u5019\u9009\u5b66\u4e60\u64cd\u4f5c\u3001\u4e0e\u5176\u76f8\u5173\u7684\u591a\u6e90\u8bc1\u636e\u3001\u91d1\u6807\u9898\u76ee\u84dd\u56fe\u548c\u5019\u9009\u6807\u51c6KU\u8def\u5f84\u3002\u8bf7\u5c06\u5019\u9009\u89c4\u8303\u5316\u4e3a\u4e00\u4e2a\u64cd\u4f5c\uff0c\u5e76\u5224\u65adrelevance\u3001standard_ku\u3001responsibility\u53ca\u8bc1\u636e\u5f15\u7528\u3002\u4e25\u683c\u8fd4\u56de\u7b26\u5408output_json_schema\u7684JSON\uff0c\u4e0d\u8981\u8f93\u51fa\u89e3\u91ca\u6216Markdown\u3002'
MAP_SCHEMA = {'type': 'object', 'required': ['local_candidates'], 'additionalProperties': False, 'properties': {'local_candidates': {'type': 'array', 'minItems': 0, 'items': {'type': 'object', 'required': ['operation', 'evidence_refs'], 'additionalProperties': False, 'properties': {'operation': {'type': 'string', 'minLength': 1}, 'evidence_refs': {'type': 'array', 'minItems': 1}}}}}}
REDUCE_SCHEMA = {'type': 'object', 'required': ['canonical_operation'], 'additionalProperties': False, 'properties': {'canonical_operation': {'type': 'object'}}}

def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()

def stable_hash(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open('r', encoding='utf-8') as stream:
        for number, raw in enumerate(stream, 1):
            if not raw.strip():
                continue
            try:
                rows.append(json.loads(raw))
            except json.JSONDecodeError as exc:
                raise SystemExit(f'Safety stop: invalid JSONL at {path}:{number}: {exc}') from exc
    return rows

def write_json_atomic(path: Path, value: dict) -> None:
    temporary = Path(str(path) + '.partial')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    os.replace(temporary, path)

def write_jsonl_atomic(path: Path, rows: list[dict]) -> None:
    temporary = Path(str(path) + '.partial')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
    os.replace(temporary, path)

def normalize(text: str) -> str:
    text = unicodedata.normalize('NFKC', text or '').lower()
    return re.sub('\\s+', ' ', re.sub('[^\\w\\u3400-\\u9fff]+', ' ', text)).strip()

def features(text: str, limit: int=6000) -> set[str]:
    text = normalize(text)[:limit]
    words = set(re.findall('[a-z0-9_]+|[\\u3400-\\u9fff]', text))
    compact = re.sub('\\s+', '', text)
    grams = {compact[index:index + 2] for index in range(max(0, len(compact) - 1))}
    return words | grams

def overlap_score(left: str, right: str) -> float:
    a, b = (features(left), features(right))
    if not a or not b:
        return 0.0
    return len(a & b) / math.sqrt(len(a) * len(b))

def token_ids(value) -> list[int]:
    if hasattr(value, 'keys'):
        return list(value['input_ids'])
    return list(value)

def encode_text(tokenizer, text: str) -> list[int]:
    encoded = tokenizer(text, add_special_tokens=False)
    return token_ids(encoded)

def token_chunks(tokenizer, text: str, size: int, overlap: int) -> list[dict]:
    ids = encode_text(tokenizer, text)
    if not ids:
        return [{'chunk_index': 0, 'text': '', 'token_count': 0}]
    chunks = []
    step = max(1, size - overlap)
    for start in range(0, len(ids), step):
        part = ids[start:start + size]
        chunks.append({'chunk_index': len(chunks), 'text': tokenizer.decode(part, skip_special_tokens=False), 'token_count': len(part)})
        if start + size >= len(ids):
            break
    return chunks

def select_question_context(tokenizer, question: str, query: str, budget: int, precomputed_chunks: list[dict] | None=None) -> dict:
    chunks = precomputed_chunks or token_chunks(tokenizer, question, QUESTION_CHUNK_TOKENS, QUESTION_OVERLAP_TOKENS)
    if len(chunks) == 1:
        selected = chunks
    else:
        ranked = sorted(chunks, key=lambda item: (-overlap_score(item['text'], query), item['chunk_index']))
        keep = max(1, budget // QUESTION_CHUNK_TOKENS)
        chosen = {0}
        for item in ranked:
            if len(chosen) >= keep:
                break
            chosen.add(item['chunk_index'])
        selected = [chunks[index] for index in sorted(chosen)]
    while sum((item['token_count'] for item in selected)) > budget and len(selected) > 1:
        selected.pop()
    return {'selection_method': 'first_chunk_plus_input_only_lexical_overlap', 'source_question_tokens': sum((item['token_count'] for item in chunks)) - QUESTION_OVERLAP_TOKENS * max(0, len(chunks) - 1), 'selected_chunk_indices': [item['chunk_index'] for item in selected], 'selected_tokens': sum((item['token_count'] for item in selected)), 'text': '\n\n'.join((item['text'] for item in selected))}

def dialogue_blocks(messages: list[dict]) -> list[dict]:
    blocks = []
    index = 0
    while index < len(messages):
        current = messages[index]
        group = [current]
        if current.get('speaker') == 'student' and index + 1 < len(messages) and (messages[index + 1].get('speaker') == 'assistant'):
            group.append(messages[index + 1])
            index += 1
        text = '\n\n'.join((f"[{item.get('message_id', 'UNKNOWN')}|{item.get('speaker', 'UNKNOWN')}]\n{item.get('content', '')}" for item in group))
        blocks.append({'block_kind': 'dialogue_exchange', 'source_ids': [item.get('message_id') for item in group if item.get('message_id')], 'source_speakers': {item.get('message_id'): item.get('speaker') for item in group if item.get('message_id')}, 'text': text})
        index += 1
    return blocks

def source_blocks(payload: dict) -> list[dict]:
    blocks = dialogue_blocks(payload.get('dialogue_with_message_ids') or [])
    for document in (payload.get('submission') or {}).get('documents') or []:
        source_id = document.get('source_id') or document.get('message_id')
        blocks.append({'block_kind': 'submission_document', 'source_ids': [source_id] if source_id else [], 'source_speakers': {source_id: 'submission'} if source_id else {}, 'text': f"[{source_id or 'UNKNOWN'}|submission]\n{document.get('content', '')}"})
    for index, block in enumerate(blocks):
        block['block_index'] = index
    return blocks

def evidence_ref_id(item: dict) -> str | None:
    return item.get('message_id') or item.get('source_id')

def evidence_ref_text(item: dict) -> str:
    return ' '.join((str(item.get(key, '')) for key in ('quote', 'content', 'evidence', 'text') if item.get(key)))

def make_block_chunks(tokenizer, blocks: list[dict]) -> list[dict]:
    output = []
    for block in blocks:
        for chunk in token_chunks(tokenizer, block['text'], EVIDENCE_CHUNK_TOKENS, EVIDENCE_OVERLAP_TOKENS):
            output.append({**block, 'chunk_index': chunk['chunk_index'], 'chunk_id': f"block-{block['block_index']:03d}-chunk-{chunk['chunk_index']:03d}", 'text': chunk['text'], 'token_count': chunk['token_count']})
    return output

def best_chunk_for_operation(operation: dict, chunks: list[dict]) -> dict:
    refs = [item for item in operation.get('evidence_refs') or [] if evidence_ref_id(item)]
    ref_ids = {evidence_ref_id(item) for item in refs}
    reference_text = ' '.join((evidence_ref_text(item) for item in refs))
    query = f"{operation.get('operation', '')} {reference_text}"
    candidates = [chunk for chunk in chunks if ref_ids & set(chunk['source_ids'])]
    if not candidates:
        raise SystemExit(f"Safety stop: no evidence chunk for operation {operation.get('operation_id')}")
    return min(candidates, key=lambda chunk: (-overlap_score(chunk['text'], query), chunk['block_index'], chunk['chunk_index']))

def local_refs(operation: dict, chunk: dict) -> list[dict]:
    source_ids = set(chunk['source_ids'])
    refs = [item for item in operation.get('evidence_refs') or [] if evidence_ref_id(item) in source_ids]
    if not refs:
        raise SystemExit(f"Safety stop: local evidence refs empty for {operation.get('operation_id')} / {chunk['chunk_id']}")
    return refs

def canonical_without_id(operation: dict) -> dict:
    result = dict(operation)
    result['operation_id'] = 'U01'
    return result

def chat_token_count(tokenizer, messages: list[dict]) -> int:
    encoded = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=False)
    return len(token_ids(encoded))

def quantiles(values: list[int]) -> dict:
    if not values:
        return {'min': 0, 'p50': 0, 'p75': 0, 'p90': 0, 'p95': 0, 'max': 0}
    values = sorted(values)

    def pick(q: float) -> int:
        return values[round((len(values) - 1) * q)]
    return {'min': values[0], 'p50': pick(0.5), 'p75': pick(0.75), 'p90': pick(0.9), 'p95': pick(0.95), 'max': values[-1]}

def derive_unit(tokenizer, row: dict, split: str) -> tuple[list[dict], list[dict], list[dict], dict]:
    metadata = row['metadata']
    unit_id = metadata['unit_id']
    payload = json.loads(row['messages'][1]['content'])
    target = json.loads(row['messages'][2]['content'])
    operations = target.get('operations') or []
    blocks = source_blocks(payload)
    chunks = make_block_chunks(tokenizer, blocks)
    question_chunks = token_chunks(tokenizer, payload.get('question_text', ''), QUESTION_CHUNK_TOKENS, QUESTION_OVERLAP_TOKENS)
    source_to_block = {}
    for block in blocks:
        for source_id in block['source_ids']:
            if source_id in source_to_block:
                raise SystemExit(f'Safety stop: duplicate source id in {unit_id}: {source_id}')
            source_to_block[source_id] = block['block_index']
    referenced_blocks = set()
    assigned: dict[str, list[dict]] = defaultdict(list)
    ownership = []
    for operation in operations:
        refs = [evidence_ref_id(item) for item in operation.get('evidence_refs') or [] if evidence_ref_id(item)]
        unknown = set(refs) - set(source_to_block)
        if unknown:
            raise SystemExit(f'Safety stop: unknown evidence refs in {unit_id}: {sorted(unknown)}')
        referenced_blocks.update((source_to_block[ref] for ref in refs))
        by_block = defaultdict(list)
        for ref in refs:
            by_block[source_to_block[ref]].append(ref)
        selected_chunks = []
        for block_index in sorted(by_block):
            candidates = [chunk for chunk in chunks if chunk['block_index'] == block_index]
            selected = best_chunk_for_operation(operation, candidates)
            assigned[selected['chunk_id']].append(operation)
            selected_chunks.append(selected)
        ownership.append({'split': split, 'unit_id': unit_id, 'operation_id': operation.get('operation_id'), 'operation': operation.get('operation'), 'evidence_source_ids': refs, 'selected_map_chunk_ids': [item['chunk_id'] for item in selected_chunks], 'map_emission_count': len(selected_chunks)})
    blueprint_text = json.dumps(payload.get('confirmed_blueprint'), ensure_ascii=False)
    candidate_text = json.dumps(payload.get('candidate_standard_ku_paths'), ensure_ascii=False)
    base_query = f'{blueprint_text} {candidate_text}'
    map_positive = []
    map_negative_candidates = []
    for chunk in chunks:
        ops = assigned.get(chunk['chunk_id'], [])
        block_was_referenced = chunk['block_index'] in referenced_blocks
        if not ops and block_was_referenced:
            continue
        question_context = select_question_context(tokenizer, payload.get('question_text', ''), f"{chunk['text']} {base_query}", QUESTION_CONTEXT_TOKENS_MAP, question_chunks)
        local_candidates = [{'operation': op.get('operation', ''), 'evidence_refs': local_refs(op, chunk)} for op in ops]
        map_input = {'task': 'B_MAP', 'subject': metadata.get('subject'), 'question_context': question_context, 'evidence_chunk': {'chunk_id': chunk['chunk_id'], 'block_kind': chunk['block_kind'], 'source_ids': chunk['source_ids'], 'text': chunk['text']}, 'confirmed_blueprint': payload.get('confirmed_blueprint'), 'output_json_schema': MAP_SCHEMA}
        answer = {'local_candidates': local_candidates}
        sample = {'messages': [{'role': 'system', 'content': MAP_SYSTEM}, {'role': 'user', 'content': json.dumps(map_input, ensure_ascii=False, separators=(',', ':'))}, {'role': 'assistant', 'content': json.dumps(answer, ensure_ascii=False, separators=(',', ':'))}], 'metadata': {'unit_id': unit_id, 'subject': metadata.get('subject'), 'task': 'B_MAP', 'split': split, 'chunk_id': chunk['chunk_id'], 'positive': bool(ops), 'local_operation_count': len(ops), 'source_ids': chunk['source_ids']}}
        if ops:
            map_positive.append(sample)
        else:
            hardness = overlap_score(chunk['text'], base_query)
            map_negative_candidates.append((hardness, stable_hash(f"{SEED}|{split}|{unit_id}|{chunk['chunk_id']}"), sample))
    if split == 'train':
        negative_limit = len(map_positive)
        map_negative_candidates.sort(key=lambda item: (-item[0], item[1]))
        map_negative = [item[2] for item in map_negative_candidates[:negative_limit]]
    else:
        map_negative = [item[2] for item in sorted(map_negative_candidates, key=lambda item: item[1])]
    reduce_rows = []
    for operation in operations:
        refs = [evidence_ref_id(item) for item in operation.get('evidence_refs') or [] if evidence_ref_id(item)]
        refs_by_block = defaultdict(list)
        for source_id in refs:
            refs_by_block[source_to_block[source_id]].append(source_id)
        ref_chunks = []
        for block_index in sorted(refs_by_block):
            candidates = [chunk for chunk in chunks if chunk['block_index'] == block_index]
            selected = best_chunk_for_operation(operation, candidates)
            ids = encode_text(tokenizer, selected['text'])[:REDUCE_EVIDENCE_PER_SOURCE_TOKENS]
            ref_chunks.append({'source_ids': refs_by_block[block_index], 'block_kind': selected['block_kind'], 'chunk_id': selected['chunk_id'], 'text': tokenizer.decode(ids, skip_special_tokens=False), 'tokens': len(ids)})
        while sum((item['tokens'] for item in ref_chunks)) > REDUCE_EVIDENCE_TOTAL_TOKENS:
            largest = max(ref_chunks, key=lambda item: item['tokens'])
            if largest['tokens'] <= 512:
                break
            new_size = max(512, largest['tokens'] - 512)
            ids = encode_text(tokenizer, largest['text'])[:new_size]
            largest['text'] = tokenizer.decode(ids, skip_special_tokens=False)
            largest['tokens'] = len(ids)
        question_context = select_question_context(tokenizer, payload.get('question_text', ''), f"{operation.get('operation', '')} {' '.join((item['text'] for item in ref_chunks))} {base_query}", QUESTION_CONTEXT_TOKENS_REDUCE, question_chunks)
        reduce_input = {'task': 'B_REDUCE', 'subject': metadata.get('subject'), 'candidate_operation': operation.get('operation'), 'question_context': question_context, 'evidence_bundle': [{key: item[key] for key in ('source_ids', 'block_kind', 'chunk_id', 'text')} for item in ref_chunks], 'confirmed_blueprint': payload.get('confirmed_blueprint'), 'candidate_standard_ku_paths': payload.get('candidate_standard_ku_paths'), 'output_json_schema': REDUCE_SCHEMA}
        reduce_answer = {'canonical_operation': canonical_without_id(operation)}
        reduce_rows.append({'messages': [{'role': 'system', 'content': REDUCE_SYSTEM}, {'role': 'user', 'content': json.dumps(reduce_input, ensure_ascii=False, separators=(',', ':'))}, {'role': 'assistant', 'content': json.dumps(reduce_answer, ensure_ascii=False, separators=(',', ':'))}], 'metadata': {'unit_id': unit_id, 'subject': metadata.get('subject'), 'task': 'B_REDUCE', 'split': split, 'source_operation_id': operation.get('operation_id'), 'evidence_source_ids': refs}})
    stats = {'unit_id': unit_id, 'subject': metadata.get('subject'), 'source_operations': len(operations), 'source_blocks': len(blocks), 'evidence_chunks': len(chunks), 'referenced_blocks': len(referenced_blocks), 'map_positive_samples': len(map_positive), 'map_negative_available': len(map_negative_candidates), 'map_negative_selected': len(map_negative), 'reduce_samples': len(reduce_rows)}
    return (map_positive + map_negative, reduce_rows, ownership, stats)

def finalize_samples(tokenizer, rows: list[dict]) -> tuple[list[dict], list[dict]]:
    details = []
    keys = []
    for row in rows:
        metadata = row['metadata']
        if metadata['task'] == 'B_MAP':
            key = (metadata['split'], metadata['unit_id'], 'B_MAP', metadata['chunk_id'])
        else:
            key = (metadata['split'], metadata['unit_id'], 'B_REDUCE', metadata['source_operation_id'])
        keys.append(key)
        count = chat_token_count(tokenizer, row['messages'])
        row['metadata']['total_tokens'] = count
        if count > MAX_CHAT_TOKENS:
            raise SystemExit(f"Safety stop: E2 sample exceeds {MAX_CHAT_TOKENS} tokens: {row['metadata'].get('unit_id')} {row['metadata'].get('task')} {count}")
        details.append({**row['metadata'], 'total_tokens': count})
    if len(keys) != len(set(keys)):
        duplicates = [key for key, count in Counter(keys).items() if count > 1]
        raise SystemExit(f'Safety stop: duplicate E2 sample keys: {duplicates[:20]}')
    rows.sort(key=lambda item: stable_hash(f"{SEED}|{item['metadata']['split']}|{item['metadata']['unit_id']}|{item['metadata']['task']}|{item['metadata'].get('chunk_id', '')}|{item['metadata'].get('source_operation_id', '')}"))
    return (rows, details)

def derive_split(tokenizer, source: Path, split: str) -> tuple[list[dict], list[dict], list[dict], dict]:
    if sha256(source) != SOURCE_HASHES[split]:
        raise SystemExit(f'Safety stop: {split} source hash drift')
    rows = load_jsonl(source)
    if len(rows) != EXPECTED_SOURCE_ROWS[split]:
        raise SystemExit(f'Safety stop: {split} source row mismatch')
    map_rows, reduce_rows, ownership, unit_stats = ([], [], [], [])
    for index, row in enumerate(rows, 1):
        if (row.get('metadata') or {}).get('task') != 'B':
            raise SystemExit(f'Safety stop: non-B source row in {split}')
        m, r, o, s = derive_unit(tokenizer, row, split)
        map_rows.extend(m)
        reduce_rows.extend(r)
        ownership.extend(o)
        unit_stats.append(s)
        if index == 1 or index % 25 == 0 or index == len(rows):
            print(json.dumps({'event': 'e2_derivation_progress', 'split': split, 'units_completed': index, 'units_total': len(rows), 'map_samples_so_far': len(map_rows), 'reduce_samples_so_far': len(reduce_rows)}, ensure_ascii=False), flush=True)
    if len(reduce_rows) != EXPECTED_OPERATIONS[split]:
        raise SystemExit(f'Safety stop: {split} reduce operation mismatch: expected={EXPECTED_OPERATIONS[split]}, actual={len(reduce_rows)}')
    combined, length_details = finalize_samples(tokenizer, map_rows + reduce_rows)
    task_counts = Counter((item['metadata']['task'] for item in combined))
    subject_counts = Counter((item['metadata']['subject'] for item in combined))
    token_groups = defaultdict(list)
    for detail in length_details:
        token_groups[detail['task']].append(detail['total_tokens'])
    summary = {'source_units': len(rows), 'source_operations': len(reduce_rows), 'examples': len(combined), 'task_counts': dict(sorted(task_counts.items())), 'subject_counts': dict(sorted(subject_counts.items())), 'map_positive_samples': sum((item['map_positive_samples'] for item in unit_stats)), 'map_negative_available': sum((item['map_negative_available'] for item in unit_stats)), 'map_negative_selected': sum((item['map_negative_selected'] for item in unit_stats)), 'map_operation_emissions': sum((item['map_emission_count'] for item in ownership)), 'map_duplicate_emissions': sum((max(0, item['map_emission_count'] - 1) for item in ownership)), 'token_quantiles': {task: quantiles(values) for task, values in sorted(token_groups.items())}, 'max_chat_tokens_gate': MAX_CHAT_TOKENS}
    return (combined, ownership, length_details, summary)

def self_test() -> None:

    class FakeTokenizer:

        def __call__(self, text, add_special_tokens=False):
            return {'input_ids': [ord(char) for char in text]}

        def decode(self, ids, skip_special_tokens=False):
            return ''.join((chr(item) for item in ids))

        def apply_chat_template(self, messages, tokenize=True, add_generation_prompt=False):
            return [ord(char) for char in json.dumps(messages, ensure_ascii=False)]
    assert normalize(' A，B ') == 'a b'
    assert overlap_score('alpha beta', 'beta gamma') > 0
    assert quantiles([1, 2, 3])['max'] == 3
    assert stable_hash('x') == stable_hash('x')
    synthetic = {'metadata': {'unit_id': 'U_TEST', 'subject': '01_\u8ba1\u7b97\u673a\u79d1\u5b66', 'task': 'B'}, 'messages': [{'role': 'system', 'content': 's'}, {'role': 'user', 'content': json.dumps({'question_text': '\u6d4b\u8bd5\u9898\u76ee\u4e0e\u7b97\u6cd5', 'dialogue_with_message_ids': [{'message_id': 'M1', 'speaker': 'student', 'content': '\u6211\u5206\u6790\u7b97\u6cd5'}, {'message_id': 'M2', 'speaker': 'assistant', 'content': '\u8bf7\u7ee7\u7eed'}, {'message_id': 'M3', 'speaker': 'student', 'content': '\u65e0\u5173\u804a\u5929'}], 'submission': {'documents': [{'source_id': 'D1', 'content': '\u63d0\u4ea4\u7b97\u6cd5\u4ee3\u7801'}]}, 'confirmed_blueprint': [{'ku_id': 'KU1'}], 'candidate_standard_ku_paths': [{'ku_id': 'KU1'}]}, ensure_ascii=False)}, {'role': 'assistant', 'content': json.dumps({'operations': [{'operation_id': 'U01', 'operation': '\u5206\u6790\u7b97\u6cd5', 'relevance': 'REL', 'standard_ku': 'KU1', 'responsibility': '\u5b66\u751f', 'evidence_refs': [{'message_id': 'M1', 'speaker': 'student'}, {'message_id': 'D1', 'speaker': 'submission'}]}]}, ensure_ascii=False)}]}
    maps, reduces, ownership, stats = derive_unit(FakeTokenizer(), synthetic, 'train')
    assert len(reduces) == 1 and len(ownership) == 1
    assert ownership[0]['map_emission_count'] == 2
    assert sum((row['metadata']['positive'] for row in maps)) == 2
    assert any((not row['metadata']['positive'] for row in maps))
    combined, details = finalize_samples(FakeTokenizer(), maps + reduces)
    assert len(combined) == len(details) and all((item['total_tokens'] > 0 for item in details))
    print(json.dumps({'status': 'PASS', 'self_test': 'E2 derivation helpers and synthetic map/reduce', 'map_samples': len(maps), 'reduce_samples': len(reduces), 'source_blocks': stats['source_blocks']}, ensure_ascii=False))

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', type=Path)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    from transformers import AutoTokenizer
    root = (args.project_root or Path(os.environ.get('PROJECT_ROOT', ''))).resolve()
    if not root.is_dir():
        raise SystemExit('Safety stop: valid PROJECT_ROOT is required')
    source_dir = root / '\u8fd0\u884c\u8f93\u51fa' / 'LoRA\u8bad\u7ec3\u51c6\u5907_v2' / 'B-only_E1'
    sources = {'train': source_dir / 'SFT\u6837\u672c_\u8bad\u7ec3\u96c6_B-only_\u663e\u5b58\u5b89\u516872GiB.jsonl', 'validation': source_dir / 'SFT\u6837\u672c_\u9a8c\u8bc1\u96c6_B-only_\u663e\u5b58\u5b89\u516872GiB.jsonl'}
    model_path = root / '\u6a21\u578b\u6587\u4ef6' / 'Qwen3-4B-Instruct-2507'
    output_dir = root / '\u8fd0\u884c\u8f93\u51fa' / 'LoRA\u8bad\u7ec3\u51c6\u5907_v2' / 'B\u5206\u6bb5E2'
    if output_dir.exists():
        raise SystemExit(f'Safety stop: output directory already exists: {output_dir}')
    for split, path in sources.items():
        if not path.is_file():
            raise SystemExit(f'Safety stop: missing {split} source: {path}')
    tokenizer = AutoTokenizer.from_pretrained(model_path, local_files_only=True)
    print(json.dumps({'event': 'tokenizer_loaded', 'model_path': str(model_path)}, ensure_ascii=False), flush=True)
    output_dir.mkdir(parents=True, exist_ok=False)
    outputs = {}
    split_summaries = {}
    split_unit_ids = {}
    for split in ('train', 'validation'):
        rows, ownership, lengths, summary = derive_split(tokenizer, sources[split], split)
        split_unit_ids[split] = {item['metadata']['unit_id'] for item in rows}
        samples = output_dir / f"SFT\u6837\u672c_{('\u8bad\u7ec3\u96c6' if split == 'train' else '\u9a8c\u8bc1\u96c6')}_B\u5206\u6bb5E2.jsonl"
        ownership_path = output_dir / f'{split}_B\u5206\u6bb5E2\u64cd\u4f5c\u6620\u5c04\u660e\u7ec6.jsonl'
        length_path = output_dir / f'{split}_B\u5206\u6bb5E2\u6837\u672c\u957f\u5ea6\u660e\u7ec6.jsonl'
        manifest_path = output_dir / f"SFT\u6837\u672c_{('\u8bad\u7ec3\u96c6' if split == 'train' else '\u9a8c\u8bc1\u96c6')}_B\u5206\u6bb5E2\u6e05\u5355.json"
        write_jsonl_atomic(samples, rows)
        write_jsonl_atomic(ownership_path, ownership)
        write_jsonl_atomic(length_path, lengths)
        manifest = {'status': 'PASS', 'version': 'lora_b_segmentation_e2_dataset_manifest_v1', 'split': split, 'source': str(sources[split]), 'source_sha256': SOURCE_HASHES[split], 'output_samples': str(samples), 'output_samples_sha256': sha256(samples), 'operation_mapping': str(ownership_path), 'operation_mapping_sha256': sha256(ownership_path), 'length_details': str(length_path), 'length_details_sha256': sha256(length_path), 'summary': summary, 'cross_split_movement': False, 'official_test_used': False}
        write_json_atomic(manifest_path, manifest)
        outputs[split] = {'samples': str(samples), 'samples_sha256': sha256(samples), 'manifest': str(manifest_path), 'manifest_sha256': sha256(manifest_path), 'ownership': str(ownership_path), 'ownership_sha256': sha256(ownership_path), 'lengths': str(length_path), 'lengths_sha256': sha256(length_path)}
        split_summaries[split] = summary
    overlap = split_unit_ids['train'] & split_unit_ids['validation']
    if overlap:
        raise SystemExit(f'Safety stop: E2 train/validation unit overlap: {sorted(overlap)}')
    summary_path = output_dir / 'LoRA_B\u5206\u6bb5E2\u6570\u636e\u6d3e\u751f\u603b\u6e05\u5355.json'
    report = {'status': 'PASS', 'version': 'lora_b_segmentation_e2_derivation_summary_v1', 'experiment': {'id': 'E2', 'name': 'B evidence-block map/reduce segmentation', 'map_negative_policy': 'all validation negatives; deterministic hard negatives up to 1:1 with positive map samples for training', 'question_context_policy': 'first chunk plus input-only lexical-overlap chunks', 'official_test_forbidden': True}, 'constants': {'question_chunk_tokens': QUESTION_CHUNK_TOKENS, 'question_context_tokens_map': QUESTION_CONTEXT_TOKENS_MAP, 'question_context_tokens_reduce': QUESTION_CONTEXT_TOKENS_REDUCE, 'evidence_chunk_tokens': EVIDENCE_CHUNK_TOKENS, 'reduce_evidence_total_tokens': REDUCE_EVIDENCE_TOTAL_TOKENS, 'max_chat_tokens': MAX_CHAT_TOKENS, 'seed': SEED}, 'splits': split_summaries, 'train_validation_unit_overlap': 0, 'outputs': outputs}
    write_json_atomic(summary_path, report)
    print(json.dumps({**report, 'summary': str(summary_path), 'summary_sha256': sha256(summary_path)}, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
