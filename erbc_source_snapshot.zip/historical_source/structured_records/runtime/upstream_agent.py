from __future__ import annotations
import argparse
import copy
import hashlib
import json
import os
import re
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
VERSION = 'abc_e3_adaptive_c_agent_runtime_v3_b_deterministic_contract_rebuild'
CONFIG_VERSION = 'abc_e3_adaptive_c_agent_config_v1'
FROZEN_ROUTED_VALIDATOR_SHA256 = 'f0c05c0e69ed0ad9357477b40538f24fabb56ee658e2af0b8f87c265c0e51589'
FROZEN_ROUTED_CONFIG_SHA256 = 'b4fc9e9dd26ea82cd63e9b44ea2337fd717a0a4ab8564281245f86a898ece5d7'
FORBIDDEN_INPUT_KEYS = {'target', 'gold', 'label', 'labels', 'answer', 'answers', 'expected'}

def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def canonical_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')

def sha256_json(value) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()

def resolve(root: Path, value: str) -> Path:
    value = os.path.expandvars(os.path.expanduser(value))
    path = Path(value)
    return path.resolve() if path.is_absolute() else (root / path).resolve()

def require_file(path: Path, label: str) -> Path:
    if not path.is_file():
        raise SystemExit(f'Safety stop: missing {label}: {path}')
    return path

def require_sha256(path: Path, expected: str, label: str) -> str:
    require_file(path, label)
    actual = sha256_file(path)
    if actual.lower() != expected.lower():
        raise SystemExit(f'Safety stop: {label} SHA256 mismatch: expected={expected}, actual={actual}, path={path}')
    return actual

def atomic_write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(value, ensure_ascii=False, indent=2) + '\n'
    temporary = path.with_name(path.name + f'.tmp.{os.getpid()}')
    with temporary.open('w', encoding='utf-8', newline='\n') as stream:
        stream.write(payload)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)

def append_jsonl(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, separators=(',', ':')) + '\n')
        stream.flush()
        os.fsync(stream.fileno())

def safe_unit_name(unit_id: str) -> str:
    prefix = re.sub('[^0-9A-Za-z_.-]+', '_', unit_id).strip('._')[:80] or 'unit'
    return f"{prefix}__{hashlib.sha256(unit_id.encode('utf-8')).hexdigest()[:12]}"

def read_jsonl(path: Path) -> list[dict]:
    output = []
    seen = set()
    with require_file(path, 'agent input JSONL').open('r', encoding='utf-8') as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError as exc:
                raise SystemExit(f'Safety stop: invalid input JSONL at {path}:{line_number}: {exc}') from exc
            if not isinstance(row, dict):
                raise SystemExit(f'Safety stop: input row is not an object at {path}:{line_number}')
            unit_id = str(row.get('unit_id') or '').strip()
            if not unit_id:
                raise SystemExit(f'Safety stop: missing unit_id at {path}:{line_number}')
            if unit_id in seen:
                raise SystemExit(f'Safety stop: duplicate unit_id in input: {unit_id}')
            seen.add(unit_id)
            output.append(row)
    if not output:
        raise SystemExit(f'Safety stop: no records in input JSONL: {path}')
    return output

def validate_production_row(row: dict, allowed_subjects: set[str]) -> dict:
    forbidden = sorted(FORBIDDEN_INPUT_KEYS.intersection(row))
    if forbidden:
        raise ValueError(f'production input contains forbidden gold/answer keys: {forbidden}')
    allowed_top = {'schema_version', 'task', 'unit_id', 'input', 'metadata'}
    unknown = sorted(set(row) - allowed_top)
    if unknown:
        raise ValueError(f'production input contains unsupported top-level keys: {unknown}')
    unit_id = str(row.get('unit_id') or '').strip()
    if not unit_id:
        raise ValueError('unit_id must be nonempty')
    payload = row.get('input')
    metadata = row.get('metadata')
    if not isinstance(payload, dict) or not isinstance(metadata, dict):
        raise ValueError('input and metadata must be objects')
    subject = str(payload.get('subject') or metadata.get('subject') or '').strip()
    if subject not in allowed_subjects:
        raise ValueError(f'unsupported subject: {subject!r}')
    metadata_subject = str(metadata.get('subject') or subject).strip()
    if metadata_subject != subject:
        raise ValueError(f'input/metadata subject mismatch: {subject!r} != {metadata_subject!r}')
    metadata_unit = str(metadata.get('unit_id') or unit_id).strip()
    if metadata_unit != unit_id:
        raise ValueError(f'unit_id mismatch: top={unit_id!r}, metadata={metadata_unit!r}')
    question = payload.get('question')
    if not isinstance(question, dict):
        raise ValueError('input.question must be an object')
    if not str(question.get('title') or '').strip() and (not str(question.get('text') or '').strip()):
        raise ValueError('input.question requires a nonempty title or text')
    dialogue = payload.get('dialogue')
    if not isinstance(dialogue, list) or not dialogue:
        raise ValueError('input.dialogue must be a nonempty list')
    for index, message in enumerate(dialogue):
        if not isinstance(message, dict):
            raise ValueError(f'input.dialogue[{index}] must be an object')
        if str(message.get('role') or '') not in {'user', 'assistant', 'system', 'tool'}:
            raise ValueError(f"invalid dialogue role at index {index}: {message.get('role')!r}")
        if not isinstance(message.get('content'), str):
            raise ValueError(f'dialogue content must be text at index {index}')
    submission = payload.get('submission')
    if submission is not None and (not isinstance(submission, dict)):
        raise ValueError('input.submission must be an object when supplied')
    normalized = copy.deepcopy(row)
    normalized['schema_version'] = str(row.get('schema_version') or 'agent_pipeline_input_v1')
    normalized['task'] = 'pipeline_agent'
    normalized['unit_id'] = unit_id
    normalized['metadata']['unit_id'] = unit_id
    normalized['metadata']['subject'] = subject
    normalized['metadata']['split'] = 'agent_runtime'
    normalized['input']['subject'] = subject
    normalized['input'].setdefault('submission', {'available': False, 'status': 'not_supplied', 'archive_path': ''})
    return normalized

def make_adapter_row(row: dict, library_path: Path, library_sha256: str) -> dict:
    runtime = copy.deepcopy(row)
    runtime['input']['standard_library_ref'] = str(library_path)
    runtime['metadata']['standard_library_ref'] = str(library_path)
    runtime['metadata']['standard_library_sha256'] = library_sha256
    runtime['target'] = {'blueprint': [], 'operations': [], 'ksa': []}
    return runtime

def issue_codes(record: dict) -> set[str]:
    validation = record.get('schema_validation') or {}
    return {str(issue.get('code')) for issue in validation.get('issues') or [] if isinstance(issue, dict)}
B_CONTRACT_RETRY_CODES = {'RELATION_BLUEPRINT_MISMATCH'}
B_EXTRACT_RETRY_SUFFIX = '\n\n\u8865\u5145\u5408\u540c\uff08\u4ec5\u7528\u4e8e\u4e25\u683c\u6821\u9a8c\u5931\u8d25\u540e\u7684\u5355\u6b21\u91cd\u8bd5\uff09\uff1a\n- \u5fc5\u987b\u628a\u8bc1\u636e\u4e2d\u5f7c\u6b64\u72ec\u7acb\u3001\u53ef\u6838\u9a8c\u7684\u5b66\u4e60\u64cd\u4f5c\u5206\u522b\u62bd\u53d6\uff0c\u7981\u6b62\u628a\u7b97\u6cd5\u9009\u62e9\u3001\u6570\u636e\u7ed3\u6784\u8bbe\u8ba1\u3001\u7f16\u7801\u5b9e\u73b0\u3001\u8c03\u8bd5\u3001\u590d\u6742\u5ea6\u5206\u6790\u548c\u6d4b\u8bd5\u7b3c\u7edf\u5408\u5e76\u4e3a\u4e00\u4e2a\u64cd\u4f5c\u3002\n- \u6bcf\u4e2a\u5019\u9009\u64cd\u4f5c\u53ea\u5f15\u7528\u76f4\u63a5\u652f\u6301\u8be5\u64cd\u4f5c\u7684\u5b66\u751f\u6216 AI \u6d88\u606f\u3002\n'.strip()
B_REDUCE_RETRY_SUFFIX = '\n\n\u8865\u5145\u5408\u540c\uff08\u4ec5\u7528\u4e8e\u4e25\u683c\u6821\u9a8c\u5931\u8d25\u540e\u7684\u5355\u6b21\u91cd\u8bd5\uff09\uff1a\n- relevance \u5fc5\u987b\u7531 mapped_ku_ids \u4e0e confirmed_blueprint \u7684 KU \u4ea4\u96c6\u4e25\u683c\u51b3\u5b9a\uff1a\u5168\u90e8\u5728\u84dd\u56fe\u5185\u4e3a REL\uff0c\u5168\u90e8\u5728\u84dd\u56fe\u5916\u4e3a SUP\uff0c\u5185\u5916\u5747\u6709\u4e3a MIXED\u3002\n- \u7981\u6b62\u8f93\u51fa relevance=SUP \u4f46 mapped_ku_ids \u542b\u84dd\u56fe\u5185 KU\uff0c\u4e5f\u7981\u6b62\u8f93\u51fa relevance=REL \u4f46 mapped_ku_ids \u5168\u5728\u84dd\u56fe\u5916\u3002\n- responsibility \u5fc5\u987b\u53ea\u4f9d\u636e evidence_bundle\uff1a\u4ec5\u5b66\u751f\u5b8c\u6210\u4e3a\u5b66\u751f\uff0c\u4ec5 AI \u5b8c\u6210\u4e3a AI\uff0c\u53cc\u65b9\u90fd\u6709\u5b9e\u8d28\u53c2\u4e0e\u4e3a\u5171\u540c\u3002\n- \u4e0d\u5f97\u628a\u591a\u4e2a\u72ec\u7acb\u64cd\u4f5c\u91cd\u65b0\u5408\u5e76\u6210\u5bbd\u6cdb\u7684\u603b\u62ec\u63cf\u8ff0\u3002\n'.strip()

def should_retry_b_contract(record: dict) -> bool:
    codes = issue_codes(record)
    return bool(record.get('task') == 'B' and (not record.get('strict_gate_pass')) and codes and (codes <= B_CONTRACT_RETRY_CODES) and (not (record.get('candidate_violations') or [])))

def rebuild_b_deterministic_contract(record: dict, context: dict, validator, subject: str) -> dict | None:
    """Rebuild fields that are definitions of existing model choices, never KU/operation content."""
    prediction = copy.deepcopy(record.get('prediction') or {})
    operations = prediction.get('operations')
    if not isinstance(operations, list) or not operations:
        return None
    blueprint_kus = {str(item.get('ku_id') or '').strip() for item in context.get('blueprint') or [] if str(item.get('ku_id') or '').strip()}
    changes = []
    for index, operation in enumerate(operations):
        mapped = {str(value).strip() for value in operation.get('mapped_ku_ids') or [] if str(value).strip()}
        inside = mapped & blueprint_kus
        outside = mapped - blueprint_kus
        expected_relevance = 'MIXED' if inside and outside else 'REL' if inside else 'SUP'
        if operation.get('relevance') != expected_relevance:
            changes.append({'path': f'$.operations[{index}].relevance', 'before': operation.get('relevance'), 'after': expected_relevance, 'rule': 'KU_BLUEPRINT_SET_RELATION'})
            operation['relevance'] = expected_relevance
        speakers = set()
        for ref in operation.get('evidence_refs') or []:
            speaker = str(ref.get('speaker') or '').strip().lower()
            if speaker in {'student', 'user', '\u5b66\u751f'}:
                speakers.add('\u5b66\u751f')
            elif speaker in {'assistant', 'ai', '\u52a9\u624b'}:
                speakers.add('AI')
        expected_responsibility = None
        if speakers == {'\u5b66\u751f', 'AI'}:
            expected_responsibility = '\u5171\u540c'
        elif speakers == {'\u5b66\u751f'}:
            expected_responsibility = '\u5b66\u751f'
        elif speakers == {'AI'}:
            expected_responsibility = 'AI'
        if expected_responsibility is not None:
            shares = {'AI': (1.0, 0.0), '\u5171\u540c': (0.5, 0.5), '\u5b66\u751f': (0.0, 1.0)}
            ai_share, student_share = shares[expected_responsibility]
            before = {'responsibility': operation.get('responsibility'), 'ai_share': operation.get('ai_share'), 'student_share': operation.get('student_share')}
            after = {'responsibility': expected_responsibility, 'ai_share': ai_share, 'student_share': student_share}
            if before != after:
                changes.append({'path': f'$.operations[{index}].responsibility_contract', 'before': before, 'after': after, 'rule': 'CITED_SPEAKER_SET_RESPONSIBILITY'})
                operation.update(after)
    if not changes:
        return None
    validation = validator.validate('B', subject, prediction, context)
    if not validation.get('valid') or (record.get('candidate_violations') or []):
        return None
    rebuilt = copy.deepcopy(record)
    rebuilt.update({'status': 'PASS', 'strict_json_valid': True, 'strict_gate_pass': True, 'schema_validation': validation, 'prediction': prediction, 'raw_output_internal': json.dumps(prediction, ensure_ascii=False), 'b_contract_reconstruction': {'applied': True, 'policy': 'DETERMINISTIC_FROM_MODEL_KU_AND_CITED_SPEAKERS', 'changes': changes, 'operation_text_and_ku_ids_unchanged': True}})
    return rebuilt

def should_retry_c_truncation(record: dict) -> bool:
    attempt_tokens = [int(attempt.get('output_tokens', 0)) for attempt in record.get('attempts') or [] if isinstance(attempt, dict)]
    return bool(record.get('task') == 'C' and (not bool(record.get('strict_json_valid'))) and ('INVALID_JSON' in issue_codes(record)) and (max(attempt_tokens, default=0) == 6144))

def sanitize_record(record: dict, *, run_id: str, input_sha256: str, config_sha256: str) -> dict:
    output = copy.deepcopy(record)
    output.pop('gold', None)
    output['mode'] = 'agent_pipeline'
    output['run_id'] = run_id
    output['input_sha256'] = input_sha256
    output['agent_config_sha256'] = config_sha256
    output['agent_runtime_version'] = VERSION
    return output

def operation_relief(prediction: dict | None) -> dict | None:
    operations = (prediction or {}).get('operations')
    if not isinstance(operations, list) or not operations:
        return None
    shares = [float(item.get('ai_share', 0.0)) for item in operations]
    return {'operation_count': len(shares), 'ai_mass': sum(shares), 'rate': sum(shares) / len(shares)}

def cognitive_outsourcing(prediction: dict | None) -> dict | None:
    ksa = (prediction or {}).get('ksa')
    if not isinstance(ksa, list) or not ksa:
        return None
    shares = [float(item.get('ai_share', 0.0)) for item in ksa]
    return {'ksa_count': len(shares), 'ai_mass': sum(shares), 'rate': sum(shares) / len(shares)}

def verify_model_provenance(root: Path, config_path: Path, config: dict, routed) -> dict:
    if config.get('version') != CONFIG_VERSION:
        raise SystemExit(f"Safety stop: unsupported agent config version: {config.get('version')}")
    own_expected = str(config['provenance_sha256']['agent_runtime'])
    require_sha256(Path(__file__).resolve(), own_expected, 'agent runtime')
    source_config_path = resolve(root, config['frozen_routed_config'])
    source_validator_path = resolve(root, config['frozen_routed_validator'])
    require_sha256(source_config_path, FROZEN_ROUTED_CONFIG_SHA256, 'frozen routed config')
    require_sha256(source_validator_path, FROZEN_ROUTED_VALIDATOR_SHA256, 'frozen routed validator')
    if str(config['provenance_sha256'].get('frozen_routed_config', '')).lower() != FROZEN_ROUTED_CONFIG_SHA256:
        raise SystemExit('Safety stop: agent config frozen-routed-config provenance drift')
    if str(config['provenance_sha256'].get('frozen_routed_validator', '')).lower() != FROZEN_ROUTED_VALIDATOR_SHA256:
        raise SystemExit('Safety stop: agent config frozen-routed-validator provenance drift')
    base = json.loads(source_config_path.read_text(encoding='utf-8'))
    if base.get('adapter_routing') != {'A': 'ABC', 'B': 'E3', 'C': 'ABC'}:
        raise SystemExit('Safety stop: frozen adapter routing drift')
    if int(base.get('generation', {}).get('max_new_tokens', {}).get('C', -1)) != 6144:
        raise SystemExit('Safety stop: frozen initial C budget is not 6144')
    if int(config.get('adaptive_c', {}).get('retry_max_new_tokens', -1)) != 12288:
        raise SystemExit('Safety stop: adaptive C retry budget is not 12288')
    expected = config['provenance_sha256']
    prior = config['retrieval_prior_provenance']
    prior_path = resolve(root, prior['source'])
    require_sha256(prior_path, prior['source_sha256'], 'training-only retrieval-prior data')
    if prior_path.name.lower() in {'validation.jsonl', 'test.jsonl'}:
        raise SystemExit('Safety stop: runtime retrieval priors cannot come from validation/test data')
    dependency_actual = {}
    for relative, expected_hash in config['runtime_dependency_sha256'].items():
        dependency_actual[relative] = require_sha256(root / relative, expected_hash, f'frozen runtime dependency {relative}')
    abc_adapter = resolve(root, base['adapter_path'])
    e3_adapter = resolve(root, base['e3_adapter_path'])
    abc_summary = resolve(root, base['training_summary_path'])
    e3_summary = resolve(root, base['e3_training_summary_path'])
    actual = {'agent_runtime': own_expected, 'frozen_routed_config': sha256_file(source_config_path), 'frozen_routed_validator': sha256_file(source_validator_path), 'abc_adapter_model': routed.require_sha256(abc_adapter / 'adapter_model.safetensors', expected['abc_adapter_model'], 'ABC adapter model'), 'abc_adapter_config': routed.require_sha256(abc_adapter / 'adapter_config.json', expected['abc_adapter_config'], 'ABC adapter config'), 'abc_training_summary': routed.require_sha256(abc_summary, expected['abc_training_summary'], 'ABC training summary'), 'e3_adapter_model': routed.require_sha256(e3_adapter / 'adapter_model.safetensors', expected['e3_adapter_model'], 'E3 adapter model'), 'e3_adapter_config': routed.require_sha256(e3_adapter / 'adapter_config.json', expected['e3_adapter_config'], 'E3 adapter config'), 'e3_training_summary': routed.require_sha256(e3_summary, expected['e3_training_summary'], 'E3 training summary')}
    for key in ('abc_adapter_model', 'abc_adapter_config', 'abc_training_summary', 'e3_adapter_model', 'e3_adapter_config', 'e3_training_summary'):
        if actual[key].lower() != str(expected[key]).lower():
            raise SystemExit(f'Safety stop: provenance mismatch for {key}')
    return {'status': 'PASS', 'config': str(config_path), 'config_sha256': sha256_file(config_path), 'source_config': str(source_config_path), 'source_validator': str(source_validator_path), 'training_prior_data': str(prior_path), 'abc_adapter': str(abc_adapter), 'e3_adapter': str(e3_adapter), 'runtime_dependency_sha256': dependency_actual, 'verified_sha256': actual, 'base_config': base}

class AgentRuntime:

    def __init__(self, config_path: Path, *, preflight_only: bool=False):
        self.config_path = config_path.resolve()
        self.root = self.config_path.parent
        self.config = json.loads(self.config_path.read_text(encoding='utf-8'))
        routed_path = resolve(self.root, self.config['frozen_routed_validator'])
        require_sha256(routed_path, FROZEN_ROUTED_VALIDATOR_SHA256, 'frozen routed validator')
        import importlib.util
        import sys
        spec = importlib.util.spec_from_file_location('frozen_abc_e3_routed_runtime', routed_path)
        if spec is None or spec.loader is None:
            raise RuntimeError(f'cannot load frozen routed module: {routed_path}')
        self.routed = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = self.routed
        spec.loader.exec_module(self.routed)
        self.preflight = verify_model_provenance(self.root, self.config_path, self.config, self.routed)
        self.base = self.preflight.pop('base_config')
        self.config_sha256 = self.preflight['config_sha256']
        if preflight_only:
            return
        torch = self.routed.torch
        if not torch.cuda.is_available():
            raise SystemExit('Safety stop: CUDA is required for agent inference')
        device_index = int(os.environ.get('LOCAL_RANK', '0'))
        torch.cuda.set_device(device_index)
        self.device = torch.device(f'cuda:{device_index}')
        if bool(self.base.get('runtime', {}).get('disable_cudnn_sdpa', True)):
            torch.backends.cuda.enable_cudnn_sdp(False)
        seed = int(self.base['seed'])
        torch.manual_seed(seed)
        dep = self.root / '\u4f9d\u8d56'
        schema_root = dep / '\u4e25\u683cSchema\u4e0e\u6821\u9a8c'
        self.adapter = self.routed.load_module('agent_frozen_adapter', dep / 'record_adapter.py')
        self.validator = self.routed.load_module('agent_frozen_validator', schema_root / 'validate_records.py')
        stage1 = self.routed.load_module('agent_frozen_lexical', dep / 'lexical_retrieval.py')
        stage2 = self.routed.load_module('agent_frozen_semantic', dep / 'semantic_retrieval.py')
        self.smoke = self.routed.load_module('agent_frozen_prompt_helpers', dep / 'prompt_generation.py')
        e2_path = self.root / 'operation_segments.py'
        e3_path = self.root / 'operation_gate_extract.py'
        self.routed.require_sha256(e2_path, self.base['provenance_sha256']['e2_deriver'], 'frozen E2 helpers')
        self.routed.require_sha256(e3_path, self.base['provenance_sha256']['e3_deriver'], 'frozen E3 helpers')
        self.routed.E2_HELPERS = self.routed.load_module('agent_e2_helpers', e2_path)
        self.routed.E3_HELPERS = self.routed.load_module('agent_e3_helpers', e3_path)
        self.routed.E2_SMOKE = self.smoke
        self.libraries = {subject: resolve(self.root, value) for subject, value in self.base['library_paths'].items()}
        self.library_sha256 = {subject: sha256_file(path) for subject, path in self.libraries.items()}
        self.validator.LIBRARIES = self.libraries
        self.validator.SCHEMAS = {task: schema_root / name for task, name in {'A': 'blueprint.schema.json', 'B': 'operation.schema.json', 'C': 'cognitive_unit.schema.json'}.items()}
        self.validator.load_library.cache_clear()
        self.validator.schema_validator.cache_clear()
        self.smoke.SCHEMA_ROOT = schema_root
        stage1.LIBRARIES = self.libraries
        embedder = stage2.Embedder(resolve(self.root, self.base['embedding_model_path']))
        self.retrievers = {subject: stage2.HybridRetriever(stage1, subject, stage1.load_library(subject, path), embedder) for subject, path in self.libraries.items()}
        self.tokenizer = self.routed.AutoTokenizer.from_pretrained(resolve(self.root, self.base['model_path']), local_files_only=True)
        base_model = self.routed.AutoModelForCausalLM.from_pretrained(resolve(self.root, self.base['model_path']), local_files_only=True, dtype=torch.bfloat16, attn_implementation='sdpa')
        self.model = self.routed.PeftModel.from_pretrained(base_model, resolve(self.root, self.base['adapter_path']), adapter_name='abc', is_trainable=False)
        self.model.load_adapter(resolve(self.root, self.base['e3_adapter_path']), adapter_name='e3', is_trainable=False)
        self.model.set_adapter('abc')
        self.model = self.model.to(self.device).eval()
        self.retrieval_args = dict(self.base['retrieval'])
        self.retrieval_args.pop('prior_topic_k', None)
        self.topic_priors = self.config['retrieval_topic_priors']

    def candidates(self, task: str, strict_row: dict, context: dict) -> dict:
        subject = strict_row['subject']
        query = self.routed.retrieval_query(task, strict_row, context)
        return self.routed.compact_candidates(self.retrievers[subject].retrieve(query, prior_topic_ids=self.topic_priors.get(subject, []), **self.retrieval_args))

    def process_unit(self, row: dict, *, run_id: str, run_dir: Path) -> dict:
        normalized = validate_production_row(row, set(self.libraries))
        unit_id = normalized['unit_id']
        subject = normalized['input']['subject']
        input_hash = sha256_json(normalized)
        unit_dir = run_dir / 'units' / safe_unit_name(unit_id)
        result_path = unit_dir / 'result.json'
        input_audit_path = unit_dir / 'input_audit.json'
        if not input_audit_path.exists():
            atomic_write_json(input_audit_path, {'version': 'agent_normalized_input_audit_v1', 'run_id': run_id, 'unit_id': unit_id, 'subject': subject, 'input_sha256': input_hash, 'question': normalized['input']['question'], 'dialogue': normalized['input']['dialogue'], 'dialogue_count': len(normalized['input']['dialogue']), 'created_at': utc_now()})
        if result_path.exists():
            existing = json.loads(result_path.read_text(encoding='utf-8'))
            if existing.get('input_sha256') != input_hash or existing.get('agent_config_sha256') != self.config_sha256:
                raise SystemExit(f'Safety stop: resume fingerprint conflict for unit_id={unit_id}')
            return existing
        runtime_row = make_adapter_row(normalized, self.libraries[subject], self.library_sha256[subject])
        strict_row = self.adapter.adapt_row(runtime_row)
        strict_row['question'] = self.smoke.question_text(runtime_row)
        sources = self.routed.valid_source_ids(strict_row)
        context = {'blueprint': [], 'operations': [], 'valid_message_ids': sources}
        records = {}
        upstream_ok = True
        previous = ''
        event_path = run_dir / 'events.jsonl'
        append_jsonl(event_path, {'event': 'UNIT_STARTED', 'time': utc_now(), 'run_id': run_id, 'unit_id': unit_id, 'subject': subject, 'input_sha256': input_hash})
        for task in 'ABC':
            started = time.time()
            if not upstream_ok:
                record = self.routed.blocked_record(runtime_row, strict_row, 'end_to_end_pipeline', task, previous)
            else:
                candidates = self.candidates(task, strict_row, context)
                record = self.routed.run_generation(task=task, mode='end_to_end_pipeline', row=runtime_row, strict_row=strict_row, context=context, candidates=candidates, model=self.model, tokenizer=self.tokenizer, validator=self.validator, smoke=self.smoke, config=self.base, device=self.device)
                if task == 'B' and should_retry_b_contract(record):
                    initial = copy.deepcopy(record)
                    initial_clean = sanitize_record(initial, run_id=run_id, input_sha256=input_hash, config_sha256=self.config_sha256)
                    atomic_write_json(unit_dir / 'B_initial_contract_failure.json', initial_clean)
                    original_extract_system = self.routed.E3_HELPERS.EXTRACT_SYSTEM
                    original_reduce_system = self.routed.E2_HELPERS.REDUCE_SYSTEM
                    try:
                        self.routed.E3_HELPERS.EXTRACT_SYSTEM = original_extract_system.rstrip() + '\n\n' + B_EXTRACT_RETRY_SUFFIX
                        self.routed.E2_HELPERS.REDUCE_SYSTEM = original_reduce_system.rstrip() + '\n\n' + B_REDUCE_RETRY_SUFFIX
                        retry = self.routed.run_generation(task=task, mode='end_to_end_pipeline', row=runtime_row, strict_row=strict_row, context=context, candidates=candidates, model=self.model, tokenizer=self.tokenizer, validator=self.validator, smoke=self.smoke, config=self.base, device=self.device)
                    finally:
                        self.routed.E3_HELPERS.EXTRACT_SYSTEM = original_extract_system
                        self.routed.E2_HELPERS.REDUCE_SYSTEM = original_reduce_system
                    retry_clean = sanitize_record(retry, run_id=run_id, input_sha256=input_hash, config_sha256=self.config_sha256)
                    atomic_write_json(unit_dir / 'B_contract_retry_candidate.json', retry_clean)
                    retry_meta = {'triggered': True, 'rule': 'RELATION_BLUEPRINT_MISMATCH_ONLY', 'initial_status': initial.get('status'), 'initial_issue_codes': sorted(issue_codes(initial)), 'retry_status': retry.get('status'), 'retry_issue_codes': sorted(issue_codes(retry)), 'accepted': bool(retry.get('strict_gate_pass'))}
                    if retry.get('strict_gate_pass'):
                        record = retry
                    else:
                        rebuild_source = retry if should_retry_b_contract(retry) else initial if should_retry_b_contract(initial) else None
                        rebuilt = rebuild_b_deterministic_contract(rebuild_source, context, self.validator, subject) if rebuild_source is not None else None
                        if rebuilt is not None:
                            record = rebuilt
                            retry_meta['deterministic_reconstruction_applied'] = True
                            retry_meta['deterministic_reconstruction_source'] = 'retry' if rebuild_source is retry else 'initial'
                            retry_meta['accepted'] = True
                            rebuilt_clean = sanitize_record(rebuilt, run_id=run_id, input_sha256=input_hash, config_sha256=self.config_sha256)
                            atomic_write_json(unit_dir / 'B_deterministic_contract_rebuild.json', rebuilt_clean)
                        else:
                            record = initial
                            retry_meta['deterministic_reconstruction_applied'] = False
                    record['b_contract_retry'] = retry_meta
                elif task == 'B':
                    record['b_contract_retry'] = {'triggered': False, 'rule': 'RELATION_BLUEPRINT_MISMATCH_ONLY'}
                if task == 'C' and should_retry_c_truncation(record):
                    initial = copy.deepcopy(record)
                    initial_clean = sanitize_record(initial, run_id=run_id, input_sha256=input_hash, config_sha256=self.config_sha256)
                    atomic_write_json(unit_dir / 'C_initial_6144.json', initial_clean)
                    retry_config = copy.deepcopy(self.base)
                    retry_config['generation']['max_new_tokens']['C'] = int(self.config['adaptive_c']['retry_max_new_tokens'])
                    record = self.routed.run_generation(task=task, mode='end_to_end_pipeline', row=runtime_row, strict_row=strict_row, context=context, candidates=candidates, model=self.model, tokenizer=self.tokenizer, validator=self.validator, smoke=self.smoke, config=retry_config, device=self.device)
                    record['adaptive_retry'] = {'triggered': True, 'rule': 'INVALID_JSON_AND_OUTPUT_CAP_6144', 'initial_status': initial.get('status'), 'initial_issue_codes': sorted(issue_codes(initial)), 'initial_attempts': initial.get('attempts', []), 'retry_max_new_tokens': int(self.config['adaptive_c']['retry_max_new_tokens'])}
                elif task == 'C':
                    record['adaptive_retry'] = {'triggered': False, 'rule': 'INVALID_JSON_AND_OUTPUT_CAP_6144'}
            clean = sanitize_record(record, run_id=run_id, input_sha256=input_hash, config_sha256=self.config_sha256)
            records[task] = clean
            stage_path = unit_dir / f'{task}.json'
            atomic_write_json(stage_path, clean)
            append_jsonl(event_path, {'event': 'STAGE_FINISHED', 'time': utc_now(), 'run_id': run_id, 'unit_id': unit_id, 'task': task, 'status': clean.get('status'), 'strict_gate_pass': bool(clean.get('strict_gate_pass')), 'duration_seconds': time.time() - started, 'stage_output': str(stage_path), 'stage_sha256': sha256_file(stage_path), 'adaptive_retry': bool((clean.get('adaptive_retry') or {}).get('triggered')), 'b_contract_retry': bool((clean.get('b_contract_retry') or {}).get('triggered')), 'b_contract_reconstruction': bool((clean.get('b_contract_reconstruction') or {}).get('applied'))})
            upstream_ok = bool(clean.get('strict_gate_pass'))
            if upstream_ok and task == 'A':
                context['blueprint'] = clean['prediction']['blueprint']
            elif upstream_ok and task == 'B':
                context['operations'] = clean['prediction']['operations']
            previous = task
        complete = all((bool(records[task].get('strict_gate_pass')) for task in 'ABC'))
        review = [{'task': task, 'status': records[task].get('status'), 'issues': (records[task].get('schema_validation') or {}).get('issues', [])} for task in 'ABC' if not bool(records[task].get('strict_gate_pass'))]
        result = {'version': VERSION, 'run_id': run_id, 'unit_id': unit_id, 'subject': subject, 'status': 'COMPLETED' if complete else 'REVIEW_REQUIRED', 'input_sha256': input_hash, 'agent_config_sha256': self.config_sha256, 'routing': {'A': 'ABC', 'B': 'E3_GATE_EXTRACT_REDUCE', 'C': 'ABC'}, 'operation_relief': operation_relief(records['B'].get('prediction') or {}) if records['B'].get('strict_gate_pass') else None, 'cognitive_outsourcing': cognitive_outsourcing(records['C'].get('prediction') or {}) if records['C'].get('strict_gate_pass') else None, 'metric_availability': {'operation_relief': {'available': bool(records['B'].get('strict_gate_pass')), 'reason': '' if records['B'].get('strict_gate_pass') else 'B\u7ed3\u679c\u672a\u901a\u8fc7\u4e25\u683c\u95e8\u63a7\uff0c\u7981\u6b62\u8ba1\u7b97\u64cd\u4f5c\u51cf\u8d1f\u7387'}, 'cognitive_outsourcing': {'available': bool(records['C'].get('strict_gate_pass')), 'reason': '' if records['C'].get('strict_gate_pass') else 'C\u7ed3\u679c\u672a\u901a\u8fc7\u4e25\u683c\u95e8\u63a7\u6216\u88ab\u4e0a\u6e38\u963b\u65ad\uff0c\u7981\u6b62\u8ba1\u7b97\u77e5\u8bc6\u5916\u5305\u6307\u6807'}}, 'input_audit': {'path': str(input_audit_path), 'sha256': sha256_file(input_audit_path), 'dialogue_count': len(normalized['input']['dialogue'])}, 'review_reasons': review, 'results': records, 'completed_at': utc_now()}
        atomic_write_json(result_path, result)
        append_jsonl(event_path, {'event': 'UNIT_FINISHED', 'time': utc_now(), 'run_id': run_id, 'unit_id': unit_id, 'status': result['status'], 'result': str(result_path), 'result_sha256': sha256_file(result_path)})
        if not complete:
            append_jsonl(run_dir / 'review_queue.jsonl', {'run_id': run_id, 'unit_id': unit_id, 'subject': subject, 'input_sha256': input_hash, 'result': str(result_path), 'review_reasons': review, 'created_at': utc_now()})
        return result

def self_test() -> None:
    row = {'schema_version': 'agent_pipeline_input_v1', 'task': 'pipeline_agent', 'unit_id': 'SELFTEST-001', 'input': {'subject': '01_\u8ba1\u7b97\u673a\u79d1\u5b66', 'question': {'title': '\u6d4b\u8bd5', 'text': '\u6d4b\u8bd5\u9898\u76ee'}, 'dialogue': [{'turn': 1, 'role': 'user', 'content': '\u8bf7\u89e3\u91ca\u3002'}, {'turn': 2, 'role': 'assistant', 'content': '\u8fd9\u662f\u56de\u7b54\u3002'}], 'submission': {'available': False, 'status': 'not_supplied', 'archive_path': ''}}, 'metadata': {'unit_id': 'SELFTEST-001', 'subject': '01_\u8ba1\u7b97\u673a\u79d1\u5b66'}}
    normalized = validate_production_row(row, {'01_\u8ba1\u7b97\u673a\u79d1\u5b66'})
    assert 'target' not in normalized
    forbidden = copy.deepcopy(row)
    forbidden['target'] = {'blueprint': []}
    try:
        validate_production_row(forbidden, {'01_\u8ba1\u7b97\u673a\u79d1\u5b66'})
        raise AssertionError('forbidden target was accepted')
    except ValueError:
        pass
    truncation = {'task': 'C', 'strict_json_valid': False, 'schema_validation': {'issues': [{'code': 'INVALID_JSON'}]}, 'attempts': [{'output_tokens': 6144}]}
    assert should_retry_c_truncation(truncation)
    truncation['attempts'][0]['output_tokens'] = 6000
    assert not should_retry_c_truncation(truncation)
    b_relation_failure = {'task': 'B', 'strict_gate_pass': False, 'candidate_violations': [], 'schema_validation': {'issues': [{'code': 'RELATION_BLUEPRINT_MISMATCH'}]}}
    assert should_retry_b_contract(b_relation_failure)
    b_relation_failure['schema_validation']['issues'].append({'code': 'RESPONSIBILITY_EVIDENCE_MISMATCH'})
    assert not should_retry_b_contract(b_relation_failure)

    class _AcceptingValidator:

        @staticmethod
        def validate(task, subject, prediction, context):
            assert task == 'B' and subject == '01_\u8ba1\u7b97\u673a\u79d1\u5b66'
            return {'valid': True, 'issues': []}
    rebuild_source = {'task': 'B', 'status': 'REVIEW_REQUIRED', 'strict_gate_pass': False, 'candidate_violations': [], 'schema_validation': {'issues': [{'code': 'RELATION_BLUEPRINT_MISMATCH'}]}, 'prediction': {'operations': [{'operation_id': 'U01', 'operation': '\u641c\u7d22\u5e76\u5b9e\u73b0\u6700\u77ed\u8def\u5f84', 'mapped_ku_ids': ['AI-Search', 'AL-Fundamental'], 'relevance': 'SUP', 'responsibility': 'AI', 'ai_share': 1.0, 'student_share': 0.0, 'evidence_refs': [{'message_id': 'm1', 'speaker': 'student', 'turn': 1}, {'message_id': 'm2', 'speaker': 'assistant', 'turn': 2}]}]}}
    rebuilt = rebuild_b_deterministic_contract(rebuild_source, {'blueprint': [{'ku_id': 'AL-Fundamental'}]}, _AcceptingValidator(), '01_\u8ba1\u7b97\u673a\u79d1\u5b66')
    assert rebuilt is not None and rebuilt['strict_gate_pass']
    rebuilt_operation = rebuilt['prediction']['operations'][0]
    assert rebuilt_operation['relevance'] == 'MIXED'
    assert rebuilt_operation['responsibility'] == '\u5171\u540c'
    assert rebuilt_operation['ai_share'] == 0.5
    assert rebuilt_operation['student_share'] == 0.5
    assert rebuilt_operation['operation'] == '\u641c\u7d22\u5e76\u5b9e\u73b0\u6700\u77ed\u8def\u5f84'
    assert rebuilt_operation['mapped_ku_ids'] == ['AI-Search', 'AL-Fundamental']
    path = Path(__file__).resolve().parent / f'.agent_atomic_selftest_{os.getpid()}.json'
    try:
        atomic_write_json(path, {'ok': True})
        assert json.loads(path.read_text(encoding='utf-8')) == {'ok': True}
    finally:
        path.unlink(missing_ok=True)
    print(json.dumps({'status': 'PASS', 'version': VERSION, 'tests': ['gold-free input accepted', 'gold-bearing input rejected', 'C truncation retry gate', 'B relation-contract retry gate', 'B deterministic relation/responsibility contract reconstruction', 'atomic JSON persistence']}, ensure_ascii=False))

def main() -> None:
    parser = argparse.ArgumentParser(description='ABC/E3 routed production agent with adaptive C retry')
    parser.add_argument('--config', type=Path)
    parser.add_argument('--input-jsonl', type=Path)
    parser.add_argument('--run-dir', type=Path)
    parser.add_argument('--run-id', default='')
    parser.add_argument('--limit', type=int, default=0)
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.config is None:
        raise SystemExit('Safety stop: --config is required')
    runtime = AgentRuntime(args.config, preflight_only=args.preflight_only)
    if args.preflight_only:
        print(json.dumps(runtime.preflight, ensure_ascii=False, indent=2))
        return
    if args.input_jsonl is None or args.run_dir is None:
        raise SystemExit('Safety stop: --input-jsonl and --run-dir are required')
    if args.limit < 0:
        raise SystemExit('Safety stop: --limit must be non-negative')
    rows = read_jsonl(args.input_jsonl.resolve())
    if args.limit:
        rows = rows[:args.limit]
    run_dir = args.run_dir.resolve()
    manifest_path = run_dir / 'run_manifest.json'
    input_sha = sha256_file(args.input_jsonl.resolve())
    if manifest_path.exists():
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        run_id = args.run_id.strip() or str(manifest.get('run_id') or '')
        if not run_id or manifest.get('run_id') != run_id or manifest.get('input_file_sha256') != input_sha or (manifest.get('agent_config_sha256') != runtime.config_sha256):
            raise SystemExit('Safety stop: run resume manifest conflict')
    else:
        run_id = args.run_id.strip() or f"agent-{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"
        atomic_write_json(manifest_path, {'version': VERSION, 'run_id': run_id, 'created_at': utc_now(), 'input_file': str(args.input_jsonl.resolve()), 'input_file_sha256': input_sha, 'record_count': len(rows), 'agent_config': str(runtime.config_path), 'agent_config_sha256': runtime.config_sha256, 'routing': {'A': 'ABC', 'B': 'E3_GATE_EXTRACT_REDUCE', 'C': 'ABC'}, 'adaptive_c': runtime.config['adaptive_c'], 'official_test_forbidden': True})
    counts = Counter()
    for row in rows:
        result = runtime.process_unit(row, run_id=run_id, run_dir=run_dir)
        counts[result['status']] += 1
        print(json.dumps({'event': 'agent_progress', 'run_id': run_id, 'completed': sum(counts.values()), 'total': len(rows), 'unit_id': result['unit_id'], 'status': result['status']}, ensure_ascii=False), flush=True)
    summary = {'status': 'PASS', 'version': VERSION, 'run_id': run_id, 'records': len(rows), 'status_counts': dict(counts), 'run_dir': str(run_dir), 'completed_at': utc_now()}
    atomic_write_json(run_dir / 'run_summary.json', summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
