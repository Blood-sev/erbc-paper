from __future__ import annotations
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import random
import sys
import time
from collections import Counter, defaultdict
from pathlib import Path
import torch
from peft import PeftModel
from transformers import AutoModelForCausalLM, AutoTokenizer

def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'cannot load module: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def resolve(root: Path, value: str) -> Path:
    value = os.path.expandvars(os.path.expanduser(value))
    path = Path(value)
    return path if path.is_absolute() else (root / path).resolve()

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def require_sha256(path: Path, expected: str, label: str) -> str:
    if not path.is_file():
        raise SystemExit(f'Safety stop: missing {label}: {path}')
    actual = sha256_file(path)
    if actual.lower() != expected.lower():
        raise SystemExit(f'Safety stop: {label} SHA256 mismatch: expected={expected}, actual={actual}, path={path}')
    return actual

def validate_lora_provenance(root: Path, config_path: Path, config: dict) -> dict:
    if config.get('version') != 'h100_abc_e3_routed_formal_validation_inference_v1':
        raise SystemExit(f"Safety stop: unsupported configuration version: {config.get('version')}")
    if config.get('data_split') != 'validation':
        raise SystemExit('Safety stop: this program is locked to data_split=validation')
    scope = config.get('evaluation_scope') or {}
    if scope.get('modes') != ['taskwise_gold_context', 'end_to_end_pipeline'] or scope.get('tasks') != ['A', 'B', 'C']:
        raise SystemExit('Safety stop: routed ABC validation scope must cover frozen taskwise and pipeline ABC')
    data_path = resolve(root, config['test_data'])
    if data_path.name != 'validation.jsonl':
        raise SystemExit(f'Safety stop: expected validation.jsonl, got {data_path}')
    if not data_path.is_file():
        raise SystemExit(f'Safety stop: validation data not found: {data_path}')
    output_dir = resolve(root, config['output_dir'])
    forbidden_output_dir = resolve(root, config['safety']['forbidden_baseline_output_dir'])
    if output_dir == forbidden_output_dir:
        raise SystemExit('Safety stop: LoRA output directory must not equal the frozen baseline directory')
    if '\u6d4b\u8bd5\u96c6' in str(output_dir) or 'test' in output_dir.name.lower():
        raise SystemExit(f'Safety stop: test-like output path is forbidden in validation phase: {output_dir}')
    adapter_dir = resolve(root, config['adapter_path'])
    adapter_model = adapter_dir / 'adapter_model.safetensors'
    adapter_config_path = adapter_dir / 'adapter_config.json'
    training_summary_path = resolve(root, config['training_summary_path'])
    baseline_reference_path = resolve(root, config['baseline_reference_config'])
    expected_hashes = config['provenance_sha256']
    actual_hashes = {'adapter_model': require_sha256(adapter_model, expected_hashes['adapter_model'], 'final LoRA adapter model'), 'adapter_config': require_sha256(adapter_config_path, expected_hashes['adapter_config'], 'final LoRA adapter config'), 'training_summary': require_sha256(training_summary_path, expected_hashes['training_summary'], 'formal training summary'), 'validation_data': require_sha256(data_path, expected_hashes['validation_data'], 'frozen validation data'), 'baseline_reference_config': require_sha256(baseline_reference_path, expected_hashes['baseline_reference_config'], 'frozen baseline reference config')}
    baseline_config = json.loads(baseline_reference_path.read_text(encoding='utf-8'))
    invariant_keys = ['model_id', 'model_path', 'embedding_model_id', 'embedding_model_path', 'test_data', 'eligibility_manifest', 'input_length_scan', 'library_paths', 'evaluation_modes', 'generation', 'retrieval', 'scoring', 'seed', 'schema_policy_version', 'standard_library_manifest', 'retrieval_prior_data', 'data_split', 'engineering_smoke_excluded_unit_ids']
    differences = {key: {'baseline': baseline_config.get(key), 'lora': config.get(key)} for key in invariant_keys if baseline_config.get(key) != config.get(key)}
    if baseline_config.get('runtime', {}).get('disable_cudnn_sdpa') != config.get('runtime', {}).get('disable_cudnn_sdpa'):
        differences['runtime.disable_cudnn_sdpa'] = {'baseline': baseline_config.get('runtime', {}).get('disable_cudnn_sdpa'), 'lora': config.get('runtime', {}).get('disable_cudnn_sdpa')}
    if differences:
        raise SystemExit('Safety stop: LoRA validation protocol drifted from the frozen baseline: ' + json.dumps(differences, ensure_ascii=False))
    adapter_config = json.loads(adapter_config_path.read_text(encoding='utf-8'))
    expected_adapter = config['expected_adapter']
    checks = {'peft_type': adapter_config.get('peft_type'), 'task_type': adapter_config.get('task_type'), 'r': adapter_config.get('r'), 'lora_alpha': adapter_config.get('lora_alpha'), 'lora_dropout': adapter_config.get('lora_dropout'), 'target_modules': sorted(adapter_config.get('target_modules') or [])}
    expected_checks = {'peft_type': expected_adapter['peft_type'], 'task_type': expected_adapter['task_type'], 'r': expected_adapter['r'], 'lora_alpha': expected_adapter['lora_alpha'], 'lora_dropout': expected_adapter['lora_dropout'], 'target_modules': sorted(expected_adapter['target_modules'])}
    if checks != expected_checks:
        raise SystemExit('Safety stop: final adapter configuration differs from the frozen expectation: ' + json.dumps({'expected': expected_checks, 'actual': checks}, ensure_ascii=False))
    training_summary = json.loads(training_summary_path.read_text(encoding='utf-8'))
    if training_summary.get('status') != 'PASS':
        raise SystemExit('Safety stop: formal training summary status is not PASS')
    if int(training_summary.get('world_size', -1)) != int(config['training_provenance']['world_size']):
        raise SystemExit('Safety stop: formal training world_size differs from the frozen provenance')
    if int(training_summary.get('optimizer_steps', -1)) != int(config['training_provenance']['optimizer_steps']):
        raise SystemExit('Safety stop: optimizer step count differs from the frozen provenance')
    summary_adapter = Path(training_summary.get('final_adapter', '')).resolve()
    if summary_adapter != adapter_dir.resolve():
        raise SystemExit(f'Safety stop: training summary final_adapter={summary_adapter} does not match {adapter_dir.resolve()}')
    return {'status': 'PASS', 'program_version': config['version'], 'config': str(config_path), 'config_sha256': sha256_file(config_path), 'data_split': config['data_split'], 'validation_data': str(data_path), 'adapter_path': str(adapter_dir), 'training_summary': str(training_summary_path), 'baseline_reference_config': str(baseline_reference_path), 'verified_sha256': actual_hashes, 'expected_adapter': expected_checks, 'training_provenance': config['training_provenance'], 'configured_output_dir': str(output_dir), 'forbidden_baseline_output_dir': str(forbidden_output_dir)}

def validate_e3_adapter(root: Path, config: dict) -> dict:
    adapter_dir = resolve(root, config['e3_adapter_path'])
    summary_path = resolve(root, config['e3_training_summary_path'])
    expected = config['e3_provenance_sha256']
    actual = {'adapter_model': require_sha256(adapter_dir / 'adapter_model.safetensors', expected['adapter_model'], 'frozen E3 adapter model'), 'adapter_config': require_sha256(adapter_dir / 'adapter_config.json', expected['adapter_config'], 'frozen E3 adapter config'), 'training_summary': require_sha256(summary_path, expected['training_summary'], 'frozen E3 training summary')}
    summary = json.loads(summary_path.read_text(encoding='utf-8'))
    expected_summary = {'status': 'PASS', 'world_size': 4, 'optimizer_steps': 2184, 'microsteps_completed': 4368, 'epochs_completed': 1, 'trainable_parameters': 33030144}
    observed = {key: summary.get(key) for key in expected_summary}
    if observed != expected_summary:
        raise SystemExit('Safety stop: E3 training provenance drift: ' + json.dumps({'expected': expected_summary, 'actual': observed}, ensure_ascii=False))
    if Path(summary.get('final_adapter', '')).resolve() != adapter_dir.resolve():
        raise SystemExit('Safety stop: E3 training summary final_adapter mismatch')
    adapter_config = json.loads((adapter_dir / 'adapter_config.json').read_text(encoding='utf-8'))
    expected_adapter = config['expected_adapter']
    checks = {'peft_type': adapter_config.get('peft_type'), 'task_type': adapter_config.get('task_type'), 'r': adapter_config.get('r'), 'lora_alpha': adapter_config.get('lora_alpha'), 'lora_dropout': adapter_config.get('lora_dropout'), 'target_modules': sorted(adapter_config.get('target_modules') or [])}
    frozen = {'peft_type': expected_adapter['peft_type'], 'task_type': expected_adapter['task_type'], 'r': expected_adapter['r'], 'lora_alpha': expected_adapter['lora_alpha'], 'lora_dropout': expected_adapter['lora_dropout'], 'target_modules': sorted(expected_adapter['target_modules'])}
    if checks != frozen:
        raise SystemExit('Safety stop: E3 adapter contract differs from ABC adapter contract')
    return {'adapter_path': str(adapter_dir), 'training_summary': str(summary_path), 'verified_sha256': actual, 'training_provenance': observed}

def load_jsonl(path: Path) -> list[dict]:
    with path.open('r', encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]

def load_training_topic_priors(path: Path, top_k: int) -> dict[str, list[str]]:
    counts = defaultdict(Counter)
    for row in load_jsonl(path):
        subject = row.get('metadata', {}).get('subject') or row.get('input', {}).get('subject', '')
        target = row.get('target', {})
        blueprint = target.get('blueprint', [])
        if not blueprint and row.get('messages'):
            try:
                blueprint = json.loads(row['messages'][-1]['content']).get('blueprint', [])
            except (KeyError, TypeError, json.JSONDecodeError):
                blueprint = []
        for item in blueprint:
            topic_id = (item.get('topic_id') or '').strip()
            if topic_id:
                counts[subject][topic_id] += 1
    return {subject: [topic_id for topic_id, _ in counter.most_common(max(0, top_k))] for subject, counter in counts.items()}

def compact_candidates(result: dict) -> dict:
    compact = {level: [{'id': item['node_id'], 'parent_id': item.get('parent_id', ''), 'official_name': item.get('english_name', ''), 'project_label': item.get('chinese_label', '')} for item in result['candidates'][level]] for level in ('KA', 'KU', 'TOPIC')}
    compact['paths'] = [{'path_rank': item['path_rank'], 'ka_id': item['ka_id'], 'ka_name': item.get('ka_name', ''), 'ku_id': item['ku_id'], 'ku_name': item.get('ku_name', ''), 'topic_id': item['topic_id'], 'topic_name': item.get('topic_name', '')} for item in result.get('candidate_paths', [])]
    return compact

def retrieval_query(task: str, strict_row: dict, context: dict) -> str:
    parts = [strict_row['question']]
    if task == 'B':
        parts.extend((item.get('content', '') for item in strict_row['dialogue']))
    elif task == 'C':
        parts.extend((item.get('operation', '') for item in context.get('operations', [])))
    return '\n'.join((x for x in parts if x))

def valid_source_ids(strict_row: dict) -> list[str]:
    output = [item['message_id'] for item in strict_row['dialogue']]
    output.extend((str(item['source_id']) for item in strict_row.get('submission', {}).get('documents', []) if item.get('source_id')))
    return output

def gold_summary(task: str, gold: dict) -> dict:
    root = {'A': 'blueprint', 'B': 'operations', 'C': 'ksa'}[task]
    return {'count': len(gold[root]), root: gold[root]}

def e2_reference_id(item) -> str | None:
    if isinstance(item, str):
        return item.strip() or None
    if isinstance(item, dict):
        return E2_HELPERS.evidence_ref_id(item)
    return None

def e2_generation_call(*, messages, model, tokenizer, device, max_new_tokens: int, max_attempts: int, input_limit: int, validator_fn) -> tuple:
    attempts = []
    current = list(messages)
    final_parsed, final_raw = (None, '')
    for attempt in range(1, max_attempts + 1):
        prompt = tokenizer.apply_chat_template(current, tokenize=False, add_generation_prompt=True)
        encoded = tokenizer(prompt, return_tensors='pt', add_special_tokens=False)
        input_tokens = int(encoded['input_ids'].shape[1])
        if input_tokens > input_limit:
            attempts.append({'attempt': attempt, 'status': 'CONTEXT_OVERFLOW', 'input_tokens': input_tokens, 'input_limit': input_limit})
            return (None, attempts, '')
        encoded = {key: value.to(device) for key, value in encoded.items()}
        started = time.time()
        with torch.inference_mode():
            generated = model.generate(**encoded, do_sample=False, max_new_tokens=max_new_tokens, eos_token_id=tokenizer.eos_token_id, pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id)
        output_ids = generated[0, encoded['input_ids'].shape[1]:]
        raw = tokenizer.decode(output_ids, skip_special_tokens=True).strip()
        parsed, parse_error = E2_SMOKE.parse_json_strict(raw)
        issues = [{'code': 'INVALID_JSON', 'message': parse_error}] if parsed is None else validator_fn(parsed)
        passed = parsed is not None and (not issues)
        attempts.append({'attempt': attempt, 'status': 'PASS' if passed else 'RETRY', 'input_tokens': input_tokens, 'output_tokens': int(output_ids.shape[0]), 'generation_seconds': time.time() - started, 'issues': issues})
        final_parsed, final_raw = (parsed, raw)
        if passed:
            return (parsed, attempts, raw)
        current.extend([{'role': 'assistant', 'content': raw}, {'role': 'user', 'content': '\u4e0a\u6b21\u8f93\u51fa\u672a\u901a\u8fc7\u7ed3\u6784\u6821\u9a8c\u3002\u4ec5\u8f93\u51fa\u4fee\u6b63\u540e\u7684JSON\uff0c\u4e0d\u8981\u89e3\u91ca\u3002\u9519\u8bef\uff1a' + json.dumps(issues, ensure_ascii=False)}])
    return (final_parsed if final_parsed is not None and (not validator_fn(final_parsed)) else None, attempts, final_raw)

def e2_map_issues(parsed: dict, chunk: dict, max_candidates: int) -> list[dict]:
    issues = []
    if not isinstance(parsed, dict) or set(parsed) != {'local_candidates'}:
        return [{'code': 'MAP_SCHEMA', 'message': 'root must contain only local_candidates'}]
    values = parsed.get('local_candidates')
    if not isinstance(values, list):
        return [{'code': 'MAP_SCHEMA', 'message': 'local_candidates must be an array'}]
    if len(values) > max_candidates:
        issues.append({'code': 'MAP_CANDIDATE_CAP', 'message': f'count={len(values)}, cap={max_candidates}'})
    allowed = set((str(value) for value in chunk['source_ids']))
    for index, candidate in enumerate(values):
        if not isinstance(candidate, dict) or set(candidate) != {'operation', 'evidence_refs'}:
            issues.append({'code': 'MAP_CANDIDATE_SCHEMA', 'message': f'index={index}'})
            continue
        if not isinstance(candidate.get('operation'), str) or not candidate['operation'].strip():
            issues.append({'code': 'MAP_EMPTY_OPERATION', 'message': f'index={index}'})
        refs = candidate.get('evidence_refs')
        if not isinstance(refs, list) or not refs:
            issues.append({'code': 'MAP_EMPTY_EVIDENCE', 'message': f'index={index}'})
            continue
        ids = [e2_reference_id(item) for item in refs]
        if any((value is None or value not in allowed for value in ids)):
            issues.append({'code': 'MAP_EVIDENCE_OUTSIDE_CHUNK', 'message': f'index={index}, refs={ids}'})
    return issues

def e2_reduce_issues(parsed: dict) -> list[dict]:
    if not isinstance(parsed, dict) or set(parsed) != {'canonical_operation'}:
        return [{'code': 'REDUCE_SCHEMA', 'message': 'root must contain only canonical_operation'}]
    operation = parsed.get('canonical_operation')
    required = {'operation_id', 'operation', 'relevance', 'mapped_ku_ids', 'responsibility', 'ai_share', 'student_share', 'evidence_refs', 'support_reason'}
    if not isinstance(operation, dict) or not required <= set(operation):
        return [{'code': 'REDUCE_OPERATION_SCHEMA', 'message': f'required={sorted(required)}'}]
    if not isinstance(operation.get('operation'), str) or not operation['operation'].strip():
        return [{'code': 'REDUCE_EMPTY_OPERATION', 'message': 'operation is empty'}]
    if not isinstance(operation.get('evidence_refs'), list) or not operation['evidence_refs']:
        return [{'code': 'REDUCE_EMPTY_EVIDENCE', 'message': 'evidence_refs is empty'}]
    return []

def e2_select_cluster_chunks(cluster: dict) -> list[dict]:
    by_block = defaultdict(list)
    for chunk in cluster['chunks'].values():
        by_block[int(chunk['block_index'])].append(chunk)
    selected = []
    for block_index in sorted(by_block):
        selected.append(max(by_block[block_index], key=lambda item: (E2_HELPERS.overlap_score(cluster['candidate_operation'], item['text']), -int(item['chunk_index']))))
    return selected

def e2_make_evidence_bundle(tokenizer, cluster: dict) -> list[dict]:
    bundle = []
    for chunk in e2_select_cluster_chunks(cluster):
        refs = sorted(cluster['refs_by_chunk'].get(chunk['chunk_id'], set()))
        ids = E2_HELPERS.encode_text(tokenizer, chunk['text'])[:E2_HELPERS.REDUCE_EVIDENCE_PER_SOURCE_TOKENS]
        bundle.append({'source_ids': refs, 'block_kind': chunk['block_kind'], 'chunk_id': chunk['chunk_id'], 'text': tokenizer.decode(ids, skip_special_tokens=False), 'tokens': len(ids)})
    while sum((item['tokens'] for item in bundle)) > E2_HELPERS.REDUCE_EVIDENCE_TOTAL_TOKENS:
        largest = max(bundle, key=lambda item: item['tokens'])
        if largest['tokens'] <= 512:
            break
        ids = E2_HELPERS.encode_text(tokenizer, largest['text'])[:max(512, largest['tokens'] - 512)]
        largest['text'] = tokenizer.decode(ids, skip_special_tokens=False)
        largest['tokens'] = len(ids)
    return [{key: item[key] for key in ('source_ids', 'block_kind', 'chunk_id', 'text')} for item in bundle]

def e2_merge_reduced_operations(operations: list[dict]) -> list[dict]:
    merged = {}
    for operation in operations:
        key = E2_HELPERS.normalize(str(operation.get('operation', '')))
        if not key:
            continue
        if key not in merged:
            merged[key] = copy.deepcopy(operation)
            continue
        existing = merged[key]
        refs = existing.get('evidence_refs', []) + operation.get('evidence_refs', [])
        unique = {}
        for ref in refs:
            ref_id = e2_reference_id(ref)
            if ref_id:
                unique[ref_id, json.dumps(ref, ensure_ascii=False, sort_keys=True)] = ref
        existing['evidence_refs'] = [unique[key] for key in sorted(unique)]
    output = [merged[key] for key in sorted(merged)]
    for index, operation in enumerate(output, 1):
        operation['operation_id'] = f'U{index:02d}'
    return output

def e3_gate_issues(parsed: dict) -> list[dict]:
    if not isinstance(parsed, dict) or set(parsed) != {'has_operation'}:
        return [{'code': 'GATE_SCHEMA', 'message': 'root must contain only has_operation'}]
    if not isinstance(parsed.get('has_operation'), bool):
        return [{'code': 'GATE_SCHEMA', 'message': 'has_operation must be boolean'}]
    return []

def e3_extract_issues(parsed: dict, chunk: dict, max_candidates: int) -> list[dict]:
    issues = e2_map_issues(parsed, chunk, max_candidates)
    if not issues and (not parsed['local_candidates']):
        issues.append({'code': 'EXTRACT_EMPTY', 'message': 'Gate-positive Extract must be nonempty'})
    return issues

def run_abc_generation(*, task: str, mode: str, row: dict, strict_row: dict, context: dict, candidates: dict, model, tokenizer, validator, smoke, config: dict, device: torch.device) -> dict:
    if task not in {'A', 'C'}:
        raise RuntimeError(f'ABC adapter route only supports A/C, got task={task}')
    model.set_adapter('abc')
    system, user = smoke.prompt_for_task(task, strict_row, candidates, context)
    messages = [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}]
    max_attempts = int(config['generation']['max_internal_attempts'])
    max_new = int(config['generation']['max_new_tokens'][task])
    context_window = int(getattr(model.config, 'max_position_embeddings', 262144) or 262144)
    configured_limit = int(config['generation']['max_input_tokens'])
    input_limit = min(configured_limit, context_window - max_new)
    attempts = []
    final_parsed = None
    final_validation = None
    final_raw = ''
    final_candidate_violations = []
    for attempt in range(1, max_attempts + 1):
        prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        encoded = tokenizer(prompt, return_tensors='pt', add_special_tokens=False)
        input_tokens = int(encoded['input_ids'].shape[1])
        if input_tokens > input_limit:
            attempts.append({'attempt': attempt, 'status': 'CONTEXT_OVERFLOW', 'input_tokens': input_tokens, 'input_limit': input_limit})
            return {'unit_id': row['unit_id'], 'subject': strict_row['subject'], 'mode': mode, 'task': task, 'status': 'CONTEXT_OVERFLOW', 'strict_json_valid': False, 'strict_gate_pass': False, 'schema_validation': None, 'candidate_violations': [], 'attempts': attempts, 'gold': gold_summary(task, strict_row[task]), 'prediction': None}
        encoded = {key: value.to(device) for key, value in encoded.items()}
        started = time.time()
        with torch.inference_mode():
            generated = model.generate(**encoded, do_sample=False, max_new_tokens=max_new, eos_token_id=tokenizer.eos_token_id, pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id)
        generation_seconds = time.time() - started
        output_ids = generated[0, encoded['input_ids'].shape[1]:]
        raw = tokenizer.decode(output_ids, skip_special_tokens=True).strip()
        parsed, parse_error = smoke.parse_json_strict(raw)
        if parsed is None:
            validation = {'valid': False, 'route': 'internal_retry', 'issues': [{'code': 'INVALID_JSON', 'path': '$', 'message': parse_error, 'severity': 'retry'}]}
            candidate_errors = []
        else:
            validation = validator.validate(task, strict_row['subject'], parsed, context if task != 'A' else None)
            candidate_errors = smoke.candidate_violations(task, parsed, candidates)
            if candidate_errors:
                validation = {'valid': False, 'route': 'internal_retry', 'issues': validation['issues'] + [{'code': 'OUTSIDE_CANDIDATES', 'path': item['path'], 'message': str(item['value']), 'severity': 'retry'} for item in candidate_errors]}
        passed = parsed is not None and validation['valid'] and (not candidate_errors)
        attempts.append({'attempt': attempt, 'status': 'PASS' if passed else 'RETRY', 'input_tokens': input_tokens, 'output_tokens': int(output_ids.shape[0]), 'generation_seconds': generation_seconds, 'validation': validation})
        final_parsed, final_validation, final_raw = (parsed, validation, raw)
        final_candidate_violations = candidate_errors
        if passed:
            break
        issue_text = json.dumps(validation['issues'], ensure_ascii=False)
        repair_hint = smoke.repair_guidance(task, validation['issues'])
        messages.extend([{'role': 'assistant', 'content': raw}, {'role': 'user', 'content': '\u4e0a\u6b21\u8f93\u51fa\u672a\u901a\u8fc7\u5185\u90e8\u6821\u9a8c\u3002\u4ec5\u91cd\u65b0\u8f93\u51fa\u4fee\u6b63\u540e\u7684JSON\uff0c\u4e0d\u8981\u89e3\u91ca\u3002' + repair_hint + '\u9519\u8bef\uff1a' + issue_text}])
    strict_pass = bool(final_parsed is not None and final_validation and final_validation['valid'] and (not final_candidate_violations))
    return {'unit_id': row['unit_id'], 'subject': strict_row['subject'], 'mode': mode, 'task': task, 'status': 'PASS' if strict_pass else 'REVIEW_REQUIRED', 'strict_json_valid': final_parsed is not None, 'strict_gate_pass': strict_pass, 'schema_validation': final_validation, 'candidate_violations': final_candidate_violations, 'candidate_ids': {level: [item['id'] for item in candidates[level]] for level in ('KA', 'KU', 'TOPIC')}, 'candidate_path_count': len(candidates.get('paths', [])), 'candidate_paths': candidates.get('paths', []), 'attempts': attempts, 'gold': gold_summary(task, strict_row[task]), 'prediction': final_parsed, 'raw_output_internal': final_raw, 'adapter_route': 'ABC'}

def run_e3_b_generation(*, task: str, mode: str, row: dict, strict_row: dict, context: dict, candidates: dict, model, tokenizer, validator, smoke, config: dict, device: torch.device) -> dict:
    if task != 'B' or mode not in {'taskwise_gold_context', 'end_to_end_pipeline'}:
        raise RuntimeError(f'E3 route violation: mode={mode}, task={task}')
    _, source_user = smoke.prompt_for_task('B', strict_row, candidates, context)
    try:
        payload = json.loads(source_user)
    except json.JSONDecodeError as exc:
        return {'unit_id': row['unit_id'], 'subject': strict_row['subject'], 'mode': mode, 'task': task, 'status': 'REVIEW_REQUIRED', 'strict_json_valid': False, 'strict_gate_pass': False, 'schema_validation': {'valid': False, 'route': 'review', 'issues': [{'code': 'E3_SOURCE_PROMPT_NOT_JSON', 'path': '$', 'message': str(exc), 'severity': 'review'}]}, 'candidate_violations': [], 'attempts': [], 'gold': gold_summary(task, strict_row[task]), 'prediction': None, 'raw_output_internal': ''}
    blocks = E2_HELPERS.source_blocks(payload)
    chunks = E2_HELPERS.make_block_chunks(tokenizer, blocks)
    question_chunks = E2_HELPERS.token_chunks(tokenizer, payload.get('question_text', ''), E2_HELPERS.QUESTION_CHUNK_TOKENS, E2_HELPERS.QUESTION_OVERLAP_TOKENS)
    blueprint_text = json.dumps(payload.get('confirmed_blueprint'), ensure_ascii=False)
    candidate_text = json.dumps(payload.get('candidate_standard_ku_paths'), ensure_ascii=False)
    base_query = f'{blueprint_text} {candidate_text}'
    settings = config['e3_generation']
    max_attempts = int(settings['max_internal_attempts'])
    max_candidates = int(settings['max_candidates_per_chunk'])
    context_window = int(getattr(model.config, 'max_position_embeddings', 262144) or 262144)
    clusters = {}
    gate_attempts, gate_failures, gate_positive, gate_negative = ([], 0, 0, 0)
    extract_attempts, extract_failures = ([], 0)
    for chunk in chunks:
        question_context = E2_HELPERS.select_question_context(tokenizer, payload.get('question_text', ''), f"{chunk['text']} {base_query}", E2_HELPERS.QUESTION_CONTEXT_TOKENS_MAP, question_chunks)
        common_input = {'subject': strict_row['subject'], 'question_context': question_context, 'evidence_chunk': {'chunk_id': chunk['chunk_id'], 'block_kind': chunk['block_kind'], 'source_ids': chunk['source_ids'], 'text': chunk['text']}, 'confirmed_blueprint': payload.get('confirmed_blueprint')}
        gate_input = dict(common_input)
        gate_input.update({'task': 'B_GATE', 'output_json_schema': E3_HELPERS.GATE_SCHEMA})
        gate_messages = [{'role': 'system', 'content': E3_HELPERS.GATE_SYSTEM}, {'role': 'user', 'content': json.dumps(gate_input, ensure_ascii=False, separators=(',', ':'))}]
        model.set_adapter('e3')
        gate_parsed, attempts, _ = e2_generation_call(messages=gate_messages, model=model, tokenizer=tokenizer, device=device, max_new_tokens=int(settings['gate_max_new_tokens']), max_attempts=max_attempts, input_limit=min(int(settings['max_input_tokens']), context_window - int(settings['gate_max_new_tokens'])), validator_fn=e3_gate_issues)
        gate_attempts.append({'chunk_id': chunk['chunk_id'], 'attempts': attempts})
        if gate_parsed is None:
            gate_failures += 1
            continue
        if not gate_parsed['has_operation']:
            gate_negative += 1
            continue
        gate_positive += 1
        extract_input = dict(common_input)
        extract_input.update({'task': 'B_EXTRACT', 'output_json_schema': E3_HELPERS.EXTRACT_SCHEMA})
        extract_messages = [{'role': 'system', 'content': E3_HELPERS.EXTRACT_SYSTEM}, {'role': 'user', 'content': json.dumps(extract_input, ensure_ascii=False, separators=(',', ':'))}]
        model.set_adapter('e3')
        extracted, attempts, _ = e2_generation_call(messages=extract_messages, model=model, tokenizer=tokenizer, device=device, max_new_tokens=int(settings['extract_max_new_tokens']), max_attempts=max_attempts, input_limit=min(int(settings['max_input_tokens']), context_window - int(settings['extract_max_new_tokens'])), validator_fn=lambda value, current=chunk: e3_extract_issues(value, current, max_candidates))
        extract_attempts.append({'chunk_id': chunk['chunk_id'], 'attempts': attempts})
        if extracted is None:
            extract_failures += 1
            continue
        for candidate in extracted['local_candidates']:
            normalized = E2_HELPERS.normalize(candidate['operation'])
            if not normalized:
                continue
            cluster = clusters.setdefault(normalized, {'candidate_operation': candidate['operation'], 'variants': Counter(), 'chunks': {}, 'refs_by_chunk': defaultdict(set)})
            cluster['variants'][candidate['operation']] += 1
            cluster['chunks'][chunk['chunk_id']] = chunk
            for ref in candidate['evidence_refs']:
                ref_id = e2_reference_id(ref)
                if ref_id:
                    cluster['refs_by_chunk'][chunk['chunk_id']].add(ref_id)
    for cluster in clusters.values():
        cluster['candidate_operation'] = sorted(cluster['variants'], key=lambda text: (-cluster['variants'][text], E2_HELPERS.normalize(text), text))[0]
    reduced, reduce_attempts, reduce_failures = ([], [], 0)
    for cluster_key in sorted(clusters):
        cluster = clusters[cluster_key]
        bundle = e2_make_evidence_bundle(tokenizer, cluster)
        question_context = E2_HELPERS.select_question_context(tokenizer, payload.get('question_text', ''), f"{cluster['candidate_operation']} {' '.join((item['text'] for item in bundle))} {base_query}", E2_HELPERS.QUESTION_CONTEXT_TOKENS_REDUCE, question_chunks)
        reduce_input = {'task': 'B_REDUCE', 'subject': strict_row['subject'], 'candidate_operation': cluster['candidate_operation'], 'question_context': question_context, 'evidence_bundle': bundle, 'confirmed_blueprint': payload.get('confirmed_blueprint'), 'candidate_standard_ku_paths': payload.get('candidate_standard_ku_paths'), 'output_json_schema': E2_HELPERS.REDUCE_SCHEMA}
        messages = [{'role': 'system', 'content': E2_HELPERS.REDUCE_SYSTEM}, {'role': 'user', 'content': json.dumps(reduce_input, ensure_ascii=False, separators=(',', ':'))}]
        model.set_adapter('e3')
        parsed, attempts, _ = e2_generation_call(messages=messages, model=model, tokenizer=tokenizer, device=device, max_new_tokens=int(settings['reduce_max_new_tokens']), max_attempts=max_attempts, input_limit=min(int(settings['max_input_tokens']), context_window - int(settings['reduce_max_new_tokens'])), validator_fn=e2_reduce_issues)
        reduce_attempts.append({'cluster': cluster_key, 'attempts': attempts})
        if parsed is None:
            reduce_failures += 1
            continue
        reduced.append(parsed['canonical_operation'])
    prediction = {'operations': e2_merge_reduced_operations(reduced)}
    validation = validator.validate('B', strict_row['subject'], prediction, context)
    candidate_errors = smoke.candidate_violations('B', prediction, candidates)
    if candidate_errors:
        validation = {'valid': False, 'route': 'review', 'issues': validation['issues'] + [{'code': 'OUTSIDE_CANDIDATES', 'path': item['path'], 'message': str(item['value']), 'severity': 'review'} for item in candidate_errors]}
    strict_pass = bool(validation['valid'] and (not candidate_errors))
    return {'unit_id': row['unit_id'], 'subject': strict_row['subject'], 'mode': mode, 'task': task, 'status': 'PASS' if strict_pass else 'REVIEW_REQUIRED', 'strict_json_valid': True, 'strict_gate_pass': strict_pass, 'schema_validation': validation, 'candidate_violations': candidate_errors, 'candidate_ids': {level: [item['id'] for item in candidates[level]] for level in ('KA', 'KU', 'TOPIC')}, 'candidate_path_count': len(candidates.get('paths', [])), 'candidate_paths': candidates.get('paths', []), 'attempts': [{'stage': 'B_GATE', 'evidence_chunks': len(chunks), 'failed_chunks': gate_failures, 'positive_chunks': gate_positive, 'negative_chunks': gate_negative, 'details': gate_attempts}, {'stage': 'B_EXTRACT', 'positive_chunks': gate_positive, 'failed_chunks': extract_failures, 'candidate_clusters': len(clusters), 'details': extract_attempts}, {'stage': 'B_REDUCE', 'candidate_clusters': len(clusters), 'failed_clusters': reduce_failures, 'details': reduce_attempts}], 'gold': gold_summary(task, strict_row[task]), 'prediction': prediction, 'raw_output_internal': json.dumps(prediction, ensure_ascii=False), 'adapter_route': 'E3', 'e3_reconstruction': {'cluster_policy': settings['cluster_policy'], 'evidence_chunks': len(chunks), 'gate_failures': gate_failures, 'gate_positive_chunks': gate_positive, 'gate_negative_chunks': gate_negative, 'extract_failures': extract_failures, 'candidate_clusters': len(clusters), 'reduce_failures': reduce_failures, 'final_operations': len(prediction['operations'])}}

def run_generation(*, task: str, mode: str, row: dict, strict_row: dict, context: dict, candidates: dict, model, tokenizer, validator, smoke, config: dict, device: torch.device) -> dict:
    route = config['adapter_routing'].get(task)
    if task == 'B' and route == 'E3':
        return run_e3_b_generation(task=task, mode=mode, row=row, strict_row=strict_row, context=context, candidates=candidates, model=model, tokenizer=tokenizer, validator=validator, smoke=smoke, config=config, device=device)
    if task in {'A', 'C'} and route == 'ABC':
        return run_abc_generation(task=task, mode=mode, row=row, strict_row=strict_row, context=context, candidates=candidates, model=model, tokenizer=tokenizer, validator=validator, smoke=smoke, config=config, device=device)
    raise RuntimeError(f'unsupported adapter route: task={task}, route={route}')

def blocked_record(row: dict, strict_row: dict, mode: str, task: str, upstream: str) -> dict:
    return {'unit_id': row['unit_id'], 'subject': strict_row['subject'], 'mode': mode, 'task': task, 'status': 'UPSTREAM_BLOCKED', 'upstream_task': upstream, 'strict_json_valid': False, 'strict_gate_pass': False, 'schema_validation': None, 'candidate_violations': [], 'attempts': [], 'gold': gold_summary(task, strict_row[task]), 'prediction': None}

def main() -> None:
    parser = argparse.ArgumentParser(description='Distributed Qwen3-4B + frozen LoRA adapter inference on the official validation split')
    parser.add_argument('--config', type=Path, default=Path('H100_LoRA_v2\u6b63\u5f0f\u9a8c\u8bc1\u63a8\u7406\u914d\u7f6e.json'))
    parser.add_argument('--limit', type=int, default=0, help='0 means the complete frozen validation set')
    parser.add_argument('--output-dir', type=Path, default=None, help='optional isolated output override; required when --limit is used')
    parser.add_argument('--preflight-only', action='store_true')
    parser.add_argument('--allow-world-size-mismatch', action='store_true', help='engineering smoke only; never use for the formal validation run')
    args = parser.parse_args()
    config_path = args.config.resolve()
    root = config_path.parent
    config = json.loads(config_path.read_text(encoding='utf-8'))
    preflight = validate_lora_provenance(root, config_path, config)
    preflight['e3_adapter'] = validate_e3_adapter(root, config)
    e2_path = root / 'operation_segments.py'
    preflight['verified_sha256']['e2_deriver'] = require_sha256(e2_path, config['provenance_sha256']['e2_deriver'], 'frozen E2 derivation helpers')
    e3_path = root / 'operation_gate_extract.py'
    preflight['verified_sha256']['e3_deriver'] = require_sha256(e3_path, config['provenance_sha256']['e3_deriver'], 'frozen E3 derivation helpers')
    preflight['verified_sha256']['routed_validator'] = require_sha256(Path(__file__).resolve(), config['provenance_sha256']['routed_validator'], 'frozen ABC/E3 routed validator')
    if args.preflight_only:
        print(json.dumps(preflight, ensure_ascii=False, indent=2))
        return
    if args.limit < 0:
        raise SystemExit('Safety stop: --limit must be non-negative')
    if args.limit and args.output_dir is None:
        raise SystemExit('Safety stop: --limit requires --output-dir to isolate smoke outputs')
    dep = root / '\u4f9d\u8d56'
    schema_root = dep / '\u4e25\u683cSchema\u4e0e\u6821\u9a8c'
    local_rank = int(os.environ.get('LOCAL_RANK', '0'))
    rank = int(os.environ.get('RANK', '0'))
    world_size = int(os.environ.get('WORLD_SIZE', '1'))
    expected_world_size = int(config['runtime']['expected_world_size'])
    if world_size != expected_world_size and (not args.allow_world_size_mismatch):
        raise SystemExit(f'Safety stop: formal validation requires world_size={expected_world_size}, actual={world_size}')
    if not torch.cuda.is_available():
        raise SystemExit('CUDA is required')
    torch.cuda.set_device(local_rank)
    device = torch.device(f'cuda:{local_rank}')
    runtime_config = config.get('runtime', {})
    disable_cudnn_sdpa = bool(runtime_config.get('disable_cudnn_sdpa', True))
    if disable_cudnn_sdpa:
        torch.backends.cuda.enable_cudnn_sdp(False)
    sdpa_backend_state = {'cudnn': bool(torch.backends.cuda.cudnn_sdp_enabled()), 'flash': bool(torch.backends.cuda.flash_sdp_enabled()), 'mem_efficient': bool(torch.backends.cuda.mem_efficient_sdp_enabled()), 'math': bool(torch.backends.cuda.math_sdp_enabled())}
    if rank == 0:
        print(json.dumps({'event': 'sdpa_backend_configuration', 'disable_cudnn_sdpa_requested': disable_cudnn_sdpa, 'backends': sdpa_backend_state}, ensure_ascii=False), flush=True)
    seed = int(config['seed']) + rank
    random.seed(seed)
    torch.manual_seed(seed)
    adapter = load_module('baseline_adapter', dep / 'record_adapter.py')
    validator = load_module('baseline_validator', schema_root / 'validate_records.py')
    stage1 = load_module('baseline_lexical', dep / 'lexical_retrieval.py')
    stage2 = load_module('baseline_semantic', dep / 'semantic_retrieval.py')
    smoke = load_module('baseline_prompt_helpers', dep / 'prompt_generation.py')
    global E2_HELPERS, E2_SMOKE, E3_HELPERS
    E2_HELPERS = load_module('e2_derivation_helpers', e2_path)
    E3_HELPERS = load_module('e3_derivation_helpers', e3_path)
    E2_SMOKE = smoke
    libraries = {subject: resolve(root, value) for subject, value in config['library_paths'].items()}
    validator.LIBRARIES = libraries
    validator.SCHEMAS = {task: schema_root / name for task, name in {'A': 'blueprint.schema.json', 'B': 'operation.schema.json', 'C': 'cognitive_unit.schema.json'}.items()}
    validator.load_library.cache_clear()
    validator.schema_validator.cache_clear()
    smoke.SCHEMA_ROOT = schema_root
    stage1.LIBRARIES = libraries
    data_path = resolve(root, config['test_data'])
    rows = load_jsonl(data_path)
    data_split = config.get('data_split', 'test')
    engineering_excluded = set(config.get('engineering_smoke_excluded_unit_ids', []))
    rows = [row for row in rows if row.get('unit_id') not in engineering_excluded]
    if args.limit:
        rows = rows[:args.limit]
    elif len(rows) != int(config['expected']['validation_units']):
        raise SystemExit(f"Safety stop: expected {config['expected']['validation_units']} validation units, got {len(rows)}")
    manifest = json.loads(resolve(root, config['eligibility_manifest']).read_text(encoding='utf-8'))
    eligibility = manifest['splits'][data_split]
    excluded = {task: set(eligibility[task]['excluded_unit_ids']) for task in 'ABC'}
    pipeline_excluded = set(eligibility['pipeline_BC_evaluable']['excluded_unit_ids'])
    length_scan = json.loads(resolve(root, config['input_length_scan']).read_text(encoding='utf-8'))
    context_excluded = {item['unit_id'] for item in length_scan['risk_units']}
    embedder = stage2.Embedder(resolve(root, config['embedding_model_path']))
    retrievers = {subject: stage2.HybridRetriever(stage1, subject, stage1.load_library(subject, path), embedder) for subject, path in libraries.items()}
    tokenizer = AutoTokenizer.from_pretrained(resolve(root, config['model_path']), local_files_only=True)
    base_model = AutoModelForCausalLM.from_pretrained(resolve(root, config['model_path']), local_files_only=True, dtype=torch.bfloat16, attn_implementation='sdpa')
    model = PeftModel.from_pretrained(base_model, resolve(root, config['adapter_path']), adapter_name='abc', is_trainable=False)
    model.load_adapter(resolve(root, config['e3_adapter_path']), adapter_name='e3', is_trainable=False)
    model.set_adapter('abc')
    model = model.to(device).eval()
    if rank == 0:
        print(json.dumps({'event': 'routed_lora_adapters_loaded', 'abc_adapter_path': preflight['adapter_path'], 'abc_adapter_model_sha256': preflight['verified_sha256']['adapter_model'], 'e3_adapter_path': preflight['e3_adapter']['adapter_path'], 'e3_adapter_model_sha256': preflight['e3_adapter']['verified_sha256']['adapter_model'], 'active_adapter': getattr(model, 'active_adapter', None)}, ensure_ascii=False), flush=True)
    output_dir = resolve(root, str(args.output_dir)) if args.output_dir is not None else resolve(root, config['output_dir'])
    forbidden_output_dir = resolve(root, config['safety']['forbidden_baseline_output_dir'])
    if output_dir.resolve() == forbidden_output_dir.resolve():
        raise SystemExit('Safety stop: refusing to write LoRA results into the frozen baseline directory')
    output_dir.mkdir(parents=True, exist_ok=True)
    if rank == 0:
        (output_dir / 'LoRA\u9a8c\u8bc1\u9884\u68c0.json').write_text(json.dumps({**preflight, 'actual_world_size': world_size}, ensure_ascii=False, indent=2), encoding='utf-8')
    output_path = output_dir / f'LoRA\u9a8c\u8bc1\u539f\u59cb\u7ed3\u679c_rank{rank:02d}.jsonl'
    processed = set()
    existing_records = {}
    if output_path.exists():
        with output_path.open('r', encoding='utf-8') as f:
            for line_number, line in enumerate(f, 1):
                if not line.strip():
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise RuntimeError(f'existing resume output is not valid JSONL: {output_path}:{line_number}') from exc
                key = (item['unit_id'], item['mode'], item['task'])
                if key in processed:
                    raise RuntimeError(f'duplicate resume key in {output_path}: {key}')
                processed.add(key)
                existing_records[key] = item
    retrieval_args = dict(config['retrieval'])
    prior_topic_k = int(retrieval_args.pop('prior_topic_k', 0))
    prior_data_path = resolve(root, config.get('retrieval_prior_data', str(data_path.with_name('train.jsonl'))))
    training_priors = load_training_topic_priors(prior_data_path, prior_topic_k)
    with output_path.open('a', encoding='utf-8') as out:
        for index, original in enumerate(rows):
            if index % world_size != rank:
                continue
            runtime_row = copy.deepcopy(original)
            subject = runtime_row['metadata']['subject']
            runtime_row['input']['standard_library_ref'] = str(libraries[subject])
            strict_row = adapter.adapt_row(runtime_row)
            strict_row['question'] = smoke.question_text(runtime_row)
            sources = valid_source_ids(strict_row)

            def get_candidates(task: str, context: dict) -> dict:
                query = retrieval_query(task, strict_row, context)
                return compact_candidates(retrievers[subject].retrieve(query, prior_topic_ids=training_priors.get(subject, []), **retrieval_args))
            if 'taskwise_gold_context' in config['evaluation_scope']['modes']:
                for task in config['evaluation_scope']['tasks']:
                    key = (original['unit_id'], 'taskwise_gold_context', task)
                    if key in processed or original['unit_id'] in excluded[task] or (task in {'B', 'C'} and original['unit_id'] in context_excluded):
                        continue
                    context = {'blueprint': strict_row['A']['blueprint'], 'operations': strict_row['B']['operations'], 'valid_message_ids': sources}
                    record = run_generation(task=task, mode='taskwise_gold_context', row=original, strict_row=strict_row, context=context, candidates=get_candidates(task, context), model=model, tokenizer=tokenizer, validator=validator, smoke=smoke, config=config, device=device)
                    out.write(json.dumps(record, ensure_ascii=False) + '\n')
                    out.flush()
                    processed.add(key)
                    existing_records[key] = record
            if 'end_to_end_pipeline' in config['evaluation_scope']['modes'] and original['unit_id'] not in pipeline_excluded and (original['unit_id'] not in context_excluded):
                context = {'blueprint': [], 'operations': [], 'valid_message_ids': sources}
                upstream_ok = True
                previous = ''
                for task in 'ABC':
                    key = (original['unit_id'], 'end_to_end_pipeline', task)
                    if key in processed:
                        prior = existing_records[key]
                        upstream_ok = bool(prior.get('strict_gate_pass'))
                        if upstream_ok and task == 'A':
                            context['blueprint'] = prior['prediction']['blueprint']
                        elif upstream_ok and task == 'B':
                            context['operations'] = prior['prediction']['operations']
                        previous = task
                        continue
                    if not upstream_ok:
                        record = blocked_record(original, strict_row, 'end_to_end_pipeline', task, previous)
                    else:
                        record = run_generation(task=task, mode='end_to_end_pipeline', row=original, strict_row=strict_row, context=context, candidates=get_candidates(task, context), model=model, tokenizer=tokenizer, validator=validator, smoke=smoke, config=config, device=device)
                        upstream_ok = record['strict_gate_pass']
                        if upstream_ok and task == 'A':
                            context['blueprint'] = record['prediction']['blueprint']
                        elif upstream_ok and task == 'B':
                            context['operations'] = record['prediction']['operations']
                    previous = task
                    out.write(json.dumps(record, ensure_ascii=False) + '\n')
                    out.flush()
                    processed.add(key)
                    existing_records[key] = record
    done = {'rank': rank, 'world_size': world_size, 'rows_seen': len(rows), 'data_split': data_split, 'model_variant': 'Qwen3-4B-Instruct-2507 + routed ABC(A/C) and E3(B) adapters', 'abc_adapter_path': preflight['adapter_path'], 'abc_adapter_model_sha256': preflight['verified_sha256']['adapter_model'], 'e3_adapter_path': preflight['e3_adapter']['adapter_path'], 'e3_adapter_model_sha256': preflight['e3_adapter']['verified_sha256']['adapter_model'], 'adapter_routing': config['adapter_routing'], 'config_sha256': preflight['config_sha256'], 'engineering_smoke_excluded_unit_ids': sorted(engineering_excluded), 'context_excluded_unit_count': len(context_excluded), 'sdpa_backends': sdpa_backend_state, 'output': str(output_path)}
    (output_dir / f'LoRA\u9a8c\u8bc1\u5b8c\u6210\u6807\u8bb0_rank{rank:02d}.json').write_text(json.dumps(done, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(done, ensure_ascii=False))
if __name__ == '__main__':
    main()
