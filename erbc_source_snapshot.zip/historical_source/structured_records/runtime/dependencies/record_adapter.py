"""Read-only adapter from frozen audit-rich targets to strict A/B/C outputs."""
from __future__ import annotations
import argparse
import csv
import difflib
import importlib.util
import json
import re
import sys
from collections import Counter
from functools import lru_cache
from pathlib import Path
ROOT = Path('D:\\stress-aware-homework-agent\\\u9879\u76ee\u8fdb\u5c55\\\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e0eKSA\u53cc\u5c42\u5916\u5305\u65b0\u65b9\u6cd5\\\u6a21\u578b\u8bad\u7ec3\\\u672c\u5730\u90e8\u7f72\u6d4b\u8bd5')
PIPELINE_SAMPLES = ROOT / '\u5192\u70df\u6d4b\u8bd5\u6837\u672c' / 'pipeline' / 'samples.jsonl'
VALIDATOR_PATH = ROOT / '\u4e25\u683cSchema\u4e0e\u6821\u9a8c' / 'validate_records.py'

def load_validator():
    spec = importlib.util.spec_from_file_location('strict_output_validator', VALIDATOR_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'\u65e0\u6cd5\u52a0\u8f7d\u6821\u9a8c\u5668：{VALIDATOR_PATH}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module

def load_rows(path: Path=PIPELINE_SAMPLES) -> list[dict]:
    with path.open('r', encoding='utf-8') as handle:
        return [json.loads(line) for line in handle if line.strip()]

def speaker_name(role: str) -> str:
    value = (role or '').strip().lower()
    if value in {'user', 'student', '\u5b66\u751f'}:
        return 'student'
    if value in {'assistant', 'ai', 'system'}:
        return 'assistant'
    if value in {'submission', 'submit', '\u63d0\u4ea4'}:
        return 'submission'
    return value

def stable_message_id(unit_id: str, speaker: str, turn: int) -> str:
    return f'{unit_id}:turn:{turn}:{speaker}'

def normalized_dialogue(row: dict) -> list[dict]:
    output = []
    for index, message in enumerate(row['input'].get('dialogue', []), 1):
        try:
            turn = int(message.get('turn', index))
        except (TypeError, ValueError):
            turn = index
        speaker = speaker_name(message.get('role', ''))
        if speaker not in {'student', 'assistant'}:
            continue
        chat_id = str(message.get('chat_id') or row['unit_id'])
        message_id = f'{chat_id}:turn:{turn}:{speaker}:index:{index - 1}'
        output.append({'message_id': message_id, 'turn': turn, 'speaker': speaker, 'content': message.get('content', ''), 'dialogue_index': index - 1, 'chat_id': chat_id})
    return output

def ref_from_message(message: dict) -> dict:
    return {'message_id': message['message_id'], 'speaker': message['speaker'], 'turn': message['turn']}

def submission_sources(row: dict) -> dict[str, dict]:
    """Return readable submission documents keyed by their stable source ID."""
    submission = row.get('input', {}).get('submission', {})
    documents = submission.get('documents', []) if isinstance(submission, dict) else []
    output = {}
    for document in documents:
        if not isinstance(document, dict):
            continue
        source_id = str(document.get('source_id') or document.get('message_id') or '').strip()
        if source_id:
            output[source_id] = document
    return output

def normalize_ref(ref: dict, row: dict, dialogue: list[dict]) -> dict | None:
    raw_source_id = str(ref.get('source_id') or ref.get('message_id') or '').strip()
    if speaker_name(ref.get('speaker') or ref.get('role') or '') == 'submission' and raw_source_id:
        if raw_source_id in submission_sources(row):
            return {'message_id': raw_source_id, 'speaker': 'submission', 'turn': 0}
        return None
    if ref.get('dialogue_index') is not None:
        try:
            dialogue_index = int(ref['dialogue_index'])
            matches = [x for x in dialogue if x['dialogue_index'] == dialogue_index]
            if len(matches) == 1:
                return ref_from_message(matches[0])
        except (TypeError, ValueError):
            pass
    try:
        turn = int(ref.get('turn') or int(ref['dialogue_index']) + 1)
    except (KeyError, TypeError, ValueError):
        return None
    role = ref.get('role') or ref.get('speaker') or ''
    speaker = speaker_name(role)
    if speaker not in {'student', 'assistant', 'submission'}:
        matches = [x for x in dialogue if x['turn'] == turn]
        if len(matches) == 1:
            speaker = matches[0]['speaker']
        else:
            return None
    matches = [x for x in dialogue if x['turn'] == turn and x['speaker'] == speaker]
    if len(matches) == 1:
        return ref_from_message(matches[0])
    return None

def compact_text(text: str) -> str:
    return re.sub('\\s+', ' ', text or '').strip().lower()

def content_matches(evidence_text: str, dialogue: list[dict], speaker: str) -> list[dict]:
    evidence = compact_text(evidence_text)
    if not evidence:
        return []
    scored = []
    for message in dialogue:
        if message['speaker'] != speaker:
            continue
        content = compact_text(message['content'])
        if not content:
            continue
        prefix = content[:min(120, len(content))]
        if len(prefix) >= 12 and prefix in evidence:
            score = 1.0
        else:
            score = difflib.SequenceMatcher(None, content[:500], evidence[:3000]).ratio()
        if score >= 0.18:
            scored.append((score, message))
    scored.sort(key=lambda x: (-x[0], x[1]['dialogue_index']))
    return [ref_from_message(message) for score, message in scored]

def evidence_refs(item: dict, row: dict, dialogue: list[dict]) -> list[dict]:
    student_raw = list(item.get('student_evidence_refs', []))
    ai_raw = list(item.get('ai_evidence_refs', []))
    raw = list(item.get('evidence_refs', [])) or student_raw + ai_raw
    student_text = item.get('student_evidence', '') or ''
    ai_text = item.get('ai_evidence', '') or ''
    submission_only = any((marker in student_text for marker in ('\u63d0\u4ea4\u5dee\u5f02\u547d\u4e2d', 'submission diff', '\u63d0\u4ea4\u6587\u4ef6\u547d\u4e2d'))) and (not ai_text.strip()) and (not raw)
    if submission_only:
        return []
    output = []
    seen = set()
    for ref in raw:
        normalized = normalize_ref(ref, row, dialogue)
        if normalized is None:
            continue
        key = (normalized['message_id'], normalized['speaker'], normalized['turn'])
        if key not in seen:
            output.append(normalized)
            seen.add(key)
    if output:
        return output
    for speaker, text in (('student', item.get('student_evidence', '')), ('assistant', item.get('ai_evidence', ''))):
        for normalized in content_matches(text, dialogue, speaker):
            key = (normalized['message_id'], normalized['speaker'], normalized['turn'])
            if key not in seen:
                output.append(normalized)
                seen.add(key)
    if not output and item.get('evidence'):
        for speaker in ('student', 'assistant'):
            for normalized in content_matches(item.get('evidence', ''), dialogue, speaker):
                key = (normalized['message_id'], normalized['speaker'], normalized['turn'])
                if key not in seen:
                    output.append(normalized)
                    seen.add(key)
    return output

@lru_cache(maxsize=8)
def library_rows(path_text: str) -> list[dict]:
    path = Path(path_text)
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))

def normalized_library(path_text: str) -> tuple[dict[str, dict], list[dict]]:
    by_id = {}
    topics = []
    for row in library_rows(path_text):
        if 'Level' in row:
            level = (row.get('Level') or '').upper()
            node_id = (row.get('Node_ID') or '').strip()
            parent_id = (row.get('Parent_ID') or '').strip()
            official = (row.get('English_Name') or '').strip()
            project = (row.get('Chinese_Working_Label') or '').strip()
        else:
            level = (row.get('level') or '').upper()
            node_id = (row.get('id') or '').strip()
            parent_id = (row.get('parent_ku_id') or row.get('parent_ka_id') or '').strip()
            official = (row.get('official_name') or '').strip()
            project = (row.get('project_label') or '').strip()
        node = {'level': level, 'id': node_id, 'parent_id': parent_id, 'official': official, 'project': project}
        if node_id:
            by_id[node_id] = node
        if level == 'TOPIC':
            topics.append(node)
    return (by_id, topics)

def resolve_ksa_ids(item: dict, target: dict, library_path: str) -> tuple[str | None, str | None]:
    by_id, topics = normalized_library(library_path)
    ku_id = (item.get('ku_id') or '').strip()
    if ku_id not in by_id or by_id[ku_id]['level'] != 'KU':
        candidates = [(item.get('ku') or '').strip(), (item.get('raw') or {}).get('KU', '').strip()]
        ku_id = next((x for x in candidates if x in by_id and by_id[x]['level'] == 'KU'), '')
    topic_id = (item.get('topic_id') or '').strip()
    if topic_id in by_id and by_id[topic_id]['level'] == 'TOPIC':
        return (ku_id or by_id[topic_id]['parent_id'], topic_id)
    label = (item.get('topic') or (item.get('raw') or {}).get('CS2023 Topic') or '').strip()
    if label in {'', 'NO_TOPIC'} or item.get('ku') == 'NO_KU':
        return (None, None)
    possible = [x for x in topics if not ku_id or x['parent_id'] == ku_id]
    exact = [x for x in possible if label in {x['official'], x['project']}]
    if exact:
        return (exact[0]['parent_id'], exact[0]['id'])
    blueprint = []
    for source in target.get('blueprint', []):
        resolved = dict(source)
        if not (resolved.get('topic_id') or '').strip():
            resolved['topic_id'] = resolve_blueprint_topic_id(resolved, library_path)
        blueprint.append(resolved)
    blueprint_matches = [x for x in blueprint if (not ku_id or x.get('ku_id') == ku_id) and label in {x.get('topic', ''), x.get('project_topic_label', ''), x.get('topic_standard_name', '')}]
    if blueprint_matches:
        return (blueprint_matches[0]['ku_id'], blueprint_matches[0]['topic_id'])
    if item.get('role') == 'FOCAL':
        same_ku = [x for x in blueprint if not ku_id or x.get('ku_id') == ku_id]
        if len(same_ku) == 1:
            return (same_ku[0]['ku_id'], same_ku[0]['topic_id'])
    ranked = []
    for node in possible:
        score = max(difflib.SequenceMatcher(None, compact_text(label), compact_text(node['project'])).ratio(), difflib.SequenceMatcher(None, compact_text(label), compact_text(node['official'])).ratio())
        ranked.append((score, node))
    ranked.sort(key=lambda x: -x[0])
    if ranked and ranked[0][0] >= 0.62:
        return (ranked[0][1]['parent_id'], ranked[0][1]['id'])
    return (ku_id or None, None) if item.get('role') == 'FOCAL' else (None, None)

def split_ku_ids(value: str) -> list[str]:
    output = []
    for item in re.split('[；;，,]+', value or ''):
        item = item.strip()
        if item and item != 'NO_KU' and (item not in output):
            output.append(item)
    return output

def resolve_blueprint_topic_id(item: dict, library_path: str) -> str:
    """Resolve legacy CS project labels to an existing standard-library Topic ID."""
    by_id, topics = normalized_library(library_path)
    topic_id = (item.get('topic_id') or '').strip()
    if topic_id in by_id and by_id[topic_id]['level'] == 'TOPIC':
        return topic_id
    ku_id = (item.get('ku_id') or item.get('project_ku_code') or '').strip()
    labels = [(item.get('project_topic_label') or '').strip(), (item.get('topic') or '').strip(), (item.get('topic_standard_name') or '').strip()]
    labels = [value for value in labels if value]
    possible = [node for node in topics if not ku_id or node['parent_id'] == ku_id]
    for label in labels:
        exact = [node for node in possible if label in {node['official'], node['project']}]
        if exact:
            return exact[0]['id']
    ranked = []
    for node in possible:
        for label in labels:
            score = max(difflib.SequenceMatcher(None, compact_text(label), compact_text(node['project'])).ratio(), difflib.SequenceMatcher(None, compact_text(label), compact_text(node['official'])).ratio())
            ranked.append((score, node))
    ranked.sort(key=lambda value: -value[0])
    if ranked and ranked[0][0] >= 0.72:
        return ranked[0][1]['id']
    return ''

def adapt_blueprint(target: dict, library_path: str) -> dict:
    output = []
    for item in target.get('blueprint', []):
        output.append({'ka_id': item['ka_id'], 'ku_id': item['ku_id'], 'topic_id': resolve_blueprint_topic_id(item, library_path), 'evidence_source': 'question_text', 'evidence': item.get('evidence') or item.get('question_text') or '\u9898\u76ee\u539f\u6587'})
    return {'blueprint': output}

def adapt_operations(target: dict, row: dict, dialogue: list[dict]) -> dict:
    operations = []
    for item in target.get('operations', []):
        relevance = item['relevance']
        support_reason = ''
        if relevance == 'SUP':
            support_reason = '\u8be5\u64cd\u4f5c\u6574\u4f53\u4e0d\u5c5e\u4e8e\u5f53\u524d\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u3002'
        elif relevance == 'MIXED':
            support_reason = '\u8be5\u64cd\u4f5c\u540c\u65f6\u5305\u542b\u9898\u76ee\u84dd\u56fe\u5185\u77e5\u8bc6\u884c\u52a8\u548c\u84dd\u56fe\u5916\u652f\u6301\u5185\u5bb9\u3002'
        operations.append({'operation_id': item['operation_id'], 'operation': item['operation'], 'relevance': relevance, 'mapped_ku_ids': split_ku_ids(item.get('mapped_ku', '')), 'responsibility': item['responsibility'], 'ai_share': float(item['ai_share']), 'student_share': float(item['student_share']), 'evidence_refs': evidence_refs(item, row, dialogue), 'support_reason': support_reason})
    return {'operations': operations}

def adapt_ksa(target: dict, row: dict, dialogue: list[dict]) -> dict:
    output = []
    for item in target.get('ksa', []):
        ku_id, topic_id = resolve_ksa_ids(item, target, row['input'].get('standard_library_ref', ''))
        support_reason = ''
        if item['role'] == 'SUPPORT':
            support_reason = item.get('support_reason', '').strip()
            if not support_reason and (item.get('topic_id') == 'NO_TOPIC' or item.get('ku_id') == 'NO_KU'):
                support_reason = '\u8be5KSA\u4e0d\u5728\u9898\u76ee\u84dd\u56fe\u4e2d\uff0c\u4e14\u6ca1\u6709\u53ef\u5bf9\u5e94\u7684\u6807\u51c6\u5e93KU/Topic\u3002'
            elif not support_reason:
                support_reason = '\u8be5KSA\u6620\u5c04\u7684Topic\u4e0d\u5728\u5f53\u524d\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e2d\u3002'
        output.append({'ksa_id': item['ksa_id'], 'operation_id': item['operation_id'], 'ksa': item['ksa'], 'ka_id': None if not topic_id else normalized_library(row['input'].get('standard_library_ref', ''))[0].get(ku_id, {}).get('parent_id'), 'ku_id': ku_id, 'topic_id': topic_id, 'mapping_status': 'STANDARD_MAPPED' if ku_id and topic_id else 'STANDARD_EXTERNAL', 'role': item['role'], 'responsibility': item['responsibility'], 'ai_share': float(item['ai_share']), 'student_share': float(item['student_share']), 'evidence_refs': evidence_refs(item, row, dialogue), 'support_reason': support_reason})
    return {'ksa': output}

def adapt_row(row: dict) -> dict:
    dialogue = normalized_dialogue(row)
    target = row['target']
    library_path = row['input'].get('standard_library_ref', '')
    a = adapt_blueprint(target, library_path)
    b = adapt_operations(target, row, dialogue)
    c = adapt_ksa(target, row, dialogue)
    return {'unit_id': row['unit_id'], 'subject': row['metadata']['subject'], 'question': row['input']['question'], 'dialogue': dialogue, 'submission': row['input'].get('submission', {}), 'standard_library_ref': row['input'].get('standard_library_ref', ''), 'A': a, 'B': b, 'C': c}

def audit(rows: list[dict]) -> dict:
    validator = load_validator()
    counts = Counter()
    issue_counts = Counter()
    invalid_by_subject = Counter()
    failures = []
    for original in rows:
        row = adapt_row(original)
        valid_message_ids = [x['message_id'] for x in row['dialogue']]
        valid_message_ids.extend(submission_sources(original).keys())
        context_b = {'blueprint': row['A']['blueprint'], 'valid_message_ids': valid_message_ids}
        context_c = {'blueprint': row['A']['blueprint'], 'operations': row['B']['operations'], 'valid_message_ids': valid_message_ids}
        results = {'A': validator.validate('A', row['subject'], row['A']), 'B': validator.validate('B', row['subject'], row['B'], context_b), 'C': validator.validate('C', row['subject'], row['C'], context_c)}
        for task, result in results.items():
            counts[f'{task}_valid' if result['valid'] else f'{task}_invalid'] += 1
            if not result['valid']:
                invalid_by_subject[f"{row['subject']}:{task}"] += 1
                for item in result['issues']:
                    issue_counts[f"{task}:{item['code']}"] += 1
                failures.append({'unit_id': row['unit_id'], 'task': task, 'result': result})
    return {'version': 'frozen_to_strict_schema_adapter_v1', 'units': len(rows), 'counts': dict(counts), 'issue_counts': dict(issue_counts), 'invalid_by_subject': dict(invalid_by_subject), 'failure_count': len(failures), 'failures': failures}

def main() -> None:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, default=PIPELINE_SAMPLES)
    parser.add_argument('--unit-id')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--summary-only', action='store_true')
    args = parser.parse_args()
    rows = load_rows(args.input)
    if args.unit_id:
        rows = [row for row in rows if row['unit_id'] == args.unit_id]
        if not rows:
            raise SystemExit(f'\u627e\u4e0d\u5230\u5355\u5143：{args.unit_id}')
    result = audit(rows)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
    if args.summary_only:
        summary = {k: result[k] for k in ('version', 'units', 'counts', 'issue_counts', 'invalid_by_subject', 'failure_count')}
        summary['failure_examples'] = result['failures'][:12]
        print(json.dumps(summary, ensure_ascii=False, indent=2))
    else:
        print(text)
if __name__ == '__main__':
    main()
