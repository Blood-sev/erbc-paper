"""A/B/C outputs: JSON Schema + standard-library + project-rule validation.

Invalid model output is routed to an internal retry/review channel and must not
be returned directly to an end user.
"""
from __future__ import annotations
import argparse
import csv
import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from jsonschema import Draft202012Validator
HERE = Path(__file__).resolve().parent
MODEL_ROOT = HERE.parents[1]
TRAIN_DATA_ROOT = MODEL_ROOT / '\u8bad\u7ec3\u6570\u636e'
SCHEMAS = {'A': HERE / 'blueprint.schema.json', 'B': HERE / 'operation.schema.json', 'C': HERE / 'cognitive_unit.schema.json'}
LIBRARIES = {'01_\u8ba1\u7b97\u673a\u79d1\u5b66': TRAIN_DATA_ROOT / '01_\u8ba1\u7b97\u673a\u79d1\u5b66' / 'CS2023_\u7ed3\u6784\u5316\u6620\u5c04\u7d22\u5f15.csv', '02_\u6570\u5b66': TRAIN_DATA_ROOT / '02_\u6570\u5b66' / 'MSC2020_\u6570\u5b66\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '03_\u7269\u7406\u5b66': TRAIN_DATA_ROOT / '03_\u7269\u7406\u5b66' / '03_\u7269\u7406\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '04_\u751f\u7269\u5b66': TRAIN_DATA_ROOT / '04_\u751f\u7269\u5b66' / '04_\u751f\u7269\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '05_\u5316\u5b66': TRAIN_DATA_ROOT / '05_\u5316\u5b66' / '05_\u5316\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '06_\u5386\u53f2\u5b66': TRAIN_DATA_ROOT / '06_\u5386\u53f2\u5b66' / '06_\u5386\u53f2\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '07_\u5730\u7406\u5b66': TRAIN_DATA_ROOT / '07_\u5730\u7406\u5b66' / '07_\u5730\u7406\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv'}

@dataclass(frozen=True)
class Node:
    level: str
    node_id: str
    parent_id: str

@lru_cache(maxsize=8)
def load_library(subject: str) -> dict[str, Node]:
    path = LIBRARIES.get(subject)
    if path is None:
        raise ValueError(f'\u672a\u77e5\u5b66\u79d1：{subject}')
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        rows = csv.DictReader(handle)
        nodes = {}
        for row in rows:
            if 'Level' in row:
                level = (row.get('Level') or '').upper().strip()
                node_id = (row.get('Node_ID') or '').strip()
                parent_id = (row.get('Parent_ID') or '').strip()
            else:
                level = (row.get('level') or '').upper().strip()
                node_id = (row.get('id') or '').strip()
                if level == 'KU':
                    parent_id = (row.get('parent_ka_id') or '').strip()
                elif level == 'TOPIC':
                    parent_id = (row.get('parent_ku_id') or '').strip()
                else:
                    parent_id = ''
            if level in {'KA', 'KU', 'TOPIC'} and node_id:
                nodes[node_id] = Node(level, node_id, parent_id)
    return nodes

def issue(code: str, path: str, message: str, severity: str='retry') -> dict:
    return {'code': code, 'path': path, 'message': message, 'severity': severity}

@lru_cache(maxsize=3)
def schema_validator(task: str) -> Draft202012Validator:
    schema = json.loads(SCHEMAS[task].read_text(encoding='utf-8'))
    return Draft202012Validator(schema)

def schema_issues(task: str, payload: dict) -> list[dict]:
    validator = schema_validator(task)
    out = []
    for error in sorted(validator.iter_errors(payload), key=lambda e: list(e.absolute_path)):
        path = '$' + ''.join((f'[{part}]' if isinstance(part, int) else f'.{part}' for part in error.absolute_path))
        out.append(issue('SCHEMA', path, error.message))
    return out

def blueprint_sets(blueprint: list[dict]) -> tuple[set[str], set[str], set[str]]:
    return ({x.get('ka_id', '') for x in blueprint}, {x.get('ku_id', '') for x in blueprint}, {x.get('topic_id', '') for x in blueprint})

def validate_a(payload: dict, nodes: dict[str, Node]) -> list[dict]:
    out = []
    for index, item in enumerate(payload.get('blueprint', [])):
        base = f'$.blueprint[{index}]'
        ka = nodes.get(item.get('ka_id'))
        ku = nodes.get(item.get('ku_id'))
        topic = nodes.get(item.get('topic_id'))
        for name, node, expected in (('ka_id', ka, 'KA'), ('ku_id', ku, 'KU'), ('topic_id', topic, 'TOPIC')):
            if node is None or node.level != expected:
                out.append(issue('INVALID_STANDARD_ID', f'{base}.{name}', f'\u4e0d\u662f\u5f53\u524d\u5b66\u79d1\u6807\u51c6\u5e93\u4e2d\u7684{expected} ID'))
        if ka and ku and (ku.parent_id != ka.node_id):
            out.append(issue('INVALID_PARENT', base, 'KU\u4e0d\u5c5e\u4e8e\u6240\u9009KA'))
        if ku and topic and (topic.parent_id != ku.node_id):
            out.append(issue('INVALID_PARENT', base, 'Topic\u4e0d\u5c5e\u4e8e\u6240\u9009KU'))
    return out

def validate_evidence_refs(items: list[dict], root_key: str, valid_message_ids: set[str] | None) -> list[dict]:
    if valid_message_ids is None:
        return []
    out = []
    for i, item in enumerate(items):
        for j, ref in enumerate(item.get('evidence_refs', [])):
            if ref.get('message_id') not in valid_message_ids:
                out.append(issue('UNKNOWN_EVIDENCE', f'$.{root_key}[{i}].evidence_refs[{j}]', '\u8bc1\u636eID\u4e0d\u5728\u672c\u5355\u5143\u8f93\u5165\u4e2d'))
    return out

def validate_b(payload: dict, nodes: dict[str, Node], context: dict) -> list[dict]:
    out = []
    operations = payload.get('operations', [])
    _, blueprint_kus, _ = blueprint_sets(context.get('blueprint', []))
    ids = [item.get('operation_id') for item in operations]
    if len(ids) != len(set(ids)):
        out.append(issue('DUPLICATE_OPERATION', '$.operations', 'operation_id\u5fc5\u987b\u552f\u4e00'))
    for i, item in enumerate(operations):
        base = f'$.operations[{i}]'
        mapped = set(item.get('mapped_ku_ids', []))
        for ku_id in mapped:
            node = nodes.get(ku_id)
            if node is None or node.level != 'KU':
                out.append(issue('INVALID_STANDARD_ID', f'{base}.mapped_ku_ids', f'{ku_id}\u4e0d\u662f\u5f53\u524d\u5b66\u79d1KU'))
        relevance = item.get('relevance')
        if context.get('blueprint') and relevance in {'REL', 'MIXED'} and (not mapped & blueprint_kus):
            out.append(issue('RELATION_BLUEPRINT_MISMATCH', base, 'REL/MIXED\u64cd\u4f5c\u5fc5\u987b\u81f3\u5c11\u6620\u5c04\u4e00\u4e2a\u84dd\u56fe\u5185KU', 'review'))
        if context.get('blueprint') and relevance == 'SUP' and mapped & blueprint_kus:
            out.append(issue('RELATION_BLUEPRINT_MISMATCH', base, 'SUP\u64cd\u4f5c\u4e0d\u5e94\u6620\u5c04\u84dd\u56fe\u5185KU', 'review'))
    valid_ids = set(context['valid_message_ids']) if 'valid_message_ids' in context else None
    out.extend(validate_evidence_refs(operations, 'operations', valid_ids))
    return out

def validate_c(payload: dict, nodes: dict[str, Node], context: dict) -> list[dict]:
    out = []
    ksa = payload.get('ksa', [])
    _, _, blueprint_topics = blueprint_sets(context.get('blueprint', []))
    operation_map = {x.get('operation_id'): x for x in context.get('operations', [])}
    ksa_ids = [item.get('ksa_id') for item in ksa]
    if len(ksa_ids) != len(set(ksa_ids)):
        out.append(issue('DUPLICATE_KSA', '$.ksa', 'ksa_id\u5fc5\u987b\u552f\u4e00'))
    roles_by_operation: dict[str, set[str]] = {}
    for i, item in enumerate(ksa):
        base = f'$.ksa[{i}]'
        operation_id = item.get('operation_id')
        if operation_id not in operation_map:
            out.append(issue('UNKNOWN_OPERATION', f'{base}.operation_id', 'KSA\u6307\u5411\u4e0d\u5b58\u5728\u7684\u64cd\u4f5c'))
        roles_by_operation.setdefault(operation_id, set()).add(item.get('role'))
        topic_id = item.get('topic_id')
        ku_id = item.get('ku_id')
        role = item.get('role')
        mapping_status = item.get('mapping_status')
        ka_id = item.get('ka_id')
        if mapping_status == 'STANDARD_EXTERNAL':
            if not (ka_id is None and ku_id is None and (topic_id is None) and (role == 'SUPPORT') and item.get('support_reason', '').strip()):
                out.append(issue('INVALID_EXTERNAL_MAPPING', base, 'STANDARD_EXTERNAL\u5fc5\u987b\u662fSUPPORT\uff0c\u4e09\u5c42ID\u4e3anull\u4e14support_reason\u975e\u7a7a'))
        elif mapping_status == 'STANDARD_MAPPED':
            topic = nodes.get(topic_id)
            ku = nodes.get(ku_id)
            ka = nodes.get(ka_id)
            if topic is None or topic.level != 'TOPIC':
                out.append(issue('INVALID_STANDARD_ID', f'{base}.topic_id', '\u4e0d\u662f\u5f53\u524d\u5b66\u79d1Topic ID'))
            if ku is None or ku.level != 'KU':
                out.append(issue('INVALID_STANDARD_ID', f'{base}.ku_id', '\u4e0d\u662f\u5f53\u524d\u5b66\u79d1KU ID'))
            if ka is None or ka.level != 'KA':
                out.append(issue('INVALID_STANDARD_ID', f'{base}.ka_id', '\u4e0d\u662f\u5f53\u524d\u5b66\u79d1KA ID'))
            if topic and ku and (topic.parent_id != ku.node_id):
                out.append(issue('INVALID_PARENT', base, 'Topic\u4e0d\u5c5e\u4e8e\u6240\u9009KU'))
            if ku and ka and (ku.parent_id != ka.node_id):
                out.append(issue('INVALID_PARENT', base, 'KU\u4e0d\u5c5e\u4e8e\u6240\u9009KA'))
        else:
            out.append(issue('INVALID_MAPPING_STATUS', f'{base}.mapping_status', '\u5fc5\u987b\u4e3aSTANDARD_MAPPED\u6216STANDARD_EXTERNAL'))
        if context.get('blueprint'):
            if role == 'FOCAL' and topic_id not in blueprint_topics:
                out.append(issue('ROLE_BLUEPRINT_MISMATCH', base, 'FOCAL Topic\u4e0d\u5728\u9898\u76ee\u84dd\u56fe\u4e2d', 'review'))
            if role == 'SUPPORT' and topic_id in blueprint_topics:
                out.append(issue('ROLE_BLUEPRINT_MISMATCH', base, 'SUPPORT Topic\u5374\u4f4d\u4e8e\u9898\u76ee\u84dd\u56fe\u4e2d', 'review'))
    for operation_id, operation in operation_map.items():
        roles = roles_by_operation.get(operation_id, set())
        relevance = operation.get('relevance')
        expected = {'REL': {'FOCAL'}, 'SUP': {'SUPPORT'}, 'MIXED': {'FOCAL', 'SUPPORT'}}.get(relevance)
        if expected is not None and roles != expected:
            out.append(issue('COARSE_FINE_MISMATCH', f'operation:{operation_id}', f'{relevance}\u64cd\u4f5c\u7684KSA\u89d2\u8272\u5e94\u4e3a{sorted(expected)}，\u5b9e\u9645\u4e3a{sorted(roles)}', 'review'))
    valid_ids = set(context['valid_message_ids']) if 'valid_message_ids' in context else None
    out.extend(validate_evidence_refs(ksa, 'ksa', valid_ids))
    return out

def validate(task: str, subject: str, payload: dict, context: dict | None=None) -> dict:
    context = context or {}
    issues = schema_issues(task, payload)
    if not issues:
        nodes = load_library(subject)
        issues.extend({'A': validate_a, 'B': validate_b, 'C': validate_c}[task](payload, nodes, context) if task != 'A' else validate_a(payload, nodes))
    if not issues:
        route = 'accept'
    elif any((x['severity'] == 'retry' for x in issues)):
        route = 'internal_retry'
    else:
        route = 'human_review'
    return {'valid': not issues, 'route': route, 'issues': issues}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--task', choices=('A', 'B', 'C'), required=True)
    parser.add_argument('--subject', choices=tuple(LIBRARIES), required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--context', type=Path)
    args = parser.parse_args()
    payload = json.loads(args.input.read_text(encoding='utf-8'))
    context = json.loads(args.context.read_text(encoding='utf-8')) if args.context else {}
    print(json.dumps(validate(args.task, args.subject, payload, context), ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
