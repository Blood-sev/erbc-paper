"""Deterministic, standard-library-only candidate retrieval for KA/KU/Topic.

This script never edits the frozen dataset. It normalizes the seven subject
libraries, retrieves hierarchical candidates, and evaluates gold-label recall.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
import re
import sys
import unicodedata
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
MODEL_ROOT = Path('D:\\stress-aware-homework-agent\\\u9879\u76ee\u8fdb\u5c55\\\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e0eKSA\u53cc\u5c42\u5916\u5305\u65b0\u65b9\u6cd5\\\u6a21\u578b\u8bad\u7ec3')
TRAIN_DATA_ROOT = MODEL_ROOT / '\u8bad\u7ec3\u6570\u636e'
FROZEN_ROOT = MODEL_ROOT / '\u6700\u7ec8\u51bb\u7ed3\u8bad\u7ec3\u7248\u672c'
LIBRARIES = {'01_\u8ba1\u7b97\u673a\u79d1\u5b66': TRAIN_DATA_ROOT / '01_\u8ba1\u7b97\u673a\u79d1\u5b66' / 'CS2023_\u7ed3\u6784\u5316\u6620\u5c04\u7d22\u5f15.csv', '02_\u6570\u5b66': TRAIN_DATA_ROOT / '02_\u6570\u5b66' / 'MSC2020_\u6570\u5b66\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '03_\u7269\u7406\u5b66': TRAIN_DATA_ROOT / '03_\u7269\u7406\u5b66' / '03_\u7269\u7406\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '04_\u751f\u7269\u5b66': TRAIN_DATA_ROOT / '04_\u751f\u7269\u5b66' / '04_\u751f\u7269\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '05_\u5316\u5b66': TRAIN_DATA_ROOT / '05_\u5316\u5b66' / '05_\u5316\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '06_\u5386\u53f2\u5b66': TRAIN_DATA_ROOT / '06_\u5386\u53f2\u5b66' / '06_\u5386\u53f2\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv', '07_\u5730\u7406\u5b66': TRAIN_DATA_ROOT / '07_\u5730\u7406\u5b66' / '07_\u5730\u7406\u5b66_\u4e09\u5c42\u6b63\u5f0f\u5b57\u6bb5\u5e93.csv'}
STOPWORDS = {'a', 'an', 'and', 'are', 'as', 'at', 'be', 'by', 'can', 'create', 'describe', 'explain', 'for', 'from', 'give', 'how', 'i', 'in', 'is', 'it', 'me', 'of', 'on', 'or', 'please', 'question', 'should', 'student', 'students', 'task', 'that', 'the', 'their', 'this', 'to', 'use', 'using', 'what', 'when', 'which', 'with', 'write', 'you', 'your'}

@dataclass(frozen=True)
class Node:
    level: str
    node_id: str
    parent_id: str
    english_name: str
    chinese_label: str
    source_standard: str
    status: str

    @property
    def search_text(self) -> str:
        return ' '.join((x for x in (self.english_name, self.chinese_label, self.node_id) if x))

def _configure_stdout() -> None:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

def normalize(text: str) -> str:
    text = unicodedata.normalize('NFKC', text or '').lower()
    text = re.sub('[\\\\/_:;|]+', ' ', text)
    return re.sub('\\s+', ' ', text).strip()

def tokenize(text: str) -> list[str]:
    text = normalize(text)
    words = [w for w in re.findall("[a-z0-9]+(?:[-'][a-z0-9]+)?", text) if w not in STOPWORDS]
    cjk_runs = re.findall('[\\u3400-\\u9fff]+', text)
    cjk = []
    for run in cjk_runs:
        cjk.extend(run if len(run) == 1 else [run[i:i + 2] for i in range(len(run) - 1)])
    return words + cjk

def load_library(subject: str, path: Path) -> list[Node]:
    with path.open('r', encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    nodes: list[Node] = []
    for row in rows:
        if 'Level' in row:
            level = (row.get('Level') or '').upper().strip()
            node_id = (row.get('Node_ID') or '').strip()
            parent = (row.get('Parent_ID') or '').strip()
            english = (row.get('English_Name') or '').strip()
            chinese = (row.get('Chinese_Working_Label') or '').strip()
            source = (row.get('Source_Standard') or '').strip()
            status = (row.get('Default_Status') or '').strip()
        else:
            level = (row.get('level') or '').upper().strip()
            node_id = (row.get('id') or '').strip()
            if level == 'KU':
                parent = (row.get('parent_ka_id') or '').strip()
            elif level == 'TOPIC':
                parent = (row.get('parent_ku_id') or '').strip()
            else:
                parent = ''
            english = (row.get('official_name') or '').strip()
            chinese = (row.get('project_label') or '').strip()
            source = (row.get('source') or '').strip()
            status = (row.get('status') or '').strip()
        if level in {'KA', 'KU', 'TOPIC'} and node_id:
            nodes.append(Node(level, node_id, parent, english, chinese, source, status))
    if not nodes:
        raise ValueError(f'No valid nodes in {path}')
    return nodes

class BM25Index:

    def __init__(self, nodes: list[Node], k1: float=1.4, b: float=0.75):
        self.nodes = nodes
        self.k1 = k1
        self.b = b
        self.docs = [Counter(tokenize(n.search_text)) for n in nodes]
        self.lengths = [sum(d.values()) for d in self.docs]
        self.avgdl = sum(self.lengths) / max(len(self.lengths), 1)
        df = Counter()
        for doc in self.docs:
            df.update(doc.keys())
        total = len(nodes)
        self.idf = {term: math.log(1 + (total - freq + 0.5) / (freq + 0.5)) for term, freq in df.items()}

    def score(self, query: str) -> dict[str, float]:
        qterms = Counter(tokenize(query))
        out: dict[str, float] = {}
        qnorm = normalize(query)
        for node, doc, dl in zip(self.nodes, self.docs, self.lengths):
            score = 0.0
            for term, qtf in qterms.items():
                tf = doc.get(term, 0)
                if not tf:
                    continue
                denom = tf + self.k1 * (1 - self.b + self.b * dl / max(self.avgdl, 1e-09))
                score += self.idf.get(term, 0.0) * tf * (self.k1 + 1) / denom * min(qtf, 2)
            name = normalize(node.english_name)
            zh = normalize(node.chinese_label)
            if len(name) >= 4 and name in qnorm:
                score += 8.0
            if len(zh) >= 2 and zh in qnorm:
                score += 8.0
            out[node.node_id] = score
        return out

class HierarchicalRetriever:

    def __init__(self, subject: str, nodes: list[Node]):
        self.subject = subject
        self.nodes = nodes
        self.by_id = {n.node_id: n for n in nodes}
        self.by_level = {level: [n for n in nodes if n.level == level] for level in ('KA', 'KU', 'TOPIC')}
        self.index = {level: BM25Index(self.by_level[level]) for level in self.by_level}

    def retrieve(self, query: str, ka_k: int=5, ku_k: int=12, topic_k: int=30) -> dict:
        raw = {level: self.index[level].score(query) for level in self.index}
        topic_ids = sorted(raw['TOPIC'], key=lambda x: (-raw['TOPIC'][x], x))[:topic_k]
        ku_scores = dict(raw['KU'])
        for topic_id in topic_ids:
            parent = self.by_id[topic_id].parent_id
            if parent:
                ku_scores[parent] = ku_scores.get(parent, 0.0) + 0.65 * raw['TOPIC'][topic_id]
        ku_ids = sorted(ku_scores, key=lambda x: (-ku_scores[x], x))[:ku_k]
        ka_scores = dict(raw['KA'])
        for ku_id in ku_ids:
            node = self.by_id.get(ku_id)
            if node and node.parent_id:
                ka_scores[node.parent_id] = ka_scores.get(node.parent_id, 0.0) + 0.65 * ku_scores[ku_id]
        ka_ids = sorted(ka_scores, key=lambda x: (-ka_scores[x], x))[:ka_k]
        selected = {'KA': ka_ids, 'KU': ku_ids, 'TOPIC': topic_ids}
        return {'subject': self.subject, 'query': query, 'limits': {'KA': ka_k, 'KU': ku_k, 'Topic': topic_k}, 'candidates': {level: [{**asdict(self.by_id[node_id]), 'score': round((ka_scores if level == 'KA' else ku_scores if level == 'KU' else raw['TOPIC'])[node_id], 6)} for node_id in ids] for level, ids in selected.items()}}

def extract_question(row: dict) -> str:
    user_messages = [m.get('content', '') for m in row.get('messages', []) if m.get('role') == 'user']
    if not user_messages:
        return ''
    text = user_messages[-1]
    for marker in ('\u539f\u9898\uff1a\n', '\u539f\u9898:\n', 'Original question:\n'):
        if marker in text:
            return text.split(marker, 1)[1].strip()
    return text

def split_ids(value: str) -> list[str]:
    value = (value or '').strip()
    return [value] if value else []

def evaluate(split: str, ka_k: int, ku_k: int, topic_k: int) -> dict:
    path = FROZEN_ROOT / 'A_\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4efb\u52a1' / f'{split}.jsonl'
    retrievers = {subject: HierarchicalRetriever(subject, load_library(subject, lib)) for subject, lib in LIBRARIES.items()}
    totals = Counter()
    hits = Counter()
    subject_totals: dict[str, Counter] = defaultdict(Counter)
    subject_hits: dict[str, Counter] = defaultdict(Counter)
    misses = []
    with path.open('r', encoding='utf-8') as handle:
        for line in handle:
            row = json.loads(line)
            subject = row.get('metadata', {}).get('subject', '')
            if subject not in retrievers:
                raise KeyError(f'Unknown subject: {subject!r}')
            target = json.loads(row['messages'][-1]['content'])
            gold = {'KA': set(), 'KU': set(), 'TOPIC': set()}
            for item in target.get('blueprint', []):
                gold['KA'].update(split_ids(item.get('ka_id')))
                gold['KU'].update(split_ids(item.get('ku_id')))
                gold['TOPIC'].update(split_ids(item.get('topic_id')))
            result = retrievers[subject].retrieve(extract_question(row), ka_k, ku_k, topic_k)
            pred = {level: {x['node_id'] for x in result['candidates'][level]} for level in gold}
            for level in gold:
                totals[level] += len(gold[level])
                subject_totals[subject][level] += len(gold[level])
                count = len(gold[level] & pred[level])
                hits[level] += count
                subject_hits[subject][level] += count
                missing = sorted(gold[level] - pred[level])
                if missing and len(misses) < 200:
                    misses.append({'unit_id': row.get('unit_id'), 'subject': subject, 'level': level, 'missing': missing})

    def rates(h: Counter, t: Counter) -> dict:
        return {level: round(h[level] / t[level], 6) if t[level] else None for level in ('KA', 'KU', 'TOPIC')}
    return {'version': 'standard_only_bm25_hierarchical_v1', 'split': split, 'limits': {'KA': ka_k, 'KU': ku_k, 'Topic': topic_k}, 'overall_recall': rates(hits, totals), 'hits': dict(hits), 'totals': dict(totals), 'by_subject_recall': {s: rates(subject_hits[s], subject_totals[s]) for s in sorted(subject_totals)}, 'miss_count': sum((totals[l] - hits[l] for l in totals)), 'miss_examples': misses}

def main() -> None:
    _configure_stdout()
    parser = argparse.ArgumentParser()
    parser.add_argument('--split', choices=('train', 'validation', 'test'), default='validation')
    parser.add_argument('--ka-k', type=int, default=5)
    parser.add_argument('--ku-k', type=int, default=12)
    parser.add_argument('--topic-k', type=int, default=30)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = evaluate(args.split, args.ka_k, args.ku_k, args.topic_k)
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding='utf-8')
    print(json.dumps({k: result[k] for k in ('version', 'split', 'limits', 'overall_recall', 'hits', 'totals', 'miss_count')}, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
