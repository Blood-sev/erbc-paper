"""Run a deterministic, unfinetuned Qwen3-4B strict-schema smoke test."""
from __future__ import annotations
import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
TEST_ROOT = Path('D:\\stress-aware-homework-agent\\\u9879\u76ee\u8fdb\u5c55\\\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e0eKSA\u53cc\u5c42\u5916\u5305\u65b0\u65b9\u6cd5\\\u6a21\u578b\u8bad\u7ec3\\\u672c\u5730\u90e8\u7f72\u6d4b\u8bd5')
MODEL_PATH = TEST_ROOT / '\u6a21\u578b' / 'Qwen3-4B-Instruct-2507'
SMOKE_PATH = TEST_ROOT / '\u5192\u70df\u6d4b\u8bd5\u6837\u672c' / 'pipeline' / 'samples.jsonl'
SCHEMA_ROOT = TEST_ROOT / '\u4e25\u683cSchema\u4e0e\u6821\u9a8c'
RETRIEVER_PATH = TEST_ROOT / '\u6807\u51c6\u5e93\u5019\u9009\u68c0\u7d22' / 'lexical_retrieval.py'
ADAPTER_PATH = TEST_ROOT / '\u672a\u5fae\u8c03\u57fa\u7ebf\u6d4b\u8bd5' / 'record_adapter.py'
DEFAULT_UNIT = '05_\u5316\u5b66__00a4dea7-219d-4bc3-b980-ce37ad2d7635'

def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'\u65e0\u6cd5\u52a0\u8f7d\u6a21\u5757：{path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def load_row(unit_id: str) -> dict:
    with SMOKE_PATH.open('r', encoding='utf-8') as handle:
        for line in handle:
            row = json.loads(line)
            if row.get('unit_id') == unit_id:
                return row
    raise KeyError(f'\u56fa\u5b9a\u5192\u70df\u6837\u672c\u4e2d\u627e\u4e0d\u5230\u5355\u5143：{unit_id}')

def question_text(row: dict) -> str:
    question = row['input'].get('question', {})
    if isinstance(question, str):
        return question
    return '\n'.join((value.strip() for value in (question.get('title', ''), question.get('text', '')) if isinstance(value, str) and value.strip()))

def compact_candidates(stage1, subject: str, query: str) -> dict:
    nodes = stage1.load_library(subject, stage1.LIBRARIES[subject])
    counts = {level: sum((node.level == level for node in nodes)) for level in ('KA', 'KU', 'TOPIC')}
    if subject == '05_\u5316\u5b66':
        limits = counts
    else:
        limits = {'KA': min(7, counts['KA']), 'KU': min(16, counts['KU']), 'TOPIC': min(30, counts['TOPIC'])}
    result = stage1.HierarchicalRetriever(subject, nodes).retrieve(query, ka_k=limits['KA'], ku_k=limits['KU'], topic_k=limits['TOPIC'])
    return {level: [{'id': item['node_id'], 'parent_id': item['parent_id'], 'official_name': item['english_name'], 'project_label': item['chinese_label']} for item in result['candidates'][level]] for level in ('KA', 'KU', 'TOPIC')}

def prompt_for_task(task: str, strict_row: dict, candidates: dict, context: dict) -> tuple[str, str]:
    schema_names = {'A': 'blueprint.schema.json', 'B': 'operation.schema.json', 'C': 'cognitive_unit.schema.json'}
    root_keys = {'A': 'blueprint', 'B': 'operations', 'C': 'ksa'}
    schema = json.loads((SCHEMA_ROOT / schema_names[task]).read_text(encoding='utf-8'))
    common = f'\u53ea\u8f93\u51fa\u4e00\u4e2a\u5408\u6cd5JSON\u5bf9\u8c61，\u4e0d\u8f93\u51faMarkdown、\u89e3\u91ca\u6216\u4ee3\u7801\u56f4\u680f。\u8f93\u51fa\u6839\u5bf9\u8c61\u53ea\u80fd\u542b{root_keys[task]}，\u7981\u6b62\u989d\u5916\u5b57\u6bb5。\u53ea\u80fd\u4f7f\u7528\u5019\u9009\u6807\u51c6\u8282\u70b9\u4e2d\u5b58\u5728\u7684KA、KU、Topic ID，\u7981\u6b62\u521b\u9020\u6807\u7b7e。\u5019\u9009\u6309\u5408\u6cd5KA→KU→Topic\u5b8c\u6574\u8def\u5f84\u7ed9\u51fa；\u540c\u4e00\u6761\u8f93\u51fa\u5fc5\u987b\u4ece\u540c\u4e00\u5019\u9009\u8def\u5f84\u590d\u5236\u4e09\u4e2aID，\u7981\u6b62\u628aKU ID\u586b\u5165KA\u5b57\u6bb5、\u628aTopic ID\u586b\u5165KU\u5b57\u6bb5，\u4e5f\u7981\u6b62\u8de8\u8def\u5f84\u62fc\u63a5。\u8bc1\u636e\u5f15\u7528\u5fc5\u987b\u9010\u5b57\u4f7f\u7528dialogue_with_message_ids\u4e2d\u7684message_id，\u6216submission.documents\u4e2d\u7684source_id；\u63d0\u4ea4\u6587\u4ef6\u8bc1\u636e\u7684speaker\u56fa\u5b9a\u4e3asubmission、turn\u56fa\u5b9a\u4e3a0。\u8d23\u4efb\u89c4\u5219：AI=1.0/0.0，\u5b66\u751f=0.0/1.0，\u5171\u540c=0.5/0.5。'
    if task == 'A':
        system = '\u4f60\u662f\u5b66\u672f\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u6807\u6ce8\u5668\u3002' + common + '\u77e5\u8bc6\u84dd\u56fe\u53ea\u4f9d\u636e\u539f\u9898\uff0c\u4e0d\u6839\u636e\u5bf9\u8bdd\u53cd\u63a8\u3002\u6bcf\u4e2aTopic\u5fc5\u987b\u5c5e\u4e8e\u5bf9\u5e94KU\uff0c\u6bcf\u4e2aKU\u5fc5\u987b\u5c5e\u4e8e\u5bf9\u5e94KA\u3002evidence_source\u56fa\u5b9a\u4e3aquestion_text\uff0cevidence\u5fc5\u987b\u6765\u81ea\u539f\u9898\u3002'
        payload = {'task': 'A_\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe', 'subject': strict_row['subject'], 'question_text': strict_row['question'], 'candidate_standard_paths': candidates['paths'], 'output_json_schema': schema}
    elif task == 'B':
        system = '\u4f60\u662f\u5b66\u751f\u4f7f\u7528AI\u5b8c\u6210\u4f5c\u4e1a\u7684\u7c97\u7c92\u5ea6\u64cd\u4f5c\u6807\u6ce8\u5668\u3002' + common + '\u4f9d\u636e\u539f\u9898\u3001\u5b8c\u6574\u5bf9\u8bdd\u548c\u63d0\u4ea4\u4fe1\u606f\u72ec\u7acb\u63d0\u53d6\u5b9e\u9645\u64cd\u4f5c\u3002REL\u8868\u793a\u6574\u4f53\u5c5e\u4e8e\u84dd\u56fe\uff1bSUP\u8868\u793a\u6574\u4f53\u4e0d\u5c5e\u4e8e\u84dd\u56fe\uff1bMIXED\u8868\u793a\u540c\u4e00\u4e0d\u53ef\u518d\u62c6\u64cd\u4f5c\u540c\u65f6\u542b\u84dd\u56fe\u5185\u5916\u5185\u5bb9\u3002mapped_ku_ids\u662f\u96c6\u5408\u5f0f\u5b57\u6bb5\uff1a\u540c\u4e00\u4e2aKU ID\u5728\u540c\u4e00\u64cd\u4f5c\u4e2d\u53ea\u80fd\u51fa\u73b0\u4e00\u6b21\uff0c\u7981\u6b62\u91cd\u590d\u3002\u53ea\u4fdd\u7559\u4e0e\u5b8c\u6210\u9898\u76ee\u6709\u5173\u4e14\u6709\u76f4\u63a5\u8bc1\u636e\u7684\u64cd\u4f5c\u3002REL\u7684support_reason\u5fc5\u987b\u662f\u7a7a\u5b57\u7b26\u4e32\uff1b\u53ea\u6709SUP\u6216MIXED\u624d\u80fd\u586b\u5199\u975e\u7a7asupport_reason\u3002\u5b66\u751f\u53ea\u63d0\u51fa\u8bf7\u6c42\u3001\u8ffd\u95ee\u3001\u786e\u8ba4\u6216\u91c7\u7528\uff0c\u4f46\u6ca1\u6709\u8d21\u732e\u5b9e\u8d28\u89e3\u9898\u5185\u5bb9\u65f6\uff0c\u8d23\u4efb\u5224\u4e3aAI\uff0c\u4e0d\u5224\u4e3a\u5b66\u751f\u6216\u5171\u540c\u3002'
        ku_paths = []
        seen_ku_paths = set()
        for path in candidates['paths']:
            key = (path['ka_id'], path['ku_id'])
            if key in seen_ku_paths:
                continue
            seen_ku_paths.add(key)
            ku_paths.append({'ka_id': path['ka_id'], 'ka_name': path['ka_name'], 'ku_id': path['ku_id'], 'ku_name': path['ku_name']})
        payload = {'task': 'B_\u7c97\u7c92\u5ea6\u64cd\u4f5c', 'subject': strict_row['subject'], 'question_text': strict_row['question'], 'dialogue_with_message_ids': strict_row['dialogue'], 'submission': strict_row['submission'], 'confirmed_blueprint': context['blueprint'], 'candidate_standard_ku_paths': ku_paths, 'output_json_schema': schema}
    else:
        system = '\u4f60\u662f\u5b66\u751f\u4f7f\u7528AI\u5b8c\u6210\u4f5c\u4e1a\u7684\u7ec6\u7c92\u5ea6KSA\u6807\u6ce8\u5668\u3002' + common + 'KSA\u53ea\u80fd\u4ece\u5df2\u786e\u8ba4\u64cd\u4f5c\u5185\u90e8\u62c6\u5206\u5230Topic\u5c42\u3002FOCAL\u8868\u793aTopic\u5728\u672c\u9898\u84dd\u56fe\u4e2d\uff0cSUPPORT\u8868\u793a\u4e0d\u5728\u84dd\u56fe\u4e2d\u3002mapping_status\u4e0erole\u662f\u4e24\u4e2a\u4e0d\u540c\u7ef4\u5ea6\uff1a\u53ea\u8981\u6240\u9009KA/KU/Topic\u5b58\u5728\u4e8e\u5f53\u524d\u5b66\u79d1\u6807\u51c6\u5e93\uff0c\u65e0\u8bba\u5b83\u5728\u4e0d\u5728\u9898\u76ee\u84dd\u56fe\u4e2d\uff0cmapping_status\u90fd\u5fc5\u987b\u4e3aSTANDARD_MAPPED\uff1b\u6807\u51c6\u5e93\u4e2d\u5b58\u5728\u4f46\u4e0d\u5728\u9898\u76ee\u84dd\u56fe\u4e2d\u7684KSA\u5e94\u5199STANDARD_MAPPED+SUPPORT\uff0c\u5e76\u4fdd\u7559\u5b8c\u6574\u4e09\u5c42ID\u3002\u53ea\u6709\u5b8c\u5168\u65e0\u6cd5\u6620\u5c04\u5230\u6807\u51c6\u5e93\u7684\u6392\u7248\u3001\u6587\u4ef6\u6574\u7406\u7b49\u652f\u6301\u5185\u5bb9\u624d\u80fd\u5199STANDARD_EXTERNAL+SUPPORT\uff0c\u6b64\u65f6ka_id/ku_id/topic_id\u5fc5\u987b\u5168\u90e8\u4e3anull\u5e76\u8bf4\u660e\u7406\u7531\u3002\u7edd\u4e0d\u80fd\u628a\u2018\u84dd\u56fe\u5916\u2019\u8bef\u5199\u6210STANDARD_EXTERNAL\u3002REL\u53ea\u80fd\u62c6FOCAL\uff0cSUP\u53ea\u80fd\u62c6SUPPORT\uff0cMIXED\u5fc5\u987b\u540c\u65f6\u5305\u542bFOCAL\u548cSUPPORT\u3002\u6bcf\u4e00\u4e2aconfirmed_operations\u4e2d\u7684operation_id\u81f3\u5c11\u8f93\u51fa\u4e00\u6761KSA\uff0c\u4e0d\u5f97\u6f0f\u6389\u64cd\u4f5c\uff0c\u4e5f\u4e0d\u5f97\u521b\u5efa\u65b0operation_id\u3002FOCAL\u7684support_reason\u5fc5\u987b\u4e3a\u7a7a\uff1bSUPPORT\u5fc5\u987b\u975e\u7a7a\u3002ksa_id\u5fc5\u987b\u4e25\u683c\u5199\u6210\u64cd\u4f5cID\u52a0\u987a\u5e8f\u53f7\uff0c\u4f8b\u5982U01\u7684\u7b2c\u4e00\u6761\u662fU01-K01\u3001\u7b2c\u4e8c\u6761\u662fU01-K02\uff0c\u7edd\u5bf9\u4e0d\u80fd\u628aKU ID\u5199\u8fdbksa_id\u3002\u5b66\u751f\u53ea\u63d0\u95ee\u3001\u8ffd\u95ee\u3001\u786e\u8ba4\u6216\u91c7\u7528\u800c\u672a\u8d21\u732e\u5b9e\u8d28\u77e5\u8bc6\u5185\u5bb9\u65f6\uff0c\u8d23\u4efb\u5224\u4e3aAI\u3002'
        per_operation_candidates = {}
        for operation in context['operations']:
            ku_ids = operation.get('mapped_ku_ids', [])
            if not ku_ids:
                operation_paths = candidates['paths']
            else:
                operation_paths = [item for item in candidates['paths'] if item['ku_id'] in ku_ids]
            per_operation_candidates[operation['operation_id']] = {'candidate_standard_paths': operation_paths, 'standard_library_outside_option': {'mapping_status': 'STANDARD_EXTERNAL', 'ka_id': None, 'ku_id': None, 'topic_id': None}}
        payload = {'task': 'C_\u7ec6\u7c92\u5ea6KSA', 'subject': strict_row['subject'], 'question_text': strict_row['question'], 'dialogue_with_message_ids': strict_row['dialogue'], 'submission': strict_row['submission'], 'confirmed_blueprint': context['blueprint'], 'confirmed_operations': context['operations'], 'candidate_standard_paths_by_operation': per_operation_candidates, 'output_json_schema': schema}
    return (system, json.dumps(payload, ensure_ascii=False))

def repair_guidance(task: str, issues: list[dict]) -> str:
    """Return deterministic rule reminders for internal retry only."""
    hints = []
    if task == 'B' and any((issue.get('path', '').endswith('.mapped_ku_ids') and 'non-unique' in issue.get('message', '') for issue in issues)):
        hints.append('\u53bb\u91cd\u4fee\u590d\uff1amapped_ku_ids\u4e2d\u6bcf\u4e2aKU ID\u53ea\u80fd\u4fdd\u7559\u4e00\u6b21\uff0c\u5fc5\u987b\u5220\u9664\u6240\u6709\u91cd\u590d\u9879\u3002')
    if task == 'C' and any((issue.get('path', '').endswith(('.ka_id', '.ku_id', '.topic_id')) and 'null' in issue.get('message', '') for issue in issues)):
        hints.append('\u6620\u5c04\u72b6\u6001\u4fee\u590d\uff1a\u82e5\u4fdd\u7559\u4efb\u4e00KA/KU/Topic ID\uff0cmapping_status\u5fc5\u987b\u6539\u4e3aSTANDARD_MAPPED\uff1b\u82e5mapping_status\u4fdd\u7559STANDARD_EXTERNAL\uff0c\u5219\u4e09\u4e2aID\u5fc5\u987b\u5168\u90e8\u6539\u4e3anull\u3002\u84dd\u56fe\u5916\u4f46\u6807\u51c6\u5e93\u5185\u7684\u5185\u5bb9\u5e94\u4f7f\u7528STANDARD_MAPPED+SUPPORT\u3002')
    if any((issue.get('code') in {'INVALID_STANDARD_ID', 'INVALID_PARENT', 'OUTSIDE_CANDIDATES'} for issue in issues)):
        hints.append('\u5c42\u7ea7\u4fee\u590d\uff1a\u540c\u4e00\u8f93\u51fa\u7684KA\u3001KU\u3001Topic\u5fc5\u987b\u9010\u5b57\u590d\u5236\u81ea\u540c\u4e00\u6761\u5019\u9009\u8def\u5f84\uff0c\u7981\u6b62\u8de8\u8def\u5f84\u62fc\u63a5\u3002')
    return ''.join(hints)

def parse_json_strict(raw: str) -> tuple[dict | None, str | None]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        return (None, f'{exc.msg} (line={exc.lineno}, col={exc.colno})')
    if not isinstance(value, dict):
        return (None, '\u9876\u5c42\u8f93\u51fa\u4e0d\u662fJSON\u5bf9\u8c61')
    return (value, None)

def candidate_violations(task: str, output: dict, candidates: dict) -> list[dict]:
    allowed = {'ka_id': {item['id'] for item in candidates['KA']}, 'ku_id': {item['id'] for item in candidates['KU']}, 'topic_id': {item['id'] for item in candidates['TOPIC']}}
    issues = []
    root = {'A': 'blueprint', 'B': 'operations', 'C': 'ksa'}[task]
    for index, item in enumerate(output.get(root, [])):
        fields = ('ka_id', 'ku_id', 'topic_id') if task in {'A', 'C'} else ()
        for field in fields:
            if item.get('mapping_status') == 'STANDARD_EXTERNAL' and item.get(field) is None:
                continue
            if item.get(field) not in allowed[field]:
                issues.append({'path': f'$.{root}[{index}].{field}', 'value': item.get(field)})
        if task == 'B':
            for ku_id in item.get('mapped_ku_ids', []):
                if ku_id not in allowed['ku_id']:
                    issues.append({'path': f'$.operations[{index}].mapped_ku_ids', 'value': ku_id})
    return issues

def gold_summary(task: str, gold: dict, predicted: dict | None) -> dict:
    if predicted is None:
        return {'exact_match': False}
    root = {'A': 'blueprint', 'B': 'operations', 'C': 'ksa'}[task]
    if task == 'A':
        gold_values = {item['topic_id'] for item in gold[root]}
        pred_values = {item.get('topic_id') for item in predicted.get(root, [])}
        label = 'topic_ids'
    elif task == 'B':
        gold_values = {(item['operation'], item['relevance'], item['responsibility']) for item in gold[root]}
        pred_values = {(item.get('operation'), item.get('relevance'), item.get('responsibility')) for item in predicted.get(root, [])}
        label = 'operation_label_tuples'
    else:
        gold_values = {(item['ksa'], item['role'], item['responsibility']) for item in gold[root]}
        pred_values = {(item.get('ksa'), item.get('role'), item.get('responsibility')) for item in predicted.get(root, [])}
        label = 'ksa_label_tuples'
    return {'exact_match': gold_values == pred_values, 'comparison': label, 'gold_count': len(gold_values), 'predicted_count': len(pred_values)}

def main() -> None:
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    parser = argparse.ArgumentParser()
    parser.add_argument('--unit-id', default=DEFAULT_UNIT)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--tasks', default='A', help='A,B,C\u7684\u9017\u53f7\u7ec4\u5408\uff0c\u6216PIPELINE')
    parser.add_argument('--max-new-tokens', type=int, default=1536)
    parser.add_argument('--max-attempts', type=int, default=2)
    args = parser.parse_args()
    stage1 = load_module('stage1_smoke', RETRIEVER_PATH)
    validator = load_module('strict_validator_smoke', SCHEMA_ROOT / 'validate_records.py')
    adapter = load_module('strict_adapter_smoke', ADAPTER_PATH)
    row = load_row(args.unit_id)
    subject = row['metadata']['subject']
    question = question_text(row)
    candidates = compact_candidates(stage1, subject, question)
    strict_row = adapter.adapt_row(row)
    strict_row['question'] = question
    pipeline_mode = args.tasks.strip().upper() == 'PIPELINE'
    tasks = ['A', 'B', 'C'] if pipeline_mode else [value.strip().upper() for value in args.tasks.split(',') if value.strip()]
    if not tasks or any((value not in {'A', 'B', 'C'} for value in tasks)):
        raise SystemExit('--tasks\u53ea\u5141\u8bb8A\u3001B\u3001C\u7684\u9017\u53f7\u7ec4\u5408\uff0c\u6216PIPELINE')
    started = time.time()
    tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True)
    quantization = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_quant_type='nf4', bnb_4bit_compute_dtype=torch.float16, bnb_4bit_use_double_quant=True)
    model = AutoModelForCausalLM.from_pretrained(str(MODEL_PATH), local_files_only=True, device_map='auto', quantization_config=quantization, dtype=torch.float16, low_cpu_mem_usage=True).eval()
    load_seconds = time.time() - started
    valid_message_ids = [item['message_id'] for item in strict_row['dialogue']]
    valid_message_ids.extend((str(item['source_id']) for item in strict_row.get('submission', {}).get('documents', []) if item.get('source_id')))
    results = []
    pipeline_blueprint = None
    pipeline_operations = None
    for task in tasks:
        if pipeline_mode:
            context = {'blueprint': pipeline_blueprint or [], 'operations': pipeline_operations or [], 'valid_message_ids': valid_message_ids}
        else:
            context = {'blueprint': strict_row['A']['blueprint'], 'operations': strict_row['B']['operations'], 'valid_message_ids': valid_message_ids}
        system, user = prompt_for_task(task, strict_row, candidates, context)
        messages = [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}]
        attempts = []
        parsed = None
        raw = ''
        parse_error = None
        validation = None
        candidate_errors = []
        encoded = None
        output_ids = None
        generation_seconds = 0.0
        for attempt_number in range(1, max(1, args.max_attempts) + 1):
            prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            encoded = tokenizer(prompt, return_tensors='pt').to(model.device)
            generation_started = time.time()
            with torch.inference_mode():
                generated = model.generate(**encoded, max_new_tokens=args.max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
            output_ids = generated[0, encoded['input_ids'].shape[1]:]
            raw = tokenizer.decode(output_ids, skip_special_tokens=True).strip()
            generation_seconds = time.time() - generation_started
            parsed, parse_error = parse_json_strict(raw)
            if parsed is None:
                validation = {'valid': False, 'route': 'internal_retry', 'issues': [{'code': 'INVALID_JSON', 'path': '$', 'message': parse_error, 'severity': 'retry'}]}
                candidate_errors = []
            else:
                validation = validator.validate(task, subject, parsed, context if task != 'A' else None)
                candidate_errors = candidate_violations(task, parsed, candidates)
                if candidate_errors:
                    validation = {'valid': False, 'route': 'internal_retry', 'issues': validation['issues'] + [{'code': 'OUTSIDE_CANDIDATES', 'path': item['path'], 'message': str(item['value']), 'severity': 'retry'} for item in candidate_errors]}
            attempts.append({'attempt': attempt_number, 'input_tokens': int(encoded['input_ids'].shape[1]), 'output_tokens': int(output_ids.shape[0]), 'generation_seconds': round(generation_seconds, 3), 'strict_json_valid': parsed is not None, 'validation': validation, 'raw_output': raw})
            if validation['valid']:
                break
            missing_operation_only = bool(validation['issues']) and all((issue['code'] == 'COARSE_FINE_MISMATCH' and '\u5b9e\u9645\u4e3a[]' in issue['message'] for issue in validation['issues']))
            if validation['route'] != 'internal_retry' and (not missing_operation_only):
                break
            concise = [{key: issue[key] for key in ('code', 'path', 'message')} for issue in validation['issues']]
            guidance = repair_guidance(task, validation['issues'])
            messages.extend([{'role': 'assistant', 'content': raw}, {'role': 'user', 'content': '\u4e0a\u4e00\u6b21\u8f93\u51fa\u672a\u901a\u8fc7\u5185\u90e8\u6821\u9a8c\u3002\u8bf7\u4f9d\u636e\u539f\u59cb\u8f93\u5165\u91cd\u65b0\u751f\u6210\u5b8c\u6574JSON\uff0c\u4e0d\u8981\u53ea\u8f93\u51fa\u5c40\u90e8\u4fee\u8865\uff0c\u4e0d\u8981\u89e3\u91ca\u3002' + guidance + '\u5fc5\u987b\u4fee\u590d\u4ee5\u4e0b\u9519\u8bef\uff1a' + json.dumps(concise, ensure_ascii=False)}])
        results.append({'task': task, 'input_tokens': int(encoded['input_ids'].shape[1]), 'output_tokens': int(output_ids.shape[0]), 'generation_seconds': round(generation_seconds, 3), 'strict_json_valid': parsed is not None, 'json_error': parse_error, 'schema_validation': validation, 'candidate_violations': candidate_errors, 'gold_comparison': gold_summary(task, strict_row[task], parsed), 'attempt_count': len(attempts), 'first_attempt_valid': attempts[0]['validation']['valid'], 'attempts': attempts, 'raw_output': raw, 'parsed_output': parsed})
        if pipeline_mode:
            if not validation['valid']:
                break
            if task == 'A':
                pipeline_blueprint = parsed['blueprint']
            elif task == 'B':
                pipeline_operations = parsed['operations']
    record = {'run_type': 'unfinetuned_qwen3_4b_local_smoke_pipeline' if pipeline_mode else 'unfinetuned_qwen3_4b_local_smoke_independent_ABC', 'unit_id': args.unit_id, 'subject': subject, 'model': str(MODEL_PATH), 'quantization': 'bnb_nf4_4bit', 'load_seconds': round(load_seconds, 3), 'pipeline_completed': pipeline_mode and len(results) == 3 and all((item['schema_validation']['valid'] for item in results)), 'results': results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'run_type': record['run_type'], 'unit_id': record['unit_id'], 'load_seconds': record['load_seconds'], 'results': [{key: result[key] for key in ('task', 'input_tokens', 'output_tokens', 'generation_seconds', 'strict_json_valid', 'schema_validation', 'candidate_violations', 'gold_comparison')} for result in results]}, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
