"""Fresh original-protocol smoke primitives; no model import at module load."""
import hashlib,json,math,random,itertools
from pathlib import Path

def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def rows(p):return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8*1024**2),b''):h.update(b)
    return h.hexdigest()
def canon(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)
def digest(x):return hashlib.sha256(canon(x).encode()).hexdigest()
def save(p,x):
    with Path(p).open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def sid(r):return str(r.get('sample_id') or (r.get('metadata') or {}).get('sample_id') or '')
def views(arm,changed,enabled=True):
    need(arm in ('control','repaired') and type(changed) is bool and type(enabled) is bool,'VIEW_ARGUMENT')
    if arm=='control' or not changed or not enabled:return [('control',1.)]
    return [('control',.75),('repaired',.25)]
def layout(batch,rank):
    need(len(batch) in (4,8) and rank in (0,1),'TWO_RANK_LAYOUT')
    return batch[rank::2]
def sync_here(offset,j,views_count,micros):
    need(micros in (2,4) and offset in range(micros) and views_count in (1,2) and j in range(views_count),'SYNC_ARGUMENT')
    return offset==micros-1 and j==views_count-1
def select(index,schedule):
    by={r['sample_id']:r for r in index if r['partition']=='train'}
    batches=schedule[0]['batches'][:-1]
    mixed=[(i,b) for i,b in enumerate(batches) if {by[s]['messages_changed'] for s in b}=={False,True}]
    need(bool(mixed),'NO_MIXED_BATCH')
    i,b=min(mixed,key=lambda ib:(-sum(by[s]['candidate_numeric_tokens'] for s in ib[1]),ib[0]))
    old=min(by,key=lambda s:(-by[s]['control_numeric_tokens'],s))
    new=min((s for s in by if by[s]['messages_changed']),key=lambda s:(-by[s]['candidate_numeric_tokens'],s))
    unchanged=min((s for s in by if not by[s]['messages_changed']),key=lambda s:(by[s]['control_numeric_tokens'],s))
    # Each rank sees both maxima, followed by another backward; tail has unequal view counts.
    return {'mixed_original_step':i+1,'old_max':old,'new_max':new,'probe':unchanged,
            'batches':[b,b,[old,new,new,old,old,new,new,old],[new,unchanged,unchanged,new]]}
def parameter_hash(model):
    h=hashlib.sha256();n=0
    for name,p in model.named_parameters():
        if p.requires_grad:
            a=p.detach().cpu().contiguous();h.update(name.encode());h.update(str(a.dtype).encode());h.update(str(tuple(a.shape)).encode());h.update(a.view(__import__('torch').uint8).numpy().tobytes());n+=a.numel()
    return h.hexdigest(),n
def selftest():
    checks=0
    for n in (4,8):
        for flags in itertools.product((False,True),repeat=n):
            for arm in ('control','repaired'):
                for enabled in (False,True):
                    for rank in (0,1):
                        ids=layout(list(range(n)),rank);syncs=0;weight=0
                        for o,i in enumerate(ids):
                            vv=views(arm,flags[i],enabled);need(sum(w for _,w in vv)==1,'UNIT_WEIGHT')
                            weight+=sum(w/len(ids) for _,w in vv)
                            syncs+=sum(sync_here(o,j,len(vv),len(ids)) for j in range(len(vv)))
                        need(syncs==1 and weight==1,'RANK_NORMALIZATION');checks+=1
    need(views('control',True)==[('control',1.)],'SINGLE_VIEW_CONTROL')
    rejected=0
    for f in (lambda:layout([1]*6,0),lambda:layout([1]*8,2),lambda:views('bad',True),lambda:sync_here(3,0,1,2)):
        try:f()
        except RuntimeError:rejected+=1
    need(rejected==4,'NEGATIVE_GUARD')
    return {'status':'PASS_PURE_LAYOUT_ONLY','cases':checks,'invalid_cases_rejected':rejected,'GPU_tested':False}
def cpu_autograd():
    import torch
    errors=[]
    for n in (4,8):
        for arm in ('control','repaired'):
            flags=[i%3!=0 for i in range(n)]
            def loss(t,i,a):
                x=torch.arange(30,dtype=t.dtype).reshape(10,3)/31+i*.017
                if a=='repaired':x=x.sin()+.1
                p=(x@t).softmax(0);q=torch.zeros_like(p);q[3]=.7;q[4]=.3
                return -.1*(q*p.log()).sum()+(p.cumsum(0)[:-1]-q.cumsum(0)[:-1]).abs().sum()/9
            t=torch.tensor([.2,-.3,.7],dtype=torch.float64,requires_grad=True)
            def objective(z):return sum(w*loss(z,i,a)/n for i in range(n) for a,w in views(arm,flags[i]))
            g=torch.autograd.grad(objective(t),t)[0];parts=[]
            for rank in (0,1):
                z=t.detach().clone().requires_grad_();ii=layout(list(range(n)),rank)
                for i in ii:
                    for a,w in views(arm,flags[i]):(w*loss(z,i,a)/len(ii)).backward()
                parts.append(z.grad)
            errors.append(float((g-(parts[0]+parts[1])/2).abs().max()))
            for j in range(3):
                hi=t.detach().clone();lo=hi.clone();hi[j]+=1e-5;lo[j]-=1e-5
                errors.append(abs(float((objective(hi)-objective(lo))/2e-5-g[j])))
    need(max(errors)<1e-8 and not torch.cuda.is_initialized(),'CPU_GRADIENT_TEST')
    return {'status':'PASS_CPU_AUTOGRAD_FULL_AND_TAIL','maximum_error':max(errors),'GPU_tested':False}
