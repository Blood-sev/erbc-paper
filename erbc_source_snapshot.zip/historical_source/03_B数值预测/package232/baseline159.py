#!/usr/bin/env python3
"""NTL-Wasserstein baseline and RAFT+NTL candidate for B regression.

Both methods use the same Qwen3-4B base, LoRA configuration, frozen
multidisciplinary 1088/148 split, internal student-disjoint development split,
single-digit numeric support, and posterior-expectation decoder.  Therefore
the only controlled difference is the training objective:

* NTL-Wasserstein: soft numeric-token CE plus ordered Wasserstein-1 loss.
* RAFT+NTL: RAFT squared regression loss plus both NTL terms.

The NTL implementation is an explicit continuous-label adaptation of the ICML
2025 Number Token Loss paper; it is not presented as an exact code reproduction.
"""

from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import importlib.util
import json
import math
import os
import platform
import random
import shutil
import time
from collections import Counter, defaultdict
from pathlib import Path


VERSION = "lora_b_ntl_raft_ntl_unified_v1"
SPLIT_VERSION = "lora_b_recent_r2ccp_raft_unified_baselines_v1"
NTL_VERSION = "qwen3_4b_lora_b_ntl_wasserstein_baseline_v1"
RAFT_NTL_VERSION = "qwen3_4b_lora_b_raft_ntl_joint_candidate_v1"
TASK = "B_HOLISTIC_RELIEF_SCALAR_REGRESSION"
COMPUTER = "01_计算机科学"
NTL_PAPER = {
    "title": "Regress, Don't Guess: A Regression-like Loss on Number Tokens for Language Models",
    "authors": "Raphael Zausinger, Simon Klug, Tim Pearce, David Lindner",
    "venue": "ICML 2025 (PMLR 267)",
    "url": "https://proceedings.mlr.press/v267/zausinger25a.html",
    "adaptation": "Continuous-label NTL: adjacent-token soft targets, numeric token CE, and ordered Wasserstein-1 distance on digit probabilities.",
}
RAFT_PAPER = {
    "title": "Better Autoregressive Regression with LLMs via Regression-Aware Fine-Tuning",
    "authors": "Michal Lukasik, Zhao Meng, Harikrishna Narasimhan, Yin-Wen Chang, Aditya Krishna Menon, Felix Yu, Sanjiv Kumar",
    "venue": "ICLR 2025",
    "url": "https://proceedings.iclr.cc/paper_files/paper/2025/hash/ae3bb0adcdce28afb5f7e86a79b6cffa-Abstract-Conference.html",
    "adaptation": "Single-digit RAFT: restrict the next-token distribution to digits 0..9 and map its Bayes expectation linearly to [0,1].",
}
NUMERIC_DIGITS = 10
NUMERIC_INSTRUCTION = (
    "\n本方法把整体减负率线性映射到单个数字槽：0表示0%，9表示100%。"
    "模型只在该数字槽的0至9概率分布上计算连续期望，不进行随机采样。"
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise SystemExit(f"Safety stop: invalid JSONL {path}:{line_number}") from exc
    return rows


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_jsonl(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def extract_ids(value) -> list[int]:
    ids = value["input_ids"] if hasattr(value, "keys") else value
    if hasattr(ids, "tolist"):
        ids = ids.tolist()
    if ids and isinstance(ids[0], list):
        ids = ids[0]
    return list(ids)


def unit_id(row: dict) -> str:
    return str((row.get("metadata") or {}).get("unit_id") or row.get("unit_id") or "")


def subject(row: dict) -> str:
    return str((row.get("metadata") or {}).get("subject") or row.get("subject") or "")


def group_id(row: dict) -> str:
    metadata = row.get("metadata") or {}
    explicit = str(metadata.get("student_id") or "").strip()
    if explicit:
        return explicit
    uid = unit_id(row)
    prefix = uid.split("__", 1)[0]
    if len(prefix) >= 2 and prefix[0] == "S" and prefix[1:].isdigit():
        return prefix
    return uid


def validate_rows(rows: list[dict], split: str, expected_rows: int, expected_units: int) -> None:
    if len(rows) != expected_rows:
        raise SystemExit(f"Safety stop: expected {expected_rows} {split} rows, got {len(rows)}")
    units = set()
    samples = set()
    for row in rows:
        metadata = row.get("metadata") or {}
        uid = unit_id(row)
        sid = str(metadata.get("sample_id") or "")
        target = row.get("target_fraction")
        messages = row.get("messages") or []
        if metadata.get("task") != TASK or metadata.get("split") != split:
            raise SystemExit(f"Safety stop: identity drift: {uid}")
        if [message.get("role") for message in messages] != ["system", "user"]:
            raise SystemExit(f"Safety stop: message-role drift: {uid}")
        if not uid or not sid or sid in samples:
            raise SystemExit(f"Safety stop: missing/duplicate identity: {uid}/{sid}")
        if isinstance(target, bool) or not isinstance(target, (int, float)) or not 0.0 <= float(target) <= 1.0:
            raise SystemExit(f"Safety stop: invalid target: {uid}/{target}")
        payload = json.loads(messages[1]["content"])
        forbidden = {"target", "target_fraction", "gold", "label", "relief_rate", "relief_rate_percent", "subject"}
        if forbidden & set(payload):
            raise SystemExit(f"Safety stop: model-input leakage: {uid}")
        units.add(uid)
        samples.add(sid)
    if len(units) != expected_units:
        raise SystemExit(f"Safety stop: expected {expected_units} {split} units, got {len(units)}")


def stable_bucket(row: dict) -> tuple[str, int]:
    target = float(row["target_fraction"])
    return subject(row), min(4, int(target * 5.0))


def prepare(args) -> None:
    output = Path(args.output_json)
    if output.exists():
        raise SystemExit(f"Safety stop: output exists: {output}")
    train_path = Path(args.train_jsonl)
    validation_path = Path(args.validation_jsonl)
    train_rows = read_jsonl(train_path)
    validation_rows = read_jsonl(validation_path)
    validate_rows(train_rows, "train", args.expected_train, args.expected_train_units)
    validate_rows(validation_rows, "validation", args.expected_validation, args.expected_validation_units)
    train_groups = {group_id(row) for row in train_rows}
    validation_groups = {group_id(row) for row in validation_rows}
    overlap = train_groups & validation_groups
    if overlap:
        raise SystemExit(f"Safety stop: train/validation group leakage: {sorted(overlap)[:10]}")

    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in train_rows:
        grouped[group_id(row)].append(row)
    strata: dict[tuple[str, int], list[str]] = defaultdict(list)
    for gid, rows in grouped.items():
        representative = sorted(rows, key=lambda item: unit_id(item))[0]
        strata[stable_bucket(representative)].append(gid)
    development_groups = set()
    stratum_summary = []
    for key in sorted(strata):
        values = sorted(
            strata[key],
            key=lambda value: hashlib.sha256(f"{args.seed}:{value}".encode()).hexdigest(),
        )
        count = max(1, int(round(len(values) * args.development_fraction)))
        count = min(count, max(1, len(values) - 1)) if len(values) > 1 else 0
        selected = values[:count]
        development_groups.update(selected)
        stratum_summary.append({
            "subject": key[0], "target_bin": key[1], "groups": len(values),
            "development_groups": len(selected),
        })
    train_part = [row for row in train_rows if group_id(row) not in development_groups]
    development_part = [row for row in train_rows if group_id(row) in development_groups]
    if not train_part or not development_part:
        raise SystemExit("Safety stop: empty internal train/development partition")
    if {group_id(row) for row in train_part} & {group_id(row) for row in development_part}:
        raise SystemExit("Safety stop: internal group leakage")
    manifest = {
        "status": "PASS",
        "version": VERSION,
        "seed": args.seed,
        "policy": "deterministic subject-by-target-bin group holdout from training only",
        "development_fraction_requested": args.development_fraction,
        "source": {
            "train_jsonl": str(train_path.resolve()),
            "train_sha256": sha256(train_path),
            "validation_jsonl": str(validation_path.resolve()),
            "validation_sha256": sha256(validation_path),
        },
        "counts": {
            "source_train_rows": len(train_rows),
            "source_train_units": len({unit_id(row) for row in train_rows}),
            "internal_train_rows": len(train_part),
            "internal_train_units": len({unit_id(row) for row in train_part}),
            "internal_train_groups": len({group_id(row) for row in train_part}),
            "development_rows": len(development_part),
            "development_units": len({unit_id(row) for row in development_part}),
            "development_groups": len(development_groups),
            "official_validation_rows": len(validation_rows),
            "official_validation_groups": len(validation_groups),
        },
        "development_group_ids": sorted(development_groups),
        "strata": stratum_summary,
        "official_validation_locked": True,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    write_json(output, manifest)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def prediction_metrics(rows: list[dict]) -> dict:
    if not rows:
        return {"records": 0}
    gold = [float(row["target_fraction"]) for row in rows]
    prediction = [float(row["prediction_fraction"]) for row in rows]
    errors = [p - g for p, g in zip(prediction, gold)]
    gold_mean = sum(gold) / len(gold)
    pred_mean = sum(prediction) / len(prediction)
    covariance = sum((g - gold_mean) * (p - pred_mean) for g, p in zip(gold, prediction))
    gold_ss = sum((g - gold_mean) ** 2 for g in gold)
    pred_ss = sum((p - pred_mean) ** 2 for p in prediction)

    def ranks(values: list[float]) -> list[float]:
        order = sorted(range(len(values)), key=lambda index: values[index])
        result = [0.0] * len(values)
        start = 0
        while start < len(order):
            stop = start + 1
            while stop < len(order) and values[order[stop]] == values[order[start]]:
                stop += 1
            rank = (start + stop - 1) / 2.0 + 1.0
            for position in range(start, stop):
                result[order[position]] = rank
            start = stop
        return result

    def correlation(left: list[float], right: list[float]) -> float:
        lm = sum(left) / len(left)
        rm = sum(right) / len(right)
        numerator = sum((a - lm) * (b - rm) for a, b in zip(left, right))
        denominator = math.sqrt(sum((a - lm) ** 2 for a in left) * sum((b - rm) ** 2 for b in right))
        return numerator / denominator if denominator else 0.0

    return {
        "records": len(rows),
        "mae_percent_points": sum(abs(error) for error in errors) / len(errors) * 100.0,
        "rmse_percent_points": math.sqrt(sum(error * error for error in errors) / len(errors)) * 100.0,
        "bias_percent_points": sum(errors) / len(errors) * 100.0,
        "r2": 1.0 - sum(error * error for error in errors) / gold_ss if gold_ss else 0.0,
        "pearson_r": covariance / math.sqrt(gold_ss * pred_ss) if gold_ss and pred_ss else 0.0,
        "spearman_rho": correlation(ranks(gold), ranks(prediction)),
        "distinct_predictions_rounded_6dp": len({round(value * 100.0, 6) for value in prediction}),
        "distinct_predictions_rounded_2dp": len({round(value * 100.0, 2) for value in prediction}),
        "exact_0_50_100": sum(value * 100.0 in {0.0, 50.0, 100.0} for value in prediction),
        "prediction_min_percent": min(prediction) * 100.0,
        "prediction_max_percent": max(prediction) * 100.0,
        "prediction_mean_percent": pred_mean * 100.0,
    }


def split_metrics(rows: list[dict]) -> dict:
    return {
        "overall": prediction_metrics(rows),
        "computer_science": prediction_metrics([row for row in rows if row["subject"] == COMPUTER]),
    }


def setup_distributed():
    import torch
    import torch.distributed as dist

    world_size = int(os.environ.get("WORLD_SIZE", "1"))
    rank = int(os.environ.get("RANK", "0"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if world_size > 1:
        dist.init_process_group(backend="nccl")
    if not torch.cuda.is_available():
        raise SystemExit("Safety stop: CUDA unavailable")
    torch.cuda.set_device(local_rank)
    return rank, world_size, local_rank, torch.device(f"cuda:{local_rank}")


def barrier(world_size: int) -> None:
    import torch.distributed as dist

    if world_size > 1:
        dist.barrier()


def unwrap(model):
    from torch.nn.parallel import DistributedDataParallel

    return model.module if isinstance(model, DistributedDataParallel) else model


def trainable_state(model) -> dict[str, object]:
    return {
        name: parameter.detach().cpu().clone()
        for name, parameter in unwrap(model).named_parameters() if parameter.requires_grad
    }


def restore_trainable_state(model, state: dict[str, object]) -> None:
    import torch

    current = dict(unwrap(model).named_parameters())
    if set(state) != {name for name, parameter in current.items() if parameter.requires_grad}:
        raise RuntimeError("trainable state contract drift")
    with torch.no_grad():
        for name, value in state.items():
            current[name].copy_(value.to(device=current[name].device, dtype=current[name].dtype))


def trainable_signature(model) -> tuple[float, int]:
    import torch

    total = 0.0
    count = 0
    with torch.no_grad():
        for parameter in unwrap(model).parameters():
            if parameter.requires_grad:
                total += float(parameter.detach().float().abs().sum().item())
                count += parameter.numel()
    return total, count


def cosine_lambda(step: int, total: int, warmup: int) -> float:
    if warmup and step < warmup:
        return max(1e-8, step / warmup)
    progress = (step - warmup) / max(1, total - warmup)
    return max(0.0, 0.5 * (1.0 + math.cos(math.pi * progress)))


def rank_groups(rows: list[dict], world_size: int, seed: int, epoch: int) -> list[list[int]]:
    values = list(range(len(rows)))
    random.Random(seed + epoch).shuffle(values)
    while len(values) % world_size:
        values.append(values[len(values) % max(1, len(rows))])
    return [values[index:index + world_size] for index in range(0, len(values), world_size)]


def make_numeric_messages(row: dict) -> list[dict]:
    messages = [dict(message) for message in row["messages"]]
    messages[0] = dict(messages[0])
    messages[0]["content"] = str(messages[0]["content"]) + NUMERIC_INSTRUCTION
    return messages


def tokenizer_digit_ids(tokenizer) -> list[int]:
    ids = []
    for digit in range(NUMERIC_DIGITS):
        encoded = tokenizer.encode(str(digit), add_special_tokens=False)
        if len(encoded) != 1:
            raise RuntimeError(f"digit {digit} is not one token: {encoded}")
        ids.append(int(encoded[0]))
    if len(set(ids)) != NUMERIC_DIGITS:
        raise RuntimeError(f"digit-token collision: {ids}")
    return ids


def tokenize_row(tokenizer, row: dict, method: str, device):
    import torch

    messages = make_numeric_messages(row)
    value = tokenizer.apply_chat_template(
        messages,
        tokenize=True,
        add_generation_prompt=True,
    )
    ids = extract_ids(value)
    if not ids or len(ids) > 48512:
        raise RuntimeError(f"prompt-token gate failed: {unit_id(row)}, {len(ids)}")
    input_ids = torch.tensor([ids], dtype=torch.long, device=device)
    attention_mask = torch.ones_like(input_ids)
    target = torch.tensor([float(row["target_fraction"])], dtype=torch.float32, device=device)
    return input_ids, attention_mask, target


def method_prediction(model, input_ids, attention_mask, method: str, anchors, digit_ids):
    import torch

    logits = model(input_ids=input_ids, attention_mask=attention_mask).logits.float()
    if logits.ndim != 3 or logits.shape[0] != 1:
        raise RuntimeError(f"numeric output-shape drift: {tuple(logits.shape)}")
    selected = logits[:, -1, digit_ids]
    probabilities = torch.softmax(selected, dim=-1)
    prediction = (probabilities * anchors.unsqueeze(0)).sum(dim=-1)
    return prediction, probabilities


def adjacent_digit_target(target, digit_count: int):
    import torch

    scaled = target.clamp(0.0, 1.0) * float(digit_count - 1)
    lower = torch.floor(scaled).long()
    upper = torch.ceil(scaled).long()
    upper_weight = scaled - lower.float()
    lower_weight = 1.0 - upper_weight
    soft = torch.zeros((target.shape[0], digit_count), dtype=torch.float32, device=target.device)
    soft.scatter_add_(1, lower.unsqueeze(1), lower_weight.unsqueeze(1))
    soft.scatter_add_(1, upper.unsqueeze(1), upper_weight.unsqueeze(1))
    return soft


def ntl_components(probabilities, target):
    import torch

    soft_target = adjacent_digit_target(target, probabilities.shape[-1])
    numeric_ce = -(soft_target * probabilities.clamp_min(1e-12).log()).sum(dim=-1).mean()
    # One-dimensional W1 on an equally spaced ordered support.
    wasserstein = (
        torch.abs(probabilities.cumsum(dim=-1) - soft_target.cumsum(dim=-1))[:, :-1].sum(dim=-1)
        / float(probabilities.shape[-1] - 1)
    ).mean()
    return numeric_ce, wasserstein, soft_target


def method_loss(prediction, probabilities, target, method: str, args):
    import torch
    import torch.nn.functional as F

    numeric_ce, wasserstein, _ = ntl_components(probabilities, target)
    raft_mse = F.mse_loss(prediction, target, reduction="mean")
    loss = args.ntl_ce_weight * numeric_ce + args.ntl_wasserstein_weight * wasserstein
    if method == "raft_ntl":
        loss = loss + args.raft_weight * raft_mse
    return loss


def distributed_predictions(model, tokenizer, rows, method, anchors, digit_ids, device, rank, world_size):
    import torch
    import torch.distributed as dist

    model.eval()
    local = []
    with torch.inference_mode():
        for index in range(rank, len(rows), world_size):
            row = rows[index]
            input_ids, attention_mask, target = tokenize_row(tokenizer, row, method, device)
            prediction, probabilities = method_prediction(
                model, input_ids, attention_mask, method, anchors, digit_ids
            )
            entropy = -(probabilities * probabilities.clamp_min(1e-12).log()).sum(dim=-1)
            local.append({
                "unit_id": unit_id(row),
                "subject": subject(row),
                "target_fraction": float(target.item()),
                "prediction_fraction": float(prediction.item()),
                "distribution_entropy_nats": float(entropy.item()),
            })
            del input_ids, attention_mask, target, prediction, probabilities, entropy
    if world_size > 1:
        gathered = [None for _ in range(world_size)]
        dist.all_gather_object(gathered, local)
        combined = [item for shard in gathered for item in shard]
    else:
        combined = local
    combined.sort(key=lambda item: item["unit_id"])
    expected_coverage = Counter(unit_id(row) for row in rows)
    observed_coverage = Counter(row["unit_id"] for row in combined)
    if len(combined) != len(rows) or observed_coverage != expected_coverage:
        raise RuntimeError("distributed prediction coverage drift")
    model.train()
    return combined


def train_method(args, method: str) -> None:
    import peft
    import torch
    import torch.distributed as dist
    import transformers
    from peft import LoraConfig, TaskType, get_peft_model
    from torch.nn.parallel import DistributedDataParallel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    rank, world_size, local_rank, device = setup_distributed()
    if world_size != args.world_size:
        raise SystemExit(f"Safety stop: expected world_size={args.world_size}, got {world_size}")
    free_bytes, _ = torch.cuda.mem_get_info(device)
    if free_bytes / 1024 ** 3 < args.minimum_free_gib:
        raise SystemExit(f"Safety stop: insufficient free GPU memory on rank {rank}")
    train_path = Path(args.train_jsonl)
    validation_path = Path(args.validation_jsonl)
    split_path = Path(args.split_manifest)
    train_rows_all = read_jsonl(train_path)
    validation_rows = read_jsonl(validation_path)
    validate_rows(train_rows_all, "train", args.expected_train, args.expected_train_units)
    validate_rows(validation_rows, "validation", args.expected_validation, args.expected_validation_units)
    split = json.loads(split_path.read_text(encoding="utf-8"))
    if split.get("status") != "PASS" or split.get("version") not in {SPLIT_VERSION, VERSION}:
        raise SystemExit("Safety stop: invalid split manifest")
    if split["source"]["train_sha256"] != sha256(train_path) or split["source"]["validation_sha256"] != sha256(validation_path):
        raise SystemExit("Safety stop: split/data provenance drift")
    development_groups = set(split["development_group_ids"])
    train_rows = [row for row in train_rows_all if group_id(row) not in development_groups]
    development_rows = [row for row in train_rows_all if group_id(row) in development_groups]
    if len(train_rows) != split["counts"]["internal_train_rows"] or len(development_rows) != split["counts"]["development_rows"]:
        raise SystemExit("Safety stop: internal partition drift")

    output_dir = Path(args.output_dir).resolve()
    partial = output_dir.with_name(output_dir.name + ".partial")
    if rank == 0:
        if output_dir.exists() or partial.exists():
            raise SystemExit(f"Safety stop: output exists: {output_dir} or {partial}")
        partial.mkdir(parents=True)
    barrier(world_size)

    seed = args.seed
    random.seed(seed + rank)
    torch.manual_seed(seed + rank)
    torch.cuda.manual_seed_all(seed + rank)
    torch.backends.cuda.enable_flash_sdp(True)
    torch.backends.cuda.enable_mem_efficient_sdp(True)
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    dtype = torch.bfloat16
    base = AutoModelForCausalLM.from_pretrained(
        args.model, local_files_only=True, dtype=dtype,
        attn_implementation="flash_attention_2", low_cpu_mem_usage=True,
    )
    task_type = TaskType.CAUSAL_LM
    modules_to_save = None
    digit_ids = tokenizer_digit_ids(tokenizer)
    anchors = torch.linspace(0.0, 1.0, NUMERIC_DIGITS, device=device, dtype=torch.float32)
    version = NTL_VERSION if method == "ntl" else RAFT_NTL_VERSION
    paper = NTL_PAPER if method == "ntl" else {"raft": RAFT_PAPER, "ntl": NTL_PAPER}
    base.config.use_cache = False
    base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    lora_kwargs = dict(
        r=args.lora_rank, lora_alpha=args.lora_alpha, lora_dropout=args.lora_dropout,
        bias="none", task_type=task_type,
        target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    )
    if modules_to_save:
        lora_kwargs["modules_to_save"] = modules_to_save
    model = get_peft_model(base, LoraConfig(**lora_kwargs))
    model.enable_input_require_grads()
    model.to(device)
    model.train()
    signature_before, trainable_parameters = trainable_signature(model)
    total_parameters = sum(parameter.numel() for parameter in model.parameters())
    model = DistributedDataParallel(
        model, device_ids=[local_rank], output_device=local_rank,
        broadcast_buffers=False, find_unused_parameters=False,
    ) if world_size > 1 else model

    head_parameters = []
    lora_parameters = []
    for name, parameter in model.named_parameters():
        if parameter.requires_grad:
            (head_parameters if "score" in name else lora_parameters).append(parameter)
    parameter_groups = [{"params": lora_parameters, "lr": args.learning_rate}]
    if head_parameters:
        parameter_groups.append({"params": head_parameters, "lr": args.head_learning_rate})
    optimizer = torch.optim.AdamW(
        parameter_groups, betas=(0.9, 0.95), eps=1e-8,
        weight_decay=args.weight_decay, fused=True,
    )
    groups_per_epoch = math.ceil(len(train_rows) / world_size)
    steps_per_epoch = math.ceil(groups_per_epoch / args.gradient_accumulation)
    total_steps = steps_per_epoch * args.epochs
    warmup = math.ceil(total_steps * args.warmup_ratio)
    scheduler = torch.optim.lr_scheduler.LambdaLR(
        optimizer, lambda step: cosine_lambda(step, total_steps, warmup)
    )
    optimizer.zero_grad(set_to_none=True)
    started = time.perf_counter()
    optimizer_step = 0
    microsteps = 0
    best_epoch = 0
    best_key = None
    best_state = None
    development_history = []
    events_path = partial / "training_events.jsonl"
    stop = False
    for epoch in range(args.epochs):
        groups = rank_groups(train_rows, world_size, seed, epoch)
        cursor = 0
        while cursor < len(groups):
            window = groups[cursor:cursor + args.gradient_accumulation]
            local_abs = torch.zeros(1, dtype=torch.float64, device=device)
            local_sq = torch.zeros(1, dtype=torch.float64, device=device)
            local_count = torch.zeros(1, dtype=torch.float64, device=device)
            actual = 0
            for offset, group in enumerate(window):
                if args.max_train_microsteps is not None and microsteps >= args.max_train_microsteps:
                    stop = True
                    break
                row = train_rows[group[rank]]
                input_ids, attention_mask, target = tokenize_row(tokenizer, row, method, device)
                sync_now = offset == len(window) - 1 or (
                    args.max_train_microsteps is not None and microsteps + 1 >= args.max_train_microsteps
                )
                sync = contextlib.nullcontext() if sync_now or world_size == 1 else model.no_sync()
                with sync:
                    prediction, probabilities = method_prediction(
                        model, input_ids, attention_mask, method, anchors, digit_ids
                    )
                    loss = method_loss(prediction, probabilities, target, method, args) / len(window)
                    loss.backward()
                error = (prediction.detach() - target).double()
                local_abs += error.abs().sum()
                local_sq += (error * error).sum()
                local_count += 1
                microsteps += 1
                actual += 1
                del input_ids, attention_mask, target, prediction, probabilities, loss, error
            if not actual:
                break
            gradient_norm = float(torch.nn.utils.clip_grad_norm_(
                [parameter for parameter in model.parameters() if parameter.requires_grad],
                args.max_grad_norm,
            ).detach().float().item())
            if not math.isfinite(gradient_norm):
                raise RuntimeError(f"non-finite gradient norm: {gradient_norm}")
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad(set_to_none=True)
            optimizer_step += 1
            cursor += actual
            if world_size > 1:
                dist.all_reduce(local_abs, op=dist.ReduceOp.SUM)
                dist.all_reduce(local_sq, op=dist.ReduceOp.SUM)
                dist.all_reduce(local_count, op=dist.ReduceOp.SUM)
            event = {
                "event": "optimizer_step", "method": method, "epoch": epoch + 1,
                "optimizer_step": optimizer_step, "microsteps_completed": microsteps,
                "train_window_mae": float((local_abs / local_count).item()),
                "train_window_rmse": float(torch.sqrt(local_sq / local_count).item()),
                "gradient_norm_before_clip": gradient_norm,
                "learning_rates": scheduler.get_last_lr(),
                "elapsed_seconds": time.perf_counter() - started,
            }
            if rank == 0:
                with events_path.open("a", encoding="utf-8") as stream:
                    stream.write(json.dumps(event, ensure_ascii=False) + "\n")
                if optimizer_step == 1 or optimizer_step % args.log_every == 0:
                    print(json.dumps(event, ensure_ascii=False), flush=True)
            if stop:
                break
        if stop:
            break
        development_predictions = distributed_predictions(
            model, tokenizer, development_rows, method, anchors, digit_ids,
            device, rank, world_size,
        )
        development = split_metrics(development_predictions)
        development_history.append({"epoch": epoch + 1, "metrics": development})
        key = (
            development["overall"]["mae_percent_points"],
            development["computer_science"]["mae_percent_points"],
            development["overall"]["rmse_percent_points"],
        )
        if best_key is None or key < best_key:
            best_key = key
            best_epoch = epoch + 1
            best_state = trainable_state(model)
        if rank == 0:
            event = {
                "event": "epoch_development", "method": method, "epoch": epoch + 1,
                "development": development, "best_epoch": best_epoch,
            }
            with events_path.open("a", encoding="utf-8") as stream:
                stream.write(json.dumps(event, ensure_ascii=False) + "\n")
            print(json.dumps(event, ensure_ascii=False), flush=True)

    truncated = stop
    if best_state is None:
        best_state = trainable_state(model)
        best_epoch = 0
    restore_trainable_state(model, best_state)
    official_predictions = []
    if not args.skip_evaluation and not truncated:
        official_predictions = distributed_predictions(
            model, tokenizer, validation_rows, method, anchors, digit_ids,
            device, rank, world_size,
        )
    barrier(world_size)
    signature_after, _ = trainable_signature(model)
    if signature_after == signature_before:
        raise RuntimeError("trainable parameter signature did not change")
    peak = torch.tensor([
        torch.cuda.max_memory_allocated(device) / 1024 ** 3,
        torch.cuda.max_memory_reserved(device) / 1024 ** 3,
    ], dtype=torch.float64, device=device)
    if world_size > 1:
        dist.all_reduce(peak, op=dist.ReduceOp.MAX)
    if rank == 0:
        adapter_dir = partial / "best_adapter"
        unwrap(model).save_pretrained(adapter_dir, safe_serialization=True)
        if official_predictions:
            write_jsonl(partial / "official_validation_predictions.jsonl", official_predictions)
        summary = {
            "status": "PASS",
            "version": version,
            "suite_version": VERSION,
            "method": method,
            "paper": paper,
            "protocol": "same frozen 1088/148 data; deterministic group-disjoint development split from training only; official 148 evaluated once after epoch selection",
            "world_size": world_size,
            "epochs_requested": args.epochs,
            "best_epoch": best_epoch,
            "optimizer_steps": optimizer_step,
            "microsteps_completed": microsteps,
            "truncated_smoke": truncated,
            "trainable_parameters": trainable_parameters,
            "total_parameters": total_parameters,
            "signature_before": signature_before,
            "signature_after": signature_after,
            "development_history": development_history,
            "official_validation": split_metrics(official_predictions) if official_predictions else None,
            "continuity_contract": "posterior expectation retained as raw float; rounding only for display",
            "objective": {
                "variant": "NTL-Wasserstein continuous-label adaptation" if method == "ntl" else "RAFT plus NTL-Wasserstein joint loss",
                "digit_ids": digit_ids,
                "anchors": NUMERIC_DIGITS,
                "raft_mse_weight": args.raft_weight if method == "raft_ntl" else 0.0,
                "numeric_token_ce_weight": args.ntl_ce_weight,
                "wasserstein_1_weight": args.ntl_wasserstein_weight,
            },
            "data": {
                "train_jsonl": str(train_path), "train_sha256": sha256(train_path),
                "validation_jsonl": str(validation_path), "validation_sha256": sha256(validation_path),
                "split_manifest": str(split_path), "split_manifest_sha256": sha256(split_path),
            },
            "adapter": "best_adapter",
            "elapsed_seconds": time.perf_counter() - started,
            "peak_allocated_gib_all_ranks_max": float(peak[0].item()),
            "peak_reserved_gib_all_ranks_max": float(peak[1].item()),
            "environment": {
                "python": platform.python_version(), "torch": torch.__version__,
                "transformers": transformers.__version__, "peft": peft.__version__,
            },
        }
        write_json(partial / "training_summary.json", summary)
        manifest = {
            str(path.relative_to(partial)): sha256(path)
            for path in partial.rglob("*") if path.is_file() and path.name != "artifact_sha256.json"
        }
        write_json(partial / "artifact_sha256.json", manifest)
        shutil.move(str(partial), str(output_dir))
        print(json.dumps({
            "status": "PASS", "version": version, "method": method,
            "best_epoch": best_epoch, "official_validation": summary["official_validation"],
            "output_dir": str(output_dir),
        }, ensure_ascii=False, indent=2), flush=True)
    barrier(world_size)
    if world_size > 1:
        dist.destroy_process_group()


def load_reference(path: Path):
    spec = importlib.util.spec_from_file_location("continuous_reference_runtime", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import reference runtime: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    required = ("normalize_input", "fit_prompt", "extract_ids")
    if not all(hasattr(module, name) for name in required):
        raise RuntimeError(f"reference runtime contract missing: {required}")
    return module


def production_messages(reference, tokenizer, row: dict, method: str):
    normalized = reference.normalize_input(row)
    messages, audit, token_count = reference.fit_prompt(tokenizer, normalized)
    messages = [dict(message) for message in messages]
    messages[0] = dict(messages[0])
    messages[0]["content"] = str(messages[0]["content"]) + NUMERIC_INSTRUCTION
    return messages, audit, token_count


def predict_frozen(args, method: str) -> None:
    import torch
    from peft import PeftModel
    from transformers import AutoModelForCausalLM, AutoTokenizer

    output = Path(args.output_jsonl)
    if output.exists():
        raise SystemExit(f"Safety stop: output exists: {output}")
    rows = read_jsonl(Path(args.input_jsonl))
    if len(rows) != args.expected_records:
        raise SystemExit(f"Safety stop: expected {args.expected_records} input rows, got {len(rows)}")
    summary = json.loads((Path(args.model_dir) / "training_summary.json").read_text(encoding="utf-8"))
    expected_version = NTL_VERSION if method == "ntl" else RAFT_NTL_VERSION
    if summary.get("status") != "PASS" or summary.get("version") != expected_version:
        raise SystemExit("Safety stop: invalid training summary")
    tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    dtype = torch.bfloat16 if str(args.device).startswith("cuda") else torch.float32
    base = AutoModelForCausalLM.from_pretrained(
        args.model, local_files_only=True, dtype=dtype,
        attn_implementation="flash_attention_2" if str(args.device).startswith("cuda") else "eager",
        low_cpu_mem_usage=True, device_map=args.device,
    )
    digit_ids = tokenizer_digit_ids(tokenizer)
    anchors = torch.linspace(0.0, 1.0, NUMERIC_DIGITS, dtype=torch.float32, device=next(base.parameters()).device)
    model = PeftModel.from_pretrained(
        base, Path(args.model_dir) / summary["adapter"],
        is_trainable=False, local_files_only=True,
    ).eval()
    device = next(model.parameters()).device
    reference = load_reference(Path(args.reference_runtime))
    outputs = []
    for completed, row in enumerate(rows, 1):
        messages, audit, _original_count = production_messages(reference, tokenizer, row, method)
        value = tokenizer.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True
        )
        ids = extract_ids(value)
        input_ids = torch.tensor([ids], dtype=torch.long, device=device)
        attention_mask = torch.ones_like(input_ids)
        with torch.inference_mode():
            prediction, probabilities = method_prediction(
                model, input_ids, attention_mask, method, anchors, digit_ids
            )
            entropy = -(probabilities * probabilities.clamp_min(1e-12).log()).sum(dim=-1)
        uid = str(row.get("unit_id") or (row.get("metadata") or {}).get("unit_id") or "")
        result = {
            "status": "PASS", "version": expected_version, "unit_id": uid,
            "subject": subject(row), "relief_rate_fraction": float(prediction.item()),
            "relief_rate_percent": float(prediction.item()) * 100.0,
            "distribution_entropy_nats": float(entropy.item()),
            "prompt_tokens": len(ids), "context_compaction": audit,
            "decoder": "single_digit_ntl_wasserstein_posterior_expectation" if method == "ntl" else "single_digit_raft_ntl_joint_posterior_expectation",
            "mechanical_operation_average": False, "random_noise_or_sampling": False,
        }
        outputs.append(result)
        print(json.dumps({
            "event": f"{method}_recent_baseline_progress", "completed": completed,
            "total": len(rows), "unit_id": uid,
            "predicted_percent": result["relief_rate_percent"],
        }, ensure_ascii=False), flush=True)
    write_jsonl(output, outputs)
    print(json.dumps({
        "status": "PASS", "version": expected_version,
        "records": len(outputs), "output": str(output),
    }, ensure_ascii=False, indent=2))


def gold_fraction(row: dict) -> float:
    target = row.get("target") or {}
    if isinstance(target.get("relief_rate"), (int, float)):
        value = float(target["relief_rate"])
        if 0.0 <= value <= 1.0:
            return value
    operations = target.get("operations") or []
    if not operations:
        raise ValueError(f"missing gold operations: {row.get('unit_id')}")
    values = [float(operation["ai_share"]) for operation in operations]
    if any(value not in {0.0, 0.5, 1.0} for value in values):
        raise ValueError(f"gold responsibility drift: {row.get('unit_id')}")
    return sum(values) / len(values)


def prediction_value(row: dict) -> float:
    if isinstance(row.get("relief_rate_fraction"), (int, float)):
        return float(row["relief_rate_fraction"])
    if isinstance(row.get("relief_rate_percent"), (int, float)):
        return float(row["relief_rate_percent"]) / 100.0
    raise ValueError(f"missing prediction: {row.get('unit_id')}")


def cluster_bootstrap(details: list[dict], candidate: str, reference_name: str, seed: int, replicates: int) -> dict:
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in details:
        grouped[row["student_id"]].append(row)
    keys = sorted(grouped)
    rng = random.Random(seed)
    values = []
    for _ in range(replicates):
        sampled = []
        for _key in keys:
            sampled.extend(grouped[rng.choice(keys)])
        candidate_mae = sum(abs(row[candidate] - row["gold"]) for row in sampled) / len(sampled)
        reference_mae = sum(abs(row[reference_name] - row["gold"]) for row in sampled) / len(sampled)
        values.append((candidate_mae - reference_mae) * 100.0)
    values.sort()
    estimate = sum(
        abs(row[candidate] - row["gold"]) - abs(row[reference_name] - row["gold"])
        for row in details
    ) / len(details) * 100.0
    return {
        "definition": f"MAE({candidate}) - MAE({reference_name}); negative favors {candidate}",
        "estimate_percent_points": estimate,
        "ci_low_percent_points": values[int(0.025 * (replicates - 1))],
        "ci_high_percent_points": values[int(0.975 * (replicates - 1))],
        "clusters": len(keys), "replicates": replicates, "seed": seed,
    }


def audit(args) -> None:
    output_dir = Path(args.output_dir)
    if output_dir.exists():
        raise SystemExit(f"Safety stop: output directory exists: {output_dir}")
    sources = read_jsonl(Path(args.gold_jsonl))
    files = {
        "r2ccp": Path(args.r2ccp_output_jsonl),
        "raft": Path(args.raft_output_jsonl),
        "ntl_wasserstein": Path(args.ntl_output_jsonl),
        "raft_ntl_joint": Path(args.raft_ntl_output_jsonl),
        "current_lora_scalar": Path(args.current_output_jsonl),
    }
    source_by_id = {str(row.get("unit_id")): row for row in sources}
    predictions = {
        name: {str(row.get("unit_id")): row for row in read_jsonl(path)}
        for name, path in files.items()
    }
    if len(source_by_id) != args.expected_records:
        raise SystemExit(f"Safety stop: expected {args.expected_records} gold rows, got {len(source_by_id)}")
    for name, mapping in predictions.items():
        if set(mapping) != set(source_by_id):
            raise SystemExit(f"Safety stop: {name} alignment drift: {len(mapping)}")
    details = []
    for uid, source in source_by_id.items():
        item = {
            "unit_id": uid,
            "student_id": group_id(source),
            "subject": subject(source),
            "gold": gold_fraction(source),
        }
        for name, mapping in predictions.items():
            value = prediction_value(mapping[uid])
            if not math.isfinite(value) or not 0.0 <= value <= 1.0:
                raise SystemExit(f"Safety stop: invalid {name} prediction: {uid}/{value}")
            item[name] = value
        details.append(item)
    computer = [row for row in details if row["subject"] == COMPUTER]
    if len(computer) != args.expected_computer_records:
        raise SystemExit(f"Safety stop: expected {args.expected_computer_records} CS rows, got {len(computer)}")

    def section(rows: list[dict], seed: int) -> dict:
        metrics = {}
        for name in predictions:
            metric_rows = [{
                "target_fraction": row["gold"], "prediction_fraction": row[name],
            } for row in rows]
            metrics[name] = prediction_metrics(metric_rows)
        return {
            "metrics": metrics,
            "paired_comparisons": {
                "r2ccp_minus_current": cluster_bootstrap(rows, "r2ccp", "current_lora_scalar", seed, args.bootstrap_replicates),
                "raft_minus_current": cluster_bootstrap(rows, "raft", "current_lora_scalar", seed + 1, args.bootstrap_replicates),
                "ntl_minus_current": cluster_bootstrap(rows, "ntl_wasserstein", "current_lora_scalar", seed + 2, args.bootstrap_replicates),
                "raft_ntl_minus_current": cluster_bootstrap(rows, "raft_ntl_joint", "current_lora_scalar", seed + 3, args.bootstrap_replicates),
                "raft_ntl_minus_raft": cluster_bootstrap(rows, "raft_ntl_joint", "raft", seed + 4, args.bootstrap_replicates),
                "raft_ntl_minus_ntl": cluster_bootstrap(rows, "raft_ntl_joint", "ntl_wasserstein", seed + 5, args.bootstrap_replicates),
            },
            "ranking_by_mae": sorted(
                ({"method": name, "mae_percent_points": value["mae_percent_points"]} for name, value in metrics.items()),
                key=lambda item: item["mae_percent_points"],
            ),
        }

    summary = {
        "status": "PASS", "version": VERSION,
        "protocol": "same frozen 145 real-E3 records; same gold definition; same overall and 82-row computer-science slice; raw continuous predictions",
        "papers": {"ntl_wasserstein": NTL_PAPER, "raft": RAFT_PAPER},
        "records": len(details), "computer_records": len(computer),
        "overall": section(details, args.seed),
        "computer_science": section(computer, args.seed + 100),
    }
    output_dir.mkdir(parents=True)
    write_json(output_dir / "B大模型NTL_RAFTNTL统一冻结对比汇总.json", summary)
    jsonl_details = []
    for row in details:
        jsonl_details.append({
            "unit_id": row["unit_id"], "student_id": row["student_id"], "subject": row["subject"],
            "gold_percent": row["gold"] * 100.0,
            **{f"{name}_percent": row[name] * 100.0 for name in predictions},
            **{f"{name}_absolute_error_pp": abs(row[name] - row["gold"]) * 100.0 for name in predictions},
        })
    write_jsonl(output_dir / "B大模型NTL_RAFTNTL统一冻结对比明细.jsonl", jsonl_details)
    with (output_dir / "B大模型NTL_RAFTNTL统一冻结对比明细.csv").open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(jsonl_details[0]))
        writer.writeheader()
        writer.writerows(jsonl_details)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def self_test() -> None:
    import torch
    from types import SimpleNamespace

    anchors = torch.linspace(0.0, 1.0, NUMERIC_DIGITS)
    logits = torch.zeros(1, NUMERIC_DIGITS)
    probabilities = torch.softmax(logits, dim=-1)
    prediction = (probabilities * anchors.unsqueeze(0)).sum(dim=-1)
    target = torch.tensor([0.75])
    soft = adjacent_digit_target(target, NUMERIC_DIGITS)
    assert abs(float(soft[0, 6]) - 0.25) < 1e-6
    assert abs(float(soft[0, 7]) - 0.75) < 1e-6
    assert abs(float(soft.sum()) - 1.0) < 1e-6
    components = ntl_components(probabilities, target)
    args = SimpleNamespace(ntl_ce_weight=0.1, ntl_wasserstein_weight=1.0, raft_weight=1.0)
    ntl_loss = method_loss(prediction, probabilities, target, "ntl", args)
    joint_loss = method_loss(prediction, probabilities, target, "raft_ntl", args)
    assert all(math.isfinite(float(value.item())) for value in components[:2])
    assert float(ntl_loss.item()) > 0 and float(joint_loss.item()) > float(ntl_loss.item())
    metrics = prediction_metrics([
        {"target_fraction": 0.0, "prediction_fraction": 0.1},
        {"target_fraction": 1.0, "prediction_fraction": 0.9},
    ])
    assert metrics["records"] == 2 and abs(metrics["mae_percent_points"] - 10.0) < 1e-8
    expected_coverage = Counter(["duplicate", "duplicate", "unique"])
    observed_coverage = Counter(["unique", "duplicate", "duplicate"])
    assert expected_coverage == observed_coverage
    print(json.dumps({"status": "PASS", "version": VERSION, "self_test": True}, ensure_ascii=False))


def dependency_preflight(args) -> None:
    import peft
    import torch
    import transformers
    from transformers import AutoTokenizer

    result = {
        "status": "PASS", "version": VERSION,
        "python": platform.python_version(), "torch": torch.__version__,
        "transformers": transformers.__version__, "peft": peft.__version__,
    }
    if args.model:
        tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
        result["single_digit_contract"] = {
            str(index): token for index, token in enumerate(tokenizer_digit_ids(tokenizer))
        }
    print(json.dumps(result, ensure_ascii=False, indent=2))


def add_training_arguments(parser) -> None:
    parser.add_argument("--model", required=True)
    parser.add_argument("--train-jsonl", required=True)
    parser.add_argument("--validation-jsonl", required=True)
    parser.add_argument("--split-manifest", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--expected-train", type=int, default=1088)
    parser.add_argument("--expected-train-units", type=int, default=1085)
    parser.add_argument("--expected-validation", type=int, default=148)
    parser.add_argument("--expected-validation-units", type=int, default=148)
    parser.add_argument("--world-size", type=int, default=4)
    parser.add_argument("--epochs", type=int, default=4)
    parser.add_argument("--gradient-accumulation", type=int, default=2)
    parser.add_argument("--learning-rate", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--warmup-ratio", type=float, default=0.05)
    parser.add_argument("--max-grad-norm", type=float, default=1.0)
    parser.add_argument("--lora-rank", type=int, default=16)
    parser.add_argument("--lora-alpha", type=int, default=32)
    parser.add_argument("--lora-dropout", type=float, default=0.05)
    parser.add_argument("--ntl-ce-weight", type=float, default=0.1)
    parser.add_argument("--ntl-wasserstein-weight", type=float, default=1.0)
    parser.add_argument("--raft-weight", type=float, default=1.0)
    parser.add_argument("--minimum-free-gib", type=float, default=65.0)
    parser.add_argument("--log-every", type=int, default=10)
    parser.add_argument("--seed", type=int, default=20260928)
    parser.add_argument("--max-train-microsteps", type=int)
    parser.add_argument("--skip-evaluation", action="store_true")


def add_prediction_arguments(parser) -> None:
    parser.add_argument("--model", required=True)
    parser.add_argument("--model-dir", required=True)
    parser.add_argument("--reference-runtime", required=True)
    parser.add_argument("--input-jsonl", required=True)
    parser.add_argument("--output-jsonl", required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--expected-records", type=int, default=145)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    subparsers = parser.add_subparsers(dest="command")
    preflight_parser = subparsers.add_parser("dependency-preflight")
    preflight_parser.add_argument("--model")
    prepare_parser = subparsers.add_parser("prepare")
    prepare_parser.add_argument("--train-jsonl", required=True)
    prepare_parser.add_argument("--validation-jsonl", required=True)
    prepare_parser.add_argument("--output-json", required=True)
    prepare_parser.add_argument("--expected-train", type=int, default=1088)
    prepare_parser.add_argument("--expected-train-units", type=int, default=1085)
    prepare_parser.add_argument("--expected-validation", type=int, default=148)
    prepare_parser.add_argument("--expected-validation-units", type=int, default=148)
    prepare_parser.add_argument("--development-fraction", type=float, default=0.15)
    prepare_parser.add_argument("--seed", type=int, default=20260928)
    train_ntl = subparsers.add_parser("train-ntl")
    add_training_arguments(train_ntl)
    train_raft_ntl = subparsers.add_parser("train-raft-ntl")
    add_training_arguments(train_raft_ntl)
    predict_ntl = subparsers.add_parser("predict-ntl")
    add_prediction_arguments(predict_ntl)
    predict_raft_ntl = subparsers.add_parser("predict-raft-ntl")
    add_prediction_arguments(predict_raft_ntl)
    audit_parser = subparsers.add_parser("audit")
    audit_parser.add_argument("--gold-jsonl", required=True)
    audit_parser.add_argument("--r2ccp-output-jsonl", required=True)
    audit_parser.add_argument("--raft-output-jsonl", required=True)
    audit_parser.add_argument("--ntl-output-jsonl", required=True)
    audit_parser.add_argument("--raft-ntl-output-jsonl", required=True)
    audit_parser.add_argument("--current-output-jsonl", required=True)
    audit_parser.add_argument("--output-dir", required=True)
    audit_parser.add_argument("--expected-records", type=int, default=145)
    audit_parser.add_argument("--expected-computer-records", type=int, default=82)
    audit_parser.add_argument("--bootstrap-replicates", type=int, default=10000)
    audit_parser.add_argument("--seed", type=int, default=20260928)
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.command == "dependency-preflight":
        dependency_preflight(args)
    elif args.command == "prepare":
        prepare(args)
    elif args.command == "train-ntl":
        train_method(args, "ntl")
    elif args.command == "train-raft-ntl":
        train_method(args, "raft_ntl")
    elif args.command == "predict-ntl":
        predict_frozen(args, "ntl")
    elif args.command == "predict-raft-ntl":
        predict_frozen(args, "raft_ntl")
    elif args.command == "audit":
        audit(args)
    else:
        parser.error("choose a command or --self-test")


if __name__ == "__main__":
    main()
