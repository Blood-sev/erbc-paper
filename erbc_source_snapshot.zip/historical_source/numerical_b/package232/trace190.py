"""One frozen sample, two FA2 backward settings, twelve VJPs, no updates.

The CPU gate checks saved provenance, actual installed source/API and wrapper
wiring; it does not repeat CPU autograd or load a model. Runtime proxies only
observe the deterministic keyword reaching the original FA2 public functions.
"""
from __future__ import annotations
import argparse
import ast
import functools
import gc
import hashlib
import importlib.metadata
import importlib.util
import inspect
import json
import math
import os
import random
import sys
import time
from pathlib import Path
VERSION = 'cdfq_S058_FA2_deterministic_repeat_pair_v3_verified_partial_route'
UPSTREAM = '187_LoRA_B_CDFQ_S058\u9650\u5b9a\u53cd\u5411\u94fe\u8def\u8bca\u65ad.py'
UPSTREAM_SHA = '98ea0892f40ae6c14e8c88e2e45f44bb44fa9a081c8a80103e9f4af93a04ba42'
REPORT_REL = 'outputs/B_NTL_CDFQ\u53c2\u6570\u7a7a\u95f4\u673a\u5236\u5ba1\u8ba1_v1/S058\u9650\u5b9a\u53cd\u5411\u94fe\u8def\u8bca\u65ad_v1/\u5355\u6837\u672c\u53cd\u5411\u8bca\u65ad_v1/S058\u53cd\u5411\u94fe\u8def\u8bca\u65ad\u6c47\u603b.json'
REPORT_SHA = 'de2a8185cfa69657ebdba7f3a27d81d6eccad0ec3c8e793463aa7a2de62afd35'
ROOT_REL = 'outputs/B_NTL_CDFQ\u53c2\u6570\u7a7a\u95f4\u673a\u5236\u5ba1\u8ba1_v1/S058\u786e\u5b9a\u6027\u53cd\u5411\u914d\u5bf9\u8bca\u65ad_v3\u5b9e\u9645partial\u4fee\u590d'
FAILED_188_SHA = '233359cbf218742b5f535d1684edba1d269f7d5d804f8446af3f2a09b4902288'
FAILED_189_SHA = 'f2138da10ee15a6cf7115c68d309e730cac7a85555883ce1bd0f726053fc9a5f'
SOURCES = {'transformers/modeling_flash_attention_utils.py': 'dea5b555b5bb8fba1b4ab2c62c8df9f96019b17555b3714f75be17c54e801f95', 'transformers/integrations/flash_attention.py': 'a58018813c0aff5c29aa983bc0a82ce5b4b573d7665b8e9a4fb8fca0c157e98c', 'transformers/models/qwen3/modeling_qwen3.py': 'cbb7f2dc274c2f5592746c0dc6985ca50353efa07376f92cc922b77680a74f69', 'flash_attn/flash_attn_interface.py': 'd8eaf989a5401fedd23d11a336a7f38e67596d0a4d5a279df14cbe2d7de2ed75'}
VERSIONS = {'torch': '2.13.0a0+8145d630e8.nv26.6.54250401', 'transformers': '5.16.1', 'peft': '0.21.0', 'flash-attn': '2.7.4.post1+git5231d95fe1.54157505'}
CALL_ORDER = ('Q', 'full', 'Q', 'full', 'Q', 'full')
BUDGET = {'snapshots': 1, 'samples': 1, 'loaded_GPUs': 1, 'explicit_model_forwards': 2, 'parameter_backward_calls': 12, 'repeats_per_component_per_arm': 3, 'time_limit_seconds': 1200, 'minimum_observed_free_GiB': 8.0, 'optimizer_allowed': False, 'parameter_update_allowed': False, 'adapter_save_allowed': False}

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 ** 2), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def save(path, obj):
    with Path(path).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(obj, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write('\n')

def artifact(root):
    need(sha(root / 'runtime/188_LoRA_B_CDFQ_S058\u786e\u5b9a\u6027\u53cd\u5411\u914d\u5bf9\u8bca\u65ad.py') == FAILED_188_SHA, 'FAILED_188_CODE_DRIFT_STOP_PRESERVE_OLD_EVIDENCE')
    need(sha(root / 'runtime/189_LoRA_B_CDFQ_S058\u786e\u5b9a\u6027\u53cd\u5411\u914d\u5bf9\u8bca\u65ad_\u63a5\u53e3\u4fee\u590d.py') == FAILED_189_SHA, 'FAILED_189_CODE_DRIFT_STOP_PRESERVE_OLD_EVIDENCE')
    p = root / REPORT_REL
    need(sha(p) == REPORT_SHA and read(p.parent / 'artifact_sha256.json')[p.name] == REPORT_SHA, '187_RESULT_OR_MANIFEST_DRIFT_STOP')
    d = read(p)
    need(d['status'] == 'S058_MECHANISM_DIAGNOSTIC_COMPLETE_REVIEW_ONLY' and d['script_sha256'] == UPSTREAM_SHA and (d['plan']['sample']['unit_id'] == 'SYNTHETIC_TRACE_CASE') and (d['plan']['sample']['prompt_tokens'] == 45431) and (d['model_parameter_backward_calls'] == 16) and (d['runtime']['signature_before'] == d['runtime']['signature_after'] == d['plan']['expected_parameter_sha256']) and all((d['scope'][k] is False for k in ('optimizer_created', 'parameters_updated', 'adapter_saved', 'new_development_inference', 'official_validation_rows_read', 'test_or_E3_rows_read', 'formal_training_started'))), '187_COMPLETION_OR_READONLY_SCOPE_DRIFT_STOP')
    pre = root / 'outputs/B_NTL_CDFQ\u53c2\u6570\u7a7a\u95f4\u673a\u5236\u5ba1\u8ba1_v1/S058\u9650\u5b9a\u53cd\u5411\u94fe\u8def\u8bca\u65ad_v1/S058\u53cd\u5411\u8bca\u65ad\u51bb\u7ed3\u9884\u68c0.json'
    need(sha(pre) == d['preflight_sha256'], '187_CPU_FREEZE_DRIFT_STOP')
    need(sha(root / '\u90e8\u7f72\u4ee3\u7801' / UPSTREAM) == UPSTREAM_SHA, '187_CODE_DRIFT_STOP')
    return d

def consumer_layout(tree):
    """Verify the exact return/factory/partial route in the hash-pinned source."""
    definitions = {n.name: n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    fn = definitions.get('_flash_attention_forward')
    need(fn is not None, 'HF_CALLER_MISSING_STOP')
    lazy = definitions.get('lazy_import_flash_attention')
    factory = definitions.get('_lazy_define_process_function')
    need(lazy is not None and factory is not None, 'HF_LAZY_OR_FACTORY_MISSING_STOP')
    returns = [n.value for n in ast.walk(lazy) if isinstance(n, ast.Return)]
    need(len(returns) == 1, 'HF_LAZY_RETURN_COUNT_STOP')
    result = returns[0]
    need(isinstance(result, ast.Tuple) and len(result.elts) == 2 and isinstance(result.elts[0], ast.Tuple) and (len(result.elts[0].elts) == 5) and isinstance(result.elts[1], ast.Name) and (result.elts[1].id == '_process_flash_kwargs_fn'), 'HF_LAZY_SAVED_RETURN_ROUTE_STOP')
    factory_returns = [n.value for n in ast.walk(factory) if isinstance(n, ast.Return)]
    need(len(factory_returns) == 1, 'HF_FACTORY_RETURN_COUNT_STOP')
    value = factory_returns[0]
    need(isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and (value.func.id == 'partial') and (len(value.args) >= 1) and isinstance(value.args[0], ast.Name) and (value.args[0].id == '_process_flash_attention_kwargs') and any((k.arg == 'supports_mapping' for k in value.keywords)), 'HF_SAVED_PROCESSOR_FACTORY_STOP')
    matches = []
    for node in ast.walk(fn):
        if not isinstance(node, (ast.Assign, ast.AnnAssign)):
            continue
        value = node.value
        if not (isinstance(value, ast.Call) and isinstance(value.func, ast.Name) and (value.func.id == 'lazy_import_flash_attention')):
            continue
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        need(len(targets) == 1, 'HF_LAZY_MULTIPLE_ASSIGNMENTS_STOP')
        target = targets[0]
        need(isinstance(target, (ast.Tuple, ast.List)) and len(target.elts) == 2, 'HF_CALLER_OUTER_LAYOUT_STOP')
        funcs, processors = target.elts
        need(isinstance(funcs, (ast.Tuple, ast.List)) and len(funcs.elts) == 5 and all((isinstance(v, ast.Name) for v in funcs.elts)), 'HF_CALLER_KERNEL_LAYOUT_STOP')
        need(isinstance(processors, ast.Name), 'HF_SAVED_CALLER_PROCESSOR_LAYOUT_STOP')
        processor_name = processors.id
        forwarded = [v for v in ast.walk(fn) if isinstance(v, ast.Call) and isinstance(v.func, ast.Name) and (v.func.id == 'partial') and (len(v.args) >= 1) and isinstance(v.args[0], ast.Name) and (v.args[0].id == processor_name)]
        need(len(forwarded) == 1, 'HF_SAVED_PARTIAL_FORWARDING_ROUTE_STOP')
        matches.append({'processor_layout': 'single_callable', 'kernel_count': 5, 'consumer_line': node.lineno, 'processor_name': processor_name, 'processor_use': 'partial_forwarding', 'partial_line': forwarded[0].lineno, 'return_factory_and_consumer_verified': True})
    need(len(matches) == 1, 'HF_LAZY_CALLER_AMBIGUOUS_STOP')
    return matches[0]

def installed_sources():
    specs = {k: importlib.util.find_spec(k) for k in ('transformers', 'flash_attn')}
    need(all((v is not None and v.origin for v in specs.values())), 'INSTALLED_SOURCE_MISSING_STOP')
    bases = {k: Path(v.origin).parent for k, v in specs.items()}
    texts, result = ({}, {})
    for name, expected in SOURCES.items():
        package, relative = name.split('/', 1)
        p = bases[package] / relative
        need(p.is_file() and sha(p) == expected, 'INSTALLED_SOURCE_DRIFT_STOP:' + name)
        texts[name] = p.read_text(encoding='utf-8')
        result[name] = {'path': str(p), 'sha256': expected}
    versions = {str(d.metadata.get('Name', '')).lower().replace('_', '-'): d.version for d in importlib.metadata.distributions()}
    actual = {k: versions.get(k) for k in VERSIONS}
    need(actual == VERSIONS, 'DISTRIBUTION_VERSION_DRIFT_STOP')
    helper = ast.parse(texts['transformers/modeling_flash_attention_utils.py'])
    definitions = {n.name: n for n in helper.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}
    need('lazy_import_flash_attention' in definitions and '_process_flash_attention_kwargs' in definitions and ('FLASH_ATTENTION_DETERMINISTIC' in texts['transformers/modeling_flash_attention_utils.py']), 'HF_DETERMINISTIC_ENTRY_MISSING_STOP')
    fa = ast.parse(texts['flash_attn/flash_attn_interface.py'])
    definitions = {n.name: n for n in fa.body if isinstance(n, ast.FunctionDef)}
    for name in ('flash_attn_func', 'flash_attn_varlen_func'):
        need(name in definitions, 'FA2_PUBLIC_API_MISSING_STOP:' + name)
        fn = definitions[name]
        args = fn.args.posonlyargs + fn.args.args
        defaults = dict(zip((v.arg for v in args[-len(fn.args.defaults):]), fn.args.defaults))
        defaults.update(zip((v.arg for v in fn.args.kwonlyargs), fn.args.kw_defaults))
        value = defaults.get('deterministic')
        need(isinstance(value, ast.Constant) and value.value is False, 'FA2_DEFAULT_SIGNATURE_DRIFT_STOP:' + name)
    return {'versions': actual, 'sources': result, 'source_API_verified': True, 'HF_consumer_layout': consumer_layout(helper), 'actual_GPU_kernel_keyword_verified': False}

class KernelTrace:
    """Transparent runtime proxy: validate keywords, never modify them."""

    def __init__(self, original_lazy, processor_layout):
        need(processor_layout in ('single_callable', 'callable_pair'), 'UNKNOWN_PROCESSOR_LAYOUT_STOP')
        self.original_lazy = original_lazy
        self.processor_layout = processor_layout
        self.pool = {}
        self.active = None
        self.layout_observation = None

    def begin(self, name, requested):
        self.active = {'arm': name, 'requested': requested, 'kernel_calls': 0, 'by_function': {}, 'all_actual_keywords_match': True}

    def wrapped(self, fn, label):
        need(callable(fn), 'FA2_KERNEL_NOT_CALLABLE_STOP:' + label)
        key = (id(fn), label)
        if key not in self.pool:

            @functools.wraps(fn)
            def proxy(*args, **kwargs):
                need(self.active is not None, 'FA2_KERNEL_OUTSIDE_ARM_STOP')
                actual = kwargs.get('deterministic')
                need(type(actual) is bool and actual is self.active['requested'], 'FA2_ACTUAL_DETERMINISTIC_KEYWORD_MISMATCH_STOP')
                self.active['kernel_calls'] += 1
                counts = self.active['by_function']
                counts[label] = counts.get(label, 0) + 1
                return fn(*args, **kwargs)
            self.pool[key] = proxy
        return self.pool[key]

    def lazy(self, *args, **kwargs):
        result = self.original_lazy(*args, **kwargs)
        need(isinstance(result, tuple) and len(result) == 2, 'HF_LAZY_RETURN_LAYOUT_DRIFT_STOP')
        funcs, processors = result
        need(isinstance(funcs, tuple) and len(funcs) == 5 and callable(funcs[0]) and callable(funcs[1]) and callable(funcs[3]) and callable(funcs[4]) and (funcs[2] is None or callable(funcs[2])), 'HF_LAZY_KERNEL_LAYOUT_DRIFT_STOP')
        valid = callable(processors) if self.processor_layout == 'single_callable' else isinstance(processors, tuple) and len(processors) == 2 and all((callable(p) for p in processors))
        need(valid, 'HF_LAZY_PROCESSOR_LAYOUT_DRIFT_STOP')
        self.layout_observation = {'processor_layout': self.processor_layout, 'processor_runtime_type': type(processors).__name__, 'kernel_count': 5, 'processors_preserved_without_unpacking': True}
        return ((self.wrapped(funcs[0], 'flash_attn_func'), self.wrapped(funcs[1], 'flash_attn_varlen_func'), *funcs[2:]), processors)

def metric(a, b):
    import numpy as np
    need(a.shape == b.shape and a.ndim == 1, 'VECTOR_SHAPE_DRIFT_STOP')
    sa = sb = sd = 0.0
    for i in range(0, a.size, 262144):
        x, y = (a[i:i + 262144].astype('float64'), b[i:i + 262144].astype('float64'))
        need(bool(np.isfinite(x).all() and np.isfinite(y).all()), 'NONFINITE_GRADIENT_STOP')
        delta = x - y
        sa += float(x @ x)
        sb += float(y @ y)
        sd += float(delta @ delta)
    actual, expected, error = (math.sqrt(sa), math.sqrt(sb), math.sqrt(sd))
    return {'absolute_L2_error': error, 'reference_norm': actual, 'other_norm': expected, 'relative_L2_error': error / max(actual, 1e-12), 'denominator_floor_used': actual < 1e-12, 'bitwise_equal': bool(np.array_equal(a, b))}

def repeats(vectors):
    need(len(vectors) == 3, 'REPEAT_COVERAGE_DRIFT_STOP')
    pairs = [dict(pair=[i + 1, j + 1], **metric(vectors[i], vectors[j])) for i, j in ((0, 1), (0, 2), (1, 2))]
    return {'repeats': 3, 'all_bitwise_equal': all((p['bitwise_equal'] for p in pairs)), 'max_pair_relative_L2_error': max((p['relative_L2_error'] for p in pairs)), 'pairs': pairs}

def self_test():
    import numpy as np
    marker = object()

    def kernel(q, k, v, deterministic=False):
        return marker

    def padding(*args):
        return args

    def processor(**kwargs):
        return kwargs
    fixture = 'def lazy_import_flash_attention(implementation):\n    _process_flash_kwargs_fn = _lazy_define_process_function(_flash_varlen_fn) if _flash_varlen_fn else None\n    return ((_flash_fn, _flash_varlen_fn, _flash_with_kvcache_fn, _pad_fn, _unpad_fn), _process_flash_kwargs_fn)\ndef _lazy_define_process_function(flash_function):\n    return partial(_process_flash_attention_kwargs, supports_mapping=supports_mapping)\ndef _flash_attention_forward():\n    (flash_fn, flash_varlen_fn, _, pad_fn, unpad_fn), process_flash_kwargs_fn = lazy_import_flash_attention(attn_implementation)\n    flash_kwargs = partial(process_flash_kwargs_fn, query_length=query_length)\n    return flash_kwargs(deterministic=True)\n'
    need(consumer_layout(ast.parse(fixture))['processor_use'] == 'partial_forwarding', 'RETURNED_PARTIAL_ROUTE_REGRESSION_FAILED')
    route_rejected = 0
    for old, new in (('partial(process_flash_kwargs_fn,', 'partial(unrelated_processor,'), ('_pad_fn, _unpad_fn), _process_flash_kwargs_fn)', '_pad_fn, _unpad_fn), (processor_a, processor_b))'), ('partial(_process_flash_attention_kwargs, supports_mapping=supports_mapping)', 'unrelated_factory()')):
        try:
            consumer_layout(ast.parse(fixture.replace(old, new)))
        except RuntimeError:
            route_rejected += 1
    need(route_rejected == 3, 'PARTIAL_ROUTE_FAILURE_GUARD_FAILED')
    trace = KernelTrace(lambda: ((kernel, kernel, None, padding, padding), processor), 'single_callable')
    for requested in (False, True):
        trace.begin('partial_fixture', requested)
        functions, untouched = trace.lazy()
        kwargs = functools.partial(untouched, deterministic=requested)
        need(untouched is processor and functions[0](None, None, None, **kwargs()) is marker, 'PARTIAL_PROXY_TRANSPARENCY_TEST_FAILED')
    for mode, processors, target in (('single_callable', processor, 'process'), ('callable_pair', (processor, processor), '(process, cache_process)')):
        original = ((kernel, kernel, None, padding, padding), processors)
        trace = KernelTrace(lambda *_a, **_kw: original, mode)
        for requested in (False, True):
            trace.begin('toy', requested)
            wrapped, unchanged = trace.lazy('flash_attention_2')
            need(unchanged is processors and wrapped[3] is padding and (wrapped[4] is padding), 'PROXY_CHANGED_HELPERS_TEST_FAILED')
            need(inspect.signature(wrapped[0]) == inspect.signature(kernel), 'PROXY_SIGNATURE_TEST_FAILED')
            need(wrapped[0](None, None, None, deterministic=requested) is marker and wrapped[1](None, None, None, deterministic=requested) is marker and (trace.active['kernel_calls'] == 2), 'PROXY_RETURN_OR_COUNT_TEST_FAILED')
        need(trace.layout_observation['processor_layout'] == mode, 'RUNTIME_LAYOUT_RECORD_TEST_FAILED')
    rejected = 0
    for bad in ({}, {'deterministic': False}, {'deterministic': 1}):
        try:
            wrapped[0](None, None, None, **bad)
        except RuntimeError:
            rejected += 1
    try:
        KernelTrace(lambda: original[0], 'single_callable').lazy()
    except RuntimeError:
        rejected += 1
    bad_layouts = [(original, 'single_callable'), ((original[0], processor), 'callable_pair'), ((original[0], (processor, None)), 'callable_pair'), (((kernel, kernel, None, object(), padding), processor), 'single_callable')]
    for returned, mode in bad_layouts:
        try:
            KernelTrace(lambda: returned, mode).lazy()
        except RuntimeError:
            rejected += 1
    need(rejected == 8, 'PROXY_FAILURE_GUARD_TEST_FAILED')
    a = np.array([0.2, -0.3, 0.5], dtype='float32')
    need(repeats([a, a.copy(), a.copy()])['all_bitwise_equal'], 'EQUAL_REPEATS_TEST_FAILED')
    b = a + np.float32(0.001)
    r = repeats([a, b, a])
    need(not r['all_bitwise_equal'] and r['max_pair_relative_L2_error'] > 0, 'CHANGED_REPEAT_TEST_FAILED')
    z = metric(np.zeros(3, dtype='float32'), np.zeros(3, dtype='float32'))
    need(z['denominator_floor_used'] and z['relative_L2_error'] == 0, 'ZERO_NORM_TEST_FAILED')
    rng = np.random.default_rng(20261003)
    a = rng.normal(size=262161).astype('float32')
    b = a * np.float32(0.9)
    got = metric(a, b)
    need(abs(got['absolute_L2_error'] - float(np.linalg.norm(a.astype('float64') - b.astype('float64')))) < 1e-10, 'CHUNK_METRIC_TEST_FAILED')
    need(len(CALL_ORDER) * 2 == BUDGET['parameter_backward_calls'] == 12 and all((CALL_ORDER.count(k) == 3 for k in ('Q', 'full'))), 'BUDGET_TEST_FAILED')
    need(not any((BUDGET[k] for k in ('optimizer_allowed', 'parameter_update_allowed', 'adapter_save_allowed'))), 'READONLY_BUDGET_TEST_FAILED')
    return {'status': 'PASS', 'tests': 'saved return/factory/partial AST, real Python partial proxy, rejection guards, repeat metrics, budget', 'partial_route_rejected_cases': route_rejected, 'actual_Python_partial_exercised': True, 'processor_layouts_tested': ['single_callable', 'callable_pair'], 'rejected_proxy_cases': rejected, 'real_PyTorch_or_GPU_used': False, 'actual_FA2_kernel_or_CPU_autograd_executed': False}

def plan(root):
    d = artifact(root)
    return {'version': VERSION, 'script_sha256': sha(__file__), '187_report_sha256': REPORT_SHA, 'installed_runtime': installed_sources(), 'sample': d['plan']['sample'], 'adapter_directory': d['plan']['adapter_directory'], 'expected_parameter_sha256': d['plan']['expected_parameter_sha256'], 'budget': BUDGET, 'arm_order': ['control_false', 'candidate_true'], 'call_order_per_arm': list(CALL_ORDER), 'paired_probability_bitwise_required': True, 'historical_environment_flag_not_assumed': True, 'compatibility_revision': {'failed_188_sha256': FAILED_188_SHA, 'failed_189_sha256': FAILED_189_SHA, 'change': 'verify_saved_single_callable_return_factory_and_actual_partial_forwarding', 'old_188_189_code_logs_and_partial_outputs_preserved': True, 'loss_sample_seed_budget_unchanged': True}}

def preflight(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU_GATE_REQUIRES_DISABLED_CUDA_STOP')
    p = plan(root)
    test = self_test()
    need('torch' not in sys.modules, 'CPU_GATE_UNEXPECTED_TORCH_IMPORT_STOP')
    out = root / ROOT_REL
    need(out.resolve().is_relative_to(root), 'OUTPUT_PATH_ESCAPE_STOP')
    report = out / '\u51bb\u7ed3\u9884\u68c0.json'
    d = {'status': 'PASS', 'decision': 'READY_FOR_BOUNDED_FA2_REPEAT_PAIR_ONLY', 'plan': p, 'wrapper_self_test': test, 'model_loaded': False, 'CPU_autograd_executed': False, 'GPU_started': False}
    if out.exists():
        need(report.is_file() and read(out / 'artifact_sha256.json')[report.name] == sha(report) and (read(report) == d), 'EXISTING_PREFLIGHT_CONTEXT_DRIFT_STOP')
        print('FA2_REPEAT_PREFLIGHT_REUSED_HASH_VERIFIED')
    else:
        out.mkdir(parents=True)
        save(report, d)
        save(out / 'artifact_sha256.json', {report.name: sha(report)})
    print(json.dumps({'status': d['status'], 'decision': d['decision'], 'budget': BUDGET, 'actual_GPU_kernel_keyword_verified': False, 'GPU_started': False}, ensure_ascii=False), flush=True)

def check_preflight(root):
    p = root / ROOT_REL / '\u51bb\u7ed3\u9884\u68c0.json'
    need(read(p.parent / 'artifact_sha256.json')[p.name] == sha(p), '190_PREFLIGHT_HASH_DRIFT_STOP')
    d = read(p)
    need(d['status'] == 'PASS' and d['plan'] == plan(root), '190_FROZEN_PLAN_DRIFT_STOP')
    return d

def run(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '0,1,2,3', 'FROZEN_DEVICE_INDEX_MAP_REQUIRED_STOP')
    started = time.perf_counter()
    frozen = check_preflight(root)
    upstream = artifact(root)
    sp = importlib.util.spec_from_file_location('fa2_repeat_frozen187', root / '\u90e8\u7f72\u4ee3\u7801' / UPSTREAM)
    m = importlib.util.module_from_spec(sp)
    sys.modules[sp.name] = m
    sp.loader.exec_module(m)
    ctx = m.model_context(root)
    m.check_frozen(root, ctx)
    out = root / ROOT_REL / '\u914d\u5bf9\u8bca\u65ad\u7ed3\u679c_v1'
    partial = out.with_name(out.name + '.partial')
    need(not out.exists() and (not partial.exists()), 'GPU_OUTPUT_EXISTS_STOP')
    import numpy as np
    import torch
    import transformers
    import peft
    import platform
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import PeftModel
    import transformers.modeling_flash_attention_utils as fa_utils
    original_lazy = fa_utils.lazy_import_flash_attention
    trace = KernelTrace(original_lazy, frozen['plan']['installed_runtime']['HF_consumer_layout']['processor_layout'])
    trace.lazy('flash_attention_2')
    print(json.dumps({'event': 'HF_actual_lazy_layout_verified_before_model_load', 'layout': trace.layout_observation, 'kernel_executed': False}, ensure_ascii=False), flush=True)
    device = torch.device('cuda', 0)
    torch.cuda.set_device(device)
    need(torch.cuda.mem_get_info(device)[0] / 1024 ** 3 >= 65, 'INITIAL_GPU_FREE_BELOW_65_GIB_STOP')
    available = [v for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')]
    need(len(available) == 1 and int(available[0].split()[1]) >= 32 * 1024 ** 2, 'HOST_AVAILABLE_BELOW_32_GIB_STOP')
    environment = dict(python=platform.python_version(), torch=torch.__version__, transformers=transformers.__version__, peft=peft.__version__, cuda=torch.version.cuda, gpu=torch.cuda.get_device_name(device))
    need(environment == upstream['runtime']['environment'], '187_RUNTIME_ENVIRONMENT_DRIFT_STOP')
    runtime_numerics = {'torch_deterministic_algorithms_enabled': torch.are_deterministic_algorithms_enabled(), 'float32_matmul_precision': torch.get_float32_matmul_precision(), 'cudnn_deterministic': torch.backends.cudnn.deterministic, 'cudnn_benchmark': torch.backends.cudnn.benchmark, 'CUBLAS_WORKSPACE_CONFIG': os.environ.get('CUBLAS_WORKSPACE_CONFIG'), 'other_flags_not_changed_by_this_experiment': True, 'these_flags_were_not_all_recorded_in_187': True}
    need(ctx['smoke'].base_identity(Path(ctx['common']['base_model']), True) == ctx['old_pre']['base_identity'], 'BASE_MODEL_FILES_DRIFT_STOP')
    partial.mkdir()
    minimum_free = torch.cuda.mem_get_info(device)[0] / 1024 ** 3
    calls = forwards = 0

    def log(event):
        event.update(elapsed_seconds=time.perf_counter() - started)
        with (partial / 'progress.jsonl').open('a', encoding='utf-8') as f:
            f.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + '\n')
        print(json.dumps(event, ensure_ascii=False, allow_nan=False), flush=True)

    def resource_gate():
        nonlocal minimum_free
        minimum_free = min(minimum_free, torch.cuda.mem_get_info(device)[0] / 1024 ** 3)
        need(minimum_free >= 8.0, 'OBSERVED_GPU_FREE_BELOW_8_GIB_STOP')
        need(time.perf_counter() - started <= 1200, 'PAIR_WALL_TIME_BUDGET_STOP')
    log({'event': 'FA2_repeat_model_load_start', 'device': str(device), 'budget': BUDGET})
    tokenizer = AutoTokenizer.from_pretrained(ctx['common']['base_model'], local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token = tokenizer.eos_token
    base = AutoModelForCausalLM.from_pretrained(ctx['common']['base_model'], local_files_only=True, dtype=torch.bfloat16, attn_implementation='flash_attention_2', low_cpu_mem_usage=True)
    base.config.use_cache = False
    base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False, 'preserve_rng_state': True})
    model = PeftModel.from_pretrained(base, ctx['cp']['adapter_directory'], is_trainable=True, autocast_adapter_dtype=True, local_files_only=True)
    model.enable_input_require_grads()
    model.to(device)
    model.train()
    params = [p for p in model.parameters() if p.requires_grad]
    need(all((p.dtype == torch.float32 for p in params)), 'LORA_DTYPE_DRIFT_STOP')
    before, count = ctx['smoke'].parameter_hash(model)
    need(before == upstream['runtime']['signature_before'] and count == 33030144, 'ADAPTER_SIGNATURE_DRIFT_STOP')
    need(model.config._attn_implementation == 'flash_attention_2', 'ATTENTION_BACKEND_DRIFT_STOP')
    layer_count = int(model.config.num_hidden_layers)
    resource_gate()
    previous_flag = os.environ.get('FLASH_ATTENTION_DETERMINISTIC')
    records = {}
    fa_utils.lazy_import_flash_attention = trace.lazy

    def arm(name, requested, paired_forward=None):
        nonlocal calls, forwards
        gc.collect()
        torch.cuda.empty_cache()
        resource_gate()
        torch.cuda.reset_peak_memory_stats(device)
        os.environ['FLASH_ATTENTION_DETERMINISTIC'] = '1' if requested else '0'
        trace.begin(name, requested)
        seed = ctx['row']['new_paired_dropout_seed']
        random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        ids, mask, y = ctx['baseline'].tokenize_row(tokenizer, ctx['sample'], 'ntl', device)
        need(int(ids.shape[-1]) == 45431, 'INPUT_LENGTH_DRIFT_STOP')
        input_sha = hashlib.sha256(ids.detach().cpu().numpy().tobytes()).hexdigest()
        digits = ctx['baseline'].tokenizer_digit_ids(tokenizer)
        anchors = torch.linspace(0, 1, 10, device=device, dtype=torch.float32)
        forwards += 1
        need(forwards <= 2, 'MODEL_FORWARD_BUDGET_EXCEEDED_STOP')
        raw = model(input_ids=ids, attention_mask=mask).logits
        raw_dtype, raw_shape = (str(raw.dtype), list(raw.shape))
        logits = raw.float()
        del raw
        selected = logits[:, -1, digits]
        del logits
        probability = torch.softmax(selected, dim=-1)
        losses = m.graph_losses(torch, ctx['baseline'], ctx['design'], probability, y, anchors)
        need(all((bool(torch.isfinite(v)) for v in losses.values())), 'NONFINITE_LOSS_STOP')
        probabilities = probability.detach().cpu().tolist()[0]
        forward = {'digit_probabilities': probabilities, 'input_sha256': input_sha, 'prediction_fraction': float((probability * anchors).sum().detach()), 'raw_dtype': raw_dtype, 'raw_shape': raw_shape, 'losses': {k: float(v.detach()) for k, v in losses.items()}, 'probabilities_bitwise_equal_to_187': probabilities == upstream['forward_reproduction']['new_digit_probabilities']}
        forward_calls = trace.active['kernel_calls']
        need(forward_calls == layer_count and raw_dtype == upstream['forward_reproduction']['raw_logits_dtype'] and (raw_shape == upstream['forward_reproduction']['raw_output_shape']), 'FORWARD_ROUTE_OR_SHAPE_DRIFT_STOP')
        need(max((abs(a - b) for a, b in zip(probabilities, upstream['forward_reproduction']['new_digit_probabilities']))) <= 2e-06, '187_FORWARD_REPRODUCTION_SCREEN_STOP')
        if paired_forward is not None:
            need(input_sha == paired_forward['input_sha256'] and probabilities == paired_forward['digit_probabilities'] and (forward['losses'] == paired_forward['losses']), 'PAIRED_FORWARD_OR_LOSS_NOT_BITWISE_EQUAL_STOP')
        save(partial / (name + '_forward.json'), forward)
        log({'event': 'FA2_repeat_forward_checked', 'arm': name, 'requested_deterministic': requested, 'actual_forward_kernel_calls': forward_calls, 'expected_attention_layers': layer_count, 'paired_forward_bitwise_equal': True if paired_forward is not None else None})
        resource_gate()
        vectors = {'Q': [], 'full': []}
        for j, component in enumerate(CALL_ORDER):
            calls += 1
            need(calls <= 12, 'PARAMETER_BACKWARD_BUDGET_EXCEEDED_STOP')
            resource_gate()
            log({'event': 'FA2_repeat_backward_start', 'arm': name, 'global_call': calls, 'component': component})
            gg = torch.autograd.grad(losses[component], params, retain_graph=j < len(CALL_ORDER) - 1, create_graph=False, allow_unused=False)
            vector = np.empty(count, dtype='float32')
            pos = 0
            for g in gg:
                need(bool(torch.isfinite(g).all()), 'NONFINITE_PARAMETER_GRADIENT_STOP')
                values = g.detach().float().cpu().numpy().reshape(-1)
                vector[pos:pos + len(values)] = values
                pos += len(values)
            del gg
            need(pos == count and all((p.grad is None for p in params)), 'GRAD_BUFFER_OR_COUNT_DRIFT_STOP')
            vectors[component].append(vector)
            resource_gate()
            log({'event': 'FA2_repeat_backward_complete', 'arm': name, 'global_call': calls, 'component': component, 'actual_kernel_calls_including_recomputation': trace.active['kernel_calls']})
        report = {'arm': name, 'requested_deterministic': requested, 'forward': forward, 'HF_runtime_layout': dict(trace.layout_observation), 'actual_FA2_keyword_trace': dict(trace.active, by_function=dict(trace.active['by_function'])), 'forward_kernel_calls': forward_calls, 'repeated_parameter_gradients': {k: repeats(v) for k, v in vectors.items()}, 'peak_allocated_GiB': torch.cuda.max_memory_allocated(device) / 1024 ** 3, 'peak_reserved_GiB': torch.cuda.max_memory_reserved(device) / 1024 ** 3, 'minimum_observed_free_GiB_so_far': minimum_free}
        need(report['actual_FA2_keyword_trace']['kernel_calls'] > forward_calls, 'CHECKPOINT_RECOMPUTE_TRACE_MISSING_STOP')
        after, after_count = ctx['smoke'].parameter_hash(model)
        need(after == before and after_count == count and all((p.grad is None for p in params)), 'PARAMETERS_CHANGED_STOP')
        save(partial / (name + '_summary.json'), report)
        return report
    try:
        records['control_false'] = arm('control_false', False)
        records['candidate_true'] = arm('candidate_true', True, records['control_false']['forward'])
    finally:
        fa_utils.lazy_import_flash_attention = original_lazy
        if previous_flag is None:
            os.environ.pop('FLASH_ATTENTION_DETERMINISTIC', None)
        else:
            os.environ['FLASH_ATTENTION_DETERMINISTIC'] = previous_flag
    need(forwards == 2 and calls == 12, 'PAIRED_BUDGET_COVERAGE_INCOMPLETE_STOP')
    after, after_count = ctx['smoke'].parameter_hash(model)
    need(before == after and count == after_count and all((p.grad is None for p in params)), 'FINAL_READONLY_SIGNATURE_FAIL_STOP')
    resource_gate()
    control_exact = all((v['all_bitwise_equal'] for v in records['control_false']['repeated_parameter_gradients'].values()))
    candidate_exact = all((v['all_bitwise_equal'] for v in records['candidate_true']['repeated_parameter_gradients'].values()))
    interpretation = 'TRUE_ARM_REPEATS_BITWISE_EQUAL_DEFAULT_ARM_VARIES' if candidate_exact and (not control_exact) else 'BOTH_ARMS_REPEATS_BITWISE_EQUAL_NO_DEFAULT_VARIATION_IN_THIS_PAIR' if candidate_exact else 'TRUE_FLAG_REACHED_FA2_BUT_REPEAT_VARIATION_REMAINS'
    result = {'status': 'FA2_REPEAT_PAIR_COMPLETE_REVIEW_ONLY', 'decision': 'REVIEW_EXECUTION_REPEATABILITY_NOT_TRAINING_APPROVAL', 'version': VERSION, 'script_sha256': sha(__file__), 'preflight_sha256': sha(root / ROOT_REL / '\u51bb\u7ed3\u9884\u68c0.json'), 'plan': frozen['plan'], 'arms': records, 'explicit_model_forwards': forwards, 'parameter_backward_calls': calls, 'observation': interpretation, 'runtime': {'environment': environment, 'signature_before': before, 'signature_after': after, 'numerics': runtime_numerics, 'parameters': count, 'minimum_observed_free_GiB': minimum_free, 'elapsed_seconds': time.perf_counter() - started}, 'scope': {'optimizer_created': False, 'parameters_updated': False, 'adapter_saved': False, 'new_development_inference': False, 'official_validation_rows_read': False, 'test_or_E3_rows_read': False, 'old_reports_modified': False, 'old_5_percent_gate_changed': False, 'original_187_restarted': False, 'formal_training_started': False, 'historical_training_RNG_or_AdamW_replayed': False, 'base_dtype_or_loss_or_training_dropout_changed': False, 'loaded_GPU_count': 1, 'dependency_validation_reads_existing_internal_development_and_historical_aggregate_records': True}, 'interpretation': 'One fixed sample, sequential arm order, no opposite-order or population replication. Actual FA2 keywords observed through transparent proxies; no MAE gain, novelty, full-training resource guarantee or proof of the historical middle-region error cause. Original mixed-precision algebra deviations are not regraded.'}
    save(partial / '\u786e\u5b9a\u6027\u53cd\u5411\u914d\u5bf9\u8bca\u65ad\u6c47\u603b.json', result)
    save(partial / 'artifact_sha256.json', {p.name: sha(p) for p in partial.iterdir() if p.is_file()})
    need(not out.exists(), 'FINAL_OUTPUT_COLLISION_STOP')
    partial.rename(out)
    print('FA2_REPEAT_PAIR_FINISHED_NO_TRAINING_AUTOSTART', flush=True)
    show(root)

def show(root):
    out = root / ROOT_REL / '\u914d\u5bf9\u8bca\u65ad\u7ed3\u679c_v1'
    p = out / '\u786e\u5b9a\u6027\u53cd\u5411\u914d\u5bf9\u8bca\u65ad\u6c47\u603b.json'
    if p.is_file():
        need(read(out / 'artifact_sha256.json')[p.name] == sha(p), '190_FINAL_REPORT_HASH_DRIFT_STOP')
        d = read(p)
        arms = {name: {'requested_deterministic': v['requested_deterministic'], 'HF_runtime_layout': v['HF_runtime_layout'], 'actual_FA2_keyword_trace': v['actual_FA2_keyword_trace'], 'repeat_metrics': {k: {f: x[f] for f in ('repeats', 'all_bitwise_equal', 'max_pair_relative_L2_error')} for k, x in v['repeated_parameter_gradients'].items()}, 'peak_allocated_GiB': v['peak_allocated_GiB'], 'peak_reserved_GiB': v['peak_reserved_GiB']} for name, v in d['arms'].items()}
        print(json.dumps({k: d[k] for k in ('status', 'decision', 'observation', 'explicit_model_forwards', 'parameter_backward_calls', 'runtime', 'scope')}, ensure_ascii=False))
        print(json.dumps({'arms': arms, 'report_sha256': sha(p)}, ensure_ascii=False))
        return
    partial = out.with_name(out.name + '.partial')
    events = partial / 'progress.jsonl'
    last = None
    if events.is_file():
        lines = events.read_text(encoding='utf-8').splitlines()
        try:
            last = json.loads(lines[-1]) if lines else None
        except json.JSONDecodeError:
            last = {'event': 'LAST_EVENT_BEING_WRITTEN'}
    print(json.dumps({'status': 'PARTIAL_CHECK_WORKER_LOG' if partial.exists() else 'NO_PROGRESS_FILE_YET_CHECK_WORKER', 'last_event': last}, ensure_ascii=False))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=('self-test', 'preflight', 'run', 'show'))
    p.add_argument('--project-root', type=Path)
    a = p.parse_args()
    if a.command == 'self-test':
        print(json.dumps(self_test(), ensure_ascii=False))
    else:
        need(a.project_root is not None, 'PROJECT_ROOT_REQUIRED')
        root = a.project_root.resolve()
        globals()[a.command](root)
if __name__ == '__main__':
    main()
