"""Bounded fresh-base integration, original921/167 protocol. No formal runner."""
import argparse, contextlib, csv, datetime, importlib.util, io, os, random, subprocess, sys, time, traceback
from pathlib import Path
from core231 import *
import core231 as core
from numeric_resource221 import numeric_prediction, resource_failures, torch_test
HERE = Path(__file__).resolve().parent
OUT = 'outputs/B_NTL\u539f\u59cb\u53e3\u5f84\u4f18\u5316_v1/231_\u65b0\u521d\u59cb\u5316\u53cc\u5361\u56db\u6b65\u96c6\u6210_v1'
DATA = 'outputs/B_NTL\u539f\u59cb\u53e3\u5f84\u4f18\u5316_v1/230_\u539f921_167\u73b0\u6709\u53cc\u89c6\u56fe\u51bb\u7ed3\u51c6\u5907_v1'
MODEL = '\u6a21\u578b\u6587\u4ef6/Qwen3-4B-Instruct-2507'
SEED = 20260928

def plan():
    return read(HERE / 'plan.json')

def load_module(name, file):
    sp = importlib.util.spec_from_file_location(name, HERE / file)
    m = importlib.util.module_from_spec(sp)
    sp.loader.exec_module(m)
    return m

def modules():
    return (load_module('baseline159_fresh', 'baseline159.py'), load_module('trace190_fresh', 'trace190.py'))

def verify_package():
    for line in (HERE / 'SHA256SUMS.txt').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_DRIFT:' + n)

def verify_data(root):
    p = plan()
    folder = root / DATA
    need(sha(folder / 'summary.json') == p['source230_summary_sha256'], '230_SUMMARY_HASH')
    s = read(folder / 'summary.json')
    need(s['artifacts'] == p['source230_artifacts'] and s['package_plan_sha256'] == p['source230_package_plan_sha256'], '230_BINDING')
    for n, h in p['source230_artifacts'].items():
        need(sha(folder / n) == h, '230_ARTIFACT_HASH:' + n)
    need(read(folder / 'plan.json') == read(HERE / 'source230_plan.json'), '230_PLAN_CONTENT')
    idx = rows(folder / 'input_index_1088.jsonl')
    schedule = read(folder / 'four_epoch_sampler.json')
    by = {r['sample_id']: r for r in idx if r['partition'] == 'train'}
    dev = {r['sample_id']: r for r in idx if r['partition'] == 'development'}
    need(len(idx) == 1088 and len(by) == 921 and (len(dev) == 167) and (not set(by) & set(dev)), 'MEMBERSHIP')
    need(sum((r['messages_changed'] for r in by.values())) == 473 and (not any((r['messages_changed'] for r in dev.values()))), 'CHANGED_ROWS')
    datasets = {a: rows(folder / f'{n}_train_921.jsonl') for a, n in [('control', 'control'), ('repaired', 'candidate')]}
    maps = {a: {sid(r): r for r in rr} for a, rr in datasets.items()}
    need(all((len(rr) == len(maps[a]) == 921 and set(maps[a]) == set(by) for a, rr in datasets.items())), 'FULL_DATASET_MEMBERSHIP')
    for s, r in by.items():
        c, t = (maps[a][s] for a in ('control', 'repaired'))
        non = lambda x: {k: v for k, v in x.items() if k != 'messages'}
        need(non(c) == non(t) and digest(non(c)) == r['fixed_non_message_fields_sha256'], 'NON_MESSAGE_DRIFT')
        need(c['target_fraction'] == r['target_fraction'], 'TARGET_DRIFT')
        need(digest(c['messages']) == r['control_messages_sha256'] and digest(t['messages']) == r['candidate_messages_sha256'], 'MESSAGE_DRIFT')
        need((c['messages'] != t['messages']) == r['messages_changed'], 'CHANGE_FLAG_DRIFT')
    need(select(idx, schedule) == p['selection'], 'STRESS_SELECTION_DRIFT')
    return (idx, schedule, maps)

def verify_base(root):
    model = (root / MODEL).resolve()
    p = plan()
    files = p['base_identity']['files']
    need(not (model / 'adapter_config.json').exists(), 'BASE_IS_ADAPTER')
    for n, v in files.items():
        f = (model / n).resolve()
        need(f.is_relative_to(model) and f.is_file(), 'BASE_PATH')
        before = f.stat()
        need(before.st_size == v['bytes'] and sha(f) == v['sha256'], 'BASE_HASH:' + n)
        need((before.st_size, before.st_mtime_ns) == (f.stat().st_size, f.stat().st_mtime_ns), 'BASE_CHANGED_WHILE_HASHING')
        print(canon({'event': 'base_file_verified', 'file': n}), flush=True)
    need(digest(files) == p['base_identity']['sha256'], 'BASE_IDENTITY')
    need(set(read(model / 'model.safetensors.index.json')['weight_map'].values()) == {n for n in files if n.endswith('.safetensors')}, 'BASE_WEIGHT_INDEX')

def gpu_table():
    r = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,memory.used,memory.free,utilization.gpu', '--format=csv,noheader,nounits'], check=True, capture_output=True, text=True, timeout=30)
    rr = [dict(index=int(v[0]), uuid=v[1].strip(), used_MiB=float(v[2]), free_MiB=float(v[3]), util_percent=float(v[4])) for v in csv.reader(io.StringIO(r.stdout)) if v]
    need(len({r['index'] for r in rr}) == len(rr) == len({r['uuid'] for r in rr}), 'GPU_DUPLICATES')
    return rr

def idle(r):
    return 0 <= r['index'] <= 7 and all((math.isfinite(r[k]) for k in ('used_MiB', 'free_MiB', 'util_percent'))) and (r['used_MiB'] < 1024) and (r['free_MiB'] >= 66560) and (r['util_percent'] <= 5)

def preflight(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'PREFLIGHT_CPU_ONLY')
    verify_package()
    verify_data(root)
    verify_base(root)
    baseline, trace = modules()
    runtime = trace.installed_sources()
    import torch
    tests = core.cpu_autograd()
    numeric = torch_test('cpu')
    need(not torch.cuda.is_initialized(), 'CPU_INITIALIZED_CUDA')
    need(all((abs(baseline.cosine_lambda(i, 464, 24) * 0.0001 - v) < 1e-18 for i, v in enumerate([1e-12, 0.0001 / 24, 0.0002 / 24]))), 'WARMUP_CONTRACT')
    out = root / OUT
    out.mkdir(parents=True, exist_ok=True)
    save(out / 'preflight.json', {'status': 'PASS', 'plan_sha256': sha(HERE / 'plan.json'), 'manifest_sha256': sha(HERE / 'SHA256SUMS.txt'), 'source230_summary_sha256': plan()['source230_summary_sha256'], 'installed_runtime': runtime, 'tests': tests, 'numeric_test': numeric, 'base_identity': plan()['base_identity'], 'model_loaded': False, 'GPU_started': False})
    print('FRESH231_CPU_PREFLIGHT_PASS_NO_MODEL_LOADED', flush=True)

def frozen(root):
    verify_package()
    d = read(root / OUT / 'preflight.json')
    need(d['status'] == 'PASS' and d['plan_sha256'] == sha(HERE / 'plan.json') and (d['manifest_sha256'] == sha(HERE / 'SHA256SUMS.txt')), 'PREFLIGHT_DRIFT')
    return d

def select_gpus(root):
    frozen(root)
    rr = gpu_table()
    for r in rr:
        print(canon(dict(r, eligible=idle(r))), flush=True)
    chosen = sorted((r for r in rr if idle(r)), key=lambda r: r['index'])
    need(len(chosen) >= 2, 'FEWER_THAN_TWO_IDLE_GPUS_STOP')
    save(root / OUT / 'selected_gpus.json', {'selected': chosen[:2], 'preflight_sha256': sha(root / OUT / 'preflight.json'), 'world_size': 2, 'other_idle_cards': len(chosen) - 2, 'topology_frozen_two_no_silent_switch': True})

def check_gpus(root):
    frozen(root)
    d = read(root / OUT / 'selected_gpus.json')
    need(d['preflight_sha256'] == sha(root / OUT / 'preflight.json'), 'GPU_BINDING')
    rr = {r['uuid']: r for r in gpu_table()}
    need(len(d['selected']) == 2 and len({r['uuid'] for r in d['selected']}) == 2, 'GPU_COUNT')
    for r in d['selected']:
        need(r['uuid'] in rr and rr[r['uuid']]['index'] == r['index'] and idle(rr[r['uuid']]), 'SELECTED_GPU_BUSY_STOP')

def smoke(root, arm):
    pre = frozen(root)
    p = plan()
    selected = read(root / OUT / 'selected_gpus.json')['selected']
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == ','.join((r['uuid'] for r in selected)) and os.environ.get('FLASH_ATTENTION_DETERMINISTIC') == '1', 'GPU_ENVIRONMENT')
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel as DDP
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, TaskType, get_peft_model
    rank, local, world = (int(os.environ[k]) for k in ('RANK', 'LOCAL_RANK', 'WORLD_SIZE'))
    need(world == 2 and rank == local and (rank in (0, 1)), 'TWO_GPU_REQUIRED')
    torch.cuda.set_device(local)
    device = torch.device('cuda', local)
    start = time.monotonic()
    dist.init_process_group('nccl', timeout=datetime.timedelta(seconds=600), device_id=device)

    def gather(x):
        rr = [None] * 2
        dist.all_gather_object(rr, x)
        return rr
    folder = root / OUT / (arm + '.partial')
    final = root / OUT / arm
    try:
        need(torch.cuda.mem_get_info()[0] / 1024 ** 3 >= 65, 'INITIAL_MEMORY_GATE')
        if rank == 0:
            need(not folder.exists() and (not final.exists()), 'ARM_EXISTS_STOP')
            folder.mkdir()
            verify_base(root)
        dist.barrier()
        idx, schedule, maps = verify_data(root)
        by = {r['sample_id']: r for r in idx if r['partition'] == 'train'}
        baseline, trace_module = modules()
        need(trace_module.installed_sources() == pre['installed_runtime'], 'RUNTIME_DRIFT')
        minimum = 100.0
        sequence = 0

        def emit(e):
            e = dict(e, rank=rank, arm=arm, elapsed_seconds=time.monotonic() - start)
            with (folder / f'events_rank{rank}.jsonl').open('a', encoding='utf-8') as f:
                f.write(canon(e) + '\n')
            if rank == 0:
                print(canon(e), flush=True)

        def resource(phase, collective=True):
            nonlocal minimum, sequence
            free = torch.cuda.mem_get_info()[0] / 1024 ** 3
            minimum = min(minimum, free)
            s = dict(rank=rank, phase=phase, free_GiB=free, allocated_GiB=torch.cuda.memory_allocated() / 1024 ** 3, reserved_GiB=torch.cuda.memory_reserved() / 1024 ** 3, elapsed_seconds=time.monotonic() - start)
            if collective:
                sequence += 1
                s['sequence'] = sequence
                states = gather(s)
                need(len({(v['sequence'], v['phase']) for v in states}) == 1, 'COLLECTIVE_SEQUENCE')
                need(not resource_failures(states, 8.0, 2400.0), 'RESOURCE_GATE')
            else:
                need(math.isfinite(free) and free >= 8 and (s['elapsed_seconds'] < 2400), 'LOCAL_VIEW_RESOURCE_GATE')
            with (folder / f'resources_rank{rank}.jsonl').open('a', encoding='utf-8') as f:
                f.write(canon(s) + '\n')

        def seed():
            random.seed(SEED + rank)
            torch.manual_seed(SEED + rank)
            torch.cuda.manual_seed_all(SEED + rank)
        seed()
        numeric_test = torch_test(device)
        seed()
        emit({'event': 'fresh_model_load_start'})
        tokenizer = AutoTokenizer.from_pretrained(root / MODEL, local_files_only=True)
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        digits = baseline.tokenizer_digit_ids(tokenizer)
        need(digits == list(range(15, 25)), 'DIGIT_IDS')
        anchors = torch.linspace(0, 1, 10, device=device, dtype=torch.float32)
        base = AutoModelForCausalLM.from_pretrained(root / MODEL, local_files_only=True, dtype=torch.bfloat16, attn_implementation='flash_attention_2', low_cpu_mem_usage=True)
        base.config.use_cache = False
        base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
        cfg = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias='none', task_type=TaskType.CAUSAL_LM, target_modules=['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj'])
        model = get_peft_model(base, cfg)
        model.enable_input_require_grads()
        model.to(device)
        model.train()
        model = DDP(model, device_ids=[local], output_device=local, broadcast_buffers=False, find_unused_parameters=False)
        initial, count = parameter_hash(model.module)
        need(count == 33030144 and len(set(gather(initial))) == 1, 'FRESH_INITIALIZATION_SYNC')
        aa = [v for n, v in model.module.named_parameters() if '.lora_A.' in n]
        bb = [v for n, v in model.module.named_parameters() if '.lora_B.' in n]
        need(aa and bb and all((bool(torch.isfinite(v).all()) for v in aa + bb)) and all((bool((v == 0).all()) for v in bb)) and any((bool((v != 0).any()) for v in aa)), 'FRESH_LORA_INITIALIZATION')
        import transformers.modeling_flash_attention_utils as fa
        original_lazy = fa.lazy_import_flash_attention
        trace = trace_module.KernelTrace(original_lazy, pre['installed_runtime']['HF_consumer_layout']['processor_layout'])
        trace.begin(arm, True)
        fa.lazy_import_flash_attention = trace.lazy
        trace.lazy('flash_attention_2')
        probeid = p['selection']['probe']
        rng = (torch.get_rng_state(), torch.cuda.get_rng_state(), random.getstate())
        model.module.eval()
        with torch.inference_mode():
            ids, mask, y = baseline.tokenize_row(tokenizer, maps['control'][probeid], 'ntl', device)
            need(ids.shape[-1] == by[probeid]['control_numeric_tokens'], 'PROBE_LENGTH')
            pred, prob = numeric_prediction(model.module, ids, mask, 'ntl', anchors, digits, True)
            probe = prob[0].tolist()
            del ids, mask, y, pred, prob
        model.train()
        torch.set_rng_state(rng[0])
        torch.cuda.set_rng_state(rng[1])
        random.setstate(rng[2])
        need(parameter_hash(model.module)[0] == initial, 'PROBE_PARAMETER_MUTATION')
        parameters = [v for v in model.parameters() if v.requires_grad]
        seed()
        optimizer = torch.optim.AdamW(parameters, lr=0.0001, betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01, fused=True)
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda s: baseline.cosine_lambda(s, 464, 24))
        optimizer.zero_grad(set_to_none=True)
        history = []
        positions = []
        for step, batch in enumerate(p['selection']['batches'], 1):
            local_ids = layout(batch, rank)
            micros = len(local_ids)
            used = scheduler.get_last_lr()
            stats = torch.zeros(4, device=device, dtype=torch.float64)
            for offset, s in enumerate(local_ids):
                resource(f'before_step{step}_micro{offset}')
                vv = views(arm, by[s]['messages_changed'], step > 2)
                for j, (ia, w) in enumerate(vv):
                    resource(f'before_view{step}_{offset}_{j}', False)
                    ids, mask, y = baseline.tokenize_row(tokenizer, maps[ia][s], 'ntl', device)
                    length = by[s]['control_numeric_tokens' if ia == 'control' else 'candidate_numeric_tokens']
                    need(ids.shape[-1] == length, 'ACTUAL_LENGTH_DRIFT')
                    sync = sync_here(offset, j, len(vv), micros)
                    with contextlib.nullcontext() if sync else model.no_sync():
                        pred, prob = numeric_prediction(model, ids, mask, 'ntl', anchors, digits)
                        ce, w1, q = baseline.ntl_components(prob, y)
                        loss = 0.1 * ce + w1
                        need(bool(torch.isfinite(loss)) and bool(torch.isfinite(prob).all()), 'NONFINITE_LOSS')
                        (w * loss / micros).backward()
                    stats += w * torch.stack([loss.detach().double(), ce.detach().double(), w1.detach().double(), torch.ones((), device=device, dtype=torch.float64)])
                    positions.append(dict(step=step, offset=offset, sample_id=s, input_arm=ia, weight=w, sync=sync, tokens=length, normalization=micros))
                    del ids, mask, y, pred, prob, ce, w1, q, loss
                    resource(f'after_view{step}_{offset}_{j}', False)
                resource(f'after_step{step}_micro{offset}')
                emit({'event': 'unit_backward_completed', 'step': step, 'micro': offset + 1})
            norm = float(torch.nn.utils.clip_grad_norm_(parameters, 1.0).item())
            need(math.isfinite(norm), 'NONFINITE_GRADIENT')
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad(set_to_none=True)
            torch.cuda.synchronize()
            resource(f'after_update{step}')
            h, _ = parameter_hash(model.module)
            need(len(set(gather(h))) == 1, 'PARAMETERS_UNSYNCHRONIZED')
            dist.all_reduce(stats)
            v = (stats[:3] / stats[3]).tolist()
            event = dict(step=step, batch_positions=len(batch), parameter_sha256=h, gradient_norm=norm, learning_rate_used=used, learning_rate_next=scheduler.get_last_lr(), loss=v[0], ce=v[1], w1=v[2])
            history.append(event)
            emit(dict(event, event='optimizer_step'))
        need(history[1]['parameter_sha256'] != history[0]['parameter_sha256'] and history[1]['parameter_sha256'] != initial, 'REAL_WARMUP_UPDATE_COVERAGE')
        need(trace.active['kernel_calls'] > 0 and trace.active['all_actual_keywords_match'], 'DETERMINISTIC_KERNEL_TRACE')
        fa.lazy_import_flash_attention = original_lazy
        runtime = gather(dict(rank=rank, probe=probe, positions=positions, peak_reserved_GiB=torch.cuda.max_memory_reserved() / 1024 ** 3, minimum_free_GiB=minimum, trace=trace.active, numeric_test=numeric_test))
        if rank == 0:
            verify_data(root)
            verify_base(root)
            result = dict(status='PASS', arm=arm, plan_sha256=sha(HERE / 'plan.json'), preflight_sha256=sha(root / OUT / 'preflight.json'), gpu_selection_sha256=sha(root / OUT / 'selected_gpus.json'), initial_parameter_sha256=initial, trainable_parameters=count, events=history, runtime_by_rank=runtime, adapter_saved=False, formal_training_started=False, development_inferred=False)
            save(folder / 'summary.json', result)
            save(folder / 'artifact_sha256.json', {f.name: sha(f) for f in folder.iterdir() if f.is_file()})
            folder.rename(final)
        dist.barrier()
    except BaseException:
        traceback.print_exc()
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(1)
    else:
        dist.destroy_process_group()

def compare(root):
    frozen(root)
    p = plan()
    idx, _, _ = verify_data(root)
    by = {r['sample_id']: r for r in idx}
    rr = {}
    for arm in ('control', 'repaired'):
        folder = root / OUT / arm
        for n, h in read(folder / 'artifact_sha256.json').items():
            need(Path(n).name == n and sha(folder / n) == h, 'RESULT_HASH')
        d = read(folder / 'summary.json')
        rr[arm] = d
        need(d['status'] == 'PASS' and d['arm'] == arm and (d['plan_sha256'] == sha(HERE / 'plan.json')) and (d['preflight_sha256'] == sha(root / OUT / 'preflight.json')) and (d['gpu_selection_sha256'] == sha(root / OUT / 'selected_gpus.json')), 'ARM_BINDING')
        need(len(d['events']) == 4 and len(d['runtime_by_rank']) == 2 and ({r['rank'] for r in d['runtime_by_rank']} == {0, 1}), 'ARM_SHAPE')
        need(not any((d[k] for k in ('adapter_saved', 'formal_training_started', 'development_inferred'))), 'ARM_SCOPE')
        for r in d['runtime_by_rank']:
            expected = []
            for step, b in enumerate(p['selection']['batches'], 1):
                local = layout(b, r['rank'])
                for o, s in enumerate(local):
                    vv = views(arm, by[s]['messages_changed'], step > 2)
                    for j, (ia, w) in enumerate(vv):
                        expected.append(dict(step=step, offset=o, sample_id=s, input_arm=ia, weight=w, sync=sync_here(o, j, len(vv), len(local)), tokens=by[s]['control_numeric_tokens' if ia == 'control' else 'candidate_numeric_tokens'], normalization=len(local)))
            need(expected == r['positions'] and r['minimum_free_GiB'] >= 8, 'EXECUTION_CONTRACT')
            need(r['trace']['requested'] and r['trace']['all_actual_keywords_match'] and (r['trace']['kernel_calls'] > 0), 'KERNEL_TRACE')
    c, t = (rr[a] for a in ('control', 'repaired'))
    need(c['initial_parameter_sha256'] == t['initial_parameter_sha256'], 'PAIRED_FRESH_INITIALIZATION')
    need(c['events'][:2] == t['events'][:2] and c['events'][1]['parameter_sha256'] != c['initial_parameter_sha256'], 'MATCHED_REAL_UPDATE')
    need(c['events'][-1]['parameter_sha256'] != t['events'][-1]['parameter_sha256'], 'ACTIVE_REPAIR_UPDATE_DIFFERENCE')
    probes = [r['probe'] for d in rr.values() for r in d['runtime_by_rank']]
    need(all((len(v) == 10 and all((math.isfinite(x) for x in v)) for v in probes)), 'PROBE_FINITE')
    diff = max((abs(x - y) for v in probes for x, y in zip(v, probes[0])))
    need(diff <= 2e-06, 'PAIRED_PROBE')
    result = dict(status='PASS', decision='FRESH_ORIGINAL_TWO_GPU_INTEGRATION_PASS_REVIEW_FOUR_EPOCH_RUNNER_ONLY', plan_sha256=sha(HERE / 'plan.json'), optimizer_steps_per_arm=4, world_size=2, gradient_accumulation_full=4, gradient_accumulation_tail=2, batch_positions=[8, 8, 8, 4], fresh_initial_parameters_match=True, first_two_updates_match=True, nonzero_learning_rate_update_matched=True, active_repair_changes_later_update=True, initial_probe_max_difference=diff, training_membership=921, development_membership=167, arm_summary_sha256={a: sha(root / OUT / a / 'summary.json') for a in rr}, peak_reserved_GiB={a: max((r['peak_reserved_GiB'] for r in d['runtime_by_rank'])) for a, d in rr.items()}, adapter_saved=False, formal_training_started=False, development_inferred=False, MAE_improvement_established=False, warning='Selected/repeated training-only stress fixtures. No historical bitwise trajectory, full-run resource, or generalization guarantee. No trained adapter reused or saved.')
    save(root / OUT / 'paired_smoke_summary.json', result)
    print(json.dumps(result, ensure_ascii=False, indent=2))

def show(root):
    out = root / OUT
    if (out / 'paired_smoke_summary.json').exists():
        print((out / 'paired_smoke_summary.json').read_text(encoding='utf-8'))
    else:
        for arm in ('control', 'repaired'):
            f = out / (arm + '.partial') / 'events_rank0.jsonl'
            last = None
            if f.exists():
                for line in f.read_text(encoding='utf-8').splitlines():
                    try:
                        last = json.loads(line)
                    except json.JSONDecodeError:
                        pass
            print(canon(dict(arm=arm, status='COMPLETED' if (out / arm / 'summary.json').exists() else 'PARTIAL' if f.exists() else 'NOT_STARTED', last_event=last)))
    if (out / 'exit_code.txt').exists():
        print('WORKER_EXIT_CODE=' + (out / 'exit_code.txt').read_text().strip())
    else:
        running = False
        if (out / 'worker.pid').exists():
            pid = (out / 'worker.pid').read_text().strip()
            if pid.isdigit():
                cmd = Path('/proc') / pid / 'cmdline'
                running = cmd.exists() and str(HERE).encode() in cmd.read_bytes()
        print('FRESH231_WORKER_RUNNING=' + str(running))
    if (out / 'worker.log').exists() and (out / 'exit_code.txt').exists() and ((out / 'exit_code.txt').read_text().strip() != '0'):
        print('\n'.join((out / 'worker.log').read_text(errors='replace').splitlines()[-55:]))
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('command', choices=['self-test', 'preflight', 'select-gpus', 'check-gpus', 'visibility', 'smoke', 'compare', 'show'])
    ap.add_argument('--project-root', type=Path)
    ap.add_argument('--arm', choices=['control', 'repaired'])
    a = ap.parse_args()
    if a.command == 'self-test':
        print(canon(core.selftest()))
    else:
        need(a.project_root is not None, 'ROOT_REQUIRED')
        root = a.project_root.resolve()
        if a.command == 'visibility':
            print(','.join((r['uuid'] for r in read(root / OUT / 'selected_gpus.json')['selected'])))
        elif a.command == 'smoke':
            need(a.arm is not None, 'ARM_REQUIRED')
            smoke(root, a.arm)
        else:
            globals()[a.command.replace('-', '_')](root)
