"""Frozen original-protocol data, selection, provenance and read-only status gates."""
import contextlib, datetime, importlib.util, json, math, os, random, shutil, sys, time, traceback
from pathlib import Path
from collections import Counter, defaultdict
from core231 import *
import core231 as core
from numeric_resource221 import numeric_prediction, resource_failures, torch_test
HERE = Path(__file__).resolve().parent
OUT = 'outputs/B_NTL\u539f\u59cb\u53e3\u5f84\u4f18\u5316_v1/232_\u539f921_167\u53cc\u5361\u56db\u8f6e\u6b63\u5f0f\u914d\u5bf9_v1'
DATA = 'outputs/B_NTL\u539f\u59cb\u53e3\u5f84\u4f18\u5316_v1/230_\u539f921_167\u73b0\u6709\u53cc\u89c6\u56fe\u51bb\u7ed3\u51c6\u5907_v1'
MODEL = '\u6a21\u578b\u6587\u4ef6/Qwen3-4B-Instruct-2507'
SMOKE = 'outputs/B_NTL\u539f\u59cb\u53e3\u5f84\u4f18\u5316_v1/231_\u65b0\u521d\u59cb\u5316\u53cc\u5361\u56db\u6b65\u96c6\u6210_v1'
SEED = 20260928

def plan():
    return read(HERE / 'plan.json')

def engine():
    spec = importlib.util.spec_from_file_location('frozen231_execution232', HERE / 'execution231.py')
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.OUT = OUT
    m.HERE = HERE
    m.plan = plan
    return m

def modules():
    return engine().modules()

def verify_package():
    return engine().verify_package()

def verify_data(root):
    return engine().verify_data(root)

def verify_base(root):
    return engine().verify_base(root)

def frozen(root):
    return engine().frozen(root)

def select_gpus(root):
    return engine().select_gpus(root)

def check_gpus(root):
    return engine().check_gpus(root)

def save_rows(p, rr):
    with Path(p).open('x', encoding='utf-8', newline='\n') as f:
        for r in rr:
            f.write(canon(r) + '\n')

def manifest(folder):
    return {f.relative_to(folder).as_posix(): sha(f) for f in folder.rglob('*') if f.is_file() and f.name != 'artifact_sha256.json'}

def safe_manifest(folder):
    rr = read(folder / 'artifact_sha256.json')
    for n, h in rr.items():
        f = (folder / n).resolve()
        need(f.is_relative_to(folder.resolve()) and f.is_file() and (sha(f) == h), 'ARTIFACT_DRIFT:' + n)
    return rr

def verify231(root):
    p = plan()
    folder = root / SMOKE
    ds = {}
    for a, h in p['smoke231_arm_hashes'].items():
        f = folder / a / 'summary.json'
        need(sha(f) == h, '231_ARM_HASH')
        d = read(f)
        ds[a] = d
        need(d['status'] == 'PASS' and d['arm'] == a and (d['plan_sha256'] == p['smoke231_plan_sha256']), '231_ARM_IDENTITY')
        need(d['preflight_sha256'] == sha(folder / 'preflight.json') and d['gpu_selection_sha256'] == sha(folder / 'selected_gpus.json'), '231_PROVENANCE')
        need(not any((d[k] for k in ('adapter_saved', 'formal_training_started', 'development_inferred'))), '231_SCOPE')
        need(len(d['events']) == 4 and d['trainable_parameters'] == 33030144, '231_BUDGET')
        safe_manifest(folder / a)
        for r in d['runtime_by_rank']:
            need(r['minimum_free_GiB'] >= 8 and r['trace']['requested'] and r['trace']['all_actual_keywords_match'] and (r['trace']['kernel_calls'] > 0), '231_RESOURCE_OR_KERNEL')
    c, t = (ds[a] for a in ('control', 'repaired'))
    need(c['initial_parameter_sha256'] == t['initial_parameter_sha256'] and c['events'][:2] == t['events'][:2], '231_FRESH_MATCH')
    need(c['events'][1]['parameter_sha256'] != c['events'][0]['parameter_sha256'] and c['events'][-1]['parameter_sha256'] != t['events'][-1]['parameter_sha256'], '231_REAL_UPDATE')
    pair = read(folder / 'paired_smoke_summary.json')
    need(pair['status'] == 'PASS' and pair['decision'] == 'FRESH_ORIGINAL_TWO_GPU_INTEGRATION_PASS_REVIEW_FOUR_EPOCH_RUNNER_ONLY' and (pair['arm_summary_sha256'] == p['smoke231_arm_hashes']) and (pair['plan_sha256'] == p['smoke231_plan_sha256']), '231_PAIR')
    need((folder / 'exit_code.txt').read_text().strip() == '0', '231_EXIT')
    return {'initial_parameter_sha256': c['initial_parameter_sha256'], 'preflight_sha256': sha(folder / 'preflight.json'), 'paired_summary_sha256': sha(folder / 'paired_smoke_summary.json'), 'arm_hashes': p['smoke231_arm_hashes']}

def development(root, idx):
    rr = rows(root / DATA / 'development_167.jsonl')
    by = {r['sample_id']: r for r in idx if r['partition'] == 'development'}
    need(len(rr) == len(by) == 167 and len({sid(r) for r in rr}) == 167 and ({sid(r) for r in rr} == set(by)), 'DEV_IDENTITIES')
    for r in rr:
        f = by[sid(r)]
        need(digest(r['messages']) == f['control_messages_sha256'] == f['candidate_messages_sha256'], 'DEV_INPUT_DRIFT')
        need(r['target_fraction'] == f['target_fraction'] and digest({k: v for k, v in r.items() if k != 'messages'}) == f['fixed_non_message_fields_sha256'], 'DEV_LABEL_DRIFT')
    need(sum((r['subject'] == '01_\u8ba1\u7b97\u673a\u79d1\u5b66' for r in by.values())) == 119 and len({r['unit_id'] for r in by.values()}) == 166 and (len({r['student_group_id'] for r in by.values()}) == 56), 'DEV_COUNTS')
    train = [r for r in idx if r['partition'] == 'train']
    need(len({r['student_group_id'] for r in train} & {r['student_group_id'] for r in by.values()}) == 26, 'DISCLOSED_STUDENT_OVERLAP')
    need(not {r['unit_id'] for r in train} & {r['unit_id'] for r in by.values()}, 'UNIT_OVERLAP')
    return (rr, by)

def verify_schedule(idx, schedule, baseline):
    ids = [r['sample_id'] for r in idx if r['partition'] == 'train']
    fake = [{} for _ in ids]
    need(len(schedule) == 4, 'EPOCHS')
    for e, d in enumerate(schedule):
        expected = [ids[i] for g in baseline.rank_groups(fake, 4, SEED, e) for i in g]
        need(d['epoch'] == e + 1 and d['sample_ids'] == expected and (d['batch_sizes'] == [8] * 115 + [4]) and (d['batches'] == [expected[i:i + 8] for i in range(0, 924, 8)]), 'HISTORICAL_SAMPLER')

def key(metrics):
    result = (metrics['overall']['mae_percent_points'], metrics['computer_science']['mae_percent_points'], metrics['overall']['rmse_percent_points'])
    need(all((math.isfinite(v) for v in result)), 'NONFINITE_SELECTION')
    return result

def choose(history):
    need(bool(history), 'EMPTY_HISTORY')
    return min(history, key=lambda d: (key(d['development']), d['epoch']))

def region(r):
    if r['subject'] != '01_\u8ba1\u7b97\u673a\u79d1\u5b66':
        return 'non_CS'
    y = r.get('source_target_fraction', r['target_fraction'])
    return 'CS_low' if y < 0.2 else 'CS_high' if y >= 0.8 else 'CS_middle'

def regions(rr, baseline):
    return {g: baseline.prediction_metrics([r for r in rr if region(r) == g]) for g in ('CS_low', 'CS_middle', 'CS_high', 'non_CS')}

def eval_rounds(n):
    return [(i, i + 1 if i + 1 < n else None) for i in range(0, n, 2)]

def verify_predictions(rr, df):
    need(len(rr) == len(df) and len({r['sample_id'] for r in rr}) == len(rr) and ({r['sample_id'] for r in rr} == set(df)), 'PREDICTION_COVERAGE')
    for r in rr:
        f = df[r['sample_id']]
        need(all((r[k] == f[k] for k in ('unit_id', 'subject', 'student_group_id'))) and r['source_target_fraction'] == f['target_fraction'] and (abs(r['target_fraction'] - f['target_fraction']) < 1e-07) and (r['prompt_tokens'] == f['control_numeric_tokens']), 'PREDICTION_IDENTITY')
        need(math.isfinite(r['prediction_fraction']) and 0 <= r['prediction_fraction'] <= 1 and (len(r['digit_probabilities']) == 10) and all((math.isfinite(x) and 0 <= x <= 1 for x in r['digit_probabilities'])) and (abs(sum(r['digit_probabilities']) - 1) < 2e-06), 'PREDICTION_NUMERIC')

def preflight(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU_ONLY_PREFLIGHT')
    verify_package()
    p = plan()
    need(shutil.disk_usage(root / '\u8fd0\u884c\u8f93\u51fa').free >= 10 * 1024 ** 3, 'DISK_FREE_BELOW_10_GiB')
    idx, schedule, _ = verify_data(root)
    dev, df = development(root, idx)
    baseline, trace = modules()
    verify_schedule(idx, schedule, baseline)
    evidence = verify231(root)
    verify_base(root)
    installed = trace.installed_sources()
    old = read(root / SMOKE / 'preflight.json')
    need(installed == old['installed_runtime'], 'RUNTIME_DRIFT_SINCE_SMOKE')
    import torch
    tests = core.cpu_autograd()
    need(not torch.cuda.is_initialized(), 'UNEXPECTED_CUDA')
    out = root / OUT
    out.mkdir(parents=True, exist_ok=True)
    result = {'status': 'PASS', 'decision': 'READY_FOR_ORIGINAL921_167_FRESH_TWO_GPU_FOUR_EPOCH_PAIR', 'plan_sha256': sha(HERE / 'plan.json'), 'manifest_sha256': sha(HERE / 'SHA256SUMS.txt'), 'source230_summary_sha256': p['source230_summary_sha256'], 'installed_runtime': installed, 'smoke231': evidence, 'initial_parameter_sha256': evidence['initial_parameter_sha256'], 'base_identity': p['base_identity'], 'development_identity_sha256': digest(df), 'tests': tests, 'model_loaded': False, 'GPU_started': False, 'official_validation_or_E3_opened': False}
    save(out / 'preflight.json', result)
    print(canon(result), flush=True)

def pair_effect(c, t):
    cm = {r['sample_id']: r for r in c}
    tm = {r['sample_id']: r for r in t}
    need(len(c) == len(t) == len(cm) == len(tm) and set(cm) == set(tm), 'PAIR_IDS')
    deltas = []
    groups = defaultdict(list)
    for s in cm:
        a, b = (cm[s], tm[s])
        need(all((a[k] == b[k] for k in ('unit_id', 'subject', 'student_group_id', 'source_target_fraction', 'target_fraction', 'prompt_tokens'))), 'PAIR_IDENTITY')
        delta = 100 * (abs(b['prediction_fraction'] - b['target_fraction']) - abs(a['prediction_fraction'] - a['target_fraction']))
        deltas.append(dict(sample_id=s, unit_id=a['unit_id'], student_group_id=a['student_group_id'], region=region(a), delta_MAE_pp=delta))
        groups[a['student_group_id']].append(delta)
    avg = lambda rr: sum((r['delta_MAE_pp'] for r in rr)) / len(rr) if rr else None
    return ({'overall_MAE_pp': avg(deltas), 'CS_MAE_pp': avg([r for r in deltas if r['region'] != 'non_CS']), 'region_MAE_pp': {g: avg([r for r in deltas if r['region'] == g]) for g in ('CS_low', 'CS_middle', 'CS_high', 'non_CS')}}, deltas, [{'student_group_id': g, 'records': len(v), 'mean_delta_MAE_pp': sum(v) / len(v)} for g, v in sorted(groups.items())])

def compare(root):
    pre = frozen(root)
    idx, _, _ = verify_data(root)
    _, df = development(root, idx)
    baseline, _ = modules()
    ds = {}
    predictions = {}
    for a in ('control', 'repaired'):
        folder = root / OUT / a
        safe_manifest(folder)
        d = read(folder / 'training_summary.json')
        ds[a] = d
        need(d['status'] == 'PASS' and d['arm'] == a and (d['optimizer_steps'] == 464) and (d['epochs_completed'] == 4) and (d['plan_sha256'] == sha(HERE / 'plan.json')) and (d['preflight_sha256'] == sha(root / OUT / 'preflight.json')) and (d['gpu_selection_sha256'] == sha(root / OUT / 'selected_gpus.json')), 'FORMAL_RESULT_BINDING')
        need(d['initial_parameter_sha256'] == pre['initial_parameter_sha256'] and (not d['official_validation_or_E3_opened']), 'INITIALIZATION_OR_SCOPE')
        need(len(d['training_steps']) == 464 and [e['step'] for e in d['training_steps']] == list(range(1, 465)), 'STEP_TRACE_COVERAGE')
        for step, e in enumerate(d['training_steps'], 1):
            need(e['epoch'] == (step - 1) // 116 + 1 and e['batch_positions'] == (4 if step % 116 == 0 else 8), 'STEP_BATCH_TRACE')
            need(len(e['learning_rate_used']) == len(e['learning_rate_next']) == 1 and abs(e['learning_rate_used'][0] - 0.0001 * baseline.cosine_lambda(step - 1, 464, 24)) < 1e-15 and (abs(e['learning_rate_next'][0] - 0.0001 * baseline.cosine_lambda(step, 464, 24)) < 1e-15), 'LR_TRACE_DRIFT')
            need(all((math.isfinite(e[k]) for k in ('total_loss', 'numeric_ce', 'wasserstein_1', 'gradient_norm_before_clip', 'train_window_MAE_pp'))) and abs(e['total_loss'] - (0.1 * e['numeric_ce'] + e['wasserstein_1'])) < 1e-06, 'LOSS_TRACE_DRIFT')
        hist = []
        for epoch in range(1, 5):
            cp = folder / f'checkpoints/epoch_{epoch}'
            r = rows(cp / 'development_predictions.jsonl')
            verify_predictions(r, df)
            metrics = baseline.split_metrics(r)
            h = read(cp / 'epoch_summary.json')
            need(h['epoch'] == epoch and h['optimizer_step'] == 116 * epoch and (h['development'] == metrics) and (h['parameter_sha256'] == d['training_steps'][116 * epoch - 1]['parameter_sha256']), 'EPOCH_METRIC_RECOMPUTATION')
            hist.append(h)
        best = choose(hist)
        need(d['best_epoch'] == best['epoch'] and d['development'] == best['development'] and (d['best_parameter_sha256'] == best['parameter_sha256']), 'SELECTION_DRIFT')
        for f in (folder / f"checkpoints/epoch_{best['epoch']}/adapter").iterdir():
            if f.is_file():
                need(sha(folder / 'best_adapter' / f.name) == sha(f), 'BEST_ADAPTER_COPY_DRIFT')
        positions = []
        for rank in (0, 1):
            positions += rows(folder / f'positions_rank{rank}.jsonl')
        expected = []
        sched = read(root / DATA / 'four_epoch_sampler.json')
        by = {r['sample_id']: r for r in idx}
        for e, ep in enumerate(sched):
            for b, batch in enumerate(ep['batches']):
                for rank in (0, 1):
                    ii = layout(batch, rank)
                    for offset, s in enumerate(ii):
                        vv = views(a, by[s]['messages_changed'], True)
                        for j, (ia, w) in enumerate(vv):
                            expected.append(dict(rank=rank, epoch=e + 1, step=e * 116 + b + 1, offset=offset, view=j, sample_id=s, input_arm=ia, weight=w, sync=sync_here(offset, j, len(vv), len(ii)), tokens=by[s]['control_numeric_tokens' if ia == 'control' else 'candidate_numeric_tokens'], normalization=len(ii)))
        order = lambda r: (r['rank'], r['step'], r['offset'], r['view'])
        need(sorted(positions, key=order) == sorted(expected, key=order), 'FULL_EXECUTION_SAMPLER_VIEW_DRIFT')
        predictions[a] = rows(folder / f"checkpoints/epoch_{best['epoch']}/development_predictions.jsonl")
    effect, deltas, students = pair_effect(predictions['control'], predictions['repaired'])
    good = effect['overall_MAE_pp'] < 0 and effect['CS_MAE_pp'] <= 0
    all_regions = all((v is None or v <= 0 for v in effect['region_MAE_pp'].values()))
    result = dict(status='PASS', decision='INTERNAL_DEVELOPMENT_GAIN_REVIEW_FROZEN_OFFICIAL_EVALUATION' if good else 'KEEP_REFERENCE_NO_AUTOMATIC_ADVANCEMENT', plan_sha256=sha(HERE / 'plan.json'), best_epochs={a: d['best_epoch'] for a, d in ds.items()}, development={a: d['development'] for a, d in ds.items()}, repaired_minus_matched_control=effect, all_regions_nonworse=all_regions, arm_summary_sha256={a: sha(root / OUT / a / 'training_summary.json') for a in ds}, original_model_replaced=False, official_validation_or_E3_opened=False, historical_student_overlap=26, warning='Internal development only; adaptive development use and historical student overlap disclosed. No official NTL-W superiority claim; no automatic evaluation or deployment.')
    save_rows(root / OUT / 'paired_development_deltas_167.jsonl', deltas)
    save_rows(root / OUT / 'paired_student_deltas_56.jsonl', students)
    save(root / OUT / 'paired_training_summary.json', result)
    save(root / OUT / 'paired_artifact_sha256.json', {n: sha(root / OUT / n) for n in ('paired_training_summary.json', 'paired_development_deltas_167.jsonl', 'paired_student_deltas_56.jsonl')})
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)

def show(root):
    out = root / OUT
    if (out / 'paired_training_summary.json').exists():
        print((out / 'paired_training_summary.json').read_text(encoding='utf-8'))
    else:
        for a in ('control', 'repaired'):
            final = out / a / 'training_summary.json'
            partial = out / (a + '.partial')
            last = None
            dev = None
            if final.exists():
                d = read(final)
                print(canon(dict(arm=a, status='COMPLETED', best_epoch=d['best_epoch'], development=d['development'])))
                continue
            events = partial / 'events_rank0.jsonl'
            if events.exists():
                for line in events.read_text(encoding='utf-8').splitlines():
                    try:
                        e = json.loads(line)
                        last = e
                        if e.get('event') == 'epoch_development':
                            dev = e
                    except json.JSONDecodeError:
                        pass
            print(canon(dict(arm=a, status='RUNNING_OR_PARTIAL' if events.exists() else 'NOT_STARTED', last_event=last, latest_development=dev, total=464)))
    exitfile = out / 'exit_code.txt'
    running = False
    if (out / 'worker.pid').exists():
        pid = (out / 'worker.pid').read_text().strip()
        proc = Path('/proc') / pid / 'cmdline'
        if pid.isdigit() and proc.exists():
            try:
                running = str(HERE).encode() in proc.read_bytes()
            except FileNotFoundError:
                pass
    print('ORIGINAL232_WORKER_RUNNING=' + str(running))
    if exitfile.exists():
        rc = exitfile.read_text().strip()
        print('WORKER_EXIT_CODE=' + rc)
        if rc != '0' and (out / 'worker.log').exists():
            print('\n'.join((out / 'worker.log').read_text(errors='replace').splitlines()[-65:]))
