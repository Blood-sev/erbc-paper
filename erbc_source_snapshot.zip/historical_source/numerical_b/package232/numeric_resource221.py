"""Execution-only repair: gather ten logits before FP32 cast; explicit resource gate."""
import math

def numeric_prediction(model, input_ids, attention_mask, method, anchors, digit_ids, verify_legacy=False):
    import torch
    if method != 'ntl' or len(digit_ids) != 10 or len(set(digit_ids)) != 10:
        raise RuntimeError('NUMERIC_CONTRACT')
    outputs = model(input_ids=input_ids, attention_mask=attention_mask)
    logits = outputs.logits
    if logits.ndim != 3 or logits.shape[0] != 1 or logits.shape[1] != input_ids.shape[1]:
        raise RuntimeError('FULL_SEQUENCE_LOGIT_SHAPE_DRIFT')
    selected = logits[:, -1, digit_ids].float()
    if verify_legacy:
        legacy = logits.float()[:, -1, digit_ids]
        if not torch.equal(selected, legacy):
            raise RuntimeError('REAL_PROBE_GATHER_CAST_MISMATCH')
        del legacy
    probabilities = torch.softmax(selected, dim=-1)
    prediction = (probabilities * anchors.unsqueeze(0)).sum(dim=-1)
    return (prediction, probabilities)

def resource_failures(states, minimum=8.0, seconds=2400.0):
    if len(states) != 2 or {s['rank'] for s in states} != {0, 1}:
        raise RuntimeError('RESOURCE_RANK_LAYOUT')
    reasons = []
    for s in states:
        if not all((math.isfinite(s[k]) for k in ('free_GiB', 'allocated_GiB', 'reserved_GiB', 'elapsed_seconds'))):
            reasons.append({'rank': s['rank'], 'reason': 'NONFINITE_RESOURCE'})
        if s['free_GiB'] < minimum:
            reasons.append({'rank': s['rank'], 'reason': 'FREE_MEMORY_BELOW_8_GiB'})
        if s['elapsed_seconds'] >= seconds:
            reasons.append({'rank': s['rank'], 'reason': 'ARM_TIME_BUDGET'})
    return reasons

def pure_test():
    good = [dict(rank=r, free_GiB=8.0, allocated_GiB=60.0, reserved_GiB=70.0, elapsed_seconds=10.0) for r in (0, 1)]
    assert not resource_failures(good)
    bad = [dict(s) for s in good]
    bad[0]['free_GiB'] = 7.999
    assert resource_failures(bad) == [{'rank': 0, 'reason': 'FREE_MEMORY_BELOW_8_GiB'}]
    bad = [dict(s) for s in good]
    bad[1]['elapsed_seconds'] = 2400.0
    assert resource_failures(bad) == [{'rank': 1, 'reason': 'ARM_TIME_BUDGET'}]
    try:
        resource_failures(good[:1])
    except RuntimeError:
        pass
    else:
        raise AssertionError('MISSING_RANK_ACCEPTED')
    return {'status': 'PASS_PURE_PYTHON_RESOURCE_GATES', 'GPU_tested': False}

def torch_test(device='cpu'):
    """Check value, arbitrary VJP and parameter gradients; no downloaded model."""
    import torch
    from types import SimpleNamespace
    result = []
    for dtype in (torch.float32, torch.bfloat16):
        for noncontiguous in (False, True):
            values = torch.arange(2 * 7 * 31, device=device, dtype=torch.float32).sin().reshape(2, 7, 31)
            raw = values.to(dtype) if not noncontiguous else values.transpose(1, 2).contiguous().transpose(1, 2).to(dtype)
            raw.requires_grad_(True)
            digits = [0, 30, 4, 19, 8, 2, 13, 24, 7, 11]
            a = raw.float()[:, -1, digits]
            b = raw[:, -1, digits].float()
            upstream = torch.arange(20, device=device, dtype=torch.float32).cos().reshape(2, 10)
            ga = torch.autograd.grad(a, raw, upstream, retain_graph=True)[0]
            gb = torch.autograd.grad(b, raw, upstream)[0]
            assert torch.equal(a, b) and torch.equal(ga, gb), 'GATHER_CAST_VJP'
            h = (torch.arange(7 * 5, device=device, dtype=torch.float32).cos() / 4).reshape(1, 7, 5).to(dtype)
            w = (torch.arange(5 * 31, device=device, dtype=torch.float32).sin() / 4).reshape(5, 31).to(dtype).requires_grad_(True)
            logits = h @ w
            old = torch.softmax(logits.float()[:, -1, digits], -1)
            anchors = torch.linspace(0, 1, 10, device=device)
            pred, new = numeric_prediction(lambda **kw: SimpleNamespace(logits=logits), torch.zeros((1, 7), device=device, dtype=torch.long), None, 'ntl', anchors, digits, True)

            def loss(p):
                q = torch.zeros_like(p)
                q[:, 3] = 0.7
                q[:, 4] = 0.3
                return -0.1 * (q * p.clamp_min(1e-12).log()).sum() + (p.cumsum(-1) - q.cumsum(-1)).abs()[:, :-1].sum() / 9
            go = torch.autograd.grad(loss(old), w, retain_graph=True)[0]
            gn = torch.autograd.grad(loss(new), w)[0]
            assert torch.equal(old, new) and torch.equal(go, gn), 'LOSS_PARAMETER_GRADIENT'
            result.append({'dtype': str(dtype), 'noncontiguous': noncontiguous, 'selected_values_equal': True, 'arbitrary_VJP_equal': True, 'NTL_head_parameter_gradient_equal': True})
    return {'status': 'PASS_TORCH_GATHER_BEFORE_CAST', 'device': str(device), 'cases': result, 'real_LoRA_gradient_equivalence_established': False}
