from runtime232 import *

def train(root, arm):
    pre = frozen(root)
    p = plan()
    selected = read(root / OUT / 'selected_gpus.json')['selected']
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == ','.join((r['uuid'] for r in selected)) and os.environ.get('FLASH_ATTENTION_DETERMINISTIC') == '1', 'GPU_ENVIRONMENT')
    import torch
    import torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel as DDP
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from peft import LoraConfig, TaskType, get_peft_model
    rank, local, world = (int(os.environ[k]) for k in ('RANK', 'LOCAL_RANK', 'WORLD_SIZE'))
    need(world == 2 and rank == local and (rank in (0, 1)), 'TWO_GPU_REQUIRED')
    torch.cuda.set_device(local)
    device = torch.device('cuda', local)
    start = time.monotonic()
    dist.init_process_group('nccl', timeout=datetime.timedelta(seconds=600), device_id=device)

    def gather(x):
        rr = [None] * 2
        dist.all_gather_object(rr, x)
        return rr
    folder = root / OUT / (arm + '.partial')
    final = root / OUT / arm
    try:
        need(torch.cuda.mem_get_info()[0] / 1024 ** 3 >= 65, 'INITIAL_MEMORY_GATE')
        if rank == 0:
            need(not folder.exists() and (not final.exists()), 'ARM_EXISTS_STOP')
            folder.mkdir()
            verify_base(root)
        dist.barrier()
        idx, schedule, maps = verify_data(root)
        by = {r['sample_id']: r for r in idx if r['partition'] == 'train'}
        baseline, trace_module = modules()
        need(trace_module.installed_sources() == pre['installed_runtime'], 'RUNTIME_DRIFT')
        minimum = 100.0
        sequence = 0

        def emit(e):
            e = dict(e, rank=rank, arm=arm, elapsed_seconds=time.monotonic() - start)
            with (folder / f'events_rank{rank}.jsonl').open('a', encoding='utf-8') as f:
                f.write(canon(e) + '\n')
            if rank == 0:
                print(canon(e), flush=True)

        def resource(phase, collective=True):
            nonlocal minimum, sequence
            free = torch.cuda.mem_get_info()[0] / 1024 ** 3
            minimum = min(minimum, free)
            s = dict(rank=rank, phase=phase, free_GiB=free, allocated_GiB=torch.cuda.memory_allocated() / 1024 ** 3, reserved_GiB=torch.cuda.memory_reserved() / 1024 ** 3, elapsed_seconds=time.monotonic() - start)
            if collective:
                sequence += 1
                s['sequence'] = sequence
                states = gather(s)
                need(len({(v['sequence'], v['phase']) for v in states}) == 1, 'COLLECTIVE_SEQUENCE')
                need(not resource_failures(states, 8.0, 28800.0), 'RESOURCE_GATE')
            else:
                need(math.isfinite(free) and free >= 8 and (s['elapsed_seconds'] < 28800), 'LOCAL_VIEW_RESOURCE_GATE')
            with (folder / f'resources_rank{rank}.jsonl').open('a', encoding='utf-8') as f:
                f.write(canon(s) + '\n')

        def seed():
            random.seed(SEED + rank)
            torch.manual_seed(SEED + rank)
            torch.cuda.manual_seed_all(SEED + rank)
        seed()
        numeric_test = torch_test(device)
        seed()
        emit({'event': 'fresh_model_load_start'})
        tokenizer = AutoTokenizer.from_pretrained(root / MODEL, local_files_only=True)
        if tokenizer.pad_token_id is None:
            tokenizer.pad_token = tokenizer.eos_token
        digits = baseline.tokenizer_digit_ids(tokenizer)
        need(digits == list(range(15, 25)), 'DIGIT_IDS')
        anchors = torch.linspace(0, 1, 10, device=device, dtype=torch.float32)
        base = AutoModelForCausalLM.from_pretrained(root / MODEL, local_files_only=True, dtype=torch.bfloat16, attn_implementation='flash_attention_2', low_cpu_mem_usage=True)
        base.config.use_cache = False
        base.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant': False})
        cfg = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, bias='none', task_type=TaskType.CAUSAL_LM, target_modules=['q_proj', 'k_proj', 'v_proj', 'o_proj', 'gate_proj', 'up_proj', 'down_proj'])
        model = get_peft_model(base, cfg)
        model.enable_input_require_grads()
        model.to(device)
        model.train()
        model = DDP(model, device_ids=[local], output_device=local, broadcast_buffers=False, find_unused_parameters=False)
        initial, count = parameter_hash(model.module)
        need(count == 33030144 and len(set(gather(initial))) == 1, 'FRESH_INITIALIZATION_SYNC')
        need(initial == pre['initial_parameter_sha256'], 'FRESH_INITIALIZATION_VS_231_DRIFT')
        aa = [v for n, v in model.module.named_parameters() if '.lora_A.' in n]
        bb = [v for n, v in model.module.named_parameters() if '.lora_B.' in n]
        need(aa and bb and all((bool(torch.isfinite(v).all()) for v in aa + bb)) and all((bool((v == 0).all()) for v in bb)) and any((bool((v != 0).any()) for v in aa)), 'FRESH_LORA_INITIALIZATION')
        import transformers.modeling_flash_attention_utils as fa
        original_lazy = fa.lazy_import_flash_attention
        trace = trace_module.KernelTrace(original_lazy, pre['installed_runtime']['HF_consumer_layout']['processor_layout'])
        trace.begin(arm, True)
        fa.lazy_import_flash_attention = trace.lazy
        trace.lazy('flash_attention_2')
        probeid = p['selection']['probe']
        rng = (torch.get_rng_state(), torch.cuda.get_rng_state(), random.getstate())
        model.module.eval()
        with torch.inference_mode():
            ids, mask, y = baseline.tokenize_row(tokenizer, maps['control'][probeid], 'ntl', device)
            need(ids.shape[-1] == by[probeid]['control_numeric_tokens'], 'PROBE_LENGTH')
            pred, prob = numeric_prediction(model.module, ids, mask, 'ntl', anchors, digits, True)
            probe = prob[0].tolist()
            del ids, mask, y, pred, prob
        model.train()
        torch.set_rng_state(rng[0])
        torch.cuda.set_rng_state(rng[1])
        random.setstate(rng[2])
        need(parameter_hash(model.module)[0] == initial, 'PROBE_PARAMETER_MUTATION')
        parameters = [v for v in model.parameters() if v.requires_grad]
        seed()
        optimizer = torch.optim.AdamW(parameters, lr=0.0001, betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01, fused=True)
        scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda s: baseline.cosine_lambda(s, 464, 24))
        optimizer.zero_grad(set_to_none=True)
        dev_rows, df = development(root, idx)
        verify_schedule(idx, schedule, baseline)
        need(digest(df) == pre['development_identity_sha256'], 'DEV_FROZEN_IDENTITY')
        history = []
        epochs = []
        step = 0
        initial_probes = gather(probe)
        need(max((abs(x - y) for pp in initial_probes for x, y in zip(pp, initial_probes[0]))) <= 2e-06, 'INITIAL_RANK_PROBE')

        def evaluate(epoch):
            need(all((v.grad is None for v in parameters)), 'EVALUATION_WITH_PENDING_GRADIENTS')
            before, _ = parameter_hash(model.module)
            rng = (torch.get_rng_state(), torch.cuda.get_rng_state(), random.getstate())
            was_training = model.module.training
            model.module.eval()
            local_predictions = []
            emit({'event': 'epoch_development_start', 'epoch': epoch, 'step': step})
            try:
                with torch.inference_mode():
                    for roundno, pair in enumerate(eval_rounds(len(dev_rows)), 1):
                        resource(f'dev{epoch}_before_round{roundno}')
                        i = pair[rank]
                        if i is not None:
                            row = dev_rows[i]
                            s = sid(row)
                            f = df[s]
                            ids, mask, y = baseline.tokenize_row(tokenizer, row, 'ntl', device)
                            need(ids.shape[-1] == f['control_numeric_tokens'], 'DEV_TOKEN_LENGTH')
                            pred, prob = numeric_prediction(model.module, ids, mask, 'ntl', anchors, digits)
                            local_predictions.append(dict(sample_id=s, unit_id=f['unit_id'], subject=f['subject'], student_group_id=f['student_group_id'], source_target_fraction=f['target_fraction'], target_fraction=float(y.item()), prediction_fraction=float(pred.item()), digit_probabilities=prob[0].tolist(), prompt_tokens=int(ids.shape[-1])))
                            del ids, mask, y, pred, prob
                        resource(f'dev{epoch}_after_round{roundno}')
                        if roundno % 30 == 0:
                            emit({'event': 'evaluation_progress', 'epoch': epoch, 'step': step, 'round': roundno, 'rounds': 84})
                rr = [r for shard in gather(local_predictions) for r in shard]
                rr.sort(key=lambda r: (r['unit_id'], r['sample_id']))
                verify_predictions(rr, df)
                need(parameter_hash(model.module)[0] == before, 'EVALUATION_CHANGED_PARAMETERS')
            finally:
                model.module.train(was_training)
                torch.set_rng_state(rng[0])
                torch.cuda.set_rng_state(rng[1])
                random.setstate(rng[2])
            need(torch.equal(torch.get_rng_state(), rng[0]) and torch.equal(torch.cuda.get_rng_state(), rng[1]) and (random.getstate() == rng[2]), 'EVALUATION_RNG_RESTORE')
            return (rr, baseline.split_metrics(rr), before)
        for ep in schedule:
            epoch = ep['epoch']
            for batch in ep['batches']:
                step += 1
                local_ids = layout(batch, rank)
                micros = len(local_ids)
                used = scheduler.get_last_lr()
                stats = torch.zeros(6, device=device, dtype=torch.float64)
                for offset, s in enumerate(local_ids):
                    resource(f'before_step{step}_micro{offset}')
                    vv = views(arm, by[s]['messages_changed'], True)
                    for j, (ia, w) in enumerate(vv):
                        resource(f'before_view{step}_{offset}_{j}', False)
                        ids, mask, y = baseline.tokenize_row(tokenizer, maps[ia][s], 'ntl', device)
                        length = by[s]['control_numeric_tokens' if ia == 'control' else 'candidate_numeric_tokens']
                        need(ids.shape[-1] == length, 'ACTUAL_LENGTH_DRIFT')
                        sync = sync_here(offset, j, len(vv), micros)
                        with contextlib.nullcontext() if sync else model.no_sync():
                            pred, prob = numeric_prediction(model, ids, mask, 'ntl', anchors, digits)
                            ce, w1, q = baseline.ntl_components(prob, y)
                            loss = 0.1 * ce + w1
                            need(bool(torch.isfinite(loss)) and bool(torch.isfinite(prob).all()), 'NONFINITE_LOSS')
                            (w * loss / micros).backward()
                        stats += w * torch.stack([loss.detach().double(), ce.detach().double(), w1.detach().double(), torch.ones((), device=device, dtype=torch.float64), (pred.detach() - y).abs().mean().double(), ((pred.detach() - y) ** 2).mean().double()])
                        position = dict(rank=rank, epoch=epoch, step=step, offset=offset, view=j, sample_id=s, input_arm=ia, weight=w, sync=sync, tokens=length, normalization=micros)
                        with (folder / f'positions_rank{rank}.jsonl').open('a', encoding='utf-8') as f:
                            f.write(canon(position) + '\n')
                        del ids, mask, y, pred, prob, ce, w1, q, loss
                        resource(f'after_view{step}_{offset}_{j}', False)
                    resource(f'after_step{step}_micro{offset}')
                norm = float(torch.nn.utils.clip_grad_norm_(parameters, 1.0).item())
                need(math.isfinite(norm), 'NONFINITE_GRADIENT')
                optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                torch.cuda.synchronize()
                resource(f'after_update{step}')
                h, _ = parameter_hash(model.module)
                need(len(set(gather(h))) == 1, 'PARAMETERS_UNSYNCHRONIZED')
                dist.all_reduce(stats)
                v = (stats / stats[3]).tolist()
                event = dict(step=step, total=464, epoch=epoch, batch_positions=len(batch), parameter_sha256=h, gradient_norm_before_clip=norm, learning_rate_used=used, learning_rate_next=scheduler.get_last_lr(), total_loss=v[0], numeric_ce=v[1], wasserstein_1=v[2], train_window_MAE_pp=100 * v[4], train_window_RMSE_pp=100 * math.sqrt(v[5]), train_metric_scope='weighted_training_views_not_validation')
                history.append(event)
                emit(dict(event, event='optimizer_step'))
            need(step == 116 * epoch, 'EPOCH_STEP_DRIFT')
            predictions, metrics, paramhash = evaluate(epoch)
            report = dict(epoch=epoch, optimizer_step=step, development=metrics, development_regions=regions(predictions, baseline), parameter_sha256=paramhash, selection_key=list(key(metrics)))
            epochs.append(report)
            best = choose(epochs)
            if rank == 0:
                cp = folder / f'checkpoints/epoch_{epoch}'
                cp.mkdir(parents=True)
                model.module.save_pretrained(cp / 'adapter', safe_serialization=True)
                need(parameter_hash(model.module)[0] == paramhash, 'ADAPTER_SAVE_MUTATION')
                save_rows(cp / 'development_predictions.jsonl', predictions)
                save(cp / 'epoch_summary.json', report)
                save(cp / 'artifact_sha256.json', manifest(cp))
            dist.barrier()
            resource(f'after_checkpoint{epoch}')
            emit(dict(report, event='epoch_development', best_epoch=best['epoch'], step=step))
        need(step == 464 and len(epochs) == 4 and (history[-1]['parameter_sha256'] != initial), 'FULL_RUN_COMPLETION')
        need(trace.active['kernel_calls'] > 0 and trace.active['all_actual_keywords_match'], 'DETERMINISTIC_KERNEL_TRACE')
        fa.lazy_import_flash_attention = original_lazy
        runtimes = gather(dict(rank=rank, peak_reserved_GiB=torch.cuda.max_memory_reserved() / 1024 ** 3, minimum_free_GiB=minimum, trace=trace.active, initial_probe=probe, final_parameter_sha256=history[-1]['parameter_sha256']))
        if rank == 0:
            verify_data(root)
            verify_base(root)
            best = choose(epochs)
            selected_adapter = folder / f"checkpoints/epoch_{best['epoch']}/adapter"
            destination = folder / 'best_adapter'
            destination.mkdir()
            for f in selected_adapter.iterdir():
                if f.is_file():
                    shutil.copyfile(f, destination / f.name)
                    need(sha(f) == sha(destination / f.name), 'BEST_COPY_HASH')
            result = dict(status='PASS', arm=arm, plan_sha256=sha(HERE / 'plan.json'), preflight_sha256=sha(root / OUT / 'preflight.json'), gpu_selection_sha256=sha(root / OUT / 'selected_gpus.json'), initial_parameter_sha256=initial, trainable_parameters=count, optimizer_steps=464, epochs_completed=4, best_epoch=best['epoch'], best_parameter_sha256=best['parameter_sha256'], final_parameter_sha256=history[-1]['parameter_sha256'], development=best['development'], development_regions=best['development_regions'], development_history=epochs, training_steps=history, runtime_by_rank=runtimes, adapter_saved=True, formal_training_started=True, official_validation_or_E3_opened=False, automatic_model_replacement=False, historical_student_overlap=26, initialization='fresh_base_LoRA_no_trained_adapter', elapsed_seconds=time.monotonic() - start)
            save(folder / 'training_summary.json', result)
            save(folder / 'artifact_sha256.json', manifest(folder))
            folder.rename(final)
        dist.barrier()
    except BaseException:
        traceback.print_exc()
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(1)
    else:
        dist.destroy_process_group()
