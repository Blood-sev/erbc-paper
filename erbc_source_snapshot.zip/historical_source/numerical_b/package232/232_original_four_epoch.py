import argparse
from runtime232 import *
if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('command', choices=['preflight', 'select-gpus', 'check-gpus', 'visibility', 'train', 'compare', 'show'])
    ap.add_argument('--project-root', required=True, type=Path)
    ap.add_argument('--arm', choices=['control', 'repaired'])
    a = ap.parse_args()
    root = a.project_root.resolve()
    if a.command == 'visibility':
        print(','.join((r['uuid'] for r in read(root / OUT / 'selected_gpus.json')['selected'])))
    elif a.command == 'train':
        need(a.arm is not None, 'ARM_REQUIRED')
        from train232 import train
        train(root, a.arm)
    else:
        globals()[a.command.replace('-', '_')](root)
