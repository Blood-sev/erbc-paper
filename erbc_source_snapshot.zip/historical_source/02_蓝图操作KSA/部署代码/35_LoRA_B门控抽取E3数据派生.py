#!/usr/bin/env python3
"""Derive frozen E3 B_GATE/B_EXTRACT/B_REDUCE SFT data from audited E2 data."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
import math
import os
from collections import Counter, defaultdict
from pathlib import Path


SEED = 20260920
MAX_CHAT_TOKENS = 49152
TRAIN_TARGET_PER_TASK = 5824
MAX_ADDITIONAL_REPLICAS_PER_SOURCE = 7
SOURCE_HASHES = {
    "train": "c84edc78ca78e4f66b5936cc59ae90e55b1504d218377e317ba265db8b7693fc",
    "validation": "55a2b3a8f35ce00fa9f5626089817e392627b4f7643b01770e597f879399c4b9",
}
EXPECTED_E2 = {
    "train": {"rows": 9713, "map": 4949, "map_positive": 2911, "map_negative": 2038, "reduce": 4764},
    "validation": {"rows": 1558, "map": 985, "map_positive": 312, "map_negative": 673, "reduce": 573},
}
SUBJECTS = [
    "01_计算机科学", "02_数学", "03_物理学", "04_生物学",
    "05_化学", "06_历史学", "07_地理学",
]

GATE_SYSTEM = """你执行任务B的证据块门控。只判断当前证据块是否直接包含一个或多个学习相关操作。不得抽取操作、不得判断KU或责任归属。严格返回符合output_json_schema的JSON，不要输出解释或Markdown。"""
EXTRACT_SYSTEM = """你执行任务B的正证据块操作抽取。当前证据块已由门控确认至少包含一个学习相关操作；必须抽取一个或多个直接受证据支持的操作，不允许返回空数组。不要判断最终相关性、KU或责任归属。严格返回符合output_json_schema的JSON，不要输出解释或Markdown。"""
GATE_SCHEMA = {
    "type": "object", "required": ["has_operation"], "additionalProperties": False,
    "properties": {"has_operation": {"type": "boolean"}},
}
EXTRACT_SCHEMA = {
    "type": "object", "required": ["local_candidates"], "additionalProperties": False,
    "properties": {
        "local_candidates": {
            "type": "array", "minItems": 1,
            "items": {
                "type": "object", "required": ["operation", "evidence_refs"],
                "additionalProperties": False,
                "properties": {
                    "operation": {"type": "string", "minLength": 1},
                    "evidence_refs": {"type": "array", "minItems": 1},
                },
            },
        }
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise SystemExit(f"Safety stop: invalid JSONL {path}:{number}: {exc}") from exc
    return rows


def write_json_atomic(path: Path, value: dict) -> None:
    temporary = Path(str(path) + ".partial")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def write_jsonl_atomic(path: Path, rows: list[dict]) -> None:
    temporary = Path(str(path) + ".partial")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    os.replace(temporary, path)


def source_key(row: dict) -> str:
    metadata = row["metadata"]
    task = metadata["task"]
    suffix = metadata.get("chunk_id") if task == "B_MAP" else metadata.get("source_operation_id")
    return f"{metadata['unit_id']}|{task}|{suffix}"


def validate_e2_source(rows: list[dict], split: str) -> None:
    expected = EXPECTED_E2[split]
    counts = Counter(row.get("metadata", {}).get("task") for row in rows)
    positives = sum(
        row["metadata"].get("positive") is True for row in rows if row["metadata"].get("task") == "B_MAP"
    )
    negatives = sum(
        row["metadata"].get("positive") is False for row in rows if row["metadata"].get("task") == "B_MAP"
    )
    actual = {
        "rows": len(rows), "map": counts["B_MAP"], "map_positive": positives,
        "map_negative": negatives, "reduce": counts["B_REDUCE"],
    }
    if actual != expected:
        raise SystemExit(f"Safety stop: {split} E2 source cardinality drift: expected={expected}, actual={actual}")
    keys = [source_key(row) for row in rows]
    if len(keys) != len(set(keys)):
        raise SystemExit(f"Safety stop: duplicate {split} E2 source key")
    subjects = {row["metadata"].get("subject") for row in rows}
    if subjects != set(SUBJECTS):
        raise SystemExit(f"Safety stop: {split} subject coverage drift: {sorted(subjects)}")


def replace_user_task(row: dict, task: str, schema: dict) -> dict:
    payload = json.loads(row["messages"][1]["content"])
    payload["task"] = task
    payload["output_json_schema"] = schema
    return payload


def base_metadata(row: dict, task: str) -> dict:
    source = row["metadata"]
    suffix = source.get("chunk_id") if source["task"] == "B_MAP" else source.get("source_operation_id")
    return {
        "unit_id": source["unit_id"], "subject": source["subject"], "split": source["split"],
        "task": task, "source_task": source["task"], "source_suffix": suffix,
        "source_key": source_key(row), "replica_index": 0,
    }


def make_gate(row: dict) -> dict:
    positive = row["metadata"].get("positive") is True
    return {
        "messages": [
            {"role": "system", "content": GATE_SYSTEM},
            {"role": "user", "content": json.dumps(replace_user_task(row, "B_GATE", GATE_SCHEMA), ensure_ascii=False, separators=(",", ":"))},
            {"role": "assistant", "content": json.dumps({"has_operation": positive}, ensure_ascii=False, separators=(",", ":"))},
        ],
        "metadata": {**base_metadata(row, "B_GATE"), "gate_label": positive, "positive": positive},
    }


def make_extract(row: dict) -> dict:
    answer = json.loads(row["messages"][2]["content"])
    candidates = answer.get("local_candidates")
    if row["metadata"].get("positive") is not True or not isinstance(candidates, list) or not candidates:
        raise SystemExit(f"Safety stop: B_EXTRACT source is not a nonempty positive: {source_key(row)}")
    return {
        "messages": [
            {"role": "system", "content": EXTRACT_SYSTEM},
            {"role": "user", "content": json.dumps(replace_user_task(row, "B_EXTRACT", EXTRACT_SCHEMA), ensure_ascii=False, separators=(",", ":"))},
            {"role": "assistant", "content": json.dumps(answer, ensure_ascii=False, separators=(",", ":"))},
        ],
        "metadata": {**base_metadata(row, "B_EXTRACT"), "positive": True, "local_operation_count": len(candidates)},
    }


def make_reduce(row: dict) -> dict:
    copied = copy.deepcopy(row)
    copied["metadata"] = base_metadata(row, "B_REDUCE")
    return copied


def allocate_subject_extras(groups: dict[str, list[dict]], extra_count: int) -> dict[str, int]:
    capacities = {
        subject: len(rows) * MAX_ADDITIONAL_REPLICAS_PER_SOURCE for subject, rows in groups.items()
    }
    if sum(capacities.values()) < extra_count:
        raise SystemExit("Safety stop: E3 replica cap cannot satisfy target")
    weights = {subject: math.sqrt(len(rows)) for subject, rows in groups.items()}
    allocations = {subject: 0 for subject in groups}
    for _ in range(extra_count):
        available = [subject for subject in groups if allocations[subject] < capacities[subject]]
        selected = min(
            available,
            key=lambda subject: (
                (allocations[subject] + 1) / weights[subject],
                stable_hash(f"{SEED}|subject-allocation|{subject}"),
            ),
        )
        allocations[selected] += 1
    return allocations


def augment(rows: list[dict], target: int, category: str) -> list[dict]:
    if len(rows) > target:
        raise SystemExit(f"Safety stop: E3 target smaller than source for {category}: {len(rows)} > {target}")
    ordered = sorted(rows, key=lambda row: stable_hash(f"{SEED}|{category}|{row['metadata']['source_key']}"))
    output = [copy.deepcopy(row) for row in ordered]
    groups = defaultdict(list)
    for row in ordered:
        groups[row["metadata"]["subject"]].append(row)
    allocations = allocate_subject_extras(dict(groups), target - len(rows))
    for subject in sorted(groups):
        subject_rows = groups[subject]
        for extra_index in range(allocations[subject]):
            source = subject_rows[extra_index % len(subject_rows)]
            replica = copy.deepcopy(source)
            replica["metadata"]["replica_index"] = 1 + extra_index // len(subject_rows)
            output.append(replica)
    replica_counts = Counter(row["metadata"]["source_key"] for row in output)
    if max(replica_counts.values()) > 1 + MAX_ADDITIONAL_REPLICAS_PER_SOURCE:
        raise SystemExit(f"Safety stop: E3 per-source replica cap exceeded for {category}")
    if len(output) != target:
        raise SystemExit(f"Safety stop: E3 augmentation count mismatch for {category}")
    return output


def assign_ids_and_lengths(tokenizer, rows: list[dict], split: str) -> tuple[list[dict], list[dict]]:
    token_cache = {}
    keys = []
    details = []
    for index, row in enumerate(rows, 1):
        metadata = row["metadata"]
        cache_key = (metadata["task"], metadata["source_key"])
        if cache_key not in token_cache:
            value = tokenizer.apply_chat_template(row["messages"], tokenize=True, add_generation_prompt=False)
            token_cache[cache_key] = len(value["input_ids"] if hasattr(value, "keys") else value)
        total_tokens = token_cache[cache_key]
        if total_tokens <= 0 or total_tokens > MAX_CHAT_TOKENS:
            raise SystemExit(f"Safety stop: E3 token gate failure: {cache_key}, tokens={total_tokens}")
        sample_id = stable_hash(
            f"{SEED}|{split}|{metadata['task']}|{metadata['source_key']}|{metadata['replica_index']}"
        )[:24]
        metadata["sample_id"] = sample_id
        metadata["total_tokens"] = total_tokens
        key = (split, metadata["task"], sample_id)
        keys.append(key)
        details.append({**metadata})
        if index == 1 or index % 1000 == 0 or index == len(rows):
            print(json.dumps({
                "event": "e3_tokenization_progress", "split": split,
                "examples_completed": index, "examples_total": len(rows),
                "unique_message_sequences": len(token_cache),
            }, ensure_ascii=False), flush=True)
    if len(keys) != len(set(keys)):
        raise SystemExit(f"Safety stop: duplicate E3 sample ids in {split}")
    rows.sort(key=lambda row: stable_hash(f"{SEED}|{split}|{row['metadata']['sample_id']}"))
    details.sort(key=lambda row: row["sample_id"])
    return rows, details


def quantiles(values: list[int]) -> dict:
    values = sorted(values)
    if not values:
        return {"min": 0, "p50": 0, "p90": 0, "p95": 0, "max": 0}
    pick = lambda q: values[round((len(values) - 1) * q)]
    return {"min": values[0], "p50": pick(.5), "p90": pick(.9), "p95": pick(.95), "max": values[-1]}


def derive_split(tokenizer, source_path: Path, split: str) -> tuple[list[dict], list[dict], dict]:
    if sha256(source_path) != SOURCE_HASHES[split]:
        raise SystemExit(f"Safety stop: frozen E2 {split} hash drift")
    source_rows = load_jsonl(source_path)
    validate_e2_source(source_rows, split)
    maps = [row for row in source_rows if row["metadata"]["task"] == "B_MAP"]
    positives = [row for row in maps if row["metadata"]["positive"] is True]
    negatives = [row for row in maps if row["metadata"]["positive"] is False]
    reduces = [row for row in source_rows if row["metadata"]["task"] == "B_REDUCE"]
    gate_positive = [make_gate(row) for row in positives]
    gate_negative = [make_gate(row) for row in negatives]
    extracts = [make_extract(row) for row in positives]
    reduce_rows = [make_reduce(row) for row in reduces]
    if split == "train":
        gate_positive = augment(gate_positive, TRAIN_TARGET_PER_TASK // 2, "B_GATE_POSITIVE")
        gate_negative = augment(gate_negative, TRAIN_TARGET_PER_TASK // 2, "B_GATE_NEGATIVE")
        extracts = augment(extracts, TRAIN_TARGET_PER_TASK, "B_EXTRACT")
        reduce_rows = augment(reduce_rows, TRAIN_TARGET_PER_TASK, "B_REDUCE")
    combined, details = assign_ids_and_lengths(
        tokenizer, gate_positive + gate_negative + extracts + reduce_rows, split
    )
    task_counts = Counter(row["metadata"]["task"] for row in combined)
    gate_counts = Counter(str(row["metadata"]["gate_label"]) for row in combined if row["metadata"]["task"] == "B_GATE")
    subject_task_counts = Counter(
        (row["metadata"]["subject"], row["metadata"]["task"]) for row in combined
    )
    token_groups = defaultdict(list)
    for row in combined:
        token_groups[row["metadata"]["task"]].append(row["metadata"]["total_tokens"])
    expected_tasks = (
        {"B_GATE": 5824, "B_EXTRACT": 5824, "B_REDUCE": 5824}
        if split == "train" else {"B_GATE": 985, "B_EXTRACT": 312, "B_REDUCE": 573}
    )
    if dict(task_counts) != expected_tasks:
        raise SystemExit(f"Safety stop: E3 {split} task counts mismatch: {dict(task_counts)}")
    expected_gate = {"False": 2912, "True": 2912} if split == "train" else {"False": 673, "True": 312}
    if dict(gate_counts) != expected_gate:
        raise SystemExit(f"Safety stop: E3 {split} gate counts mismatch: {dict(gate_counts)}")
    summary = {
        "source_e2_examples": len(source_rows),
        "examples": len(combined),
        "units": len({row["metadata"]["unit_id"] for row in combined}),
        "task_counts": dict(sorted(task_counts.items())),
        "gate_label_counts": dict(sorted(gate_counts.items())),
        "subject_task_counts": {
            f"{subject}|{task}": count for (subject, task), count in sorted(subject_task_counts.items())
        },
        "replica_examples": sum(row["metadata"]["replica_index"] > 0 for row in combined),
        "max_replica_index": max(row["metadata"]["replica_index"] for row in combined),
        "token_quantiles": {task: quantiles(values) for task, values in sorted(token_groups.items())},
    }
    return combined, details, summary


def self_test() -> None:
    positive = {
        "messages": [
            {"role": "system", "content": "map"},
            {"role": "user", "content": json.dumps({"task": "B_MAP", "output_json_schema": {}}, ensure_ascii=False)},
            {"role": "assistant", "content": '{"local_candidates":[{"operation":"x","evidence_refs":[{"message_id":"M1"}]}]}'},
        ],
        "metadata": {"unit_id": "U1", "subject": SUBJECTS[0], "split": "train", "task": "B_MAP", "chunk_id": "C1", "positive": True},
    }
    negative = copy.deepcopy(positive)
    negative["messages"][2]["content"] = '{"local_candidates":[]}'
    negative["metadata"]["chunk_id"] = "C2"
    negative["metadata"]["positive"] = False
    gate_true, gate_false, extract = make_gate(positive), make_gate(negative), make_extract(positive)
    assert json.loads(gate_true["messages"][2]["content"])["has_operation"] is True
    assert json.loads(gate_false["messages"][2]["content"])["has_operation"] is False
    assert len(json.loads(extract["messages"][2]["content"])["local_candidates"]) == 1
    augmented = augment([gate_true, gate_false], 8, "SELF_TEST")
    assert len(augmented) == 8 and max(Counter(row["metadata"]["source_key"] for row in augmented).values()) <= 8
    print(json.dumps({"status": "PASS", "self_test": "E3 gate/extract transform and capped augmentation"}, ensure_ascii=False))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    from transformers import AutoTokenizer
    root = (args.project_root or Path(os.environ.get("PROJECT_ROOT", ""))).resolve()
    if not root.is_dir():
        raise SystemExit("Safety stop: valid PROJECT_ROOT is required")
    e2_dir = root / "运行输出" / "LoRA训练准备_v2" / "B分段E2"
    sources = {
        "train": e2_dir / "SFT样本_训练集_B分段E2.jsonl",
        "validation": e2_dir / "SFT样本_验证集_B分段E2.jsonl",
    }
    output_dir = root / "运行输出" / "LoRA训练准备_v2" / "B门控抽取E3"
    if output_dir.exists():
        raise SystemExit(f"Safety stop: E3 output directory already exists: {output_dir}")
    for split, path in sources.items():
        if not path.is_file():
            raise SystemExit(f"Safety stop: missing frozen E2 {split} source: {path}")
    tokenizer = AutoTokenizer.from_pretrained(root / "模型文件" / "Qwen3-4B-Instruct-2507", local_files_only=True)
    output_dir.mkdir(parents=True, exist_ok=False)
    outputs, summaries, unit_ids = {}, {}, {}
    for split in ("train", "validation"):
        print(json.dumps({"event": "e3_derivation_started", "split": split}, ensure_ascii=False), flush=True)
        rows, lengths, summary = derive_split(tokenizer, sources[split], split)
        unit_ids[split] = {row["metadata"]["unit_id"] for row in rows}
        stem = "训练集" if split == "train" else "验证集"
        samples_path = output_dir / f"SFT样本_{stem}_B门控抽取E3.jsonl"
        lengths_path = output_dir / f"{split}_B门控抽取E3样本长度明细.jsonl"
        manifest_path = output_dir / f"SFT样本_{stem}_B门控抽取E3清单.json"
        write_jsonl_atomic(samples_path, rows)
        write_jsonl_atomic(lengths_path, lengths)
        manifest = {
            "status": "PASS", "version": "lora_b_gate_extract_e3_dataset_manifest_v1",
            "split": split, "source_e2": str(sources[split]), "source_e2_sha256": SOURCE_HASHES[split],
            "output_samples": str(samples_path), "output_samples_sha256": sha256(samples_path),
            "length_details": str(lengths_path), "length_details_sha256": sha256(lengths_path),
            "summary": summary, "cross_split_movement": False, "official_test_used": False,
        }
        write_json_atomic(manifest_path, manifest)
        outputs[split] = {
            "samples": str(samples_path), "samples_sha256": sha256(samples_path),
            "manifest": str(manifest_path), "manifest_sha256": sha256(manifest_path),
            "lengths": str(lengths_path), "lengths_sha256": sha256(lengths_path),
        }
        summaries[split] = summary
        print(json.dumps({"event": "e3_derivation_finished", "split": split, **summary}, ensure_ascii=False), flush=True)
    overlap = unit_ids["train"] & unit_ids["validation"]
    if overlap:
        raise SystemExit(f"Safety stop: E3 train/validation unit overlap: {sorted(overlap)}")
    report_path = output_dir / "LoRA_B门控抽取E3数据派生总清单.json"
    report = {
        "status": "PASS", "version": "lora_b_gate_extract_e3_derivation_summary_v1",
        "experiment": {
            "id": "E3", "tasks": ["B_GATE", "B_EXTRACT", "B_REDUCE"],
            "reason": "prevent the E2 always-empty generation shortcut under teacher forcing",
            "train_task_balance": "5824 samples per task",
            "gate_balance": "2912 positive and 2912 negative",
            "subject_replication": "all originals retained; deterministic sqrt-frequency subject allocation for extras; maximum 7 additional replicas per source",
            "validation_policy": "all transformed frozen E2 validation samples exactly once; no resampling or threshold tuning",
            "official_test_forbidden": True,
        },
        "constants": {
            "seed": SEED, "max_chat_tokens": MAX_CHAT_TOKENS,
            "train_target_per_task": TRAIN_TARGET_PER_TASK,
            "max_additional_replicas_per_source": MAX_ADDITIONAL_REPLICAS_PER_SOURCE,
        },
        "splits": summaries, "train_validation_unit_overlap": 0, "outputs": outputs,
    }
    write_json_atomic(report_path, report)
    print(json.dumps({**report, "summary": str(report_path), "summary_sha256": sha256(report_path)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
