"""Run a deterministic, unfinetuned Qwen3-4B strict-schema smoke test."""

from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from pathlib import Path

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig


TEST_ROOT = Path(
    r"D:\stress-aware-homework-agent\项目进展\题目知识蓝图与KSA双层外包新方法"
    r"\模型训练\本地部署测试"
)
MODEL_PATH = TEST_ROOT / "模型" / "Qwen3-4B-Instruct-2507"
SMOKE_PATH = TEST_ROOT / "冒烟测试样本" / "pipeline" / "samples.jsonl"
SCHEMA_ROOT = TEST_ROOT / "严格Schema与校验"
RETRIEVER_PATH = TEST_ROOT / "标准库候选检索" / "第一阶段_词法分层候选检索.py"
ADAPTER_PATH = TEST_ROOT / "未微调基线测试" / "冻结数据严格Schema适配器.py"
DEFAULT_UNIT = "05_化学__00a4dea7-219d-4bc3-b980-ce37ad2d7635"


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载模块：{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_row(unit_id: str) -> dict:
    with SMOKE_PATH.open("r", encoding="utf-8") as handle:
        for line in handle:
            row = json.loads(line)
            if row.get("unit_id") == unit_id:
                return row
    raise KeyError(f"固定冒烟样本中找不到单元：{unit_id}")


def question_text(row: dict) -> str:
    question = row["input"].get("question", {})
    if isinstance(question, str):
        return question
    return "\n".join(
        value.strip()
        for value in (question.get("title", ""), question.get("text", ""))
        if isinstance(value, str) and value.strip()
    )


def compact_candidates(stage1, subject: str, query: str) -> dict:
    nodes = stage1.load_library(subject, stage1.LIBRARIES[subject])
    counts = {
        level: sum(node.level == level for node in nodes)
        for level in ("KA", "KU", "TOPIC")
    }
    # Chemistry is intentionally used for the first smoke run: its complete
    # official library is small enough to expose without retrieval truncation.
    if subject == "05_化学":
        limits = counts
    else:
        limits = {"KA": min(7, counts["KA"]), "KU": min(16, counts["KU"]), "TOPIC": min(30, counts["TOPIC"])}
    result = stage1.HierarchicalRetriever(subject, nodes).retrieve(
        query,
        ka_k=limits["KA"],
        ku_k=limits["KU"],
        topic_k=limits["TOPIC"],
    )
    return {
        level: [
            {
                "id": item["node_id"],
                "parent_id": item["parent_id"],
                "official_name": item["english_name"],
                "project_label": item["chinese_label"],
            }
            for item in result["candidates"][level]
        ]
        for level in ("KA", "KU", "TOPIC")
    }


def prompt_for_task(task: str, strict_row: dict, candidates: dict, context: dict) -> tuple[str, str]:
    schema_names = {
        "A": "A_知识蓝图输出.schema.json",
        "B": "B_粗粒度操作输出.schema.json",
        "C": "C_细粒度KSA输出.schema.json",
    }
    root_keys = {"A": "blueprint", "B": "operations", "C": "ksa"}
    schema = json.loads((SCHEMA_ROOT / schema_names[task]).read_text(encoding="utf-8"))
    common = (
        "只输出一个合法JSON对象，不输出Markdown、解释或代码围栏。"
        f"输出根对象只能含{root_keys[task]}，禁止额外字段。"
        "只能使用候选标准节点中存在的KA、KU、Topic ID，禁止创造标签。"
        "候选按合法KA→KU→Topic完整路径给出；同一条输出必须从同一候选路径复制三个ID，"
        "禁止把KU ID填入KA字段、把Topic ID填入KU字段，也禁止跨路径拼接。"
        "证据引用必须逐字使用dialogue_with_message_ids中的message_id，或submission.documents中的source_id；"
        "提交文件证据的speaker固定为submission、turn固定为0。"
        "责任规则：AI=1.0/0.0，学生=0.0/1.0，共同=0.5/0.5。"
    )
    if task == "A":
        system = (
            "你是学术题目知识蓝图标注器。" + common
            + "知识蓝图只依据原题，不根据对话反推。每个Topic必须属于对应KU，每个KU必须属于对应KA。"
            "evidence_source固定为question_text，evidence必须来自原题。"
        )
        payload = {
            "task": "A_题目知识蓝图",
            "subject": strict_row["subject"],
            "question_text": strict_row["question"],
            "candidate_standard_paths": candidates["paths"],
            "output_json_schema": schema,
        }
    elif task == "B":
        system = (
            "你是学生使用AI完成作业的粗粒度操作标注器。" + common
            + "依据原题、完整对话和提交信息独立提取实际操作。REL表示整体属于蓝图；"
            "SUP表示整体不属于蓝图；MIXED表示同一不可再拆操作同时含蓝图内外内容。"
            "mapped_ku_ids是集合式字段：同一个KU ID在同一操作中只能出现一次，禁止重复。"
            "只保留与完成题目有关且有直接证据的操作。REL的support_reason必须是空字符串；"
            "只有SUP或MIXED才能填写非空support_reason。学生只提出请求、追问、确认或采用，"
            "但没有贡献实质解题内容时，责任判为AI，不判为学生或共同。"
        )
        ku_paths = []
        seen_ku_paths = set()
        for path in candidates["paths"]:
            key = (path["ka_id"], path["ku_id"])
            if key in seen_ku_paths:
                continue
            seen_ku_paths.add(key)
            ku_paths.append({
                "ka_id": path["ka_id"], "ka_name": path["ka_name"],
                "ku_id": path["ku_id"], "ku_name": path["ku_name"],
            })
        payload = {
            "task": "B_粗粒度操作",
            "subject": strict_row["subject"],
            "question_text": strict_row["question"],
            "dialogue_with_message_ids": strict_row["dialogue"],
            "submission": strict_row["submission"],
            "confirmed_blueprint": context["blueprint"],
            "candidate_standard_ku_paths": ku_paths,
            "output_json_schema": schema,
        }
    else:
        system = (
            "你是学生使用AI完成作业的细粒度KSA标注器。" + common
            + "KSA只能从已确认操作内部拆分到Topic层。FOCAL表示Topic在本题蓝图中，SUPPORT表示不在蓝图中。"
            "mapping_status与role是两个不同维度：只要所选KA/KU/Topic存在于当前学科标准库，"
            "无论它在不在题目蓝图中，mapping_status都必须为STANDARD_MAPPED；"
            "标准库中存在但不在题目蓝图中的KSA应写STANDARD_MAPPED+SUPPORT，并保留完整三层ID。"
            "只有完全无法映射到标准库的排版、文件整理等支持内容才能写STANDARD_EXTERNAL+SUPPORT，"
            "此时ka_id/ku_id/topic_id必须全部为null并说明理由。"
            "绝不能把‘蓝图外’误写成STANDARD_EXTERNAL。REL只能拆FOCAL，SUP只能拆SUPPORT，"
            "MIXED必须同时包含FOCAL和SUPPORT。每一个confirmed_operations中的operation_id至少输出一条KSA，"
            "不得漏掉操作，也不得创建新operation_id。FOCAL的support_reason必须为空；SUPPORT必须非空。"
            "ksa_id必须严格写成操作ID加顺序号，例如U01的第一条是U01-K01、第二条是U01-K02，"
            "绝对不能把KU ID写进ksa_id。学生只提问、追问、确认或采用而未贡献实质知识内容时，责任判为AI。"
        )
        per_operation_candidates = {}
        for operation in context["operations"]:
            ku_ids = operation.get("mapped_ku_ids", [])
            if not ku_ids:
                operation_paths = candidates["paths"]
            else:
                operation_paths = [item for item in candidates["paths"] if item["ku_id"] in ku_ids]
            per_operation_candidates[operation["operation_id"]] = {
                "candidate_standard_paths": operation_paths,
                "standard_library_outside_option": {"mapping_status": "STANDARD_EXTERNAL", "ka_id": None, "ku_id": None, "topic_id": None},
            }
        payload = {
            "task": "C_细粒度KSA",
            "subject": strict_row["subject"],
            "question_text": strict_row["question"],
            "dialogue_with_message_ids": strict_row["dialogue"],
            "submission": strict_row["submission"],
            "confirmed_blueprint": context["blueprint"],
            "confirmed_operations": context["operations"],
            "candidate_standard_paths_by_operation": per_operation_candidates,
            "output_json_schema": schema,
        }
    return system, json.dumps(payload, ensure_ascii=False)


def repair_guidance(task: str, issues: list[dict]) -> str:
    """Return deterministic rule reminders for internal retry only."""
    hints = []
    if task == "B" and any(
        issue.get("path", "").endswith(".mapped_ku_ids")
        and "non-unique" in issue.get("message", "")
        for issue in issues
    ):
        hints.append("去重修复：mapped_ku_ids中每个KU ID只能保留一次，必须删除所有重复项。")
    if task == "C" and any(
        issue.get("path", "").endswith((".ka_id", ".ku_id", ".topic_id"))
        and "null" in issue.get("message", "")
        for issue in issues
    ):
        hints.append(
            "映射状态修复：若保留任一KA/KU/Topic ID，mapping_status必须改为STANDARD_MAPPED；"
            "若mapping_status保留STANDARD_EXTERNAL，则三个ID必须全部改为null。"
            "蓝图外但标准库内的内容应使用STANDARD_MAPPED+SUPPORT。"
        )
    if any(issue.get("code") in {"INVALID_STANDARD_ID", "INVALID_PARENT", "OUTSIDE_CANDIDATES"} for issue in issues):
        hints.append("层级修复：同一输出的KA、KU、Topic必须逐字复制自同一条候选路径，禁止跨路径拼接。")
    return "".join(hints)


def parse_json_strict(raw: str) -> tuple[dict | None, str | None]:
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        return None, f"{exc.msg} (line={exc.lineno}, col={exc.colno})"
    if not isinstance(value, dict):
        return None, "顶层输出不是JSON对象"
    return value, None


def candidate_violations(task: str, output: dict, candidates: dict) -> list[dict]:
    allowed = {
        "ka_id": {item["id"] for item in candidates["KA"]},
        "ku_id": {item["id"] for item in candidates["KU"]},
        "topic_id": {item["id"] for item in candidates["TOPIC"]},
    }
    issues = []
    root = {"A": "blueprint", "B": "operations", "C": "ksa"}[task]
    for index, item in enumerate(output.get(root, [])):
        fields = ("ka_id", "ku_id", "topic_id") if task in {"A", "C"} else ()
        for field in fields:
            if item.get("mapping_status") == "STANDARD_EXTERNAL" and item.get(field) is None:
                continue
            if item.get(field) not in allowed[field]:
                issues.append({"path": f"$.{root}[{index}].{field}", "value": item.get(field)})
        if task == "B":
            for ku_id in item.get("mapped_ku_ids", []):
                if ku_id not in allowed["ku_id"]:
                    issues.append({"path": f"$.operations[{index}].mapped_ku_ids", "value": ku_id})
    return issues


def gold_summary(task: str, gold: dict, predicted: dict | None) -> dict:
    if predicted is None:
        return {"exact_match": False}
    root = {"A": "blueprint", "B": "operations", "C": "ksa"}[task]
    if task == "A":
        gold_values = {item["topic_id"] for item in gold[root]}
        pred_values = {item.get("topic_id") for item in predicted.get(root, [])}
        label = "topic_ids"
    elif task == "B":
        gold_values = {(item["operation"], item["relevance"], item["responsibility"]) for item in gold[root]}
        pred_values = {(item.get("operation"), item.get("relevance"), item.get("responsibility")) for item in predicted.get(root, [])}
        label = "operation_label_tuples"
    else:
        gold_values = {(item["ksa"], item["role"], item["responsibility"]) for item in gold[root]}
        pred_values = {(item.get("ksa"), item.get("role"), item.get("responsibility")) for item in predicted.get(root, [])}
        label = "ksa_label_tuples"
    return {
        "exact_match": gold_values == pred_values,
        "comparison": label,
        "gold_count": len(gold_values),
        "predicted_count": len(pred_values),
    }


def main() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser()
    parser.add_argument("--unit-id", default=DEFAULT_UNIT)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tasks", default="A", help="A,B,C的逗号组合，或PIPELINE")
    parser.add_argument("--max-new-tokens", type=int, default=1536)
    parser.add_argument("--max-attempts", type=int, default=2)
    args = parser.parse_args()

    stage1 = load_module("stage1_smoke", RETRIEVER_PATH)
    validator = load_module("strict_validator_smoke", SCHEMA_ROOT / "严格输出校验.py")
    adapter = load_module("strict_adapter_smoke", ADAPTER_PATH)
    row = load_row(args.unit_id)
    subject = row["metadata"]["subject"]
    question = question_text(row)
    candidates = compact_candidates(stage1, subject, question)
    strict_row = adapter.adapt_row(row)
    strict_row["question"] = question
    pipeline_mode = args.tasks.strip().upper() == "PIPELINE"
    tasks = ["A", "B", "C"] if pipeline_mode else [
        value.strip().upper() for value in args.tasks.split(",") if value.strip()
    ]
    if not tasks or any(value not in {"A", "B", "C"} for value in tasks):
        raise SystemExit("--tasks只允许A、B、C的逗号组合，或PIPELINE")

    started = time.time()
    tokenizer = AutoTokenizer.from_pretrained(str(MODEL_PATH), local_files_only=True)
    quantization = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.float16,
        bnb_4bit_use_double_quant=True,
    )
    model = AutoModelForCausalLM.from_pretrained(
        str(MODEL_PATH),
        local_files_only=True,
        device_map="auto",
        quantization_config=quantization,
        dtype=torch.float16,
        low_cpu_mem_usage=True,
    ).eval()
    load_seconds = time.time() - started

    valid_message_ids = [item["message_id"] for item in strict_row["dialogue"]]
    valid_message_ids.extend(
        str(item["source_id"])
        for item in strict_row.get("submission", {}).get("documents", [])
        if item.get("source_id")
    )
    results = []
    pipeline_blueprint = None
    pipeline_operations = None
    for task in tasks:
        if pipeline_mode:
            context = {
                "blueprint": pipeline_blueprint or [],
                "operations": pipeline_operations or [],
                "valid_message_ids": valid_message_ids,
            }
        else:
            context = {
                "blueprint": strict_row["A"]["blueprint"],
                "operations": strict_row["B"]["operations"],
                "valid_message_ids": valid_message_ids,
            }
        system, user = prompt_for_task(task, strict_row, candidates, context)
        messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
        attempts = []
        parsed = None
        raw = ""
        parse_error = None
        validation = None
        candidate_errors = []
        encoded = None
        output_ids = None
        generation_seconds = 0.0
        for attempt_number in range(1, max(1, args.max_attempts) + 1):
            prompt = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            encoded = tokenizer(prompt, return_tensors="pt").to(model.device)
            generation_started = time.time()
            with torch.inference_mode():
                generated = model.generate(
                    **encoded,
                    max_new_tokens=args.max_new_tokens,
                    do_sample=False,
                    pad_token_id=tokenizer.eos_token_id,
                )
            output_ids = generated[0, encoded["input_ids"].shape[1]:]
            raw = tokenizer.decode(output_ids, skip_special_tokens=True).strip()
            generation_seconds = time.time() - generation_started
            parsed, parse_error = parse_json_strict(raw)
            if parsed is None:
                validation = {
                    "valid": False,
                    "route": "internal_retry",
                    "issues": [{"code": "INVALID_JSON", "path": "$", "message": parse_error, "severity": "retry"}],
                }
                candidate_errors = []
            else:
                validation = validator.validate(task, subject, parsed, context if task != "A" else None)
                candidate_errors = candidate_violations(task, parsed, candidates)
                if candidate_errors:
                    validation = {
                        "valid": False,
                        "route": "internal_retry",
                        "issues": validation["issues"] + [
                            {"code": "OUTSIDE_CANDIDATES", "path": item["path"], "message": str(item["value"]), "severity": "retry"}
                            for item in candidate_errors
                        ],
                    }
            attempts.append({
                "attempt": attempt_number,
                "input_tokens": int(encoded["input_ids"].shape[1]),
                "output_tokens": int(output_ids.shape[0]),
                "generation_seconds": round(generation_seconds, 3),
                "strict_json_valid": parsed is not None,
                "validation": validation,
                "raw_output": raw,
            })
            if validation["valid"]:
                break
            missing_operation_only = bool(validation["issues"]) and all(
                issue["code"] == "COARSE_FINE_MISMATCH" and "实际为[]" in issue["message"]
                for issue in validation["issues"]
            )
            if validation["route"] != "internal_retry" and not missing_operation_only:
                break
            concise = [{key: issue[key] for key in ("code", "path", "message")} for issue in validation["issues"]]
            guidance = repair_guidance(task, validation["issues"])
            messages.extend([
                {"role": "assistant", "content": raw},
                {
                    "role": "user",
                    "content": (
                        "上一次输出未通过内部校验。请依据原始输入重新生成完整JSON，不要只输出局部修补，"
                        "不要解释。" + guidance + "必须修复以下错误：" + json.dumps(concise, ensure_ascii=False)
                    ),
                },
            ])
        results.append({
            "task": task,
            "input_tokens": int(encoded["input_ids"].shape[1]),
            "output_tokens": int(output_ids.shape[0]),
            "generation_seconds": round(generation_seconds, 3),
            "strict_json_valid": parsed is not None,
            "json_error": parse_error,
            "schema_validation": validation,
            "candidate_violations": candidate_errors,
            "gold_comparison": gold_summary(task, strict_row[task], parsed),
            "attempt_count": len(attempts),
            "first_attempt_valid": attempts[0]["validation"]["valid"],
            "attempts": attempts,
            "raw_output": raw,
            "parsed_output": parsed,
        })
        if pipeline_mode:
            if not validation["valid"]:
                break
            if task == "A":
                pipeline_blueprint = parsed["blueprint"]
            elif task == "B":
                pipeline_operations = parsed["operations"]

    record = {
        "run_type": (
            "unfinetuned_qwen3_4b_local_smoke_pipeline"
            if pipeline_mode else "unfinetuned_qwen3_4b_local_smoke_independent_ABC"
        ),
        "unit_id": args.unit_id,
        "subject": subject,
        "model": str(MODEL_PATH),
        "quantization": "bnb_nf4_4bit",
        "load_seconds": round(load_seconds, 3),
        "pipeline_completed": pipeline_mode and len(results) == 3 and all(
            item["schema_validation"]["valid"] for item in results
        ),
        "results": results,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "run_type": record["run_type"],
        "unit_id": record["unit_id"],
        "load_seconds": record["load_seconds"],
        "results": [{
            key: result[key] for key in (
                "task", "input_tokens", "output_tokens", "generation_seconds",
                "strict_json_valid", "schema_validation", "candidate_violations", "gold_comparison",
            )
        } for result in results],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
