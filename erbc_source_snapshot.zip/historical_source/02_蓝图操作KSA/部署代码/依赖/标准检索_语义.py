"""Semantic reranking for the stage-1 hierarchical candidate retriever.

The Qwen embedding model only ranks official standard-library nodes. It does
not generate labels and does not access gold labels during retrieval.
"""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import torch
import torch.nn.functional as F
from transformers import AutoModel, AutoTokenizer


ROOT = Path(
    r"D:\stress-aware-homework-agent\项目进展\题目知识蓝图与KSA双层外包新方法\模型训练\本地部署测试"
)
RETRIEVAL_ROOT = ROOT / "标准库候选检索"
STAGE1_PATH = RETRIEVAL_ROOT / "第一阶段_词法分层候选检索.py"
EMBED_MODEL = ROOT / "模型" / "Qwen3-Embedding-0.6B"
FROZEN_ROOT = ROOT.parent / "最终冻结训练版本"

QUERY_INSTRUCTION = (
    "Given an educational assignment or academic question, retrieve the most "
    "appropriate official knowledge-standard nodes for a KA-KU-Topic blueprint."
)


def load_stage1():
    spec = importlib.util.spec_from_file_location("stage1_retriever", STAGE1_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {STAGE1_PATH}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def last_token_pool(hidden: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    left_padding = bool((attention_mask[:, -1].sum() == attention_mask.shape[0]).item())
    if left_padding:
        return hidden[:, -1]
    sequence_lengths = attention_mask.sum(dim=1) - 1
    return hidden[torch.arange(hidden.shape[0], device=hidden.device), sequence_lengths]


class Embedder:
    def __init__(self, model_path: Path, dimensions: int = 1024):
        self.tokenizer = AutoTokenizer.from_pretrained(
            str(model_path), local_files_only=True, padding_side="left"
        )
        self.model = AutoModel.from_pretrained(
            str(model_path), local_files_only=True, dtype=torch.float16
        ).cuda().eval()
        self.dimensions = dimensions

    @torch.inference_mode()
    def encode(self, texts: list[str], *, is_query: bool, batch_size: int = 64) -> torch.Tensor:
        if is_query:
            texts = [f"Instruct: {QUERY_INSTRUCTION}\nQuery: {text}" for text in texts]
        outputs = []
        for start in range(0, len(texts), batch_size):
            batch = texts[start : start + batch_size]
            encoded = self.tokenizer(
                batch,
                padding=True,
                truncation=True,
                max_length=8192 if is_query else 512,
                return_tensors="pt",
            ).to(self.model.device)
            result = self.model(**encoded)
            pooled = last_token_pool(result.last_hidden_state, encoded["attention_mask"])
            pooled = pooled[:, : self.dimensions]
            outputs.append(F.normalize(pooled, p=2, dim=1).cpu())
        return torch.cat(outputs, dim=0)


def node_document(node, by_id: dict) -> str:
    fields = [node.english_name, node.chinese_label, node.node_id]
    parent = by_id.get(node.parent_id)
    if parent:
        fields.extend([parent.english_name, parent.chinese_label])
        grand = by_id.get(parent.parent_id)
        if grand:
            fields.extend([grand.english_name, grand.chinese_label])
    return " | ".join(x for x in fields if x)


class HybridRetriever:
    def __init__(self, stage1, subject: str, nodes: list, embedder: Embedder):
        self.stage1 = stage1.HierarchicalRetriever(subject, nodes)
        self.subject = subject
        self.by_id = self.stage1.by_id
        self.level_nodes = self.stage1.by_level
        self.level_pos = {
            level: {node.node_id: i for i, node in enumerate(nodes)}
            for level, nodes in self.level_nodes.items()
        }
        self.topic_nodes = self.level_nodes["TOPIC"]
        self.topic_pos = self.level_pos["TOPIC"]
        self.topics_by_ku = defaultdict(list)
        for node in self.topic_nodes:
            if node.parent_id:
                self.topics_by_ku[node.parent_id].append(node)
        self.level_embeddings = {
            level: embedder.encode(
                [node_document(node, self.by_id) for node in nodes], is_query=False
            )
            for level, nodes in self.level_nodes.items()
        }
        self.topic_embeddings = self.level_embeddings["TOPIC"]
        self.embedder = embedder

    def retrieve(
        self,
        query: str,
        *,
        lexical_topic_k: int = 150,
        dense_topic_k: int = 150,
        final_topic_k: int = 30,
        ku_k: int = 16,
        ka_k: int = 7,
        semantic_weight: float = 0.8,
        expand_ku_children: bool = True,
        model_path_k: int = 48,
        path_ku_diversity: int = 8,
        prior_topic_ids: list[str] | None = None,
        prior_weight: float = 0.08,
        query_embedding: torch.Tensor | None = None,
    ) -> dict:
        lexical = self.stage1.retrieve(query, ka_k=ka_k, ku_k=max(ku_k, 30), topic_k=lexical_topic_k)
        lexical_topics = lexical["candidates"]["TOPIC"]
        lexical_by_id = {item["node_id"]: item for item in lexical_topics}
        if query_embedding is None:
            query_embedding = self.embedder.encode([query], is_query=True)[0]
        all_semantic = self.topic_embeddings @ query_embedding
        dense_k = min(dense_topic_k, len(self.topic_nodes))
        dense_positions = torch.topk(all_semantic, k=dense_k).indices.tolist()

        # Union lexical and full-library dense candidates. This removes the
        # recall ceiling caused by reranking lexical candidates alone.
        union_ids = list(lexical_by_id)
        seen = set(union_ids)
        for pos in dense_positions:
            node_id = self.topic_nodes[pos].node_id
            if node_id not in seen:
                union_ids.append(node_id)
                seen.add(node_id)

        positions = torch.tensor([self.topic_pos[node_id] for node_id in union_ids])
        semantic = all_semantic[positions]
        lexical_raw = torch.tensor(
            [float(lexical_by_id.get(node_id, {}).get("score", 0.0)) for node_id in union_ids]
        )
        positive = lexical_raw[lexical_raw > 0]
        if positive.numel() and float(positive.max() - positive.min()) > 1e-9:
            lexical_values = torch.where(
                lexical_raw > 0,
                (lexical_raw - positive.min()) / (positive.max() - positive.min()),
                torch.zeros_like(lexical_raw),
            )
        elif positive.numel():
            lexical_values = (lexical_raw > 0).float()
        else:
            lexical_values = torch.zeros_like(lexical_raw)
        hybrid = semantic_weight * semantic + (1.0 - semantic_weight) * lexical_values
        order = torch.argsort(hybrid, descending=True).tolist()[:final_topic_k]
        topic_candidates = []
        for rank, idx in enumerate(order, 1):
            node_id = union_ids[idx]
            if node_id in lexical_by_id:
                item = dict(lexical_by_id[node_id])
            else:
                item = self._brief(node_id, 0.0, rank)
            item.update(
                semantic_score=round(float(semantic[idx]), 6),
                hybrid_score=round(float(hybrid[idx]), 6),
                lexical_candidate=node_id in lexical_by_id,
                dense_candidate=self.topic_pos[node_id] in dense_positions,
                rank=rank,
            )
            topic_candidates.append(item)

        ku_score = defaultdict(float)
        lexical_kus = lexical["candidates"]["KU"]
        lexical_ku_values = torch.tensor([float(item["score"]) for item in lexical_kus])
        if lexical_ku_values.numel() and float(lexical_ku_values.max() - lexical_ku_values.min()) > 1e-9:
            lexical_ku_values = (
                (lexical_ku_values - lexical_ku_values.min())
                / (lexical_ku_values.max() - lexical_ku_values.min())
            )
        elif lexical_ku_values.numel():
            lexical_ku_values = torch.ones_like(lexical_ku_values)
        ku_semantic = self.level_embeddings["KU"] @ query_embedding
        dense_ku_k = min(max(ku_k, 30), len(self.level_nodes["KU"]))
        dense_ku_positions = torch.topk(ku_semantic, k=dense_ku_k).indices.tolist()
        for item, lexical_value in zip(lexical_kus, lexical_ku_values.tolist()):
            pos = self.level_pos["KU"][item["node_id"]]
            ku_score[item["node_id"]] = max(
                ku_score[item["node_id"]],
                semantic_weight * float(ku_semantic[pos])
                + (1.0 - semantic_weight) * lexical_value,
            )
        for pos in dense_ku_positions:
            node_id = self.level_nodes["KU"][pos].node_id
            ku_score[node_id] = max(
                ku_score[node_id], semantic_weight * float(ku_semantic[pos])
            )
        for item in topic_candidates:
            parent = self.by_id[item["node_id"]].parent_id
            if parent:
                ku_score[parent] = max(ku_score[parent], float(item["hybrid_score"]))
        # Preserve evidence from both retrieval channels before score-based
        # filling. A raw weighted sum can otherwise suppress a strong dense
        # match merely because many Topic-parent boosts favour lexical KUs.
        quota = max(1, ku_k // 2)
        ku_ids = []
        for node_id in [item["node_id"] for item in lexical_kus[:quota]]:
            if node_id not in ku_ids:
                ku_ids.append(node_id)
        for pos in dense_ku_positions[:quota]:
            node_id = self.level_nodes["KU"][pos].node_id
            if node_id not in ku_ids:
                ku_ids.append(node_id)
        for node_id in sorted(ku_score, key=lambda x: (-ku_score[x], x)):
            if len(ku_ids) >= ku_k:
                break
            if node_id not in ku_ids:
                ku_ids.append(node_id)
        ku_ids = ku_ids[:ku_k]

        # Every returned Topic must have its official parent KU in the same
        # candidate package. Parent preservation may exceed the soft KU limit
        # by a few nodes; structural validity takes priority over list length.
        for item in topic_candidates:
            parent_id = self.by_id[item["node_id"]].parent_id
            if parent_id and parent_id not in ku_ids:
                ku_ids.append(parent_id)
                ku_score[parent_id] = max(
                    ku_score[parent_id], float(item.get("hybrid_score", 0.0))
                )

        # A Topic is only valid beneath its official KU parent. Once a KU is
        # retrieved, expose all of its official Topic children to remove the
        # arbitrary flat Top-K cutoff while keeping the list far smaller than
        # the entire subject library.
        if expand_ku_children:
            selected_topic_ids = {item["node_id"] for item in topic_candidates}
            for ku_id in ku_ids:
                for node in self.topics_by_ku.get(ku_id, []):
                    if node.node_id in selected_topic_ids:
                        continue
                    item = self._brief(node.node_id, 0.0, len(topic_candidates) + 1)
                    item.update(
                        semantic_score=round(float(all_semantic[self.topic_pos[node.node_id]]), 6),
                        hybrid_score=0.0,
                        lexical_candidate=node.node_id in lexical_by_id,
                        dense_candidate=self.topic_pos[node.node_id] in dense_positions,
                        hierarchy_expansion=True,
                    )
                    topic_candidates.append(item)
                    selected_topic_ids.add(node.node_id)

        # A small subject-specific prior is estimated from the training split
        # only. It protects common labels whose official descriptions are too
        # generic for semantic retrieval, without consulting validation/test
        # gold labels. Semantic retrieval still supplies unseen labels.
        prior_topic_ids = list(dict.fromkeys(prior_topic_ids or []))
        topic_item_by_id = {item["node_id"]: item for item in topic_candidates}
        for prior_rank, topic_id in enumerate(prior_topic_ids, 1):
            node = self.by_id.get(topic_id)
            if node is None or node.level != "TOPIC" or not node.parent_id:
                continue
            if topic_id not in topic_item_by_id:
                item = self._brief(topic_id, 0.0, len(topic_candidates) + 1)
                item.update(
                    semantic_score=round(float(all_semantic[self.topic_pos[topic_id]]), 6),
                    hybrid_score=0.0,
                    lexical_candidate=topic_id in lexical_by_id,
                    dense_candidate=self.topic_pos[topic_id] in dense_positions,
                    training_prior=True,
                    training_prior_rank=prior_rank,
                )
                topic_candidates.append(item)
                topic_item_by_id[topic_id] = item
            else:
                topic_item_by_id[topic_id]["training_prior"] = True
                topic_item_by_id[topic_id]["training_prior_rank"] = prior_rank
            if node.parent_id not in ku_ids:
                ku_ids.append(node.parent_id)
            ku_score[node.parent_id] = max(
                ku_score[node.parent_id],
                semantic_weight * float(self.level_embeddings["KU"][self.level_pos["KU"][node.parent_id]] @ query_embedding),
            )

        ka_score = defaultdict(float)
        for item in lexical["candidates"]["KA"]:
            ka_score[item["node_id"]] = max(ka_score[item["node_id"]], 0.2 * float(item["score"]))
        for ku_id in ku_ids:
            ku_node = self.by_id.get(ku_id)
            if ku_node and ku_node.parent_id:
                ka_score[ku_node.parent_id] = max(ka_score[ku_node.parent_id], ku_score[ku_id])
        ka_semantic = self.level_embeddings["KA"] @ query_embedding
        # Keep broad KA evidence internally. The model-visible candidate set is
        # contracted below to ancestor-closed KA -> KU -> Topic paths.
        for pos, node in enumerate(self.level_nodes["KA"]):
            ka_score[node.node_id] = max(
                ka_score[node.node_id], semantic_weight * float(ka_semantic[pos])
            )
        broad_ka_ids = sorted(ka_score, key=lambda x: (-ka_score[x], x))

        # Rank complete official hierarchy paths instead of showing the model
        # three unrelated flat lists. Broad KU-child expansion remains an
        # internal recall mechanism, but only a compact, ancestor-closed path
        # subgraph is exposed to the generator.
        prior_rank_by_id = {topic_id: rank for rank, topic_id in enumerate(prior_topic_ids, 1)}
        ranked_topics = []
        for item in topic_candidates:
            topic_id = item["node_id"]
            topic = self.by_id[topic_id]
            ku_id = topic.parent_id
            ku = self.by_id.get(ku_id)
            if ku is None or ku.level != "KU" or not ku.parent_id:
                continue
            ka = self.by_id.get(ku.parent_id)
            if ka is None or ka.level != "KA":
                continue
            semantic_score = float(item.get("semantic_score", 0.0))
            hybrid_score = float(item.get("hybrid_score", 0.0))
            parent_score = float(ku_score.get(ku_id, 0.0))
            prior_rank = prior_rank_by_id.get(topic_id)
            prior_score = 1.0 / math.log2(prior_rank + 1.0) if prior_rank else 0.0
            path_score = (
                max(hybrid_score, semantic_weight * semantic_score)
                + 0.1 * parent_score
                + prior_weight * prior_score
            )
            ranked_topics.append((path_score, semantic_score, topic_id, ku_id, ka.node_id, item))
        ranked_topics.sort(key=lambda x: (-x[0], -x[1], x[2]))

        selected_topic_ids = set()
        selected_rows = []
        path_limit = max(1, model_path_k)

        # Reserve the training-only prior paths before semantic filling. The
        # reserve remains inside model_path_k, so prompt size stays bounded.
        for topic_id in prior_topic_ids:
            if len(selected_rows) >= path_limit:
                break
            prior = next((row for row in ranked_topics if row[2] == topic_id), None)
            if prior is not None and prior[2] not in selected_topic_ids:
                selected_rows.append(prior)
                selected_topic_ids.add(prior[2])

        # Preserve a small amount of KU diversity, then fill by path score.
        # This avoids one broad KU monopolising the prompt without exposing all
        # children of every retrieved KU.
        for ku_id in ku_ids[: max(0, path_ku_diversity)]:
            if len(selected_rows) >= path_limit:
                break
            best = next((row for row in ranked_topics if row[3] == ku_id), None)
            if best is not None and best[2] not in selected_topic_ids:
                selected_rows.append(best)
                selected_topic_ids.add(best[2])
        for row in ranked_topics:
            if len(selected_rows) >= path_limit:
                break
            if row[2] not in selected_topic_ids:
                selected_rows.append(row)
                selected_topic_ids.add(row[2])
        selected_rows.sort(key=lambda x: (-x[0], -x[1], x[2]))

        visible_topic_ids = [row[2] for row in selected_rows]
        visible_ku_ids = []
        visible_ka_ids = []
        paths = []
        for rank, (path_score, semantic_score, topic_id, ku_id, ka_id, item) in enumerate(selected_rows, 1):
            if ku_id not in visible_ku_ids:
                visible_ku_ids.append(ku_id)
            if ka_id not in visible_ka_ids:
                visible_ka_ids.append(ka_id)
            topic = self.by_id[topic_id]
            ku = self.by_id[ku_id]
            ka = self.by_id[ka_id]
            paths.append({
                "path_rank": rank,
                "path_score": round(float(path_score), 6),
                "ka_id": ka.node_id,
                "ka_name": ka.english_name,
                "ku_id": ku.node_id,
                "ku_name": ku.english_name,
                "topic_id": topic.node_id,
                "topic_name": topic.english_name,
            })

        visible_topics = []
        topic_item_by_id = {item["node_id"]: item for item in topic_candidates}
        for rank, topic_id in enumerate(visible_topic_ids, 1):
            item = dict(topic_item_by_id[topic_id])
            item["rank"] = rank
            visible_topics.append(item)

        return {
            "subject": self.subject,
            "query": query,
            "limits": {
                "KA_requested": ka_k,
                "KA_broad_returned": len(broad_ka_ids),
                "KU_requested": ku_k,
                "KU_returned": len(ku_ids),
                "Topic_seed": final_topic_k,
                "Topic_broad_returned": len(topic_candidates),
                "model_path_requested": model_path_k,
                "model_path_returned": len(paths),
                "model_KA_returned": len(visible_ka_ids),
                "model_KU_returned": len(visible_ku_ids),
                "model_Topic_returned": len(visible_topic_ids),
            },
            "retrieval": {
                "lexical_topic_k": lexical_topic_k,
                "dense_topic_k": dense_topic_k,
                "semantic_weight": semantic_weight,
                "expand_ku_children": expand_ku_children,
                "model_path_k": model_path_k,
                "path_ku_diversity": path_ku_diversity,
                "training_prior_topic_count": len(prior_topic_ids),
                "prior_weight": prior_weight,
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
            },
            "candidates": {
                "KA": [self._brief(node_id, ka_score[node_id], rank) for rank, node_id in enumerate(visible_ka_ids, 1)],
                "KU": [self._brief(node_id, ku_score[node_id], rank) for rank, node_id in enumerate(visible_ku_ids, 1)],
                "TOPIC": visible_topics,
            },
            "candidate_paths": paths,
            "internal_broad_counts": {
                "KA": len(broad_ka_ids),
                "KU": len(ku_ids),
                "TOPIC": len(topic_candidates),
            },
        }

    def _brief(self, node_id: str, score: float, rank: int) -> dict:
        node = self.by_id[node_id]
        return {
            "level": node.level,
            "node_id": node.node_id,
            "parent_id": node.parent_id,
            "english_name": node.english_name,
            "chinese_label": node.chinese_label,
            "source_standard": node.source_standard,
            "status": node.status,
            "score": round(float(score), 6),
            "rank": rank,
        }


def load_training_topic_priors(stage1, top_k: int) -> dict[str, list[str]]:
    path = FROZEN_ROOT / "A_题目知识蓝图任务" / "train.jsonl"
    counts = defaultdict(Counter)
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if not line.strip():
                continue
            row = json.loads(line)
            subject = row.get("metadata", {}).get("subject", "")
            target = json.loads(row["messages"][-1]["content"])
            for item in target.get("blueprint", []):
                topic_id = (item.get("topic_id") or "").strip()
                if topic_id:
                    counts[subject][topic_id] += 1
    return {
        subject: [topic_id for topic_id, _ in counter.most_common(max(0, top_k))]
        for subject, counter in counts.items()
    }


def evaluate(
    stage1,
    split: str,
    final_topic_k: int,
    ku_k: int,
    ka_k: int,
    semantic_weight: float,
    dense_topic_k: int,
    model_path_k: int,
    path_ku_diversity: int,
    prior_topic_k: int,
    prior_weight: float,
) -> dict:
    embedder = Embedder(EMBED_MODEL)
    retrievers = {
        subject: HybridRetriever(stage1, subject, stage1.load_library(subject, path), embedder)
        for subject, path in stage1.LIBRARIES.items()
    }
    training_priors = load_training_topic_priors(stage1, prior_topic_k)
    path = FROZEN_ROOT / "A_题目知识蓝图任务" / f"{split}.jsonl"
    totals = Counter()
    hits = Counter()
    by_total = defaultdict(Counter)
    by_hit = defaultdict(Counter)
    candidate_counts = defaultdict(lambda: defaultdict(list))
    topic_ranks = []
    topic_totals_by_subject = Counter()
    topic_ranks_by_subject = defaultdict(list)
    misses = []
    with path.open("r", encoding="utf-8") as handle:
        rows = [json.loads(line) for line in handle]
    queries = [stage1.extract_question(row) for row in rows]
    query_embeddings = embedder.encode(queries, is_query=True, batch_size=2)
    for row, query, query_embedding in zip(rows, queries, query_embeddings):
        subject = row.get("metadata", {}).get("subject", "")
        target = json.loads(row["messages"][-1]["content"])
        gold = {"KA": set(), "KU": set(), "TOPIC": set()}
        for item in target.get("blueprint", []):
            for level, key in (("KA", "ka_id"), ("KU", "ku_id"), ("TOPIC", "topic_id")):
                value = (item.get(key) or "").strip()
                if value:
                    gold[level].add(value)
        result = retrievers[subject].retrieve(
            query,
            dense_topic_k=dense_topic_k,
            final_topic_k=final_topic_k,
            ku_k=ku_k,
            ka_k=ka_k,
            semantic_weight=semantic_weight,
            model_path_k=model_path_k,
            path_ku_diversity=path_ku_diversity,
            prior_topic_ids=training_priors.get(subject, []),
            prior_weight=prior_weight,
            query_embedding=query_embedding,
        )
        path_rank_by_topic = {item["topic_id"]: item["path_rank"] for item in result["candidate_paths"]}
        for topic_id in gold["TOPIC"]:
            topic_totals_by_subject[subject] += 1
            rank = path_rank_by_topic.get(topic_id)
            topic_ranks.append(rank)
            topic_ranks_by_subject[subject].append(rank)
        pred = {level: {item["node_id"] for item in result["candidates"][level]} for level in gold}
        for level in gold:
            candidate_counts[subject][level].append(len(pred[level]))
            totals[level] += len(gold[level])
            by_total[subject][level] += len(gold[level])
            found = len(gold[level] & pred[level])
            hits[level] += found
            by_hit[subject][level] += found
            missing = sorted(gold[level] - pred[level])
            if missing and len(misses) < 200:
                misses.append({"unit_id": row.get("metadata", {}).get("unit_id"), "subject": subject, "level": level, "missing": missing})

    def rates(h, t):
        return {level: round(h[level] / t[level], 6) if t[level] else None for level in ("KA", "KU", "TOPIC")}

    def rank_summary(values, total):
        found = sorted(value for value in values if value is not None)
        if not total:
            return None
        midpoint = len(found) // 2
        median = (
            (found[midpoint - 1] + found[midpoint]) / 2
            if found and len(found) % 2 == 0
            else found[midpoint] if found else None
        )
        p90_index = max(0, math.ceil(0.9 * len(found)) - 1) if found else 0
        return {
            "gold_topic_count": total,
            "retrieved_topic_count": len(found),
            "mrr": round(sum(1.0 / value for value in found) / total, 6),
            "mean_rank_retrieved": round(sum(found) / len(found), 3) if found else None,
            "median_rank_retrieved": median,
            "p90_rank_retrieved": found[p90_index] if found else None,
            "recall_at": {
                str(k): round(sum(value <= k for value in found) / total, 6)
                for k in (5, 10, 20, 48)
            },
        }

    return {
        "version": "bm25_dense_hierarchy_path_subgraph_v4",
        "split": split,
        "configuration": {
            "lexical_topic_k": 150,
            "dense_topic_k": dense_topic_k,
            "final_topic_k": final_topic_k,
            "ku_k": ku_k,
            "ka_k": ka_k,
            "semantic_weight": semantic_weight,
            "expand_ku_children": True,
            "model_path_k": model_path_k,
            "path_ku_diversity": path_ku_diversity,
            "prior_topic_k": prior_topic_k,
            "prior_weight": prior_weight,
            "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
            "embedding_model_revision": "97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3",
        },
        "overall_recall": rates(hits, totals),
        "hits": dict(hits),
        "totals": dict(totals),
        "by_subject_recall": {subject: rates(by_hit[subject], by_total[subject]) for subject in sorted(by_total)},
        "topic_path_ranking": rank_summary(topic_ranks, totals["TOPIC"]),
        "topic_path_ranking_by_subject": {
            subject: rank_summary(topic_ranks_by_subject[subject], topic_totals_by_subject[subject])
            for subject in sorted(topic_totals_by_subject)
        },
        "candidate_count_by_subject": {
            subject: {
                level: {
                    "min": min(values),
                    "max": max(values),
                    "mean": round(sum(values) / len(values), 2),
                }
                for level, values in levels.items()
            }
            for subject, levels in sorted(candidate_counts.items())
        },
        "miss_count": sum(totals[level] - hits[level] for level in totals),
        "miss_examples": misses,
    }


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser()
    parser.add_argument("--split", choices=("validation", "test"), default="validation")
    parser.add_argument("--topic-k", type=int, default=30)
    parser.add_argument("--dense-topic-k", type=int, default=150)
    parser.add_argument("--ku-k", type=int, default=16)
    parser.add_argument("--ka-k", type=int, default=7)
    parser.add_argument("--semantic-weight", type=float, default=0.8)
    parser.add_argument("--model-path-k", type=int, default=48)
    parser.add_argument("--path-ku-diversity", type=int, default=8)
    parser.add_argument("--prior-topic-k", type=int, default=8)
    parser.add_argument("--prior-weight", type=float, default=0.08)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    stage1 = load_stage1()
    result = evaluate(
        stage1,
        args.split,
        args.topic_k,
        args.ku_k,
        args.ka_k,
        args.semantic_weight,
        args.dense_topic_k,
        args.model_path_k,
        args.path_ku_diversity,
        args.prior_topic_k,
        args.prior_weight,
    )
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(json.dumps({k: result[k] for k in ("version", "split", "configuration", "overall_recall", "hits", "totals", "miss_count")}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
