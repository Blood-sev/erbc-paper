"""CPU-only shared data build. No retriever, torch or model import."""
import argparse,copy,importlib.util,os
from core import *

DATA='运行输出/C数值统一输入_20261014_v1'
TRAIN='训练数据/提交证据精确追溯派生版_v2/完整流水线评估/train.jsonl'
GOLD='训练数据/提交证据精确追溯派生版_v2/完整流水线评估/validation.jsonl'
SFT='运行输出/LoRA训练准备_v2/SFT样本_训练集.jsonl'
SOURCE='运行输出/独立C基线_剩余6条双卡5GiB收尾_20261014_v5'

def sources(dialogue,submission):
    result=[]
    for d in dialogue:result.append({'source_id':d['message_id'],'speaker':d['speaker'],'content':d['content']})
    for d in submission.get('documents',[]):
        if d.get('source_id') and isinstance(d.get('content'),str):result.append({'source_id':d['source_id'],'speaker':'submission','content':d['content']})
    return result

def split_members(train):
    groups={}
    for x in train:
        m=x['metadata'];groups.setdefault(m['subject'],set()).add(m['subject']+'::'+m['student_id'])
    dev=set()
    for ss in groups.values():
        order=sorted(ss,key=lambda s:hashlib.sha256(('C_COMMON_20261014_V1|'+s).encode()).hexdigest())
        n=min(len(ss)-1,max(1,round(len(ss)*.15))) if len(ss)>1 else 0;dev.update(order[:n])
    return {x['unit_id']:('development' if x['metadata']['subject']+'::'+x['metadata']['student_id'] in dev else 'train') for x in train}

def make_record(g,payload,partition,status='READY'):
    y=math.fsum(z['ai_share'] for z in g['target']['ksa'])/len(g['target']['ksa'])
    need(math.isfinite(y) and 0<=y<=1,'C_LABEL')
    variants=[]
    if status=='READY':
        for eb,qb in [(24000,6000),(12000,4000),(6000,2000),(2000,1000),(0,0)]:
            m,a=render(payload,eb,qb);variants.append({'messages':m,'audit':a})
    return {'unit_id':g['unit_id'],'subject':g['metadata']['subject'],
      'student_group_id':g['metadata']['subject']+'::'+g['metadata']['student_id'],
      'partition':partition,'target_fraction':y,'status':status,'variants':variants}

def prepare(root):
    root=Path(root).resolve();stage=Path(__file__).resolve().parent;p=read(stage/'plan.json');out=root/DATA
    need(not out.exists(),'DATA_EXISTS_STOP')
    for rel,h in p['source_hashes'].items():need(sha(root/rel)==h,'SOURCE_CHANGED:'+rel)
    train=rows(root/TRAIN);gold=rows(root/GOLD);by={x['unit_id']:x for x in train};og={x['unit_id']:x for x in gold}
    need(len(by)==1085 and len(og)==148,'MEMBERSHIP')
    student=lambda x:x['metadata']['subject']+'::'+x['metadata']['student_id']
    need(not set(by)&set(og) and not {student(x) for x in train}&{student(x) for x in gold},'OFFICIAL_OVERLAP')
    partition=split_members(train);records={'train':[],'development':[],'official':[]};admitted=set()
    with (root/SFT).open(encoding='utf-8') as f:
        for line in f:
            x=json.loads(line)
            if x['metadata']['task']!='C':continue
            u=x['metadata']['unit_id'];need(u not in admitted and u in by,'SFT_MEMBERSHIP');admitted.add(u)
            x=json.loads(x['messages'][1]['content'])
            payload={'subject':x['subject'],'question':x['question_text'],'blueprint':x['confirmed_blueprint'],
              'operations':x['confirmed_operations'],'sources':sources(x['dialogue_with_message_ids'],x['submission'])}
            part=partition[u];records[part].append(make_record(by[u],payload,part))
    need(sorted(set(by)-admitted)==p['historical_excluded_ids'] and len(admitted)==1081,'EXCLUSION_DRIFT')
    old={x['unit_id']:x for x in rows(root/'训练数据/提交证据增强派生版/完整流水线评估/validation.jsonl')}
    cache_ids={x['unit_id'] for x in rows(root/'运行输出/ABC_E3第一版单标量最终Agent主线_v1_四卡/final_output_139.jsonl')}
    saved=read(root/SOURCE/'source_results148.json');need(set(saved)==set(og),'OFFICIAL_AB_MEMBERSHIP')
    spec=importlib.util.spec_from_file_location('frozen_adapter',root/'部署代码/依赖/冻结数据严格Schema适配器.py')
    adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
    for u,g in sorted(og.items()):
        x=saved[u]
        if not all(x['results'][t]['strict_gate_pass'] for t in 'AB'):
            records['official'].append(make_record(g,None,'official','UPSTREAM_BLOCKED'));continue
        raw=old[u] if u in cache_ids else g;inp=raw['input'];q=inp['question']
        question=q if isinstance(q,str) else '\n'.join(v.strip() for v in (q.get('title',''),q.get('text','')) if isinstance(v,str) and v.strip())
        payload={'subject':g['metadata']['subject'],'question':question,
            'blueprint':x['results']['A']['prediction']['blueprint'],'operations':x['results']['B']['prediction']['operations'],
            'sources':sources(adapter.normalized_dialogue(raw),inp.get('submission',{}))}
        records['official'].append(make_record(g,payload,'official'))
    need(sum(x['subject'].startswith('01_') for x in records['official'])==85,'CS85')
    a={x['student_group_id'] for x in records['train']};b={x['student_group_id'] for x in records['development']};need(not a&b,'STUDENT_SPLIT_LEAK')
    out.mkdir(parents=True)
    for part,rr in records.items():
        rr.sort(key=lambda x:x['unit_id'])
        with (out/f'{part}.jsonl').open('x',encoding='utf-8') as f:
            for x in rr:f.write(canonical(x)+'\n')
    report={'status':'COMMON_NUMERICAL_C_DATA_PREPARED_CPU_ONLY','protocol':VERSION,
      'counts':{k:len(v) for k,v in records.items()},'official_CS':85,'official_upstream_blocked':sum(x['status']!='READY' for x in records['official']),
      'training_pool_source':1085,'admitted_pool':1081,'historical_excluded_ids':p['historical_excluded_ids'],
      'training_dev_context':'historical teacher-forced gold A/B','official_context':'frozen predicted A/E3-B',
      'all_C_labels_unchanged':True,'official_membership_unchanged':True,'official_adaptive_use':True,
      'source_hashes':p['source_hashes'],'artifacts':{f'{k}.jsonl':sha(out/f'{k}.jsonl') for k in records},
      'actual_token_lengths_verified':False,'GPU_used':False,'training_started':False,
      'note':'Old structured-C scores are separate reference. Numerical baseline and every trained numerical-C method must use these same selected tokenized inputs.'}
    write(out/'summary.json',report);print(canonical(report));return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--project-root',required=True);a=p.parse_args();prepare(a.project_root)
