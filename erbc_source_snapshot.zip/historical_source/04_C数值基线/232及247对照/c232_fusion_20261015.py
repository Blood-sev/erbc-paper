"""Pre-frozen 50/50 prediction mean; a control, not C algorithm optimization."""
import math
from core import need,metrics

def blend(reference,candidate,expected):
    need(len(reference)==len(candidate)==expected,'FUSION_RECORD_COUNT')
    a={r['unit_id']:r for r in reference};b={r['unit_id']:r for r in candidate}
    need(len(a)==len(b)==expected and set(a)==set(b),'FUSION_MEMBERSHIP')
    result=[]
    for u,x in a.items():
        y=b[u];keys=('unit_id','subject','student_group_id','target_fraction')
        need(all(x[k]==y[k] for k in keys),'FUSION_IDENTITY_OR_LABEL')
        need(x['status']==y['status'] and x['status'] in ('PASS','UPSTREAM_BLOCKED'),'FUSION_STATUS_NO_FALLBACK')
        z={k:x[k] for k in keys};z['status']=x['status']
        if x['status']=='PASS':
            need(x.get('token_ids_sha256') and x['token_ids_sha256']==y.get('token_ids_sha256'),'FUSION_INPUT_HASH')
            for r in (x,y):need(type(r['prediction_fraction']) in (int,float) and math.isfinite(r['prediction_fraction']) and 0<=r['prediction_fraction']<=1,'FUSION_PREDICTION')
            z.update(token_ids_sha256=x['token_ids_sha256'],prediction_fraction=.5*x['prediction_fraction']+.5*y['prediction_fraction'],reference_prediction_fraction=x['prediction_fraction'],replica_prediction_fraction=y['prediction_fraction'])
        else:
            need(x.get('prediction_fraction') is None and y.get('prediction_fraction') is None,'BLOCKED_HAS_PREDICTION')
            z['prediction_fraction']=None
        result.append(z)
    return result

def publish(e,root):
    from method_control import verify_reference,REFERENCE_OUT
    verify_reference(e,root);out=root/e.OUT;ref=root/REFERENCE_OUT;dest=out/'247_control';dest.mkdir()
    selected=e.read(out/'replica232_training/selection.json');prior=e.read(ref/'ntl_training/selection.json')
    reports={}
    for split,n,old,new in (
        ('development',156,ref/'ntl_training'/prior['adapter_directory']/'development_predictions.json',out/'replica232_training'/selected['adapter_directory']/'development_predictions.json'),
        ('official',148,ref/'ntl_C/predictions.json',out/'replica232_C/predictions.json')):
        aa=e.read(old);bb=e.read(new);fused=blend(aa,bb,n)
        if split=='official':need(sum(r['status']=='UPSTREAM_BLOCKED' for r in fused)==7,'FUSION_UPSTREAM_COUNT')
        f=dest/(split+'_predictions.json');e.write(f,fused)
        reports[split]={'NTL_C':metrics(aa),'232_C':metrics(bb),'247_control_C':metrics(fused),
          'source_prediction_sha256':[e.sha(old),e.sha(new)],'fused_prediction_sha256':e.sha(f)}
    summary={'status':'COMPLETE','role':'247_control_fixed_prediction_mean_not_C_algorithm_optimization','weights':[.5,.5],
      'B247_unchanged':True,'final_247_C_optimization_status':'NOT_IMPLEMENTED_NOT_EVALUATED','official_adaptive_use':True,
      'checkpoint_selection':'Each branch selected on development only, separately, before official inference; no ensemble-driven reselection.',
      'reference_checkpoint_sha256':prior['adapter_sha256'],'replica_checkpoint_sha256':selected['adapter_sha256'],
      'two_model_forward_cost':True,'reference_predictions_reused':True,**reports}
    e.write(dest/'summary.json',summary)
    return summary
