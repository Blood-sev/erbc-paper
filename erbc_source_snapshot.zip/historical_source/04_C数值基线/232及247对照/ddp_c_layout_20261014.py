"""Four-rank assignment: 8 real items or a tail of5; zero-weight placeholders."""
def layout(batch,rank,world=4):
    if world!=4 or rank not in range(world) or not 1<=len(batch)<=8:raise RuntimeError('DDP_BATCH_LAYOUT')
    return [(batch[j],4/len(batch)) if j<len(batch) else (None,0.) for j in (rank,rank+world)]

def all_real(batch):
    return [i for r in range(4) for i,w in layout(batch,r) if w]
