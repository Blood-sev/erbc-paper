"""RAFT point regression: squared error of ten-digit posterior expectation."""
import math

def oracle(z,y):
    if len(z)!=10 or not all(math.isfinite(x) for x in z) or not math.isfinite(y) or not 0<=y<=1:
        raise RuntimeError('RAFT_ARGUMENT')
    q=[math.exp(x-max(z)) for x in z];p=[x/sum(q) for x in q]
    mean=sum(i*x/9 for i,x in enumerate(p));d=mean-y
    return d*d,[2*d*x*(i/9-mean) for i,x in enumerate(p)]

def method_loss(p,y):
    import torch
    if p.ndim!=2 or p.shape[-1]!=10 or y.shape!=(p.shape[0],):raise RuntimeError('RAFT_SHAPE')
    anchors=torch.linspace(0,1,10,device=p.device,dtype=p.dtype)
    return (((p*anchors).sum(-1)-y)**2).mean()
