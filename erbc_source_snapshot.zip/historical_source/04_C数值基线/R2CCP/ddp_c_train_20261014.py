"""Four full model replicas; DDP gradient averaging, effective batch8/tail5."""
import argparse,os,sys,time,random,math,contextlib,datetime,traceback
from pathlib import Path
import run as e
from ddp_c_layout_20261014 import layout
from r2ccp_c_method_20261014 import method_loss,check_saved_head

def main(root,mode):
    import torch,torch.distributed as dist,transformers,peft
    from torch.nn.parallel import DistributedDataParallel as DDP
    from transformers import AutoModelForSequenceClassification
    from peft import LoraConfig,TaskType,get_peft_model
    out=root/e.OUT;pre=e.verify_frozen(root);folder=out/('ddp_smoke' if mode=='smoke' else 'r2ccp_training')
    rank=int(os.environ['RANK']);local=int(os.environ['LOCAL_RANK']);world=int(os.environ['WORLD_SIZE'])
    e.need(world==4 and local==rank and rank in range(4),'FOUR_DDP_REQUIRED')
    selected=e.read(out/'selected_gpus.json')['selected']
    e.need([g['index'] for g in selected]==[0,1,2,3],'R2CCP_PHYSICAL_SCOPE')
    e.need(os.environ['CUDA_VISIBLE_DEVICES']==','.join(g['uuid'] for g in selected),'GPU_ENV')
    e.need(pre['runtime']=={'torch':torch.__version__,'transformers':transformers.__version__,'peft':peft.__version__},'RUNTIME_DRIFT')
    torch.cuda.set_device(local);torch.set_num_threads(1);device=torch.device('cuda',local)
    random.seed(e.SEED+rank);torch.manual_seed(e.SEED+rank);torch.cuda.manual_seed_all(e.SEED+rank)
    free,total=torch.cuda.mem_get_info(local);e.need(free/1024**3>=33.35,'INITIAL_FREE_BELOW_MEASURED_PEAK_PLUS_MARGIN')
    torch.cuda.set_per_process_memory_fraction(min(.99,(free-6*1024**3)/total),local)
    dist.init_process_group('nccl',timeout=datetime.timedelta(seconds=300),device_id=device)
    def emit(v):e.log(folder/f'events_rank{rank}.jsonl',dict(v,time=time.time(),rank=rank))
    def guard(phase):
        free=torch.cuda.mem_get_info(local)[0]/1024**3
        e.log(folder/f'resources_rank{rank}.jsonl',{'phase':phase,'physical_gpu':selected[rank]['index'],'free_GiB':free,'reserved_GiB':torch.cuda.memory_reserved(local)/1024**3,'allocated_GiB':torch.cuda.memory_allocated(local)/1024**3,'time':time.time()})
        e.need(free>=5,'RESOURCE_BELOW_5GiB')
    def hashes():
        import hashlib
        h=hashlib.sha256()
        for n,p in model.named_parameters():
            if p.requires_grad:h.update(n.encode());h.update(p.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
        rr=[None]*4;dist.all_gather_object(rr,h.hexdigest());e.need(len(set(rr))==1,'DDP_PARAMETERS_DIVERGED');return rr[0]
    try:
        emit({'event':'model_load_start','mode':mode});guard('before_load')
        base=AutoModelForSequenceClassification.from_pretrained(root/e.MODEL,num_labels=101,local_files_only=True,dtype=torch.bfloat16,attn_implementation='flash_attention_2',low_cpu_mem_usage=True,device_map={'':local})
        base.config.use_cache=False;base.config.pad_token_id=None
        model=get_peft_model(base,LoraConfig(r=16,lora_alpha=32,lora_dropout=.05,bias='none',task_type=TaskType.SEQ_CLS,modules_to_save=["score"],target_modules=['q_proj','k_proj','v_proj','o_proj','gate_proj','up_proj','down_proj']))
        model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.enable_input_require_grads()
        e.need(all(p.device==device for p in model.parameters()),'FULL_REPLICA_PLACEMENT')
        ddp=DDP(model,device_ids=[local],output_device=local,broadcast_buffers=False,find_unused_parameters=False)
        parameters=[p for p in model.parameters() if p.requires_grad]
        e.need(sum(p.numel() for p in parameters)==33288704,'LORA_AND_SCORE_SIZE')
        initial=hashes();guard('after_load');emit({'event':'initial_parameters_synchronized','sha256':initial})
        optimizer=torch.optim.AdamW(parameters,lr=1e-4,betas=(.9,.95),eps=1e-8,weight_decay=.01,foreach=False)
        rr=e.rows(out/'train_tokens.jsonl');dev=e.rows(out/'development_tokens.jsonl');digits=pre['digits'];anchors=torch.linspace(0,1,101,device=device)
        shortest=min(range(len(rr)),key=lambda i:len(rr[i]['input_ids']))
        def probability(row,network):
            ids=torch.tensor([row['input_ids']],device=device,dtype=torch.long)
            outputs=network(input_ids=ids,attention_mask=torch.ones_like(ids),use_cache=False)
            e.need(tuple(outputs.logits.shape)==(1,101),'R2CCP_LOGIT_SHAPE')
            p=outputs.logits.float().softmax(-1);e.need(bool(torch.isfinite(p).all()),'NONFINITE_PROBABILITY');return p
        def update(batch,lr,step):
            for group in optimizer.param_groups:group['lr']=lr
            optimizer.zero_grad(set_to_none=True);stats=torch.zeros(2,dtype=torch.float64,device=device)
            for micro,(index,weight) in enumerate(layout(batch,rank)):
                actual=shortest if index is None else index;guard('before_forward')
                with ddp.no_sync() if micro==0 else contextlib.nullcontext():
                    p=probability(rr[actual],ddp);target=torch.tensor([rr[actual]['target_fraction']],device=device)
                    loss=method_loss(p,target);e.need(bool(torch.isfinite(loss)),'NONFINITE_LOSS');(weight*loss).backward()
                if index is not None:stats+=torch.tensor([float(loss.detach()),1.],dtype=torch.float64,device=device)
                emit({'event':'micro_backward','step':step,'micro':micro,'unit_id':None if index is None else rr[index]['unit_id'],'zero_weight_padding':index is None,'loss_scale':weight})
                del p,target,loss;guard('after_backward')
            if mode=='smoke':
                e.need(any(p.grad is not None and bool((p.grad!=0).any()) for n,p in model.named_parameters() if 'score' in n and p.requires_grad),'R2CCP_HEAD_NO_GRADIENT')
            norm=torch.nn.utils.clip_grad_norm_(parameters,1.,foreach=False,error_if_nonfinite=True)
            optimizer.step();optimizer.zero_grad(set_to_none=True);guard('after_optimizer')
            dist.all_reduce(stats);e.need(int(stats[1])==len(batch),'GLOBAL_REAL_BATCH_COUNT')
            return {'loss':float(stats[0]/stats[1]),'gradient_norm':float(norm),'learning_rate':lr,'batch_positions':len(batch)}
        if mode=='smoke':
            longest=max(range(len(rr)),key=lambda i:len(rr[i]['input_ids']));model.train()
            for step,n in enumerate((8,5),1):
                result=update([longest]*n,1e-5,step);h=hashes();e.need(h!=initial,'NO_UPDATE');emit({'event':'smoke_update','step':step,'parameter_sha256':h,**result})
            dist.barrier()
            if rank==0:e.write(folder/'summary.json',{'status':'PASS_REAL_FOUR_GPU_DDP_SMOKE','full_batch':8,'tail_batch':5,'max_train_tokens':len(rr[longest]['input_ids']),'initial_parameter_sha256':initial,'parameters_synchronized_after_updates':True,'adapter_saved':False})
        else:
            total=464;warmup=24;step=0;candidates=[]
            for epoch in range(4):
                model.train()
                for batch in e.batches(len(rr),epoch):
                    factor=max(1e-8,step/warmup) if step<warmup else .5*(1+math.cos(math.pi*(step-warmup)/(total-warmup)))
                    result=update(batch,1e-4*factor,step+1);step+=1
                    event={'event':'optimizer_step','epoch':epoch+1,'step':step,'total_steps':total,'world_size':4,'time':time.time(),**result}
                    if rank==0:e.log(folder/'events.jsonl',event)
                h=hashes();cp=folder/f'epoch{epoch+1}'
                if rank==0:cp.mkdir();model.save_pretrained(cp,safe_serialization=True);check_saved_head(cp)
                dist.barrier();model.eval();pred=[]
                with torch.no_grad():
                    for row in dev[rank::4]:
                        guard('before_development');p=probability(row,model);v=float((p*anchors).sum())
                        pred.append({k:row[k] for k in ('unit_id','subject','student_group_id','target_fraction')}|{'status':'PASS','prediction_fraction':v,'token_ids_sha256':row['token_ids_sha256']})
                        del p;guard('after_development')
                gathered=[None]*4;dist.all_gather_object(gathered,pred)
                if rank==0:
                    pred=sorted(sum(gathered,[]),key=lambda x:x['unit_id']);by={r['unit_id']:r for r in dev}
                    e.need(len(pred)==len(by)==156 and len({r['unit_id'] for r in pred})==156,'DEV_COVERAGE')
                    for r in pred:e.validate_result(r,by[r['unit_id']])
                    m=e.metrics(pred);e.write(cp/'development_predictions.json',pred);e.write(cp/'metrics.json',m)
                    candidates.append({'epoch':epoch+1,'adapter_directory':cp.name,'development_metrics':m,'adapter_sha256':e.sha(cp/'adapter_model.safetensors'),'adapter_config_sha256':e.sha(cp/'adapter_config.json')})
                    e.log(folder/'events.jsonl',{'event':'epoch_evaluation_complete','epoch':epoch+1,'step':step,'total_steps':total,'parameter_sha256':h,'metrics':m,'time':time.time()})
                dist.barrier()
            e.need(step==464,'UPDATE_COUNT')
            if rank==0:
                best=min(candidates,key=lambda x:(x['development_metrics']['overall']['failure_penalized_MAE_pp'],x['development_metrics']['computer_science']['failure_penalized_MAE_pp'],x['epoch']))
                e.write(folder/'selection.json',best);e.write(folder/'summary.json',{'epochs':candidates,'steps':step,'world_size':4,'formal_training_completed':True,'single_GPU_trajectory_equivalence_claimed':False})
        dist.barrier()
        if rank==0:e.write(folder/'exit.json',{'status':'PASS'})
    except BaseException:
        e.write(folder/f'failure_rank{rank}.json',{'traceback':traceback.format_exc(),'rank':rank});raise
    finally:
        if dist.is_initialized():dist.destroy_process_group()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--project-root',required=True);p.add_argument('--mode',choices=['smoke','train'],required=True);a=p.parse_args();main(Path(a.project_root).resolve(),a.mode)
