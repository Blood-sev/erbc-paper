"""C-task adaptation of TRACT: explanation CE plus score-expectation MSE.

All common evidence is preserved. Only the method instruction changes. Gold C is
available to the training teacher, NEVER to self-CoT, development or official prompts.
"""
import copy,math
from core import need,digest,rows,read,write,sha,extract_ids,SYSTEM
from raft_c_method_20261014 import method_loss
SCORE='\n最终评分：'
MAX_COT=160
INSTRUCTION=('你评估学生在AI辅助作业中的KSA认知外包率，不是操作减负率。'
 '根据冻结知识蓝图、操作及所列证据，估计细粒度知识/技能/行动中AI承担比例的均值。'
 '证据为长度受控摘录，缺失内容不能视为不存在；操作比例不能直接当KSA比例。'
 '先用2至4句中文简述证据支持的认知责任归属，说明AI承担和学生保留的部分，不编造证据；'
 '然后换行写“最终评分：”及单个数字槽0至9，0表示0%，9表示100%。')

def messages(source,teacher_target=None):
    need(len(source)==2 and source[0]['role']=='system' and source[0]['content']==SYSTEM and source[1]['role']=='user','COMMON_MESSAGES_DRIFT')
    out=copy.deepcopy(source);out[0]['content']=INSTRUCTION
    if teacher_target is not None:
        need(type(teacher_target) in (int,float) and math.isfinite(teacher_target) and 0<=teacher_target<=1,'TEACHER_TARGET')
        out[0]['content']+='\n仅供训练解释标注：已知认知外包率标签为'+format(100*teacher_target,'.12g')+'%。根据证据给出支持或限制该标注的简短解释，不复述标签数值。'
    need(out[1]==source[1],'EVIDENCE_CHANGED')
    return out

def prepare(e,root):
    from transformers import AutoTokenizer
    tokenizer=AutoTokenizer.from_pretrained(root/e.MODEL,local_files_only=True)
    out=root/e.OUT;pre=e.read(out/'preflight.json');artifacts={};lengths={}
    for part in ('train','development','official'):
        originals={x['unit_id']:x for x in rows(root/e.DATA/(part+'.jsonl'))}
        result=[]
        for row in rows(out/(part+'_tokens.jsonl')):
            if row['status']!='READY':continue
            matches=[v['messages'] for v in originals[row['unit_id']]['variants'] if digest(v['messages'])==row['input_audit']['messages_sha256']]
            # Several byte budgets can produce identical messages on short rows.
            need(matches and all(x==matches[0] for x in matches),'TRACT_COMMON_VARIANT');source=matches[0]
            common=extract_ids(tokenizer.apply_chat_template(source,tokenize=True,add_generation_prompt=True,return_dict=False))
            need(common==row['input_ids'],'TRACT_BASE_INPUT_CHANGED')
            ids=extract_ids(tokenizer.apply_chat_template(messages(source),tokenize=True,add_generation_prompt=True,return_dict=False))
            x={'unit_id':row['unit_id'],'common_token_ids_sha256':row['token_ids_sha256'],'tract_input_ids':ids,'tract_input_sha256':digest(ids),'evidence_sha256':digest(source[1])}
            if part=='train':
                x['teacher_input_ids']=extract_ids(tokenizer.apply_chat_template(messages(source,row['target_fraction']),tokenize=True,add_generation_prompt=True,return_dict=False))
                x['teacher_input_sha256']=digest(x['teacher_input_ids'])
            need(len(ids)<=32768+512 and len(x.get('teacher_input_ids',ids))<=32768+512,'TRACT_METHOD_PROMPT_BUDGET')
            result.append(x)
        f=out/(part+'_tract_inputs.json');write(f,result);artifacts[f.name]=sha(f)
        lengths[part]={'records':len(result),'maximum_input':max(len(x['tract_input_ids']) for x in result),'maximum_teacher_input':max(len(x.get('teacher_input_ids',[])) for x in result)}
    write(out/'tract_inputs.json',{'artifacts':artifacts,'lengths':lengths,'method_instruction_changed':True,'common_evidence_identical':True,'teacher_gold_only_training':True,'plan_sha256':sha(e.HERE/'plan.json')})

def get_rows(e,root,part):
    out=root/e.OUT;m=read(out/'tract_inputs.json');need(m['plan_sha256']==sha(e.HERE/'plan.json'),'TRACT_PLAN_BINDING')
    f=out/(part+'_tract_inputs.json');need(sha(f)==m['artifacts'][f.name],'TRACT_INPUT_HASH')
    extra={x['unit_id']:x for x in read(f)};rr=rows(out/(part+'_tokens.jsonl'))
    for r in rr:
        if r['status']=='READY':
            a=extra.pop(r['unit_id']);need(a['common_token_ids_sha256']==r['token_ids_sha256'] and digest(a['tract_input_ids'])==a['tract_input_sha256'],'TRACT_INPUT_IDENTITY')
            if part!='train':need('teacher_input_ids' not in a,'LABEL_IN_EVALUATION_PROMPT')
            else:need(digest(a['teacher_input_ids'])==a['teacher_input_sha256'],'TEACHER_INPUT_HASH')
            r.update(a)
    need(not extra,'EXTRA_TRACT_ID');return rr

def annotation(e,root,kind,rr):
    folder=root/e.OUT/(kind+'_cots');m=read(folder/'summary.json');f=folder/'cots.json'
    need(m['sha256']==sha(f) and m['plan_sha256']==sha(e.HERE/'plan.json'),'COT_BINDING')
    cc={r['unit_id']:r for r in read(f)};need(len(cc)==len(rr)==925,'COT_COVERAGE')
    for row in rr:
        c=cc.pop(row['unit_id'])
        need(all(c[k]==row[k] for k in ('target_fraction','subject','student_group_id')) and c['token_ids_sha256']==row['token_ids_sha256'] and c['tract_input_sha256']==row['tract_input_sha256'],'COT_IDENTITY')
        need(c['kind']==kind and len(c['cot_ids'])>0,'COT_KIND_OR_EMPTY')
        row['cot_ids']=c['cot_ids']
    need(not cc,'COT_EXTRA');return rr

def rationale(model,tokenizer,row,device,teacher=False,guard=None):
    import torch
    from transformers import StoppingCriteria,StoppingCriteriaList
    prompt=row['teacher_input_ids'] if teacher else row['tract_input_ids']
    ids=torch.tensor([prompt],device=device,dtype=torch.long)
    config=copy.deepcopy(model.generation_config);config.do_sample=False;config.num_beams=1;config.max_new_tokens=MAX_COT
    config.temperature=1.;config.top_p=1.;config.top_k=0;config.pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id;config.use_cache=True
    class Stop(StoppingCriteria):
        def __call__(self,input_ids,scores,**kwargs):
            n=input_ids.shape[-1]-len(prompt)
            if guard and n%16==0:guard('cot_decode')
            # Stop before generating a numeric score. Its posterior is read separately.
            tail=tokenizer.decode(input_ids[0,-min(n,20):].tolist(),skip_special_tokens=True)
            return '最终评分' in tail
    if guard:guard('before_cot')
    with torch.inference_mode():generated=model.generate(input_ids=ids,attention_mask=torch.ones_like(ids),generation_config=config,stopping_criteria=StoppingCriteriaList([Stop()]))
    continuation=generated[0,len(prompt):].tolist();text=tokenizer.decode(continuation,skip_special_tokens=True)
    explanation=text.split('最终评分',1)[0].strip();need(len(explanation)>=4,'COT_EMPTY_STOP_NO_FABRICATED_RATIONALE')
    cot_ids=tokenizer.encode(explanation,add_special_tokens=False);need(0<len(cot_ids)<=MAX_COT+16,'COT_TOKEN_BUDGET')
    del generated,ids
    if guard:guard('after_cot')
    return {'cot_ids':cot_ids,'cot_text':explanation,'raw_generated_ids':continuation,'raw_generated_text':text,'generation_tokens':len(continuation),'hit_token_limit':len(continuation)==MAX_COT,'teacher_label_conditioned':teacher}

def score(model,tokenizer,row,cot_ids,device,digits):
    import torch
    tokens=row['tract_input_ids']+cot_ids+tokenizer.encode(SCORE,add_special_tokens=False)
    ids=torch.tensor([tokens],device=device,dtype=torch.long)
    with torch.inference_mode():
        logits=model(input_ids=ids,attention_mask=torch.ones_like(ids),use_cache=False,logits_to_keep=1).logits[:,-1,digits].float()
        p=logits.softmax(-1);need(bool(torch.isfinite(p).all()),'TRACT_NONFINITE_PROBABILITY')
        value=float((p*torch.linspace(0,1,10,device=p.device)).sum())
    return value

def predict(model,tokenizer,row,device,digits,guard=None):
    c=rationale(model,tokenizer,row,device,False,guard);v=score(model,tokenizer,row,c['cot_ids'],device,digits)
    return {k:row[k] for k in ('unit_id','subject','student_group_id','target_fraction')}|{'status':'PASS','prediction_fraction':v,'token_ids_sha256':row['token_ids_sha256'],'tract_input_sha256':row['tract_input_sha256'],**c}

def training_layout(row,tokenizer,digits):
    prompt=row['tract_input_ids'];tail=row['cot_ids']+tokenizer.encode(SCORE,add_special_tokens=False)
    need(prompt and row['cot_ids'] and tail,'EMPTY_TRAIN_SEQUENCE')
    score_position=len(prompt)+len(tail);gold=digits[min(9,max(0,round(row['target_fraction']*9)))]
    ids=prompt+tail+[gold];labels=[-100]*len(prompt)+tail+[-100]
    if tokenizer.eos_token_id is not None:ids.append(tokenizer.eos_token_id);labels.append(tokenizer.eos_token_id)
    positions=[i-1 for i in range(1,len(labels)) if labels[i]!=-100];targets=[labels[i+1] for i in positions]
    needed=sorted(set(positions+[score_position-1]));slots=[needed.index(i) for i in positions]
    need(len(ids)<=32768+1024,'TRACT_TRAIN_BUDGET')
    return ids,needed,slots,targets,needed.index(score_position-1)

def loss(network,tokenizer,row,device,digits):
    import torch
    import torch.nn.functional as F
    ids,positions,slots,targets,score_slot=training_layout(row,tokenizer,digits)
    x=torch.tensor([ids],device=device,dtype=torch.long)
    outputs=network(input_ids=x,attention_mask=torch.ones_like(x),use_cache=False,logits_to_keep=torch.tensor(positions,device=device))
    z=outputs.logits;need(z.shape[1]==len(positions),'SPARSE_LOGIT_SHAPE')
    ce=F.cross_entropy(z[0,slots,:].float(),torch.tensor(targets,device=device))
    p=z[:,score_slot,digits].float().softmax(-1)
    mse=method_loss(p,torch.tensor([row['target_fraction']],device=device))
    return ce+mse
