"""Resume only after verified completed base evaluation + single-GPU training probe."""
import json, math, time, shutil, hashlib
from pathlib import Path
SOURCE = 'outputs/C\u72ec\u7acb\u6570\u503c\u57fa\u7ebf_NTL\u5206\u8bcd\u517c\u5bb9\u4fee\u590d_20261014_v2'
PINS = {'preflight.json': '92758cc38cee7d64b3daa6f2b6e3ee432e3f6f41ce97f136a5f13366477d9ada', 'unfinetuned_numeric/summary.json': 'b38a40a6fbdb6550f8dbe67460c37d25df0ce1dd0b783f71a3b1c500496199f3', 'unfinetuned_numeric/predictions.json': '60273aad8efe99671fd3225bae65eec5d1fd444f08dd25422ce2256b4d5743da', 'train_probe_width1/summary.json': 'd277c873426dd42487a9bdf307e4e442f25c4255358f97ab527ea51f3d56609e', 'train_probe_width1/assignment.json': '5b05fe77c18833b6e6899bc5ca3c814d30b41fb22e2b9622fc3a23e05e919286', 'train_probe_width1/exit.json': '041dff8cee4c14767a03435eb9f84a05152b2dc00e322d74a702b6f6944a4bdf', 'exit.json': '56296949d3a02e635b050fd6b4762f0f0b52c23d05b925203095f7daf8e19027'}

def ready_pair(first, second, selected, minimum):
    """Exact original UUID and physical index; never select a different idle card."""
    for g in selected:
        for snapshot in (first, second):
            matches = [r for r in snapshot if r['uuid'] == g['uuid'] and r['index'] == g['index']]
            if len(matches) != 1:
                return False
            r = matches[0]
            if not all((math.isfinite(r[k]) for k in ('free_GiB', 'util'))):
                return False
            if r['free_GiB'] < minimum or r['util'] > 5:
                return False
    return True

def wait_selected(e, selected, minimum, logfile, timeout=120, clock=time.monotonic, sleep=time.sleep):
    start = clock()
    previous = None
    while True:
        snapshot = e.table()
        elapsed = clock() - start
        good = previous is not None and ready_pair(previous, snapshot, selected, minimum)
        e.log(logfile, {'event': 'selected_gpu_recheck', 'elapsed_seconds': elapsed, 'ready': good, 'minimum_start_free_GiB': minimum, 'selected': selected, 'snapshot': snapshot, 'time': time.time()})
        if good:
            return selected
        e.need(elapsed < timeout, 'SELECTED_GPU_BUSY_TIMEOUT_RESULTS_RETAINED')
        previous = snapshot
        sleep(min(3, max(0, timeout - elapsed)))

def verify_source(e, root):
    src = root / SOURCE
    for n, h in PINS.items():
        e.need(e.sha(src / n) == h, 'RESUME_SOURCE_HASH:' + n)
    e.need(not (src / 'ntl_training').exists(), 'SOURCE_FORMAL_TRAINING_ALREADY_EXISTS')
    pre = e.read(src / 'preflight.json')
    for n, h in pre['files'].items():
        e.need(e.sha(src / n) == h, 'TOKEN_SOURCE_HASH:' + n)
    rr = e.read(src / 'unfinetuned_numeric/predictions.json')
    by = {r['unit_id']: r for r in e.rows(src / 'official_tokens.jsonl')}
    e.need(len(rr) == len(by) == 148 and len({r['unit_id'] for r in rr}) == 148, 'BASE148_MEMBERSHIP')
    for r in rr:
        e.need(r['unit_id'] in by, 'UNKNOWN_BASE_ID')
        e.validate_result(r, by[r['unit_id']])
    e.need(sum((r['subject'].startswith('01_') for r in rr)) == 85, 'BASE_CS85')
    calculated = e.metrics(rr)
    saved = e.read(src / 'unfinetuned_numeric/summary.json')['metrics']
    e.need(calculated == saved, 'BASE_METRICS_RECOMPUTATION')
    probe = e.read(src / 'train_probe_width1/summary.json')
    e.need(probe['status'] == 'PASS_TRAINING_MEMORY_PROBE' and probe['width'] == 1 and (probe['max_train_tokens'] == 31698) and (probe['full_batch'] == 8) and (probe['tail_batch'] == 5), 'PROBE_COVERAGE')
    return pre

def prepare_resume(e, root):
    e.package()
    pre = verify_source(e, root)
    src = root / SOURCE
    out = root / e.OUT
    oldplan = e.read(root / 'outputs/packages/C_NUMERIC_NTL_TOKENIZER_FIX_20261014_SAFE/plan.json')
    e.need(e.sha(root / 'outputs/packages/C_NUMERIC_NTL_TOKENIZER_FIX_20261014_SAFE/plan.json') == pre['plan_sha256'], 'ORIGINAL_PLAN_HASH')
    newplan = e.read(e.HERE / 'plan.json')
    e.need(all((newplan[k] == v for k, v in oldplan.items() if k != 'version')), 'SCIENTIFIC_PROTOCOL_CHANGED')
    for n in pre['files']:
        e.need(not (out / n).exists(), 'RESUME_OUTPUT_EXISTS')
        shutil.copyfile(src / n, out / n)
        e.need(e.sha(out / n) == pre['files'][n], 'COPY_TOKEN_HASH')
    (out / 'unfinetuned_numeric').mkdir()
    for n in ('summary.json', 'predictions.json'):
        shutil.copyfile(src / 'unfinetuned_numeric' / n, out / 'unfinetuned_numeric' / n)
    for name in ('tokenizer_compatibility.json',):
        if (src / name).exists():
            shutil.copyfile(src / name, out / name)
    bound = dict(pre, plan_sha256=e.sha(e.HERE / 'plan.json'), manifest_sha256=e.sha(e.HERE / 'SHA256SUMS'), reused_from=str(src), source_preflight_sha256=PINS['preflight.json'])
    e.write(out / 'preflight.json', bound)
    e.write(out / 'reuse.json', {'source': str(src), 'pinned_source_files': PINS, 'baseline_reinferred': False, 'probe_retrained': False, 'tokenization_repeated': False, 'probe_optimizer_or_weights_reused': False})
    return e.read(src / 'train_probe_width1/assignment.json')['gpus']

def coordinate_resume(e, root):
    out = root / e.OUT
    try:
        selected = prepare_resume(e, root)
        resources = e.rows(root / SOURCE / 'train_probe_width1/resources.jsonl')
        minimum = max(18.0, max((r['reserved_GiB'] for r in resources)) + 6.0)
        wait_selected(e, selected, minimum, out / 'events.jsonl')
        folder = out / 'ntl_training'
        e.log(out / 'events.jsonl', {'event': 'formal_training_launch_after_reused_probe', 'selected': selected, 'time': time.time()})
        result = e.joined(e.child(root, 'train', selected, folder), folder)
        e.need(result['status'] == 'PASS', 'TRAINING_INCOMPLETE:' + str(result))
        best = e.read(folder / 'selection.json')
        adapter = folder / best['adapter_directory']
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'] and e.sha(adapter / 'adapter_config.json') == best['adapter_config_sha256'], 'SELECTED_ADAPTER_DRIFT')
        e.log(out / 'events.jsonl', {'event': 'candidate_frozen_before_official', 'selection': best, 'time': time.time()})
        e.infer_all(root, 'ntl_C', adapter)
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'], 'ADAPTER_CHANGED_DURING_INFERENCE')
        e.write(out / 'summary.json', {'status': 'COMPLETE', 'method': 'NTL-W independently trained C adaptation', 'unfinetuned_numeric': e.read(out / 'unfinetuned_numeric/summary.json')['metrics'], 'NTL_C': e.read(out / 'ntl_C/summary.json')['metrics'], 'selection': best, 'B247_unchanged': True, 'official_adaptive_use': True, 'new_algorithm_innovation_claimed': False, 'old_structured_C_not_same_input_comparator': True, 'baseline_reused': True})
        e.write(out / 'exit.json', {'exit_code': 0})
    except BaseException:
        import traceback
        traceback.print_exc()
        e.write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'traceback': traceback.format_exc()})
        e.write(out / 'exit.json', {'exit_code': 1})
        raise
