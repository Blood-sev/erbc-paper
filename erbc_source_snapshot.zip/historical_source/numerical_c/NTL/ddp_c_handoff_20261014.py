"""Exact argv + pidfd handoff, only when user invokes launch."""
import os, signal, time
from pathlib import Path
OLD_STAGE = 'outputs/packages/C_NUMERIC_NTL_TRAIN_RESUME_20261014_SAFE'
OLD_OUT = 'outputs/C\u72ec\u7acb\u6570\u503c\u57fa\u7ebf_NTL\u6b63\u5f0f\u8bad\u7ec3\u63a5\u7eed_20261014_v3'

def matches(args, root, kind):
    if kind == 'coordinator':
        suffix = [str(root / OLD_STAGE / 'run.py'), 'coordinate', '--project-root', str(root)]
    else:
        suffix = [str(root / OLD_STAGE / 'run.py'), 'worker', '--project-root', str(root), '--mode', 'train', '--folder', str(root / OLD_OUT / 'ntl_training')]
    return len(args) >= len(suffix) + 1 and args[-len(suffix):] == suffix

def argv(pid):
    return [x.decode() for x in (Path('/proc') / str(pid) / 'cmdline').read_bytes().split(b'\x00') if x]

def alive(pid):
    try:
        return (Path('/proc') / str(pid) / 'stat').read_text().rsplit(')', 1)[1].split()[0] != 'Z'
    except FileNotFoundError:
        return False

def stop_exact(e, root):
    old = root / OLD_OUT
    e.need(not (old / 'summary.json').exists(), 'OLD_ALREADY_COMPLETE_NO_REDUNDANT_RESTART')
    p = e.read(old / 'worker.json')['pid']
    opened = []
    frozen = None
    sent = False
    e.need(hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal'), 'PIDFD_REQUIRED')
    try:
        if alive(p):
            frozen = os.pidfd_open(p)
            e.need(matches(argv(p), root, 'coordinator'), 'COORDINATOR_IDENTITY')
            signal.pidfd_send_signal(frozen, signal.SIGSTOP)
            for _ in range(30):
                if not alive(p) or (Path('/proc') / str(p) / 'stat').read_text().rsplit(')', 1)[1].split()[0] in ('T', 't'):
                    break
                time.sleep(0.1)
            else:
                raise RuntimeError('COORDINATOR_NOT_FROZEN')
            opened.append((p, 'coordinator', frozen))
        children = []
        for f in Path('/proc').iterdir():
            if not f.name.isdigit():
                continue
            try:
                args = argv(int(f.name))
                if matches(args, root, 'train'):
                    fd = os.pidfd_open(int(f.name))
                    e.need(matches(argv(int(f.name)), root, 'train'), 'WORKER_IDENTITY')
                    children.append((int(f.name), 'train', fd))
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                continue
        opened += children
        e.need(len(children) <= 1, 'MULTIPLE_OLD_TRAIN_WORKERS_STOP')
        last = []
        path = old / 'ntl_training/events.jsonl'
        if path.exists():
            last = path.read_text().splitlines()[-1:]
        for pid, role, fd in opened:
            try:
                signal.pidfd_send_signal(fd, signal.SIGTERM)
            except ProcessLookupError:
                pass
        sent = True
        if frozen is not None:
            try:
                signal.pidfd_send_signal(frozen, signal.SIGCONT)
            except ProcessLookupError:
                pass
        end = time.monotonic() + 45
        while any((alive(pid) for pid, _, _ in opened)) and time.monotonic() < end:
            time.sleep(0.5)
        e.need(not any((alive(pid) for pid, _, _ in opened)), 'OLD_TASK_NOT_EXITED_NO_NEW_GPU_JOB')
        return {'stopped': [{'pid': pid, 'role': role} for pid, role, _ in opened], 'last_old_event': last, 'old_output_preserved': True, 'optimizer_state_resumed': False, 'fresh_restart_required': True}
    finally:
        if frozen is not None and (not sent):
            try:
                signal.pidfd_send_signal(frozen, signal.SIGCONT)
            except ProcessLookupError:
                pass
        for _, _, fd in opened:
            os.close(fd)
        if frozen is not None and all((fd != frozen for _, _, fd in opened)):
            os.close(frozen)
