import os, sys, subprocess, time, traceback
from c_numeric_resume_support_20261014 import prepare_resume, verify_source, wait_selected, ready_pair
from ddp_c_handoff_20261014 import stop_exact

def select_before_handoff(e, root):
    snapshots = []
    for i in range(2):
        snapshots.append(e.table())
        if i == 0:
            time.sleep(2)
    selected = []
    for i in (4, 5, 6, 7):
        rr = [r for r in snapshots[-1] if r['index'] == i]
        e.need(len(rr) == 1, 'MISSING_REQUIRED_GPU')
        selected += rr
    other = [g for g in selected if g['index'] != 5]
    e.need(ready_pair(snapshots[0], snapshots[1], other, 33.35), 'OTHER_THREE_GPUS_BUSY_OLD_JOB_LEFT_RUNNING')
    return (selected, snapshots)

def ddp_job(e, root, selected, mode):
    folder = root / e.OUT / ('ddp_smoke' if mode == 'smoke' else 'ntl_training')
    folder.mkdir()
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((g['uuid'] for g in selected)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', FLASH_ATTENTION_DETERMINISTIC='1', TORCH_NCCL_ASYNC_ERROR_HANDLING='1')
    with (folder / 'worker.log').open('x', encoding='utf-8') as f:
        p = subprocess.Popen([sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nnodes=1', '--nproc_per_node=4', '--max_restarts=0', str(e.HERE / 'ddp_c_train_20261014.py'), '--project-root', str(root), '--mode', mode], env=env, stdout=f, stderr=subprocess.STDOUT)
    e.write(folder / 'launcher.json', {'pid': p.pid, 'mode': mode, 'selected': selected})
    code = p.wait()
    e.need(code == 0 and e.read(folder / 'exit.json')['status'] == 'PASS', 'DDP_' + mode.upper() + '_FAILED_RESULTS_RETAINED')

def coordinate(e, root):
    out = root / e.OUT
    try:
        prepare_resume(e, root)
        selected, snap = select_before_handoff(e, root)
        e.write(out / 'before_handoff_gpus.json', snap)
        e.write(out / 'handoff.json', stop_exact(e, root))
        wait_selected(e, selected, 33.35, out / 'events.jsonl')
        e.write(out / 'selected_gpus.json', {'selected': selected, 'world_size': 4, 'effective_batch': 8, 'gradient_accumulation': 2, 'tail_real_count': 5, 'tail_placeholder_weight': 0})
        ddp_job(e, root, selected, 'smoke')
        e.log(out / 'events.jsonl', {'event': 'DDP_SMOKE_PASS_START_FRESH_FORMAL', 'time': time.time()})
        wait_selected(e, selected, 33.35, out / 'events.jsonl')
        ddp_job(e, root, selected, 'train')
        folder = out / 'ntl_training'
        best = e.read(folder / 'selection.json')
        adapter = folder / best['adapter_directory']
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'], 'SELECTED_ADAPTER_HASH')
        e.log(out / 'events.jsonl', {'event': 'candidate_frozen_before_official', 'selection': best, 'time': time.time()})
        e.infer_all(root, 'ntl_C', adapter)
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'], 'ADAPTER_CHANGED')
        e.write(out / 'summary.json', {'status': 'COMPLETE', 'method': 'NTL-W independent numerical C; four-rank DDP', 'unfinetuned_numeric': e.read(out / 'unfinetuned_numeric/summary.json')['metrics'], 'NTL_C': e.read(out / 'ntl_C/summary.json')['metrics'], 'selection': best, 'B247_unchanged': True, 'official_adaptive_use': True, 'baseline_reused': True, 'single_GPU_trajectory_equivalence_claimed': False, 'new_algorithm_innovation_claimed': False, 'old_structured_C_not_same_input_comparator': True})
        e.write(out / 'exit.json', {'exit_code': 0})
    except BaseException:
        traceback.print_exc()
        e.write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'traceback': traceback.format_exc()})
        e.write(out / 'exit.json', {'exit_code': 1})
        raise
