"""Read-only proof that the previous TRACT attempt stopped BEFORE GPU work."""
from pathlib import Path
SOURCE = 'outputs/C\u72ec\u7acb\u6570\u503c\u57fa\u7ebf_TRACT\u4e24\u9636\u6bb5\u56db\u5361DDP_20261014_v1'
STAGE = 'outputs/packages/C_NUMERIC_TRACT_DDP4_20261014_SAFE'
MANIFEST = 'de93ff85011d59d16f891fc3dd571955c065ffa67d5387794dfceb6064d1fb2a'
PINNED = {'exit.json': '56296949d3a02e635b050fd6b4762f0f0b52c23d05b925203095f7daf8e19027', 'failure.json': 'f169fc5d62e835d8710e83b7e7c99a40228a4d0afc6348b8b00ae0557bdaf1b2', 'preflight.json': '35a300aa9a7754b7564c31f882498cf562566f54de8bf1411a7853f3cb35ceec', 'worker.json': '3bc930349409440cddfd1e8cb80183ed8b9de0a454e9e3c114813a4ab170738e'}
ALLOWED = {'development_tokens.jsonl', 'events.jsonl', 'exit.json', 'failure.json', 'official_tokens.jsonl', 'preflight.json', 'reuse.json', 'train_tokens.jsonl', 'unfinetuned_numeric', 'worker.json', 'worker.log'}
PINNED['tract_inputs.json'] = '7475eeddbb94f5cbab36bd7cd09c074b2944fe9e3b94dd78f8c65d79ab43871a'
ALLOWED.update({'tract_inputs.json', 'train_tract_inputs.json', 'development_tract_inputs.json', 'official_tract_inputs.json'})

def assert_not_running(e, root, record, proc_root=Path('/proc')):
    pid = record['pid']
    e.need(type(pid) == int and pid > 1, 'BAD_PRIOR_PID')
    p = proc_root / str(pid)
    try:
        raw = (p / 'cmdline').read_bytes()
    except FileNotFoundError:
        return
    args = [x.decode('utf-8', 'strict') for x in raw.split(b'\x00') if x]
    same = str(root / STAGE / 'run.py') in args and 'coordinate' in args
    e.need(not same, 'PRIOR_TRACT_COORDINATOR_STILL_PRESENT_NO_DUPLICATE')

def verify_failed(e, root, check_process=False):
    src = root / SOURCE
    stage = root / STAGE
    e.need(e.sha(stage / 'SHA256SUMS') == MANIFEST, 'PRIOR_MANIFEST_DRIFT')
    for line in (stage / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        e.need(Path(n).name == n and e.sha(stage / n) == h, 'PRIOR_PACKAGE_DRIFT')
    for n, h in PINNED.items():
        e.need(e.sha(src / n) == h, 'PRIOR_FAILURE_PROOF_DRIFT:' + n)
    e.need({f.name for f in src.iterdir()} == ALLOWED, 'PRIOR_GPU_OR_UNKNOWN_OUTPUT_EXISTS')
    e.need(e.read(src / 'exit.json') == {'exit_code': 1}, 'PRIOR_NOT_TERMINAL_FAILURE')
    f = e.read(src / 'failure.json')
    e.need(f['traceback'].rstrip().endswith('RuntimeError: SELECTED_GPU_BUSY_TIMEOUT_RESULTS_RETAINED'), 'PRIOR_FAILURE_NOT_RESOURCE_GATE')
    pre = e.read(src / 'preflight.json')
    old = e.read(stage / 'plan.json')
    plan = e.read(e.HERE / 'plan.json')
    from gpu_advisory_20261015 import validate_plan_policy
    validate_plan_policy(plan)
    e.need(pre['manifest_sha256'] == MANIFEST and pre['plan_sha256'] == e.sha(stage / 'plan.json'), 'PRIOR_PREFLIGHT_BINDING')
    e.need({k: v for k, v in old.items() if k != 'version'} == {k: v for k, v in plan.items() if k not in ('version', 'resource_retry', 'utilization_policy')}, 'SCIENTIFIC_PROTOCOL_CHANGED')
    for n, h in pre['files'].items():
        e.need(e.sha(src / n) == h, 'PRIOR_TOKEN_CACHE_DRIFT')
    m = e.read(src / 'tract_inputs.json')
    e.need(m['plan_sha256'] == e.sha(stage / 'plan.json'), 'OLD_METHOD_PLAN')
    for n, h in m['artifacts'].items():
        e.need(Path(n).name == n and e.sha(src / n) == h, 'OLD_METHOD_TOKEN_CACHE')
    if check_process:
        assert_not_running(e, root, e.read(src / 'worker.json'))
    return {'source': SOURCE, 'failure_pins': PINNED, 'prior_GPU_work_started': False, 'prior_output_modified': False, 'process_checked_on_this_host': check_process}

def reuse_method_inputs(e, root):
    import shutil
    src = root / SOURCE
    out = root / e.OUT
    m = e.read(src / 'tract_inputs.json')
    for n, h in m['artifacts'].items():
        e.need(not (out / n).exists(), 'NEW_METHOD_INPUT_EXISTS')
        shutil.copyfile(src / n, out / n)
        e.need(e.sha(out / n) == h, 'METHOD_COPY_HASH')
    e.write(out / 'tract_inputs.json', dict(m, plan_sha256=e.sha(e.HERE / 'plan.json'), reused_from=str(src), source_manifest_sha256=PINNED['tract_inputs.json']))
