"""Independent 0-3 job: never stops, resumes or touches the 4-7 NTL job."""
import os, sys, subprocess, time, traceback, shutil
from c_numeric_resume_support_20261014 import verify_source, SOURCE, PINS, ready_pair, wait_selected
REFERENCE = 'outputs/packages/C_NUMERIC_NTL_DDP4_20261014_SAFE'
SCOPE = (4, 5, 6, 7)
MIN_START = 33.35
CHANGED_KEYS = {'version', 'loss', 'method_role', 'zero_shot_comparator', 'GPU_scope', 'training_execution'}

def verify_protocol(e, root):
    e.package()
    plan = e.read(e.HERE / 'plan.json')
    ref = root / REFERENCE / 'plan.json'
    e.need(e.sha(ref) == plan['matched_NTL_plan_sha256'], 'MATCHED_NTL_PLAN_DRIFT')
    reference = e.read(ref)
    for k, v in reference.items():
        if k not in CHANGED_KEYS:
            e.need(plan.get(k) == v, 'COMMON_PROTOCOL_DRIFT:' + k)
    for k, v in reference['training_execution'].items():
        if k != 'physical_gpus':
            e.need(plan['training_execution'].get(k) == v, 'TRAINING_EXECUTION_DRIFT:' + k)
    e.need(plan['GPU_scope'] == list(SCOPE) and plan['training_execution']['physical_gpus'] == list(SCOPE), 'GPU_SCOPE')
    e.need(plan['loss'] == {'rationale_CE': 1.0, 'posterior_mean_MSE': 1.0} and plan['stages'] == [{'epochs': 2, 'steps': 232}, {'epochs': 2, 'steps': 232}], 'TRACT_PLAN')
    pre = verify_source(e, root)
    e.need(e.sha(root / e.DATA / 'summary.json') == plan['common_data_summary_sha256'] == pre['source_summary_sha256'], 'COMMON_DATA_DRIFT')
    historical = root / plan['historical_method_source']['path']
    e.need(e.sha(historical) == plan['historical_method_source']['sha256'], 'HISTORICAL_METHOD_DRIFT')
    return pre

def prepare(e, root):
    pre = verify_protocol(e, root)
    out = root / e.OUT
    src = root / SOURCE
    plan = e.read(e.HERE / 'plan.json')
    for n, v in plan['base_identity']['files'].items():
        f = root / e.MODEL / n
        e.need(f.stat().st_size == v['bytes'] and e.sha(f) == v['sha256'], 'BASE_IDENTITY:' + n)
    for n, h in pre['files'].items():
        e.need(not (out / n).exists(), 'OUTPUT_TOKEN_EXISTS')
        shutil.copyfile(src / n, out / n)
        e.need(e.sha(out / n) == h, 'TOKEN_COPY_DRIFT')
    (out / 'unfinetuned_numeric').mkdir()
    for n in ('summary.json', 'predictions.json'):
        shutil.copyfile(src / 'unfinetuned_numeric' / n, out / 'unfinetuned_numeric' / n)
    e.write(out / 'preflight.json', dict(pre, plan_sha256=e.sha(e.HERE / 'plan.json'), manifest_sha256=e.sha(e.HERE / 'SHA256SUMS'), reused_from=str(src), source_preflight_sha256=PINS['preflight.json']))
    e.write(out / 'reuse.json', {'source': str(src), 'pinned_source_files': PINS, 'tokenization_repeated': False, 'baseline_reinferred': False, 'weights_or_optimizer_reused': False, 'reference_readout': 'Unfinetuned ten-digit LM expectation; identical bounded input and readout', 'new_TRACT_GPU_smoke_required': True})
    e.log(out / 'events.jsonl', {'event': 'CPU_CACHE_AND_PROTOCOL_VERIFIED', 'time': time.time()})

def select(e, out):
    snapshot = e.table()
    selected = [next((g for g in snapshot if g['index'] == i), None) for i in SCOPE]
    e.need(all(selected), 'REQUIRED_GPU_4_TO7_MISSING')
    wait_selected(e, selected, MIN_START, out / 'events.jsonl')
    latest = e.rows(out / 'events.jsonl')[-1]['snapshot']
    return [next((g for g in latest if g['uuid'] == s['uuid'] and g['index'] == s['index'])) for s in selected]
