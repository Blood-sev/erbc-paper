"""C-task adaptation of TRACT: explanation CE plus score-expectation MSE.

All common evidence is preserved. Only the method instruction changes. Gold C is
available to the training teacher, NEVER to self-CoT, development or official prompts.
"""
import copy, math
from core import need, digest, rows, read, write, sha, extract_ids, SYSTEM
from raft_c_method_20261014 import method_loss
SCORE = '\n\u6700\u7ec8\u8bc4\u5206\uff1a'
MAX_COT = 160
INSTRUCTION = '\u4f60\u8bc4\u4f30\u5b66\u751f\u5728AI\u8f85\u52a9\u4f5c\u4e1a\u4e2d\u7684KSA\u8ba4\u77e5\u5916\u5305\u7387\uff0c\u4e0d\u662f\u64cd\u4f5c\u51cf\u8d1f\u7387\u3002\u6839\u636e\u51bb\u7ed3\u77e5\u8bc6\u84dd\u56fe\u3001\u64cd\u4f5c\u53ca\u6240\u5217\u8bc1\u636e\uff0c\u4f30\u8ba1\u7ec6\u7c92\u5ea6\u77e5\u8bc6/\u6280\u80fd/\u884c\u52a8\u4e2dAI\u627f\u62c5\u6bd4\u4f8b\u7684\u5747\u503c\u3002\u8bc1\u636e\u4e3a\u957f\u5ea6\u53d7\u63a7\u6458\u5f55\uff0c\u7f3a\u5931\u5185\u5bb9\u4e0d\u80fd\u89c6\u4e3a\u4e0d\u5b58\u5728\uff1b\u64cd\u4f5c\u6bd4\u4f8b\u4e0d\u80fd\u76f4\u63a5\u5f53KSA\u6bd4\u4f8b\u3002\u5148\u75282\u81f34\u53e5\u4e2d\u6587\u7b80\u8ff0\u8bc1\u636e\u652f\u6301\u7684\u8ba4\u77e5\u8d23\u4efb\u5f52\u5c5e\uff0c\u8bf4\u660eAI\u627f\u62c5\u548c\u5b66\u751f\u4fdd\u7559\u7684\u90e8\u5206\uff0c\u4e0d\u7f16\u9020\u8bc1\u636e\uff1b\u7136\u540e\u6362\u884c\u5199\u201c\u6700\u7ec8\u8bc4\u5206\uff1a\u201d\u53ca\u5355\u4e2a\u6570\u5b57\u69fd0\u81f39\uff0c0\u8868\u793a0%\uff0c9\u8868\u793a100%\u3002'

def messages(source, teacher_target=None):
    need(len(source) == 2 and source[0]['role'] == 'system' and (source[0]['content'] == SYSTEM) and (source[1]['role'] == 'user'), 'COMMON_MESSAGES_DRIFT')
    out = copy.deepcopy(source)
    out[0]['content'] = INSTRUCTION
    if teacher_target is not None:
        need(type(teacher_target) in (int, float) and math.isfinite(teacher_target) and (0 <= teacher_target <= 1), 'TEACHER_TARGET')
        out[0]['content'] += '\n\u4ec5\u4f9b\u8bad\u7ec3\u89e3\u91ca\u6807\u6ce8\uff1a\u5df2\u77e5\u8ba4\u77e5\u5916\u5305\u7387\u6807\u7b7e\u4e3a' + format(100 * teacher_target, '.12g') + '%\u3002\u6839\u636e\u8bc1\u636e\u7ed9\u51fa\u652f\u6301\u6216\u9650\u5236\u8be5\u6807\u6ce8\u7684\u7b80\u77ed\u89e3\u91ca\uff0c\u4e0d\u590d\u8ff0\u6807\u7b7e\u6570\u503c\u3002'
    need(out[1] == source[1], 'EVIDENCE_CHANGED')
    return out

def prepare(e, root):
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(root / e.MODEL, local_files_only=True)
    out = root / e.OUT
    pre = e.read(out / 'preflight.json')
    artifacts = {}
    lengths = {}
    for part in ('train', 'development', 'official'):
        originals = {x['unit_id']: x for x in rows(root / e.DATA / (part + '.jsonl'))}
        result = []
        for row in rows(out / (part + '_tokens.jsonl')):
            if row['status'] != 'READY':
                continue
            matches = [v['messages'] for v in originals[row['unit_id']]['variants'] if digest(v['messages']) == row['input_audit']['messages_sha256']]
            need(matches and all((x == matches[0] for x in matches)), 'TRACT_COMMON_VARIANT')
            source = matches[0]
            common = extract_ids(tokenizer.apply_chat_template(source, tokenize=True, add_generation_prompt=True, return_dict=False))
            need(common == row['input_ids'], 'TRACT_BASE_INPUT_CHANGED')
            ids = extract_ids(tokenizer.apply_chat_template(messages(source), tokenize=True, add_generation_prompt=True, return_dict=False))
            x = {'unit_id': row['unit_id'], 'common_token_ids_sha256': row['token_ids_sha256'], 'tract_input_ids': ids, 'tract_input_sha256': digest(ids), 'evidence_sha256': digest(source[1])}
            if part == 'train':
                x['teacher_input_ids'] = extract_ids(tokenizer.apply_chat_template(messages(source, row['target_fraction']), tokenize=True, add_generation_prompt=True, return_dict=False))
                x['teacher_input_sha256'] = digest(x['teacher_input_ids'])
            need(len(ids) <= 32768 + 512 and len(x.get('teacher_input_ids', ids)) <= 32768 + 512, 'TRACT_METHOD_PROMPT_BUDGET')
            result.append(x)
        f = out / (part + '_tract_inputs.json')
        write(f, result)
        artifacts[f.name] = sha(f)
        lengths[part] = {'records': len(result), 'maximum_input': max((len(x['tract_input_ids']) for x in result)), 'maximum_teacher_input': max((len(x.get('teacher_input_ids', [])) for x in result))}
    write(out / 'tract_inputs.json', {'artifacts': artifacts, 'lengths': lengths, 'method_instruction_changed': True, 'common_evidence_identical': True, 'teacher_gold_only_training': True, 'plan_sha256': sha(e.HERE / 'plan.json')})

def get_rows(e, root, part):
    out = root / e.OUT
    m = read(out / 'tract_inputs.json')
    need(m['plan_sha256'] == sha(e.HERE / 'plan.json'), 'TRACT_PLAN_BINDING')
    f = out / (part + '_tract_inputs.json')
    need(sha(f) == m['artifacts'][f.name], 'TRACT_INPUT_HASH')
    extra = {x['unit_id']: x for x in read(f)}
    rr = rows(out / (part + '_tokens.jsonl'))
    for r in rr:
        if r['status'] == 'READY':
            a = extra.pop(r['unit_id'])
            need(a['common_token_ids_sha256'] == r['token_ids_sha256'] and digest(a['tract_input_ids']) == a['tract_input_sha256'], 'TRACT_INPUT_IDENTITY')
            if part != 'train':
                need('teacher_input_ids' not in a, 'LABEL_IN_EVALUATION_PROMPT')
            else:
                need(digest(a['teacher_input_ids']) == a['teacher_input_sha256'], 'TEACHER_INPUT_HASH')
            r.update(a)
    need(not extra, 'EXTRA_TRACT_ID')
    return rr

def annotation(e, root, kind, rr):
    folder = root / e.OUT / (kind + '_cots')
    m = read(folder / 'summary.json')
    f = folder / 'cots.json'
    need(m['sha256'] == sha(f) and m['plan_sha256'] == sha(e.HERE / 'plan.json'), 'COT_BINDING')
    cc = {r['unit_id']: r for r in read(f)}
    need(len(cc) == len(rr) == 925, 'COT_COVERAGE')
    for row in rr:
        c = cc.pop(row['unit_id'])
        need(all((c[k] == row[k] for k in ('target_fraction', 'subject', 'student_group_id'))) and c['token_ids_sha256'] == row['token_ids_sha256'] and (c['tract_input_sha256'] == row['tract_input_sha256']), 'COT_IDENTITY')
        need(c['kind'] == kind and len(c['cot_ids']) > 0, 'COT_KIND_OR_EMPTY')
        row['cot_ids'] = c['cot_ids']
    need(not cc, 'COT_EXTRA')
    return rr

def rationale(model, tokenizer, row, device, teacher=False, guard=None):
    import torch
    from transformers import StoppingCriteria, StoppingCriteriaList
    prompt = row['teacher_input_ids'] if teacher else row['tract_input_ids']
    ids = torch.tensor([prompt], device=device, dtype=torch.long)
    config = copy.deepcopy(model.generation_config)
    config.do_sample = False
    config.num_beams = 1
    config.max_new_tokens = MAX_COT
    config.temperature = 1.0
    config.top_p = 1.0
    config.top_k = 0
    config.pad_token_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    config.use_cache = True

    class Stop(StoppingCriteria):

        def __call__(self, input_ids, scores, **kwargs):
            n = input_ids.shape[-1] - len(prompt)
            if guard and n % 16 == 0:
                guard('cot_decode')
            tail = tokenizer.decode(input_ids[0, -min(n, 20):].tolist(), skip_special_tokens=True)
            return '\u6700\u7ec8\u8bc4\u5206' in tail
    if guard:
        guard('before_cot')
    with torch.inference_mode():
        generated = model.generate(input_ids=ids, attention_mask=torch.ones_like(ids), generation_config=config, stopping_criteria=StoppingCriteriaList([Stop()]))
    continuation = generated[0, len(prompt):].tolist()
    text = tokenizer.decode(continuation, skip_special_tokens=True)
    explanation = text.split('\u6700\u7ec8\u8bc4\u5206', 1)[0].strip()
    need(len(explanation) >= 4, 'COT_EMPTY_STOP_NO_FABRICATED_RATIONALE')
    cot_ids = tokenizer.encode(explanation, add_special_tokens=False)
    need(0 < len(cot_ids) <= MAX_COT + 16, 'COT_TOKEN_BUDGET')
    del generated, ids
    if guard:
        guard('after_cot')
    return {'cot_ids': cot_ids, 'cot_text': explanation, 'raw_generated_ids': continuation, 'raw_generated_text': text, 'generation_tokens': len(continuation), 'hit_token_limit': len(continuation) == MAX_COT, 'teacher_label_conditioned': teacher}

def score(model, tokenizer, row, cot_ids, device, digits):
    import torch
    tokens = row['tract_input_ids'] + cot_ids + tokenizer.encode(SCORE, add_special_tokens=False)
    ids = torch.tensor([tokens], device=device, dtype=torch.long)
    with torch.inference_mode():
        logits = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1).logits[:, -1, digits].float()
        p = logits.softmax(-1)
        need(bool(torch.isfinite(p).all()), 'TRACT_NONFINITE_PROBABILITY')
        value = float((p * torch.linspace(0, 1, 10, device=p.device)).sum())
    return value

def predict(model, tokenizer, row, device, digits, guard=None):
    c = rationale(model, tokenizer, row, device, False, guard)
    v = score(model, tokenizer, row, c['cot_ids'], device, digits)
    return {k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction')} | {'status': 'PASS', 'prediction_fraction': v, 'token_ids_sha256': row['token_ids_sha256'], 'tract_input_sha256': row['tract_input_sha256'], **c}

def training_layout(row, tokenizer, digits):
    prompt = row['tract_input_ids']
    tail = row['cot_ids'] + tokenizer.encode(SCORE, add_special_tokens=False)
    need(prompt and row['cot_ids'] and tail, 'EMPTY_TRAIN_SEQUENCE')
    score_position = len(prompt) + len(tail)
    gold = digits[min(9, max(0, round(row['target_fraction'] * 9)))]
    ids = prompt + tail + [gold]
    labels = [-100] * len(prompt) + tail + [-100]
    if tokenizer.eos_token_id is not None:
        ids.append(tokenizer.eos_token_id)
        labels.append(tokenizer.eos_token_id)
    positions = [i - 1 for i in range(1, len(labels)) if labels[i] != -100]
    targets = [labels[i + 1] for i in positions]
    needed = sorted(set(positions + [score_position - 1]))
    slots = [needed.index(i) for i in positions]
    need(len(ids) <= 32768 + 1024, 'TRACT_TRAIN_BUDGET')
    return (ids, needed, slots, targets, needed.index(score_position - 1))

def loss(network, tokenizer, row, device, digits):
    import torch
    import torch.nn.functional as F
    ids, positions, slots, targets, score_slot = training_layout(row, tokenizer, digits)
    x = torch.tensor([ids], device=device, dtype=torch.long)
    outputs = network(input_ids=x, attention_mask=torch.ones_like(x), use_cache=False, logits_to_keep=torch.tensor(positions, device=device))
    z = outputs.logits
    need(z.shape[1] == len(positions), 'SPARSE_LOGIT_SHAPE')
    ce = F.cross_entropy(z[0, slots, :].float(), torch.tensor(targets, device=device))
    p = z[:, score_slot, digits].float().softmax(-1)
    mse = method_loss(p, torch.tensor([row['target_fraction']], device=device))
    return ce + mse
