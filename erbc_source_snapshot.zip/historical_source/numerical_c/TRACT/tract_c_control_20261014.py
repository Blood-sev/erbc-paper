"""Independent TRACT-C on physical4-7: teacher -> train1 -> self -> fresh train2."""
import os, sys, subprocess, time, traceback
import method_control as shared
from c_numeric_resume_support_20261014 import wait_selected
import tract_c_method_20261014 as tract
SCOPE = (4, 5, 6, 7)

def cots(e, root, kind, adapter=None):
    out = root / e.OUT
    dest = out / (kind + '_cots')
    dest.mkdir()
    rr = tract.get_rows(e, root, 'train')
    by = {r['unit_id']: r for r in rr}
    completed = {}
    pending = list(by)
    need = e.need
    for width in (1, 2, 4):
        if not pending:
            break
        eligible, snapshot = e.available(width)
        e.write(dest / f'snapshot_width{width}.json', snapshot)
        groups = [eligible[i:i + width] for i in range(0, len(eligible) - width + 1, width)]
        queues = [[] for g in groups]
        loads = [0] * len(groups)
        for u in sorted(pending, key=lambda u: (-len(by[u]['tract_input_ids']), u)):
            j = min(range(len(groups)), key=lambda i: (loads[i], i))
            queues[j].append(u)
            loads[j] += len(by[u]['tract_input_ids'])
        children = []
        for j, (g, q) in enumerate(zip(groups, queues)):
            if not q:
                continue
            shortest = min(q, key=lambda u: (len(by[u]['tract_input_ids']), u))
            q.remove(shortest)
            q.insert(0, shortest)
            qf = dest / f'queue_width{width}_{j}.json'
            e.write(qf, q)
            folder = dest / f'width{width}_worker{j}'
            args = ['--queue', str(qf), '--kind', kind] + (['--adapter', str(adapter)] if adapter else [])
            children.append((e.child(root, 'cot', g, folder, args), folder))
        results = [(e.joined(p, f), f) for p, f in children]
        for status, f in results:
            if (f / 'predictions.jsonl').exists():
                for r in e.rows(f / 'predictions.jsonl'):
                    need(r['unit_id'] in by and r['unit_id'] not in completed, 'COT_DUPLICATE_OR_UNKNOWN')
                    row = by[r['unit_id']]
                    need(all((r[k] == row[k] for k in ('subject', 'student_group_id', 'target_fraction', 'token_ids_sha256', 'tract_input_sha256'))), 'COT_IDENTITY')
                    need(r['kind'] == kind and r['teacher_label_conditioned'] == (kind == 'teacher') and r['cot_ids'], 'COT_ROLE')
                    completed[r['unit_id']] = r
            need(status['status'] in ('PASS', 'OOM'), 'COT_EXECUTION_ERROR_RESULTS_RETAINED')
        pending = [u for u in pending if u not in completed]
    need(not pending and set(completed) == set(by) and (len(completed) == 925), 'COT_INCOMPLETE_STOP_NO_DROPS')
    e.write(dest / 'cots.json', [completed[r['unit_id']] for r in rr])
    e.write(dest / 'summary.json', {'records': 925, 'kind': kind, 'sha256': e.sha(dest / 'cots.json'), 'plan_sha256': e.sha(e.HERE / 'plan.json'), 'adapter_sha256': e.sha(adapter / 'adapter_model.safetensors') if adapter else None, 'generated_scores_used_as_labels': False, 'official_accessed': False, 'hit_token_limit_count': sum((r['hit_token_limit'] for r in completed.values())), 'max_cot_tokens': max((len(r['cot_ids']) for r in completed.values()))})

def job(e, root, selected, stage, mode):
    folder = root / e.OUT / (f'ddp_smoke_stage{stage}' if mode == 'smoke' else f'tract_stage{stage}')
    folder.mkdir()
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((g['uuid'] for g in selected)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', FLASH_ATTENTION_DETERMINISTIC='1', TORCH_NCCL_ASYNC_ERROR_HANDLING='1', TRACT_STAGE=str(stage))
    with (folder / 'worker.log').open('x', encoding='utf-8') as f:
        p = subprocess.Popen([sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nnodes=1', '--nproc_per_node=4', '--max_restarts=0', str(e.HERE / 'ddp_c_train_20261014.py'), '--project-root', str(root), '--mode', mode], env=env, stdout=f, stderr=subprocess.STDOUT)
    e.write(folder / 'launcher.json', {'pid': p.pid, 'selected': selected, 'mode': mode, 'stage': stage})
    code = p.wait()
    e.need(code == 0 and e.read(folder / 'exit.json')['status'] == 'PASS', 'TRACT_STAGE_FAILED_RESULTS_RETAINED')

def coordinate(e, root):
    out = root / e.OUT
    try:
        from tract_resource_retry_20261015 import verify_failed, reuse_method_inputs
        proof = verify_failed(e, root, check_process=True)
        e.write(out / 'resource_retry_proof.json', proof)
        shared.prepare(e, root)
        reuse_method_inputs(e, root)
        selected = shared.select(e, out)
        e.write(out / 'selected_gpus.json', {'selected': selected, 'world_size': 4, 'effective_batch': 8, 'gradient_accumulation': 2, 'tail_real_count': 5, 'tail_placeholder_weight': 0})
        e.log(out / 'events.jsonl', {'event': 'training_teacher_cots_start', 'records': 925, 'time': time.time()})
        cots(e, root, 'teacher')
        for stage in (1, 2):
            if stage == 2:
                first = out / 'tract_stage1/epoch2'
                s = e.read(out / 'tract_stage1/summary.json')
                endpoint = s['epochs'][1]
                e.need(e.sha(first / 'adapter_model.safetensors') == endpoint['adapter_sha256'] and e.sha(first / 'adapter_config.json') == endpoint['adapter_config_sha256'], 'TEACHER_ADAPTER_DRIFT')
                wait_selected(e, selected, shared.MIN_START, out / 'events.jsonl')
                e.log(out / 'events.jsonl', {'event': 'self_cots_from_stage1_epoch2', 'time': time.time()})
                cots(e, root, 'self', first)
            wait_selected(e, selected, shared.MIN_START, out / 'events.jsonl')
            job(e, root, selected, stage, 'smoke')
            wait_selected(e, selected, shared.MIN_START, out / 'events.jsonl')
            job(e, root, selected, stage, 'train')
        s1 = e.read(out / 'tract_stage1/summary.json')
        s2 = e.read(out / 'tract_stage2/summary.json')
        e.need(s1['steps'] == s2['steps'] == 232 and s1['initial_parameter_sha256'] == s2['initial_parameter_sha256'], 'TRACT_FRESH_RESET_OR_BUDGET')
        best = e.read(out / 'tract_stage2/selection.json')
        adapter = out / 'tract_stage2' / best['adapter_directory']
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'] and e.sha(adapter / 'adapter_config.json') == best['adapter_config_sha256'], 'SELECTED_ADAPTER_DRIFT')
        e.log(out / 'events.jsonl', {'event': 'candidate_frozen_before_official', 'selection': best, 'time': time.time()})
        wait_selected(e, selected, shared.MIN_START, out / 'events.jsonl')
        e.infer_all(root, 'tract_C', adapter)
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'] and e.sha(adapter / 'adapter_config.json') == best['adapter_config_sha256'], 'ADAPTER_CHANGED_DURING_OFFICIAL')
        e.write(out / 'summary.json', {'status': 'COMPLETE', 'method': 'TRACT-C two-stage local-teacher task adaptation; CE rationale + posterior mean MSE', 'TRACT_C': e.read(out / 'tract_C/summary.json')['metrics'], 'unfinetuned_numeric': e.read(out / 'unfinetuned_numeric/summary.json')['metrics'], 'selection': best, 'steps': 464, 'stage_steps': [232, 232], 'stage2_fresh_base_verified': True, 'explanation_generation_extra_cost': True, 'common_evidence_and_labels_unchanged': True, 'method_instruction_differs_from_direct_numeric_reference': True, 'B247_unchanged': True, 'official_adaptive_use': True, 'new_algorithm_innovation_claimed': False, 'baseline_reused': True})
        e.write(out / 'exit.json', {'exit_code': 0})
    except BaseException:
        traceback.print_exc()
        e.write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'traceback': traceback.format_exc()})
        e.write(out / 'exit.json', {'exit_code': 1})
        raise
