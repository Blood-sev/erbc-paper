"""Independent 0-3 job: never stops, resumes or touches the 4-7 NTL job."""
import os, sys, subprocess, time, traceback, shutil
from c_numeric_resume_support_20261014 import verify_source, SOURCE, PINS, ready_pair, wait_selected
REFERENCE = 'outputs/packages/C_NUMERIC_NTL_DDP4_20261014_SAFE'
SCOPE = (0, 1, 2, 3)
MIN_START = 33.35
CHANGED_KEYS = {'version', 'loss', 'method_role', 'zero_shot_comparator', 'GPU_scope', 'training_execution'}

def verify_protocol(e, root):
    e.package()
    plan = e.read(e.HERE / 'plan.json')
    ref = root / REFERENCE / 'plan.json'
    e.need(e.sha(ref) == plan['matched_NTL_plan_sha256'], 'MATCHED_NTL_PLAN_DRIFT')
    reference = e.read(ref)
    for k, v in reference.items():
        if k not in CHANGED_KEYS:
            e.need(plan.get(k) == v, 'COMMON_PROTOCOL_DRIFT:' + k)
    for k, v in reference['training_execution'].items():
        if k != 'physical_gpus':
            e.need(plan['training_execution'].get(k) == v, 'TRAINING_EXECUTION_DRIFT:' + k)
    e.need(plan['GPU_scope'] == list(SCOPE) and plan['training_execution']['physical_gpus'] == list(SCOPE), 'GPU_SCOPE')
    e.need(plan['loss'] == {'expected_absolute_distance': 1.0, 'negative_entropy': 0.01, 'distance_power': 1.0}, 'R2CCP_LOSS_PLAN')
    e.need(plan['output_head']['bins'] == 101 and plan['output_head']['trainable_score_head'] is True, 'R2CCP_HEAD_PLAN')
    pre = verify_source(e, root)
    e.need(e.sha(root / e.DATA / 'summary.json') == plan['common_data_summary_sha256'] == pre['source_summary_sha256'], 'COMMON_DATA_DRIFT')
    historical = root / plan['historical_method_source']['path']
    e.need(e.sha(historical) == plan['historical_method_source']['sha256'], 'HISTORICAL_METHOD_DRIFT')
    return pre

def prepare(e, root):
    pre = verify_protocol(e, root)
    out = root / e.OUT
    src = root / SOURCE
    plan = e.read(e.HERE / 'plan.json')
    for n, v in plan['base_identity']['files'].items():
        f = root / e.MODEL / n
        e.need(f.stat().st_size == v['bytes'] and e.sha(f) == v['sha256'], 'BASE_IDENTITY:' + n)
    for n, h in pre['files'].items():
        e.need(not (out / n).exists(), 'OUTPUT_TOKEN_EXISTS')
        shutil.copyfile(src / n, out / n)
        e.need(e.sha(out / n) == h, 'TOKEN_COPY_DRIFT')
    (out / 'unfinetuned_numeric').mkdir()
    for n in ('summary.json', 'predictions.json'):
        shutil.copyfile(src / 'unfinetuned_numeric' / n, out / 'unfinetuned_numeric' / n)
    e.write(out / 'preflight.json', dict(pre, plan_sha256=e.sha(e.HERE / 'plan.json'), manifest_sha256=e.sha(e.HERE / 'SHA256SUMS'), reused_from=str(src), source_preflight_sha256=PINS['preflight.json']))
    e.write(out / 'reuse.json', {'source': str(src), 'pinned_source_files': PINS, 'tokenization_repeated': False, 'baseline_reinferred': False, 'weights_or_optimizer_reused': False, 'reference_readout': 'Unfinetuned ten-digit LM expectation; same inputs, not a pretrained 101-bin head', 'new_R2CCP_GPU_smoke_required': True})
    e.log(out / 'events.jsonl', {'event': 'CPU_CACHE_AND_PROTOCOL_VERIFIED', 'time': time.time()})

def select(e, out):
    snapshot = e.table()
    selected = [next((g for g in snapshot if g['index'] == i), None) for i in SCOPE]
    e.need(all(selected), 'REQUIRED_GPU_0_TO3_MISSING')
    wait_selected(e, selected, MIN_START, out / 'events.jsonl')
    latest = e.rows(out / 'events.jsonl')[-1]['snapshot']
    return [next((g for g in latest if g['uuid'] == s['uuid'] and g['index'] == s['index'])) for s in selected]

def ddp_job(e, root, selected, mode):
    folder = root / e.OUT / ('ddp_smoke' if mode == 'smoke' else 'r2ccp_training')
    folder.mkdir()
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((g['uuid'] for g in selected)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', FLASH_ATTENTION_DETERMINISTIC='1', TORCH_NCCL_ASYNC_ERROR_HANDLING='1')
    with (folder / 'worker.log').open('x', encoding='utf-8') as f:
        p = subprocess.Popen([sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nnodes=1', '--nproc_per_node=4', '--max_restarts=0', str(e.HERE / 'ddp_c_train_20261014.py'), '--project-root', str(root), '--mode', mode], env=env, stdout=f, stderr=subprocess.STDOUT)
    e.write(folder / 'launcher.json', {'pid': p.pid, 'mode': mode, 'selected': selected})
    code = p.wait()
    e.need(code == 0 and e.read(folder / 'exit.json')['status'] == 'PASS', 'R2CCP_DDP_' + mode.upper() + '_FAILED_RESULTS_RETAINED')

def coordinate(e, root):
    out = root / e.OUT
    try:
        prepare(e, root)
        selected = select(e, out)
        e.write(out / 'selected_gpus.json', {'selected': selected, 'world_size': 4, 'effective_batch': 8, 'gradient_accumulation': 2, 'tail_real_count': 5, 'tail_placeholder_weight': 0})
        ddp_job(e, root, selected, 'smoke')
        e.log(out / 'events.jsonl', {'event': 'DDP_SMOKE_PASS_START_FRESH_FORMAL', 'time': time.time()})
        wait_selected(e, selected, MIN_START, out / 'events.jsonl')
        ddp_job(e, root, selected, 'train')
        folder = out / 'r2ccp_training'
        best = e.read(folder / 'selection.json')
        adapter = folder / best['adapter_directory']
        for n, k in [('adapter_model.safetensors', 'adapter_sha256'), ('adapter_config.json', 'adapter_config_sha256')]:
            e.need(e.sha(adapter / n) == best[k], 'SELECTED_ADAPTER_DRIFT')
        e.log(out / 'events.jsonl', {'event': 'candidate_frozen_before_official', 'selection': best, 'time': time.time()})
        wait_selected(e, selected, MIN_START, out / 'events.jsonl')
        e.infer_all(root, 'r2ccp_C', adapter)
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'], 'ADAPTER_CHANGED')
        e.write(out / 'summary.json', {'status': 'COMPLETE', 'method': 'R2CCP-style independently trained numerical C; 101-bin head; four-rank DDP', 'unfinetuned_numeric': e.read(out / 'unfinetuned_numeric/summary.json')['metrics'], 'R2CCP_C': e.read(out / 'r2ccp_C/summary.json')['metrics'], 'selection': best, 'B247_unchanged': True, 'official_adaptive_use': True, 'baseline_reused': True, 'same_input_unfinetuned_reference_has_different_output_head': True, 'conformal_calibration_or_coverage_claimed': False, 'new_algorithm_innovation_claimed': False, 'old_structured_C_not_same_input_comparator': True})
        e.write(out / 'exit.json', {'exit_code': 0})
    except BaseException:
        traceback.print_exc()
        e.write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'traceback': traceback.format_exc()})
        e.write(out / 'exit.json', {'exit_code': 1})
        raise
