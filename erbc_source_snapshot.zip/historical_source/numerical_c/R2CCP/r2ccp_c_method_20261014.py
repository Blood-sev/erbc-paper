"""R2CCP-style C point regression; no conformal calibration/coverage claim."""
import math
BINS = 101
TAU = 0.01
POWER = 1.0
TRAINABLE_PARAMETERS = 33288704

def method_loss(probability, target):
    import torch
    if probability.ndim != 2 or probability.shape[1] != BINS or target.shape != (probability.shape[0],):
        raise RuntimeError('R2CCP_LOSS_SHAPE')
    anchors = torch.linspace(0, 1, BINS, device=probability.device, dtype=probability.dtype)
    distance = (anchors[None, :] - target[:, None]).abs().pow(POWER)
    expected = (probability * distance).sum(-1)
    negative_entropy = (probability * probability.clamp_min(1e-12).log()).sum(-1)
    return (expected + TAU * negative_entropy).mean()

def oracle(logits, target):
    if len(logits) != BINS or not 0 <= target <= 1 or (not all((math.isfinite(v) for v in logits))):
        raise RuntimeError('R2CCP_ORACLE_INPUT')
    a = max(logits)
    ee = [math.exp(x - a) for x in logits]
    s = math.fsum(ee)
    p = [v / s for v in ee]
    d = [abs(i / (BINS - 1) - target) ** POWER for i in range(BINS)]
    loss = math.fsum((q * x + TAU * q * math.log(q) for q, x in zip(p, d)))
    v = [x + TAU * (math.log(q) + 1) for q, x in zip(p, d)]
    mean = math.fsum((q * x for q, x in zip(p, v)))
    return (loss, [q * (x - mean) for q, x in zip(p, v)])

def check_saved_head(folder):
    import json
    from safetensors import safe_open
    config = json.loads((folder / 'adapter_config.json').read_text())
    if 'score' not in (config.get('modules_to_save') or []):
        raise RuntimeError('R2CCP_HEAD_NOT_SAVED')
    with safe_open(str(folder / 'adapter_model.safetensors'), framework='pt', device='cpu') as f:
        heads = [k for k in f.keys() if 'score' in k and k.endswith('weight')]
        if len(heads) != 1 or list(f.get_slice(heads[0]).get_shape()) != [BINS, 2560]:
            raise RuntimeError('R2CCP_SAVED_HEAD_SHAPE')
