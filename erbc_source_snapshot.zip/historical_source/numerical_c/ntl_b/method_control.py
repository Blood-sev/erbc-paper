"""User-launched 4-7 job after TRACT completion; never stops any task."""
import os, sys, subprocess, time, traceback, shutil
from c_numeric_resume_support_20261014 import verify_source, SOURCE, PINS, ready_pair, wait_selected
REFERENCE = 'outputs/packages/C_NUMERIC_NTL_DDP4_20261014_SAFE'
SCOPE = (4, 5, 6, 7)
MIN_START = 33.35
REFERENCE_OUT = 'outputs/C\u72ec\u7acb\u6570\u503c\u57fa\u7ebf_NTL\u56db\u5361DDP_20261014_v4'

def verify_reference(e, root):
    plan = e.read(e.HERE / 'plan.json')
    src = root / REFERENCE_OUT
    e.need(plan['reference_output'] == REFERENCE_OUT, 'REFERENCE_PATH')
    for n, h in plan['reference_hashes'].items():
        e.need(e.Path(n).is_absolute() == False and '..' not in e.Path(n).parts, 'REFERENCE_ESCAPE')
        e.need(e.sha(src / n) == h, 'NTL_REFERENCE_HASH:' + n)
    selected = e.read(src / 'ntl_training/selection.json')
    cp = src / 'ntl_training' / selected['adapter_directory']
    e.need(selected['epoch'] == 4 and selected['adapter_directory'] == 'epoch4', 'REFERENCE_SELECTION')
    for n, k in [('adapter_model.safetensors', 'adapter_sha256'), ('adapter_config.json', 'adapter_config_sha256')]:
        e.need(e.sha(cp / n) == selected[k], 'REFERENCE_CHECKPOINT_HASH')
    e.need(e.read(src / 'exit.json')['exit_code'] == 0 and e.read(src / 'summary.json')['status'] == 'COMPLETE', 'REFERENCE_NOT_COMPLETE')
    pre = verify_source(e, root)
    e.need(e.read(src / 'preflight.json')['files'] == pre['files'], 'REFERENCE_TOKEN_PROTOCOL')
    for split, pp, n in [('official', src / 'ntl_C/predictions.json', 148), ('development', cp / 'development_predictions.json', 156)]:
        rows = e.read(pp)
        ix = {r['unit_id']: r for r in e.rows(src / (split + '_tokens.jsonl'))}
        e.need(len(rows) == len(ix) == len({r['unit_id'] for r in rows}) == n and {r['unit_id'] for r in rows} == set(ix), 'REFERENCE_MEMBERSHIP')
        for row in rows:
            e.validate_result(row, ix[row['unit_id']])
    return selected

def verify_protocol(e, root):
    e.package()
    plan = e.read(e.HERE / 'plan.json')
    ref = root / REFERENCE / 'plan.json'
    e.need(e.sha(ref) == plan['matched_NTL_plan_sha256'], 'MATCHED_NTL_PLAN_DRIFT')
    reference = e.read(ref)
    for k, v in reference.items():
        if k not in ('version', 'method_role', 'GPU_scope', 'training_execution'):
            e.need(plan.get(k) == v, 'COMMON_PROTOCOL_DRIFT:' + k)
    for k, v in reference['training_execution'].items():
        if k != 'physical_gpus':
            e.need(plan['training_execution'].get(k) == v, 'TRAINING_EXECUTION_DRIFT:' + k)
    e.need(plan['GPU_scope'] == list(SCOPE) and plan['training_execution']['physical_gpus'] == list(SCOPE), 'GPU_SCOPE')
    e.need(plan['loss'] == {'numeric_CE': 0.1, 'Wasserstein1': 1.0}, 'NTL_LOSS_PLAN')
    e.need(plan['seed_policy'] == {'sampler_seed': 20261014, 'model_training_seed': 20261015, 'rank_offset': True, 'new_seed_chosen_before_replica_results': True} and e.SEED == 20261014 and (e.MODEL_TRAINING_SEED == 20261015), 'SEED_POLICY')
    e.need(plan['fusion']['weights'] == [0.5, 0.5] and (not plan['fusion']['official_weight_search']) and (not plan['fusion']['partial_branch_fallback']), 'FIXED_FUSION_POLICY')
    e.need(plan['resource_admission'] == {'utilization': 'advisory_only', 'startup_free_GiB': 33.35, 'preload_free_GiB': 18, 'runtime_free_GiB': 5, 'allocator_extra_GiB': 1}, 'RESOURCE_POLICY')
    verify_reference(e, root)
    pre = verify_source(e, root)
    e.need(e.sha(root / e.DATA / 'summary.json') == plan['common_data_summary_sha256'] == pre['source_summary_sha256'], 'COMMON_DATA_DRIFT')
    return pre

def prepare(e, root):
    pre = verify_protocol(e, root)
    out = root / e.OUT
    src = root / SOURCE
    plan = e.read(e.HERE / 'plan.json')
    for n, v in plan['base_identity']['files'].items():
        f = root / e.MODEL / n
        e.need(f.stat().st_size == v['bytes'] and e.sha(f) == v['sha256'], 'BASE_IDENTITY:' + n)
    for n, h in pre['files'].items():
        e.need(not (out / n).exists(), 'OUTPUT_TOKEN_EXISTS')
        shutil.copyfile(src / n, out / n)
        e.need(e.sha(out / n) == h, 'TOKEN_COPY_DRIFT')
    (out / 'unfinetuned_numeric').mkdir()
    for n in ('summary.json', 'predictions.json'):
        shutil.copyfile(src / 'unfinetuned_numeric' / n, out / 'unfinetuned_numeric' / n)
    e.write(out / 'preflight.json', dict(pre, plan_sha256=e.sha(e.HERE / 'plan.json'), manifest_sha256=e.sha(e.HERE / 'SHA256SUMS'), reused_from=str(src), source_preflight_sha256=PINS['preflight.json']))
    e.write(out / 'reuse.json', {'source': str(src), 'pinned_source_files': PINS, 'tokenization_repeated': False, 'baseline_reinferred': False, 'weights_or_optimizer_reused': False, 'reference_readout': 'Unfinetuned ten-digit LM expectation; identical bounded input and readout', 'new_replica_GPU_smoke_required': True})
    e.log(out / 'events.jsonl', {'event': 'CPU_CACHE_AND_PROTOCOL_VERIFIED', 'time': time.time()})

def select(e, out):
    snapshot = e.table()
    selected = [next((g for g in snapshot if g['index'] == i), None) for i in SCOPE]
    e.need(all(selected), 'REQUIRED_GPU_4_TO7_MISSING')
    wait_selected(e, selected, MIN_START, out / 'events.jsonl')
    latest = e.rows(out / 'events.jsonl')[-1]['snapshot']
    return [next((g for g in latest if g['uuid'] == s['uuid'] and g['index'] == s['index'])) for s in selected]

def ddp_job(e, root, selected, mode):
    folder = root / e.OUT / ('ddp_smoke' if mode == 'smoke' else 'replica232_training')
    folder.mkdir()
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((g['uuid'] for g in selected)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', FLASH_ATTENTION_DETERMINISTIC='1', TORCH_NCCL_ASYNC_ERROR_HANDLING='1')
    with (folder / 'worker.log').open('x', encoding='utf-8') as f:
        p = subprocess.Popen([sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nnodes=1', '--nproc_per_node=4', '--max_restarts=0', str(e.HERE / 'ddp_c_train_20261014.py'), '--project-root', str(root), '--mode', mode], env=env, stdout=f, stderr=subprocess.STDOUT)
    e.write(folder / 'launcher.json', {'pid': p.pid, 'mode': mode, 'selected': selected})
    code = p.wait()
    e.need(code == 0 and e.read(folder / 'exit.json')['status'] == 'PASS', 'REPLICA232_DDP_' + mode.upper() + '_FAILED_RESULTS_RETAINED')

def coordinate(e, root):
    out = root / e.OUT
    try:
        prepare(e, root)
        selected = select(e, out)
        e.write(out / 'selected_gpus.json', {'selected': selected, 'world_size': 4, 'effective_batch': 8, 'gradient_accumulation': 2, 'tail_real_count': 5, 'tail_placeholder_weight': 0})
        ddp_job(e, root, selected, 'smoke')
        e.log(out / 'events.jsonl', {'event': 'DDP_SMOKE_PASS_START_FRESH_FORMAL', 'time': time.time()})
        wait_selected(e, selected, MIN_START, out / 'events.jsonl')
        ddp_job(e, root, selected, 'train')
        folder = out / 'replica232_training'
        best = e.read(folder / 'selection.json')
        adapter = folder / best['adapter_directory']
        for n, k in [('adapter_model.safetensors', 'adapter_sha256'), ('adapter_config.json', 'adapter_config_sha256')]:
            e.need(e.sha(adapter / n) == best[k], 'SELECTED_ADAPTER_DRIFT')
        e.log(out / 'events.jsonl', {'event': 'candidate_frozen_before_official', 'selection': best, 'time': time.time()})
        wait_selected(e, selected, MIN_START, out / 'events.jsonl')
        e.infer_all(root, 'replica232_C', adapter)
        e.need(e.sha(adapter / 'adapter_model.safetensors') == best['adapter_sha256'], 'ADAPTER_CHANGED')
        from c232_fusion_20261015 import publish
        fusion = publish(e, root)
        e.write(out / 'summary.json', {'status': 'COMPLETE', '247_control_C': fusion['official']['247_control_C'], '247_control_development': fusion['development']['247_control_C'], 'final_247_C_optimization_status': 'NOT_IMPLEMENTED_NOT_EVALUATED', 'method': '232-C NTL replica, model seed20261015, frozen sampler20261014, four-rank DDP', 'unfinetuned_numeric': e.read(out / 'unfinetuned_numeric/summary.json')['metrics'], '232_C': e.read(out / 'replica232_C/summary.json')['metrics'], 'selection': best, 'B247_unchanged': True, 'official_adaptive_use': True, 'baseline_reused': True, 'same_input_unfinetuned_reference_has_different_output_head': False, 'conformal_calibration_or_coverage_claimed': False, 'new_algorithm_innovation_claimed': False, 'old_structured_C_not_same_input_comparator': True})
        e.write(out / 'exit.json', {'exit_code': 0})
    except BaseException:
        traceback.print_exc()
        e.write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'traceback': traceback.format_exc()})
        e.write(out / 'exit.json', {'exit_code': 1})
        raise
