"""User-launched numerical C: common tokens, independent replicas, fresh NTL LoRA."""
import argparse, csv, io, os, subprocess, sys, time, traceback, random, signal
from core import *
from gpu_advisory_20261015 import ready as memory_ready, select as memory_select, advisory
from prepare import DATA
HERE = Path(__file__).resolve().parent
OUT = 'outputs/C\u72ec\u7acb\u6570\u503c\u5bf9\u7167_232\u6d4b\u8bd5\u7c7b\u578b\u4fee\u590d\u56db\u81f3\u4e03\u5361_20261015_v3'
MODEL = '\u6a21\u578b\u6587\u4ef6/Qwen3-4B-Instruct-2507'
MODEL_TRAINING_SEED = 20261015

def package():
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_CHANGED:' + n)

def table():
    r = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,memory.free,utilization.gpu', '--format=csv,noheader,nounits'], capture_output=True, text=True, check=True, timeout=20)
    return [{'index': int(v[0]), 'uuid': v[1].strip(), 'free_GiB': float(v[2]) / 1024, 'util': float(v[3])} for v in csv.reader(io.StringIO(r.stdout)) if v]

def available(width):
    snaps = []
    for i in range(2):
        snaps.append(table())
        if i == 0:
            time.sleep(1)
    eligible = memory_select(snaps[0], snaps[1], (4, 5, 6, 7), 18)
    eligible.sort(key=lambda r: r['index'])
    need(len(eligible) >= width, 'INSUFFICIENT_MEMORY_OR_IDENTITY_NO_LAUNCH')
    notice = advisory(snaps[0], snaps[1], eligible)
    if notice['warning']:
        print(json.dumps(notice, ensure_ascii=False), flush=True)
    return (eligible, snaps)

def preflight(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU_PREFLIGHT_ENV')
    package()
    out = root / OUT
    out.mkdir(parents=True, exist_ok=True)
    p = read(HERE / 'plan.json')
    data = root / DATA
    need(sha(data / 'summary.json') == p['common_data_summary_sha256'], 'DATA_SUMMARY_HASH')
    d = read(data / 'summary.json')
    need(d['counts'] == {'train': 925, 'development': 156, 'official': 148}, 'COUNTS')
    for n, h in d['artifacts'].items():
        need(sha(data / n) == h, 'DATA_HASH:' + n)
    for n, v in p['base_identity']['files'].items():
        f = root / MODEL / n
        need(f.stat().st_size == v['bytes'] and sha(f) == v['sha256'], 'BASE_HASH:' + n)
    if (out / 'preflight.json').exists():
        verify_frozen(root)
        return
    from transformers import AutoTokenizer
    import torch, transformers, peft
    need(not torch.cuda.is_initialized(), 'CPU_CUDA_INITIALIZED')
    tokenizer = AutoTokenizer.from_pretrained(root / MODEL, local_files_only=True)
    sample = rows(data / 'train.jsonl')[0]['variants'][0]['messages']
    default = tokenizer.apply_chat_template(sample, tokenize=True, add_generation_prompt=True)
    explicit = tokenizer.apply_chat_template(sample, tokenize=True, add_generation_prompt=True, return_dict=False)
    need(extract_ids(default) == extract_ids(explicit), 'TOKENIZER_FORMAT_ONLY_EQUIVALENCE')
    write(out / 'tokenizer_compatibility.json', {'status': 'PASS_REAL_TOKENIZER_CPU', 'default_type': type(default).__name__, 'explicit_type': type(explicit).__name__, 'tokens': len(extract_ids(default)), 'token_sha256': digest(extract_ids(default)), 'GPU_used': False})
    digits = [tokenizer.encode(str(i), add_special_tokens=False) for i in range(10)]
    need(digits == [[i] for i in range(15, 25)], 'DIGIT_IDS')
    files = {}
    stats = {}
    idsets = {}
    studentsets = {}
    for part in ('train', 'development', 'official'):
        rr = rows(data / f'{part}.jsonl')
        selected = []
        for r in rr:
            x = {k: v for k, v in r.items() if k != 'variants'}
            if r['status'] == 'READY':
                for v in r['variants']:
                    ids = tokenizer.apply_chat_template(v['messages'], tokenize=True, add_generation_prompt=True)
                    log(out / 'tokenizer_formats.jsonl', {'partition': part, 'unit_id': r['unit_id'], 'return_type': type(ids).__name__}) if not selected else None
                    ids = extract_ids(ids)
                    if len(ids) <= MAX_TOKENS:
                        x.update(input_ids=ids, input_audit=v['audit'], token_ids_sha256=digest(ids))
                        break
                else:
                    raise RuntimeError('FULL_AB_EXCEEDS_BUDGET:' + r['unit_id'])
            else:
                need(part == 'official' and r['status'] == 'UPSTREAM_BLOCKED', 'BAD_PREEXISTING_FAILURE')
            selected.append(x)
        dest = out / (part + '_tokens.jsonl')
        need(not dest.exists(), 'PARTIAL_TOKENIZATION_EXISTS_REVIEW_BEFORE_RETRY')
        with dest.open('x', encoding='utf-8') as f:
            for x in selected:
                f.write(canonical(x) + '\n')
        files[dest.name] = sha(dest)
        lengths = [len(x['input_ids']) for x in selected if 'input_ids' in x]
        stats[part] = {'records': len(selected), 'inference_records': len(lengths), 'max_tokens': max(lengths), 'mean_tokens': sum(lengths) / len(lengths), 'selected_budget_counts': {str(b): sum((x.get('input_audit', {}).get('evidence_byte_budget') == b for x in selected)) for b in (24000, 12000, 6000, 2000, 0)}}
        idsets[part] = {x['unit_id'] for x in selected}
        studentsets[part] = {x['student_group_id'] for x in selected}
    for a, b in [('train', 'development'), ('train', 'official'), ('development', 'official')]:
        need(not idsets[a] & idsets[b] and (not studentsets[a] & studentsets[b]), 'SPLIT_LEAK')
    z = torch.zeros((1, 10), requires_grad=True)
    loss = ntl_loss(z.softmax(-1), torch.tensor([0.37]))
    loss.backward()
    need(torch.isfinite(loss).item() and torch.isfinite(z.grad).all().item() and (z.grad.abs().sum().item() > 0), 'CPU_LOSS_GRADIENT')
    write(out / 'preflight.json', {'status': 'PASS_CPU_TOKENIZATION_ONLY', 'plan_sha256': sha(HERE / 'plan.json'), 'manifest_sha256': sha(HERE / 'SHA256SUMS'), 'files': files, 'lengths': stats, 'digits': [x[0] for x in digits], 'runtime': {'torch': torch.__version__, 'transformers': transformers.__version__, 'peft': peft.__version__}, 'GPU_tested': False, 'source_summary_sha256': sha(data / 'summary.json')})
    print(canonical(stats), flush=True)

def verify_frozen(root):
    package()
    out = root / OUT
    d = read(out / 'preflight.json')
    need(d['plan_sha256'] == sha(HERE / 'plan.json') and d['manifest_sha256'] == sha(HERE / 'SHA256SUMS'), 'PREFLIGHT_BINDING')
    for n, h in d['files'].items():
        need(sha(out / n) == h, 'TOKEN_FILE_CHANGED')
    return d

def child(root, mode, gpus, folder, extra=()):
    folder.mkdir(parents=True, exist_ok=False)
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((x['uuid'] for x in gpus)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', FLASH_ATTENTION_DETERMINISTIC='1')
    write(folder / 'assignment.json', {'mode': mode, 'gpus': gpus, 'plan_sha256': sha(HERE / 'plan.json')})
    f = (folder / 'worker.log').open('x', encoding='utf-8')
    try:
        p = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'worker', '--project-root', str(root), '--mode', mode, '--folder', str(folder), *extra], env=env, stdout=f, stderr=subprocess.STDOUT)
    finally:
        f.close()
    return p

def joined(p, folder):
    code = p.wait()
    r = read(folder / 'exit.json') if (folder / 'exit.json').exists() else {'status': 'UNKNOWN_WORKER_FAILURE'}
    need((code == 0) == (r['status'] == 'PASS'), 'CHILD_EXIT_RECORD_MISMATCH')
    return r

def validate_result(r, source):
    need(all((r[k] == source[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction'))), 'RESULT_IDENTITY_DRIFT')
    if source['status'] == 'READY':
        need(r['status'] == 'PASS' and r['token_ids_sha256'] == source['token_ids_sha256'], 'RESULT_INPUT_DRIFT')
    else:
        need(r['status'] == 'UPSTREAM_BLOCKED', 'UPSTREAM_STATUS_DRIFT')

def infer_all(root, arm, adapter=None):
    out = root / OUT
    rr = rows(out / 'official_tokens.jsonl')
    dest = out / arm
    dest.mkdir()
    completed = {}
    for r in rr:
        if r['status'] == 'UPSTREAM_BLOCKED':
            completed[r['unit_id']] = dict(r, prediction_fraction=None)
    pending = [r['unit_id'] for r in rr if r['status'] == 'READY']
    by = {x['unit_id']: x for x in rr}
    for width in (1, 2, 4):
        if not pending:
            break
        eligible, snap = available(width)
        write(dest / f'gpu_snapshot_width{width}.json', snap)
        groups = [eligible[i:i + width] for i in range(0, len(eligible) - width + 1, width)]
        queues = [[] for _ in groups]
        loads = [0] * len(groups)
        for u in sorted(pending, key=lambda u: (-len(by[u]['input_ids']), u)):
            i = min(range(len(groups)), key=lambda i: (loads[i], i))
            queues[i].append(u)
            loads[i] += len(by[u]['input_ids'])
        children = []
        for i, (g, q) in enumerate(zip(groups, queues)):
            if not q:
                continue
            shortest = min(q, key=lambda u: (len(by[u]['input_ids']), u))
            q.remove(shortest)
            q.insert(0, shortest)
            folder = dest / f'width{width}_worker{i}'
            qf = dest / f'width{width}_queue{i}.json'
            write(qf, q)
            extra = ['--queue', str(qf)] + (['--adapter', str(adapter)] if adapter else [])
            children.append((child(root, 'infer', g, folder, extra), folder))
        results = [(joined(p, f), f) for p, f in children]
        for result, f in results:
            if (f / 'predictions.jsonl').exists():
                for r in rows(f / 'predictions.jsonl'):
                    need(r['unit_id'] in by, 'UNKNOWN_RESULT_ID')
                    validate_result(r, by[r['unit_id']])
                    need(r['unit_id'] not in completed, 'DUPLICATE_COMPLETED_RESULT')
                    completed[r['unit_id']] = r
            need(result['status'] in ('PASS', 'OOM'), 'INFERENCE_EXECUTION_STOP:' + str(result))
        pending = [u for u in pending if u not in completed]
    need(not pending and set(completed) == set(by), 'INFERENCE_INCOMPLETE_NOT_SCORE')
    result = [completed[x['unit_id']] for x in rr]
    for r in result:
        validate_result(r, by[r['unit_id']])
    write(dest / 'predictions.json', result)
    write(dest / 'summary.json', {'status': 'PASS', 'metrics': metrics(result), 'records': 148, 'official_adaptive_use': True, 'predictions_sha256': sha(dest / 'predictions.json')})

def coordinate(root):
    from method_control import coordinate as ddp_coordinate
    return ddp_coordinate(sys.modules[__name__], root)

def worker(root, args):
    folder = Path(args.folder)
    out = root / OUT
    pre = verify_frozen(root)
    assignment = read(folder / 'assignment.json')
    gpus = assignment['gpus']
    width = len(gpus)
    need(width in (1, 2, 4) and os.environ.get('CUDA_VISIBLE_DEVICES') == ','.join((g['uuid'] for g in gpus)), 'WORKER_GPU_BINDING')
    try:
        import torch, transformers, peft
        from transformers import AutoModelForCausalLM
        from peft import LoraConfig, TaskType, get_peft_model, PeftModel
        need(pre['runtime'] == {'torch': torch.__version__, 'transformers': transformers.__version__, 'peft': peft.__version__}, 'RUNTIME_CHANGED')
        random.seed(SEED)
        torch.manual_seed(SEED)
        torch.cuda.manual_seed_all(SEED)
        torch.set_num_threads(1)
        need(torch.cuda.device_count() == width, 'VISIBLE_COUNT')
        snapshot = table()
        need(memory_ready(snapshot, snapshot, gpus, 18), 'GPU_MEMORY_OR_IDENTITY_CHANGED_BEFORE_LOAD')
        log(folder / 'resources.jsonl', dict(event='pre_load_resource_screen', snapshot=snapshot, **advisory([], snapshot, gpus)))
        for i in range(width):
            free, total = torch.cuda.mem_get_info(i)
            torch.cuda.set_per_process_memory_fraction(max(0.01, min(0.99, (free - 6 * 1024 ** 3) / total)), i)

        def guard(phase):
            for i, g in enumerate(gpus):
                free = torch.cuda.mem_get_info(i)[0] / 1024 ** 3
                log(folder / 'resources.jsonl', {'phase': phase, 'physical_gpu': g['index'], 'free_GiB': free, 'allocated_GiB': torch.cuda.memory_allocated(i) / 1024 ** 3, 'reserved_GiB': torch.cuda.memory_reserved(i) / 1024 ** 3, 'time': time.time()})
                need(free >= 5, 'RESOURCE_BELOW_5GiB')
        placement = {'model.embed_tokens': 0, 'model.norm': 0, 'lm_head': 0}
        placement.update({f'model.layers.{i}': i * width // 36 for i in range(36)})
        guard('before_load')
        model = AutoModelForCausalLM.from_pretrained(root / MODEL, local_files_only=True, dtype=torch.bfloat16, attn_implementation='flash_attention_2', device_map=placement, low_cpu_mem_usage=True)
        model.config.use_cache = False
        need(args.mode == 'infer' and args.adapter, 'TRAINED_RAFT_REQUIRED')
        model = PeftModel.from_pretrained(model, args.adapter, is_trainable=False, local_files_only=True)
        need(all((p.device.type == 'cuda' for p in model.parameters())), 'CPU_OFFLOAD_FORBIDDEN')
        decoder = model.get_base_model().model if hasattr(model, 'get_base_model') else model.model
        need(len(decoder.layers) == 36, 'DECODER_LAYER_COUNT')
        for i, layer in enumerate(decoder.layers):
            need(all((p.device.index == i * width // 36 for p in layer.parameters())), 'LAYER_PLACEMENT_DRIFT')
        guard('after_load')
        digits = pre['digits']
        anchors = torch.linspace(0, 1, 10, device='cuda:0')

        def probability(row):
            guard('before_forward')
            ids = torch.tensor([row['input_ids']], device='cuda:0', dtype=torch.long)
            y = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False).logits
            need(y.shape[:2] == ids.shape, 'LOGIT_SHAPE')
            p = y[:, -1, digits].float().softmax(-1)
            need(bool(torch.isfinite(p).all()), 'NONFINITE_PROBABILITY')
            guard('after_forward')
            return p

        def predicted(row):
            with torch.no_grad():
                p = probability(row)
                v = float((p * anchors.to(p.device)).sum().item())
            return {k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction')} | {'status': 'PASS', 'prediction_fraction': v, 'token_ids_sha256': row['token_ids_sha256']}
        if args.mode == 'infer':
            model.eval()
            by = {x['unit_id']: x for x in rows(out / 'official_tokens.jsonl')}
            queue = read(args.queue)
            if width > 1:
                candidates = sorted(folder.parent.glob('width1_worker*/predictions.jsonl'))
                refs = [x for f in candidates for x in rows(f)]
                need(refs, 'NO_SINGLE_GPU_REFERENCE_FOR_WIDER_LAYOUT')
                checks = []
                for ref in sorted(refs, key=lambda x: len(by[x['unit_id']]['input_ids']))[::max(1, len(refs) - 1)]:
                    replayed = predicted(by[ref['unit_id']])
                    delta = abs(replayed['prediction_fraction'] - ref['prediction_fraction'])
                    need(delta <= 1e-06, 'LAYOUT_PREDICTION_MISMATCH')
                    checks.append({'unit_id': ref['unit_id'], 'difference_fraction': delta})
                write(folder / 'layout_replay.json', {'checks': checks, 'tolerance': 1e-06, 'scope': 'shortest and longest available completed single-GPU records, not all inputs'})
            for u in queue:
                log(folder / 'events.jsonl', {'event': 'sample_start', 'unit_id': u, 'time': time.time()})
                r = predicted(by[u])
                log(folder / 'predictions.jsonl', r)
                guard('inference_complete')
        write(folder / 'exit.json', {'status': 'PASS'})
        return 0
    except BaseException as e:
        traceback.print_exc()
        oom = 'torch' in locals() and isinstance(e, torch.cuda.OutOfMemoryError)
        write(folder / 'exit.json', {'status': 'OOM' if oom else 'EXECUTION_ERROR', 'exception': repr(e), 'traceback': traceback.format_exc()})
        return 1

def launch(root):
    package()
    out = root / OUT
    from method_control import verify_protocol
    verify_protocol(sys.modules[__name__], root)
    need(not (root / 'outputs/C\u72ec\u7acb\u6570\u503c\u5bf9\u7167_232\u590d\u8bad\u53ca247\u56fa\u5b9a\u878d\u5408_20261015_v1').exists(), 'PRIOR_232_OUTPUT_EXISTS_REVIEW_NO_DUPLICATE_JOB')
    need(not (root / 'outputs/C\u72ec\u7acb\u6570\u503c\u5bf9\u7167_232\u590d\u8bad\u53ca247\u56fa\u5b9a\u878d\u5408\u56db\u81f3\u4e03\u5361_20261015_v2').exists(), 'PREVIOUS_GPU47_OUTPUT_EXISTS_REVIEW_NO_DUPLICATE_JOB')
    need(not out.exists(), 'OUTPUT_EXISTS_STOP_USE_SHOW_NO_DUPLICATE_JOB')
    from c_numeric_resume_support_20261014 import ready_pair
    selected, snapshots = available(4)
    need(ready_pair(snapshots[0], snapshots[1], selected, 33.35), 'RESOURCES_NOT_READY_NO_NEW_OUTPUT_CREATED')
    out.mkdir(parents=True)
    write(out / 'startup_resources.json', dict(snapshots=snapshots, selected=selected, **advisory(snapshots[0], snapshots[1], selected)))
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false')
    with (out / 'worker.log').open('x', encoding='utf-8') as f:
        p = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'coordinate', '--project-root', str(root)], env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'worker.json', {'pid': p.pid, 'plan_sha256': sha(HERE / 'plan.json')})
    print('C_NUMERIC_COORDINATOR_PID=' + str(p.pid))
    print('LOG=' + str(out / 'worker.log'))

def show(root):
    out = root / OUT
    for n in ('preflight.json', 'summary.json', 'failure.json', 'exit.json'):
        if (out / n).exists():
            d = read(out / n)
            print(canonical(d['lengths'] if n == 'preflight.json' else d))
    for f in sorted(out.rglob('events.jsonl')):
        lines = f.read_text(encoding='utf-8').splitlines()
        if lines:
            print(canonical({'file': str(f.relative_to(out)), 'last': json.loads(lines[-1])}))
    if (out / 'worker.log').exists():
        print('\n'.join((out / 'worker.log').read_text(encoding='utf-8', errors='replace').splitlines()[-12:]))
if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('command', choices=['launch', 'show', 'coordinate', 'preflight', 'worker'])
    p.add_argument('--project-root', required=True)
    p.add_argument('--mode', choices=['infer'])
    p.add_argument('--folder')
    p.add_argument('--queue')
    p.add_argument('--adapter')
    a = p.parse_args()
    root = Path(a.project_root).resolve()
    if a.command == 'worker':
        sys.exit(worker(root, a))
    else:
        globals()[a.command](root)
