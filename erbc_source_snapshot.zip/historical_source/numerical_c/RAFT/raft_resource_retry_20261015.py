"""Read-only proof that the previous RAFT attempt stopped BEFORE GPU work."""
from pathlib import Path
SOURCE = 'outputs/C\u72ec\u7acb\u6570\u503c\u57fa\u7ebf_RAFT\u56db\u5361DDP_20261014_v1'
STAGE = 'outputs/packages/C_NUMERIC_RAFT_DDP4_20261014_SAFE'
MANIFEST = '214f45075f0cb747e1eb7fb7d498799d3232080f7ea0855ea1267a42da815a0c'
PINNED = {'exit.json': '56296949d3a02e635b050fd6b4762f0f0b52c23d05b925203095f7daf8e19027', 'failure.json': 'f8df98fefd2d078fbf733266a061cfed931301e7b16a0c202b859e4aa5133a9d', 'preflight.json': 'aaddc97a51f007b6000a51a654d18988ca45fb89e81c393afa84ba534adcea37', 'worker.json': '57e6cbab0598969ee9bdd36c8701f16c86d9aafb662d75e11d6082de86cb4d40'}
ALLOWED = {'development_tokens.jsonl', 'events.jsonl', 'exit.json', 'failure.json', 'official_tokens.jsonl', 'preflight.json', 'reuse.json', 'train_tokens.jsonl', 'unfinetuned_numeric', 'worker.json', 'worker.log'}

def assert_not_running(e, root, record, proc_root=Path('/proc')):
    pid = record['pid']
    e.need(type(pid) == int and pid > 1, 'BAD_PRIOR_PID')
    p = proc_root / str(pid)
    try:
        raw = (p / 'cmdline').read_bytes()
    except FileNotFoundError:
        return
    args = [x.decode('utf-8', 'strict') for x in raw.split(b'\x00') if x]
    same = str(root / STAGE / 'run.py') in args and 'coordinate' in args
    e.need(not same, 'PRIOR_RAFT_COORDINATOR_STILL_PRESENT_NO_DUPLICATE')

def verify_failed(e, root, check_process=False):
    src = root / SOURCE
    stage = root / STAGE
    e.need(e.sha(stage / 'SHA256SUMS') == MANIFEST, 'PRIOR_MANIFEST_DRIFT')
    for line in (stage / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        e.need(Path(n).name == n and e.sha(stage / n) == h, 'PRIOR_PACKAGE_DRIFT')
    for n, h in PINNED.items():
        e.need(e.sha(src / n) == h, 'PRIOR_FAILURE_PROOF_DRIFT:' + n)
    e.need({f.name for f in src.iterdir()} == ALLOWED, 'PRIOR_GPU_OR_UNKNOWN_OUTPUT_EXISTS')
    e.need(e.read(src / 'exit.json') == {'exit_code': 1}, 'PRIOR_NOT_TERMINAL_FAILURE')
    f = e.read(src / 'failure.json')
    e.need(f['traceback'].rstrip().endswith('RuntimeError: SELECTED_GPU_BUSY_TIMEOUT_RESULTS_RETAINED'), 'PRIOR_FAILURE_NOT_RESOURCE_GATE')
    pre = e.read(src / 'preflight.json')
    old = e.read(stage / 'plan.json')
    plan = e.read(e.HERE / 'plan.json')
    from gpu_advisory_20261015 import validate_plan_policy
    validate_plan_policy(plan)
    e.need(pre['manifest_sha256'] == MANIFEST and pre['plan_sha256'] == e.sha(stage / 'plan.json'), 'PRIOR_PREFLIGHT_BINDING')
    e.need({k: v for k, v in old.items() if k != 'version'} == {k: v for k, v in plan.items() if k not in ('version', 'resource_retry', 'utilization_policy')}, 'SCIENTIFIC_PROTOCOL_CHANGED')
    for n, h in pre['files'].items():
        e.need(e.sha(src / n) == h, 'PRIOR_TOKEN_CACHE_DRIFT')
    if check_process:
        assert_not_running(e, root, e.read(src / 'worker.json'))
    return {'source': SOURCE, 'failure_pins': PINNED, 'prior_GPU_work_started': False, 'prior_output_modified': False, 'process_checked_on_this_host': check_process}
