import argparse, os, sys, time, subprocess, traceback, math
from pathlib import Path
from core import need, read, write, log, sha, batches, metrics
HERE = Path(__file__).resolve().parent
OUT = 'outputs/C\u8d23\u4efb\u8fc1\u79fb\u6709\u5e8f\u5c40\u90e8\u8d23\u4efb\u4fee\u590d_20261018_v1'

def preflight(root):
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_HASH')
    p = read(HERE / 'plan.json')
    for rel, h in p['pins'].items():
        need(not Path(rel).is_absolute() and '..' not in Path(rel).parts and (sha(root / rel) == h), 'SOURCE_HASH:' + rel)
    sys.path.insert(0, str(root / p['audit_package']))
    import run as frozen_audit
    old, ev, rows, caches = frozen_audit.preflight(root)
    need(old['source'] == p['source'], 'TEACHER_SOURCE')
    supervision = read(root / p['source'] / 'supervision.json')
    need(set(supervision) == {x['unit_id'] for x in rows['clean_train']}, 'TRAIN_SUPERVISION_MEMBERSHIP')
    for x in rows['pred_train']:
        if x['status'] != 'READY':
            continue
        s = supervision[x['unit_id']]['predicted']
        n = len(x['operation_positions'])
        need(len(s['mask']) == len(s['responsibility']) == n and all((type(b) == bool for b in s['mask'])), 'SUPERVISION_SHAPE')
        for use, q in zip(s['mask'], s['responsibility']):
            need(len(q) == 3 and all((type(v) in (int, float) and math.isfinite(v) and (0 <= v <= 1) for v in q)), 'SUPERVISION_VALUES')
            if use:
                need(abs(sum(q) - 1) < 1e-06, 'SUPERVISION_NORMALIZATION')
    return (p, ev, rows, caches)

def launch(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU_ONLY')
    out = root / OUT
    need(not out.exists(), 'OUTPUT_EXISTS_USE_SHOW')
    out.mkdir(parents=True)
    p = read(HERE / 'plan.json')
    write(out / 'plan.json', p)
    write(out / 'started.json', {'time': time.time()})
    with (out / 'worker.log').open('x') as f:
        child = subprocess.Popen([sys.executable, '-B', str(HERE / 'refine.py'), 'work', '--project-root', str(root)], stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'pid.json', {'pid': child.pid})
    print('\u5df2\u63d0\u4ea4CPU\u6709\u5e8f\u8d23\u4efb\u4fee\u590d\uff5c1411\u53c2\u6570\uff0f464\u6b65\uff5c\u6210\u529f\u6c47\u603b\u6743\u91cd\u4e0e\u6821\u6b63\u95e8\u51bb\u7ed3\uff5cPID=' + str(child.pid))

def work(root):
    out = root / OUT

    def check():
        need(time.time() - read(out / 'started.json')['time'] < 900, 'TIME_BUDGET_KEEP_SUCCESSFUL')
    try:
        check()
        p, ev, rows, caches = preflight(root)
        check()
        import torch
        from safetensors.torch import load_file, save_file
        import model_v2
        from correction import ResponsibilityRepair, make_state, update_batch, select_epoch
        from robust import official_decision
        need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and (not torch.cuda.is_initialized()), 'CPU_ONLY')
        need(torch.__version__ == p['torch_version'], 'TORCH_VERSION')
        torch.set_num_threads(2)
        torch.manual_seed(p['seed'])
        teacher = model_v2.make_head(2560)
        teacher.load_state_dict(load_file(str(root / p['source'] / 'epoch1/head.safetensors'), device='cpu'))
        teacher.eval()
        teacher.requires_grad_(False)
        teacher_snapshot = {k: v.detach().clone() for k, v in teacher.state_dict().items()}
        write(out / 'teacher_replay.json', ev.replay_development(root, {'output': p['source'], 'selected_epoch': 1, 'model_version': 2}, teacher, load_file, torch))
        states = {}

        def state_for(kind, row):
            check()
            u = row['unit_id']
            entry = caches[kind][u]
            f = load_file(entry['absolute_feature_path'], device='cpu')
            need(set(f) == {'last', 'operations'} and f['last'].shape == (2560,) and (f['operations'].shape == (len(row['operation_positions']), 2560)), 'FEATURE_SHAPE')
            need(all((bool(torch.isfinite(x).all()) for x in f.values())), 'FEATURE_NONFINITE')
            ctx = torch.cat([f['operations'], f['last'][None]], 0)
            return make_state(teacher, f['operations'], ctx, torch.tensor(row['b_share']), torch.tensor((entry['first'] + entry['second']) / 2, dtype=torch.float64))
        head = ResponsibilityRepair()
        identity = 0
        for kind in ('clean_train', 'pred_train', 'clean_development', 'pred_development'):
            states[kind] = {}
            for row in rows[kind]:
                if row['status'] != 'READY':
                    continue
                u = row['unit_id']
                state = state_for(kind, row)
                states[kind][u] = state
                with torch.no_grad():
                    need(float(head(state)['prediction']) == float(state['prediction']), 'ZERO_IDENTITY')
                identity += 1
            log(out / 'events.jsonl', {'event': 'frozen_states_ready', 'kind': kind, 'records': len(states[kind]), 'time': time.time()})
        need(sum((x.numel() for x in head.parameters())) == 1411, 'PARAMETERS')
        write(out / 'zero_identity.json', {'exact': True, 'records': identity, 'trainable_parameters': 1411})
        optimizer = torch.optim.AdamW(head.parameters(), lr=p['learning_rate'], betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01)
        real = {x['unit_id']: x for x in rows['pred_train']}

        def evaluate(kind):
            pp = []
            head.eval()
            with torch.no_grad():
                for x in rows[kind]:
                    check()
                    v = {k: x[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'status')}
                    if x['status'] == 'READY':
                        state = states[kind][x['unit_id']] if kind in states else state_for(kind, x)
                        z = head(state)
                        v.update(status='PASS', prediction_fraction=float(z['prediction']), gate=float(state['gate']), token_ids_sha256=x['token_ids_sha256'])
                    ev.check_result(v, x)
                    pp.append(v)
            return (pp, metrics(pp))
        supervision = read(root / p['source'] / 'supervision.json')
        need(set(supervision) == set(real), 'TRAIN_SUPERVISION_MEMBERSHIP')
        candidates = []
        step = 0
        for epoch in range(1, 5):
            head.train()
            queue = batches(925, epoch)
            need(len(queue) == 116, 'STEP_COUNT')
            for indices in queue:
                step += 1
                rec = update_batch(head, optimizer, indices, rows['clean_train'], real, states, supervision, check)
                log(out / 'events.jsonl', dict(event='responsibility_update', step=step, total=464, time=time.time(), **rec))
            ep = out / ('epoch' + str(epoch))
            ep.mkdir()
            save_file(head.state_dict(), str(ep / 'repair_head.safetensors'))
            for kind in ('clean_development', 'pred_development'):
                pp, m = evaluate(kind)
                write(ep / (kind + '_predictions.json'), pp)
                write(ep / (kind + '_metrics.json'), m)
                if kind == 'pred_development':
                    predicted_metrics = m
            candidates.append({'epoch': epoch, 'predicted_metrics': predicted_metrics, 'head_sha256': sha(ep / 'repair_head.safetensors')})
        selected = select_epoch(candidates)
        file = out / ('epoch' + str(selected['epoch'])) / 'repair_head.safetensors'
        need(sha(file) == selected['head_sha256'], 'SELECTED_HEAD_DRIFT')
        head.load_state_dict(load_file(str(file), device='cpu'))
        need(all((torch.equal(v, load_file(str(file), device='cpu')[k]) for k, v in head.state_dict().items())), 'HEAD_SERIALIZATION')
        write(out / 'selection.json', {'rule': 'Predicted-AB development overall MAE,CS MAE,earlier epoch; no clean veto; freeze before one official evaluation', 'candidates': candidates, 'selected': selected})
        pp, m = evaluate('clean_official')
        write(out / 'official_predictions.json', pp)
        retained = read(root / p['retained_official'] / 'summary.json')['candidates'][0]['metrics']
        oldrows = {x['unit_id']: x for x in read(root / p['retained_official'] / 'retention_v2_best_official_predictions.json')}
        for x in pp:
            if x['status'] == 'PASS':
                need(x['gate'] == oldrows[x['unit_id']]['gate'], 'FUNCTIONAL_GATE_CHANGED')
        need(all((torch.equal(teacher_snapshot[k], v) for k, v in teacher.state_dict().items())), 'SUCCESSFUL_TEACHER_CHANGED')
        check()
        preflight(root)
        check()
        need(not torch.cuda.is_initialized(), 'CUDA_UNEXPECTED')
        write(out / 'summary.json', {'status': 'COMPLETE', 'official_metrics': m, 'retained_metrics': retained, **official_decision(m, retained), 'teacher_weights_and_functional_gate_unchanged': True, 'teacher_mass_unchanged': True, 'trainable_parameters': 1411, 'steps': 464, 'selected_epoch': selected['epoch'], 'B247_unchanged': True, 'GPU_used': False, 'official_adaptive_use': True, 'table_updated': False, 'elapsed_seconds': time.time() - read(out / 'started.json')['time']})
    except BaseException as e:
        write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'error': repr(e), 'traceback': traceback.format_exc()})
        raise

def show(root):
    out = root / OUT
    if not out.exists():
        print('\u5c1a\u672a\u542f\u52a8')
        return
    if (out / 'failure.json').exists():
        print('\u6267\u884c\u4e2d\u65ad\uff0c\u4fdd\u7559\u6210\u529f\u7248\uff5c' + read(out / 'failure.json')['error'])
        return
    if (out / 'summary.json').exists():
        s = read(out / 'summary.json')
        m = s['official_metrics']
        d = s['delta_vs_retained_MAE_pp']
        print('\u72b6\u6001\uff1a' + s['decision'])
        print('\u5b98\u65b9\u60e9\u7f5aMAE\uff1a%.4f / %.4f\uff5c\u76f8\u5bf9\u6210\u529f\u7248\uff1a%+.4f / %+.4f\uff08\u8d1f\u503c\u6539\u5584\uff09' % (m['overall']['failure_penalized_MAE_pp'], m['computer_science']['failure_penalized_MAE_pp'], d['overall'], d['computer_science']))
        return
    ev = out / 'events.jsonl'
    if ev.exists():
        last = __import__('json').loads(ev.read_text().splitlines()[-1])
        if last['event'] == 'responsibility_update':
            print('CPU\u8d23\u4efb\u4fee\u590d\uff1a%s/464\u6b65\uff5c\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u5b58\u6d3b' % last['step'])
        else:
            print('\u51bb\u7ed3\u6210\u529f\u5934\u72b6\u6001\uff1a%s\uff5c%s\u6761\uff5c\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u5b58\u6d3b' % (last['kind'], last['records']))
    else:
        print('\u6765\u6e90\u6838\u9a8c\uff0f\u6210\u529f\u5934\u56de\u653e\u4e2d\uff1b\u4e0d\u91cd\u8dd1A/B')
if __name__ == '__main__':
    a = argparse.ArgumentParser()
    a.add_argument('command', choices=['launch', 'work', 'show', 'preflight'])
    a.add_argument('--project-root', required=True)
    x = a.parse_args()
    root = Path(x.project_root).resolve()
    if x.command == 'preflight':
        preflight(root)
        print('PASS_CPU_SOURCE_AND_CACHE_PREFLIGHT_NO_TRAINING')
    else:
        globals()[x.command](root)
