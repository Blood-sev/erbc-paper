"""CPU-only, train/development-only candidate. Official evaluation is NOT implemented here."""
import argparse, hashlib, importlib.util, json, math, os, random, subprocess, sys, time, traceback
from pathlib import Path
HERE = Path(__file__).resolve().parent
OUT = 'outputs/C\u6210\u529f\u7248\u4e0a\u4e0b\u6587\u8d23\u4efb\u8d21\u732e\u8054\u5408\u4fee\u6b63_20261020_v1'

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def read(p):
    return json.loads(Path(p).read_text(encoding='utf8'))

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(x)
    return h.hexdigest()

def write(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf8') as f:
        json.dump(x, f, ensure_ascii=False, indent=2, allow_nan=False)

def log(p, x):
    with Path(p).open('a', encoding='utf8') as f:
        f.write(json.dumps(x, ensure_ascii=False, allow_nan=False) + '\n')

def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def package_check():
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_HASH:' + n)

def preflight(root):
    package_check()
    p = read(HERE / 'plan.json')
    for rel, h in p['pins'].items():
        need(not Path(rel).is_absolute() and '..' not in Path(rel).parts and (sha(root / rel) == h), 'SOURCE_HASH:' + rel)
    prior = root / p['prior_package']
    sys.path.insert(0, str(prior))
    old = load_module('frozen_ordinal_driver', prior / 'refine.py')
    op, ev, rows, caches = old.preflight(root)
    need(op['source'] == p['teacher_source'], 'TEACHER_SOURCE')
    need(len(rows['clean_train']) == 925 and len(rows['pred_train']) == 925, 'TRAIN_COUNT')
    need(sum((x['status'] == 'READY' for x in rows['pred_train'])) == 856, 'PREDICTED_TRAIN_COUNT')
    need(all((len(rows[k]) == 156 for k in ('clean_development', 'pred_development'))), 'DEV_COUNT')
    sup = read(root / p['teacher_source'] / 'supervision.json')
    for row in rows['pred_train']:
        if row['status'] != 'READY':
            continue
        s = sup[row['unit_id']]['predicted']
        n = len(row['operation_positions'])
        need(len(s['mask']) == len(s['counts']) == len(s['responsibility']) == n, 'SUPERVISION_SHAPE')
        for use, count in zip(s['mask'], s['counts']):
            need(isinstance(count, (int, float)) and math.isfinite(count) and (count >= 0), 'COUNT_FINITE')
            if use:
                need(count > 0, 'MATCHED_COUNT_POSITIVE')
    return (p, ev, rows, caches)

def train_fit(head, states, rows, supervision, p, out, metrics, check):
    """Pure training/development engine; no official rows/files/callbacks accepted."""
    import torch
    from safetensors.torch import save_file
    from joint import loss_unit, choose
    need(set(rows) == {'clean_train', 'pred_train', 'clean_development', 'pred_development'}, 'TRAIN_DEV_ONLY')
    need(set(states) == set(rows), 'STATE_PARTITIONS')

    def evaluate(kind, baseline=False):
        head.eval()
        pp = []
        with torch.no_grad():
            for row in rows[kind]:
                check()
                v = {k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'status')}
                if row['status'] == 'READY':
                    state = states[kind][row['unit_id']]
                    prediction = state['prediction'] if baseline else head(state)['prediction']
                    need(bool(torch.isfinite(prediction)), 'PREDICTION_FINITE')
                    v.update(status='PASS', prediction_fraction=float(prediction), token_ids_sha256=row['token_ids_sha256'])
                else:
                    need(row['status'] == 'UPSTREAM_BLOCKED', 'INVALID_EXECUTION_STATUS')
                pp.append(v)
        return (pp, metrics(pp))
    base = {}
    for kind in ('clean_development', 'pred_development'):
        pp, m = evaluate(kind, True)
        base[kind] = m
        write(out / ('retained_' + kind + '_metrics.json'), m)
    optimizer = torch.optim.AdamW(head.parameters(), lr=p['learning_rate'], betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01)
    n = len(rows['clean_train'])
    step = 0
    candidates = []
    for epoch in range(1, p['epochs'] + 1):
        order = list(range(n))
        random.Random(p['seed'] + epoch).shuffle(order)
        head.train()
        for start in range(0, n, p['batch']):
            check()
            indices = order[start:start + p['batch']]
            optimizer.zero_grad(set_to_none=True)
            loss_value = 0.0
            for idx in indices:
                row = rows['clean_train'][idx]
                u = row['unit_id']
                clean = states['clean_train'][u]
                real = states['pred_train'].get(u)
                loss = loss_unit(head, clean, real, row['target_fraction'], supervision[u].get('predicted'))
                need(bool(torch.isfinite(loss)), 'LOSS_FINITE')
                (loss / len(indices)).backward()
                loss_value += float(loss.detach()) / len(indices)
            grad = torch.nn.utils.clip_grad_norm_(head.parameters(), 1.0, error_if_nonfinite=True)
            optimizer.step()
            step += 1
            need(all((bool(torch.isfinite(x).all()) for x in head.parameters())), 'PARAMETER_FINITE')
            log(out / 'events.jsonl', {'event': 'joint_update', 'epoch': epoch, 'step': step, 'total': p['epochs'] * math.ceil(n / p['batch']), 'batch_positions': len(indices), 'loss': loss_value, 'gradient_norm': float(grad), 'time': time.time()})
        ep = out / ('epoch' + str(epoch))
        ep.mkdir()
        save_file(head.state_dict(), str(ep / 'joint_head.safetensors'))
        for kind in ('clean_development', 'pred_development'):
            pp, m = evaluate(kind)
            write(ep / (kind + '_predictions.json'), pp)
            write(ep / (kind + '_metrics.json'), m)
            if kind == 'pred_development':
                selected_metrics = m
        candidates.append({'epoch': epoch, 'metrics': selected_metrics, 'head_sha256': sha(ep / 'joint_head.safetensors')})
    selected = choose(candidates, base['pred_development'])
    return {'candidates': candidates, 'selected': selected, 'retained_development': base, 'steps': step}

def work(root):
    out = root / OUT
    try:
        p, ev, allrows, caches = preflight(root)
        import torch
        from safetensors.torch import load_file
        import model_v2
        from joint import JointRefiner
        from core import metrics
        repair_module = load_module('frozen_ordinal_algorithm', root / p['prior_package'] / 'correction.py')
        need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and (not torch.cuda.is_initialized()), 'CPU_ONLY')
        need(torch.__version__ == p['torch_version'], 'TORCH_VERSION')
        torch.set_num_threads(2)
        torch.manual_seed(p['seed'])
        teacher = model_v2.make_head(2560)
        teacher.load_state_dict(load_file(str(root / p['teacher_source'] / 'epoch1/head.safetensors')))
        repair = repair_module.ResponsibilityRepair()
        repair.load_state_dict(load_file(str(root / p['retained_source'] / 'epoch4/repair_head.safetensors')))
        for model in (teacher, repair):
            model.eval()
            model.requires_grad_(False)
        snapshots = [{k: v.clone() for k, v in model.state_dict().items()} for model in (teacher, repair)]
        rows = {k: allrows[k] for k in ('clean_train', 'pred_train', 'clean_development', 'pred_development')}

        def check():
            need(time.time() - read(out / 'started.json')['time'] < p['max_seconds'], 'TIME_BUDGET_RESULTS_RETAINED')
        states = {}
        head = JointRefiner()
        count = 0
        replay_max = 0.0
        need(sum((x.numel() for x in head.parameters())) == p['parameters'], 'PARAMETER_COUNT')
        for kind in rows:
            states[kind] = {}
            reference = {x['unit_id']: x for x in read(root / p['retained_source'] / 'epoch4' / (kind + '_predictions.json'))} if 'development' in kind else None
            for row in rows[kind]:
                check()
                u = row['unit_id']
                if row['status'] != 'READY':
                    if reference is not None:
                        ev.check_result(reference[u], row)
                    continue
                f = load_file(caches[kind][u]['absolute_feature_path'], device='cpu')
                need(set(f) == {'operations', 'last'} and f['operations'].shape == (len(row['operation_positions']), 2560) and (f['last'].shape == (2560,)), 'FEATURE_SHAPE')
                need(all((bool(torch.isfinite(x).all()) for x in f.values())), 'FEATURE_FINITE')
                entry = caches[kind][u]
                with torch.no_grad():
                    state = repair_module.make_state(teacher, f['operations'], torch.cat([f['operations'], f['last'][None]], 0), torch.tensor(row['b_share']), torch.tensor((entry['first'] + entry['second']) / 2, dtype=torch.float64))
                    rr = repair(state)
                    state.update(prediction=rr['prediction'].detach(), responsibility=rr['responsibility'].detach(), operations=f['operations'], last=f['last'])
                    need(float(head(state)['prediction']) == float(state['prediction']), 'ZERO_IDENTITY')
                    if reference is not None:
                        ev.check_result(reference[u], row)
                        diff = abs(float(state['prediction']) - reference[u]['prediction_fraction'])
                        need(diff <= 1e-12, 'RETAINED_REPLAY_DIFFERENCE')
                        replay_max = max(replay_max, diff)
                states[kind][u] = state
                count += 1
            log(out / 'events.jsonl', {'event': 'frozen_states_ready', 'kind': kind, 'records': len(states[kind]), 'time': time.time()})
        write(out / 'identity_replay.json', {'zero_head_exact_records': count, 'development_max_difference': replay_max, 'best_teacher_and_epoch4_repair': True})
        result = train_fit(head, states, rows, read(root / p['teacher_source'] / 'supervision.json'), p, out, metrics, check)
        need(result['steps'] == 464, 'STEP_COUNT')
        for model, snapshot in zip((teacher, repair), snapshots):
            need(all((torch.equal(snapshot[k], v) for k, v in model.state_dict().items())), 'RETAINED_WEIGHTS_CHANGED')
        check()
        preflight(root)
        check()
        need(not torch.cuda.is_initialized(), 'CUDA_UNEXPECTED')
        write(out / 'selection.json', dict(result, rule=p['selection'], plan_sha256=sha(HERE / 'plan.json'), package_manifest_sha256=sha(HERE / 'SHA256SUMS')))
        selected = result['selected']
        delta = None
        if selected:
            delta = {k: selected['metrics'][k]['failure_penalized_MAE_pp'] - result['retained_development']['pred_development'][k]['failure_penalized_MAE_pp'] for k in ('overall', 'computer_science')}
        write(out / 'summary.json', {'status': 'DEVELOPMENT_PASS_OFFICIAL_NOT_RUN' if selected else 'DEVELOPMENT_GATE_FAILED_KEEP_BEST', 'selected_epoch': selected['epoch'] if selected else None, 'development_delta_MAE_pp': delta, 'steps': 464, 'parameters': p['parameters'], 'retained_unchanged': True, 'table_updated': False, 'official_inference': False, 'GPU_used': False, 'elapsed_seconds': time.time() - read(out / 'started.json')['time']})
    except BaseException as e:
        if not (out / 'failure.json').exists():
            write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'error': repr(e), 'traceback': traceback.format_exc()})
        raise

def monitor(root):
    out = root / OUT
    p = read(HERE / 'plan.json')
    with (out / 'worker.log').open('x') as f:
        child = subprocess.Popen([sys.executable, '-u', '-B', str(HERE / 'driver.py'), 'work', '--project-root', str(root)], stdout=f, stderr=subprocess.STDOUT)
        write(out / 'worker_pid.json', {'pid': child.pid})
        try:
            code = child.wait(timeout=p['max_seconds'])
        except subprocess.TimeoutExpired:
            child.terminate()
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
            if not (out / 'failure.json').exists():
                write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'error': '30_MINUTE_LIMIT_OWN_CHILD_STOPPED_RESULTS_RETAINED'})
            return
        if code != 0 and (not (out / 'failure.json').exists()):
            write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'error': 'CHILD_EXIT_' + str(code)})

def launch(root):
    package_check()
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU_ONLY')
    out = root / OUT
    need(not out.exists(), 'OUTPUT_EXISTS_USE_SHOW')
    out.mkdir(parents=True)
    write(out / 'started.json', {'time': time.time()})
    write(out / 'plan.json', read(HERE / 'plan.json'))
    with (out / 'monitor.log').open('x') as f:
        child = subprocess.Popen([sys.executable, '-u', '-B', str(HERE / 'driver.py'), 'monitor', '--project-root', str(root)], stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'pid.json', {'pid': child.pid})
    print('\u5df2\u63d0\u4ea4CPU\u4e0a\u4e0b\u6587\u8054\u5408\u4fee\u6b63\uff5c\u4ec5\u8bad\u7ec3/\u5f00\u53d1\uff0c\u6682\u4e0d\u5b98\u65b9\u8bc4\u4f30\uff5c30\u5206\u949f\u4e0a\u9650\uff5cPID=' + str(child.pid))

def show(root):
    out = root / OUT
    if not out.exists():
        print('\u5c1a\u672a\u542f\u52a8')
        return
    if (out / 'failure.json').exists():
        print('\u6267\u884c\u4e2d\u65ad\uff0c\u539f\u6700\u4f73\u7248\u4fdd\u7559\uff5c' + read(out / 'failure.json')['error'])
        return
    if (out / 'summary.json').exists():
        s = read(out / 'summary.json')
        print('\u72b6\u6001\uff1a' + s['status'])
        if s['development_delta_MAE_pp']:
            d = s['development_delta_MAE_pp']
            print('\u5f00\u53d1\u76f8\u5bf9\u5f53\u524d\u6700\u4f73MAE\u5dee\uff1a%+.4f / %+.4f\uff08\u8d1f\u503c\u6539\u5584\uff09\uff1b\u5c1a\u672a\u5b98\u65b9\u8bc4\u4f30' % (d['overall'], d['computer_science']))
        else:
            print('\u5f00\u53d1\u95e8\u69db\u672a\u8fc7\uff1b\u5f53\u524d\u6700\u4f73\u6a21\u578b\u548c\u8868\u683c\u4e0d\u53d8')
        return
    if (out / 'events.jsonl').exists():
        line = (out / 'events.jsonl').read_text().splitlines()[-1]
        e = json.loads(line)
        if e['event'] == 'joint_update':
            print('CPU\u8054\u5408\u4fee\u6b63\uff1a%s/464\u6b65\uff5c\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u5b58\u6d3b' % e['step'])
        else:
            print('\u51c6\u5907\u51bb\u7ed3\u7279\u5f81\uff1a%s / %s\u6761\uff5c\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u5b58\u6d3b' % (e['kind'], e['records']))
    else:
        print('\u6765\u6e90\u6838\u9a8c\u4e0e\u6210\u529f\u6a21\u578b\u56de\u653e\u4e2d\uff5c\u4e0d\u91cd\u65b0\u751f\u6210A/B')
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['launch', 'monitor', 'work', 'show', 'preflight'])
    parser.add_argument('--project-root', required=True)
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    if args.command == 'preflight':
        preflight(root)
        print('PASS_CPU_SOURCE_CACHE_CHECK_NO_TRAINING')
    else:
        globals()[args.command](root)
