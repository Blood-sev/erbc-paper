"""Context-conditioned joint responsibility/mass refinement of the frozen best C.

No label, subject identifier or sample ID is consumed by forward().
The update is a difference of two structured expectations, not a scalar shortcut.
"""
import math
import torch
from torch import nn

class JointRefiner(nn.Module):

    def __init__(self, hidden=2560, width=32):
        super().__init__()
        self.hidden = hidden
        self.width = width
        self.norm = nn.LayerNorm(hidden, elementwise_affine=False)
        self.local_norm = nn.LayerNorm(width, elementwise_affine=False)
        self.project = nn.Linear(hidden, width)
        self.merge = nn.Linear(3 * width + 9, width)
        self.query = nn.Linear(width, width)
        self.key = nn.Linear(width, width)
        self.value = nn.Linear(width, width)
        self.fuse = nn.Linear(2 * width, width)
        self.out = nn.Linear(width, 4)
        nn.init.zeros_(self.out.weight)
        nn.init.zeros_(self.out.bias)

    def forward(self, s):
        h = s['operations'].float()
        last = s['last'].float()
        q = s['responsibility'].float()
        m = s['mass'].float()
        local = s['local'].float()
        b = s['b_onehot'].float()
        n = h.shape[0]
        if h.shape != (n, self.hidden) or n == 0 or last.shape != (self.hidden,):
            raise RuntimeError('FEATURE_SHAPE')
        if q.shape != (n, 3) or m.shape != (n,) or local.shape != (n, self.width) or (b.shape != (n, 3)):
            raise RuntimeError('STATE_SHAPE')
        hp = self.project(self.norm(h))
        ep = self.project(self.norm(last))
        u = torch.nn.functional.gelu(self.merge(torch.cat([hp, ep.expand(n, -1), self.local_norm(local), q, b, s['prediction'].float().expand(n, 1), s['gate'].float().expand(n, 1), m.clamp_min(1e-12).log()[:, None]], -1)))
        context = torch.cat([hp, ep[None]], 0)
        attention = (self.query(u) @ self.key(context).T / math.sqrt(self.width)).softmax(-1)
        z = torch.nn.functional.gelu(self.fuse(torch.cat([u, attention @ self.value(context)], -1)))
        shifts = self.out(z)
        qlog = q.clamp_min(1e-06).log()
        mlog = m.clamp_min(1e-12).log()
        q0 = qlog.softmax(-1)
        m0 = mlog.softmax(-1)
        qnew = (qlog + 4 * shifts[:, :3].tanh()).softmax(-1)
        mnew = (mlog + shifts[:, 3].tanh()).softmax(-1)
        v = q.new_tensor([0, 0.5, 1], dtype=torch.float64)
        base_term = m0.double() * (q0.double() * v).sum(-1)
        new_term = mnew.double() * (qnew.double() * v).sum(-1)
        delta = (new_term - base_term).sum()
        prediction = (s['prediction'].double() + s['gate'].double() * delta).clamp(0, 1)
        qkl = (m0 * (qnew * (qnew.clamp_min(1e-12).log() - q0.clamp_min(1e-12).log())).sum(-1)).sum().clamp_min(0)
        mkl = (mnew * (mnew.clamp_min(1e-12).log() - m0.clamp_min(1e-12).log())).sum().clamp_min(0)
        return {'prediction': prediction, 'responsibility': qnew, 'mass': mnew, 'base_responsibility': q0, 'base_mass': m0, 'q_KL': qkl, 'm_KL': mkl, 'operation_delta': s['gate'].double() * (new_term - base_term), 'preclip_delta': s['gate'].double() * delta, 'attention': attention}

def local_losses(out, supervision):
    q = out['responsibility']
    m = out['mass']
    mask = torch.tensor(supervision['mask'], dtype=torch.bool, device=q.device)
    if mask.shape != (len(q),):
        raise RuntimeError('SUPERVISION_MASK')
    zero = q.sum() * 0
    if not bool(mask.any()):
        return (zero, zero)
    target = torch.tensor(supervision['responsibility'], dtype=q.dtype, device=q.device)
    counts = torch.tensor(supervision['counts'], dtype=m.dtype, device=m.device)
    if target.shape != q.shape or counts.shape != m.shape:
        raise RuntimeError('SUPERVISION_SHAPE')
    if not bool((counts[mask] > 0).all()) or not bool(torch.isfinite(target[mask]).all()):
        raise RuntimeError('SUPERVISION_VALUES')
    if not bool((target[mask] >= 0).all()) or not torch.allclose(target[mask].sum(-1), torch.ones_like(counts[mask]), atol=1e-06):
        raise RuntimeError('SUPERVISION_PROBABILITY')
    ordinal = 0.5 * (q[mask].cumsum(-1)[:, :2] - target[mask].cumsum(-1)[:, :2]).abs().sum(-1).mean()
    omega = counts[mask] / counts[mask].sum()
    mm = m[mask] / m[mask].sum().clamp_min(1e-12)
    mass_loss = (omega * (omega.log() - mm.clamp_min(1e-12).log())).sum().clamp_min(0)
    return (ordinal, mass_loss)

def loss_unit(head, clean, real, target, supervision):
    c = head(clean)
    dc = (c['prediction'] - clean['prediction']).abs()
    if real is None:
        return 0.05 * dc + 0.01 * c['q_KL'] + 0.01 * c['m_KL']
    z = head(real)
    error = (z['prediction'] - target).abs()
    prior = (real['prediction'] - target).abs()
    ordinal, mass = local_losses(z, supervision)
    return error + 0.1 * (error - prior).clamp_min(0) + 0.02 * (z['prediction'] - real['prediction']).abs() + 0.05 * dc + 0.01 * z['q_KL'] + 0.01 * z['m_KL'] + 0.05 * ordinal + 0.02 * mass

def choose(candidates, retained):
    keys = ('overall', 'computer_science')
    name = 'failure_penalized_MAE_pp'
    eligible = [x for x in candidates if all((x['metrics'][k][name] <= retained[k][name] + 1e-10 for k in keys)) and any((x['metrics'][k][name] < retained[k][name] - 1e-10 for k in keys))]
    return min(eligible, key=lambda x: (x['metrics']['overall'][name], x['metrics']['computer_science'][name], x['epoch'])) if eligible else None
