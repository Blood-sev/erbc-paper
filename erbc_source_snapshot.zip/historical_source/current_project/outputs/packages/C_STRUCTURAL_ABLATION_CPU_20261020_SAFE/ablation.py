"""Ordered responsibility, count-normalized mass, bounded relational attention.
Frozen retained predictions are an anchor; no label or subject enters forward.
"""
import torch
from torch import nn
import torch.nn.functional as F

class AblationRefiner(nn.Module):

    def __init__(self, hidden=2560, width=32, responsibility=True, mass=True, context=True):
        super().__init__()
        self.width = width
        self.hidden = hidden
        if width % 2:
            raise ValueError('EVEN_WIDTH_REQUIRED')
        if not (responsibility or mass):
            raise ValueError('AT_LEAST_ONE_BRANCH')
        self.q_enabled = responsibility
        self.m_enabled = mass
        self.context_enabled = context
        self.norm = nn.LayerNorm(hidden, elementwise_affine=False)
        self.local_norm = nn.LayerNorm(width, elementwise_affine=False)
        self.project = nn.Linear(hidden, width)
        self.query = nn.Linear(width, width)
        self.key = nn.Linear(width, width)
        self.value = nn.Linear(width, width)
        self.responsibility = nn.Sequential(nn.Linear(4 * width + 9, width), nn.GELU(), nn.Linear(width, 2))
        self.count = nn.Sequential(nn.Linear(4 * width + 9, width), nn.GELU(), nn.Linear(width, 1))
        for branch in (self.responsibility, self.count):
            nn.init.zeros_(branch[-1].weight)
            nn.init.zeros_(branch[-1].bias)
        if not responsibility:
            self.responsibility.requires_grad_(False)
        if not mass:
            self.count.requires_grad_(False)
        if not context:
            for module in (self.query, self.key, self.value):
                module.requires_grad_(False)

    def forward(self, s):
        h = s['operations'].float()
        n = len(h)
        if n < 1 or h.ndim != 2:
            raise RuntimeError('EMPTY_OR_INVALID_OPERATIONS')
        if h.shape != (n, self.hidden) or s['last'].shape != (self.hidden,) or s['local'].shape != (n, self.width):
            raise RuntimeError('FEATURE_SHAPE')
        if s['responsibility'].shape != (n, 3) or s['mass'].shape != (n,) or s['b_onehot'].shape != (n, 3):
            raise RuntimeError('STATE_SHAPE')
        hp = self.project(self.norm(h))
        global_state = self.project(self.norm(s['last'].float()))
        qh = F.normalize(self.query(hp).reshape(n, 2, -1).transpose(0, 1), dim=-1, eps=1e-06)
        kh = F.normalize(self.key(hp).reshape(n, 2, -1).transpose(0, 1), dim=-1, eps=1e-06)
        vh = self.value(hp).reshape(n, 2, -1).transpose(0, 1)
        logits = 4 * (qh @ kh.transpose(-1, -2))
        if n > 1:
            logits = logits.masked_fill(torch.eye(n, dtype=torch.bool, device=h.device)[None], float('-inf'))
        attention = logits.softmax(-1)
        context = (attention @ vh).transpose(0, 1).reshape(n, self.width)
        if not self.context_enabled:
            context = torch.zeros_like(context)
            global_state = torch.zeros_like(global_state)
        q = s['responsibility'].float()
        m = s['mass'].float()
        x = torch.cat([hp, context, global_state.expand(n, -1), self.local_norm(s['local'].float()), q, s['b_onehot'].float(), s['prediction'].float().expand(n, 1), s['gate'].float().expand(n, 1), m.clamp_min(1e-12).log()[:, None]], -1)
        shift = 3 * self.responsibility(x).tanh() if self.q_enabled else x.new_zeros(n, 2)
        u = (q[:, 0] + q[:, 1]).clamp(1e-05, 1 - 1e-05)
        r = (q[:, 0] / (q[:, 0] + q[:, 1]).clamp_min(1e-12)).clamp(1e-05, 1 - 1e-05)
        natural = torch.stack([torch.logit(u), torch.logit(r)], -1)

        def probabilities(t):
            v = t.sigmoid()
            a, b = (v[:, 0], v[:, 1])
            return torch.stack([a * b, a * (1 - b), 1 - a], -1)
        q0 = probabilities(natural)
        qnew = probabilities(natural + shift)
        prior = (n * m).clamp_min(1e-06)
        inv = prior + torch.log(-torch.expm1(-prior))
        count0 = F.softplus(inv)
        counts = F.softplus(inv + 3 * self.count(x).squeeze(-1).tanh()) if self.m_enabled else count0
        m0 = count0 / count0.sum()
        mnew = counts / counts.sum().clamp_min(1e-12)
        v = q.new_tensor([0.0, 0.5, 1.0], dtype=torch.float64)
        base = m0.double() * (q0.double() * v).sum(-1)
        new = mnew.double() * (qnew.double() * v).sum(-1)
        contribution = s['gate'].double() * (new - base)
        prediction = (s['prediction'].double() + contribution.sum()).clamp(0, 1)
        qkl = (m0 * (qnew * (qnew.clamp_min(1e-12).log() - q0.clamp_min(1e-12).log())).sum(-1)).sum().clamp_min(0)
        mkl = (mnew * (mnew.clamp_min(1e-12).log() - m0.clamp_min(1e-12).log())).sum().clamp_min(0)
        return {'prediction': prediction, 'responsibility': qnew, 'mass': mnew, 'predicted_counts': counts, 'base_responsibility': q0, 'base_mass': m0, 'attention': attention if self.context_enabled else None, 'q_KL': qkl, 'm_KL': mkl, 'operation_delta': contribution}

def local_loss(z, sup):
    q = z['responsibility']
    mask = torch.tensor(sup['mask'], dtype=torch.bool, device=q.device)
    zero = q.sum() * 0
    if mask.shape != (len(q),):
        raise RuntimeError('MASK_SHAPE')
    if not bool(mask.any()):
        return (zero, zero)
    r = torch.tensor(sup['responsibility'], dtype=q.dtype, device=q.device)
    c = torch.tensor(sup['counts'], dtype=q.dtype, device=q.device)
    if r.shape != q.shape or c.shape != (len(q),):
        raise RuntimeError('LABEL_SHAPE')
    if not bool(torch.isfinite(r[mask]).all() and (r[mask] >= 0).all() and torch.isfinite(c[mask]).all() and (c[mask] > 0).all()):
        raise RuntimeError('LOCAL_LABEL')
    if not torch.allclose(r[mask].sum(-1), torch.ones_like(c[mask]), atol=1e-06):
        raise RuntimeError('LOCAL_PROBABILITY')
    ordinal = 0.5 * (q[mask].cumsum(-1)[:, :2] - r[mask].cumsum(-1)[:, :2]).abs().sum(-1).mean()
    counts = F.smooth_l1_loss(z['predicted_counts'][mask].clamp_min(1e-06).log(), c[mask].log(), beta=0.5)
    return (ordinal, counts)
ARMS = {'q_local': dict(responsibility=True, mass=False, context=False), 'm_local': dict(responsibility=False, mass=True, context=False), 'qm_local': dict(responsibility=True, mass=True, context=False), 'q_context': dict(responsibility=True, mass=False, context=True), 'm_context': dict(responsibility=False, mass=True, context=True), 'qm_context': dict(responsibility=True, mass=True, context=True)}
WEIGHTS = {'MAE': 1.0, 'excess': 0.1, 'pred_drift': 0.02, 'clean_drift': 0.05, 'q_KL': 0.01, 'm_KL': 0.01, 'ordinal': 0.05, 'log_count': 0.02}

def loss_parts(head, clean, real, target, sup):
    c = head(clean)
    zero = c['prediction'] * 0
    parts = {k: zero for k in WEIGHTS}
    parts['clean_drift'] = (c['prediction'] - clean['prediction']).abs()
    if real is None:
        parts['q_KL'] = c['q_KL']
        parts['m_KL'] = c['m_KL']
    else:
        z = head(real)
        error = (z['prediction'] - target).abs()
        base = (real['prediction'] - target).abs()
        ordinal, counts = local_loss(z, sup)
        parts.update(MAE=error, excess=(error - base).clamp_min(0), pred_drift=(z['prediction'] - real['prediction']).abs(), q_KL=z['q_KL'], m_KL=z['m_KL'], ordinal=ordinal if head.q_enabled else zero, log_count=counts if head.m_enabled else zero)
    return (sum((WEIGHTS[k] * v for k, v in parts.items())), parts)
