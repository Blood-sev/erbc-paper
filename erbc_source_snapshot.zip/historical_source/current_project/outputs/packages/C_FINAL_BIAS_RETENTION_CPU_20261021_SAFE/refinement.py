"""One final paired experiment: only reduce internal-bias retention 0.02 -> 0.005."""
import importlib.util, math
ARMS = ('control', 'relaxed_bias')
KEYS = ('overall', 'computer_science')
SOURCE = None

def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def configure(path):
    global SOURCE
    spec = importlib.util.spec_from_file_location('frozen_success_objective', path)
    SOURCE = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(SOURCE)

def new_loss(head, clean, pred, y, sup, tc, tp, arm):
    need(arm in ARMS and SOURCE is not None, 'OBJECTIVE')
    _, terms = SOURCE.new_loss(head, clean, pred, y, sup, tc, tp, 'success_reference')
    terms = dict(terms)
    if arm == 'relaxed_bias':
        for k in ('clean_bias', 'pred_bias'):
            if k in terms:
                terms[k] = terms[k] * 0.25
    return (sum(terms.values()), terms)

def choose(runs, seeds):
    by = {(r['arm'], r['seed']): r for r in runs}
    need(len(by) == len(runs) == len(ARMS) * len(seeds) and set(by) == {(a, s) for a in ARMS for s in seeds}, 'RUNS')
    checks = []
    for seed in seeds:
        for a in ARMS:
            r = by[a, seed]
            need(r['epoch'] == 4, 'FIXED_EPOCH')
            for d in r['delta'].values():
                need(set(d) == set(KEYS) and all((math.isfinite(x) for x in d.values())), 'METRICS')
        d = by['relaxed_bias', seed]['delta']
        c = by['control', seed]['delta']
        checks.append(dict(seed=seed, audit_nonworse=all((x <= 1e-10 for x in d['pred_audit'].values())), dev_improves=all((x <= 1e-10 for x in d['pred_development'].values())) and any((x < -1e-10 for x in d['pred_development'].values())), beats_control_audit=d['pred_audit']['overall'] < c['pred_audit']['overall'] - 1e-10, beats_control_dev=d['pred_development']['overall'] < c['pred_development']['overall'] - 1e-10))
    passed = all((all((v for k, v in c.items() if k != 'seed')) for c in checks))
    return dict(candidate=by['relaxed_bias', seeds[0]] if passed else None, checks=checks, rule='One fixed coefficient .005; relaxed_bias seed20261020 epoch4 only. Both-seed audit/dev checks and paired control advantage. No epoch/official search or fallback substitution.')
