import argparse, importlib, os, subprocess, sys, time, traceback
from pathlib import Path
from core import need, read, write, log, sha, digest, batches, metrics
from robust import output, batch_backward, sam_step, official_decision
HERE = Path(__file__).resolve().parent
OUT = 'outputs/C\u8d23\u4efb\u8fc1\u79fb\u6700\u7ec8\u4e00\u6b21\u6297\u566a\u5f3a\u5316_20261018_v1'

def preflight(root):
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_HASH')
    p = read(HERE / 'plan.json')
    for rel, h in p['pins'].items():
        need(sha(root / rel) == h, 'SOURCE_HASH:' + rel)
    sys.path.insert(0, str(root / p['official_package']))
    ev = importlib.import_module('evaluate')
    ev.preflight(root)
    src = root / p['source']
    datasets = {k: read(src / (k + '.json')) for k in ('clean_train', 'pred_train', 'clean_development', 'pred_development', 'clean_official')}
    caches = read(src / 'feature_sources.json')
    pred = read(src / 'predicted_feature_manifest.json')
    for part in ('train', 'development'):
        caches['pred_' + part] = {u: e for u, e in pred.items() if e['partition'] == part}
    for kind, rows in datasets.items():
        need(len(rows) == len({x['unit_id'] for x in rows}) == (925 if kind.endswith('train') else 148 if kind.endswith('official') else 156), 'MEMBERSHIP')
        ready = {x['unit_id']: x for x in rows if x['status'] == 'READY'}
        need(set(caches[kind]) == set(ready), 'CACHE_MEMBERSHIP')
        for u, x in ready.items():
            f = caches[kind][u]
            need(all((x[k] == f[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256', 'operation_positions'))), 'FEATURE_IDENTITY')
            need(digest(x['input_ids']) == x['token_ids_sha256'], 'TOKENS_CHANGED')
            fp = Path(f['absolute_feature_path']).resolve()
            need(fp.is_relative_to(root) and sha(fp) == f['feature_sha256'], 'FEATURE_HASH')
            need(all((type(f[k]) in (int, float) and 0 <= f[k] <= 1 for k in ('first', 'second'))), 'FROZEN_BRANCH')
    need(sum((x['status'] == 'READY' for x in datasets['pred_train'])) == 856, 'TRAIN_VIEW_SCOPE')
    train = {x['unit_id']: x for x in datasets['clean_train']}
    need(set(train) == {x['unit_id'] for x in datasets['pred_train']}, 'PAIRED_IDS')
    for x in datasets['pred_train']:
        need(x['target_fraction'] == train[x['unit_id']]['target_fraction'], 'PAIRED_LABEL')
    return (p, ev, datasets, caches)

def launch(root):
    need(os.environ.get('CUDA_VISIBLE_DEVICES') == '', 'CPU_ONLY')
    p = read(HERE / 'plan.json')
    out = root / OUT
    need(not out.exists(), 'OUTPUT_EXISTS_USE_SHOW')
    out.mkdir(parents=True)
    write(out / 'plan.json', p)
    write(out / 'started.json', {'time': time.time(), 'max_seconds': p['max_seconds']})
    with (out / 'worker.log').open('x') as f:
        child = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'work', '--project-root', str(root)], stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'pid.json', {'pid': child.pid})
    print('\u5df2\u63d0\u4ea4\u4e00\u6b21CPU\u5c0f\u5934\u5f3a\u5316\uff5c\u6700\u591a116\u6b65\uff0f15\u5206\u949f\uff5c\u539f\u6210\u529f\u65b9\u6848\u4e0d\u52a8\uff5cPID=' + str(child.pid))

def work(root):
    out = root / OUT

    def check():
        need(time.time() - read(out / 'started.json')['time'] < 900, 'TIME_LIMIT_KEEP_RETAINED')
    try:
        check()
        p, ev, rows, caches = preflight(root)
        check()
        import torch
        from safetensors.torch import load_file, save_file
        from algorithm import make_head, loss_terms
        need(os.environ.get('CUDA_VISIBLE_DEVICES') == '' and (not torch.cuda.is_initialized()), 'CPU_ONLY')
        need(torch.__version__ == p['torch_version'], 'TORCH_VERSION')
        torch.set_num_threads(2)
        torch.manual_seed(p['seed'])
        head = make_head(2560)
        head.load_state_dict(load_file(str(root / p['source'] / 'epoch1/head.safetensors'), device='cpu'))
        head.eval()
        arm = {'output': p['source'], 'selected_epoch': 1, 'model_version': 2}
        write(out / 'starting_replay.json', ev.replay_development(root, arm, head, load_file, torch))
        features = {}
        teachers = {}
        for kind in ('clean_train', 'pred_train'):
            features[kind] = {}
            teachers[kind] = {}
            for x in rows[kind]:
                check()
                if x['status'] != 'READY':
                    continue
                u = x['unit_id']
                f = load_file(caches[kind][u]['absolute_feature_path'], device='cpu')
                need(set(f) == {'last', 'operations'} and f['last'].shape == (2560,) and (f['operations'].shape == (len(x['operation_positions']), 2560)), 'FEATURE_SHAPE')
                need(all((bool(torch.isfinite(v).all()) for v in f.values())), 'FEATURE_FINITE')
                features[kind][u] = f
                with torch.no_grad():
                    teachers[kind][u] = float(output(head, x, f, caches[kind][u])['prediction'])
        write(out / 'frozen_teacher_training_predictions.json', teachers)
        supervision = read(root / p['source'] / 'supervision.json')
        trainrows = {'clean_train': rows['clean_train'], 'pred_by_id': {x['unit_id']: x for x in rows['pred_train']}}
        optimizer = torch.optim.AdamW(head.parameters(), lr=p['learning_rate'], betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01)
        head.train()
        queue = batches(925, 1)
        need(len(queue) == 116 and len(queue[-1]) == 5, 'STEPS')
        for step, items in enumerate(queue, 1):
            closure = lambda: batch_backward(head, items, trainrows, features, caches, supervision, teachers, loss_terms, check)
            rec = sam_step(head, optimizer, closure, p['rho'])
            check()
            log(out / 'events.jsonl', dict(event='sam_step', step=step, total=116, time=time.time(), **rec))
        check()
        save_file(head.state_dict(), str(out / 'head.safetensors'))
        write(out / 'selected.json', {'rule': 'Only terminal116-step head; no checkpoint or hyperparameter search', 'head_sha256': sha(out / 'head.safetensors')})
        for kind in ('clean_development', 'pred_development'):
            check()
            pp = ev.calculate(head, 2, rows[kind], caches[kind], load_file, torch)
            write(out / (kind + '_predictions.json'), pp)
            write(out / (kind + '_metrics.json'), metrics(pp))
        check()
        pp = ev.calculate(head, 2, rows['clean_official'], caches['clean_official'], load_file, torch)
        mm = metrics(pp)
        write(out / 'official_predictions.json', pp)
        retained = read(root / p['retained_official'] / 'summary.json')['candidates'][0]['metrics']
        decision = official_decision(mm, retained)
        check()
        preflight(root)
        check()
        need(not torch.cuda.is_initialized(), 'CUDA_UNEXPECTED')
        write(out / 'summary.json', {'status': 'COMPLETE', 'official_metrics': mm, 'retained_metrics': retained, **decision, 'training_updates': 116, 'extra_forward_backward_passes_per_update': 2, 'B247_unchanged': True, 'official_adaptive_use': True, 'table_updated': False, 'original_models_unchanged': True, 'GPU_used': False, 'elapsed_seconds': time.time() - read(out / 'started.json')['time']})
    except BaseException as e:
        write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_KEEP_RETAINED', 'error': repr(e), 'traceback': traceback.format_exc(), 'not_model_score': True})
        raise

def show(root):
    out = root / OUT
    if not out.exists():
        print('\u5c1a\u672a\u542f\u52a8')
        return
    if (out / 'failure.json').exists():
        print('\u6267\u884c\u4e2d\u65ad\uff0c\u4fdd\u7559\u5df2\u6210\u529f\u65b9\u6848\uff5c' + read(out / 'failure.json')['error'])
        return
    if (out / 'summary.json').exists():
        s = read(out / 'summary.json')
        m = s['official_metrics']
        d = s['delta_vs_retained_MAE_pp']
        print('\u72b6\u6001\uff1a' + s['decision'])
        print('\u5b98\u65b9\u60e9\u7f5aMAE\uff1a%.4f / %.4f\uff5c\u76f8\u5bf9\u5df2\u6210\u529f\u7248\uff1a%+.4f / %+.4f\uff08\u8d1f\u503c\u6539\u5584\uff09' % (m['overall']['failure_penalized_MAE_pp'], m['computer_science']['failure_penalized_MAE_pp'], d['overall'], d['computer_science']))
        return
    ev = out / 'events.jsonl'
    if ev.exists():
        lines = ev.read_text().splitlines()
        last = __import__('json').loads(lines[-1])
        print('CPU\u6297\u566a\u5f3a\u5316\uff1a%d/116\u6b65\uff5c\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u8fdb\u7a0b\u5b58\u6d3b' % last['step'])
    else:
        print('\u6765\u6e90\u6838\u9a8c\uff0f\u7f13\u5b58\u4e0e\u6210\u529f\u5934\u56de\u653e\u51c6\u5907\u4e2d\uff5c\u672a\u91cd\u65b0\u751f\u6210A/B')
if __name__ == '__main__':
    a = argparse.ArgumentParser()
    a.add_argument('command', choices=['launch', 'work', 'show', 'preflight'])
    a.add_argument('--project-root', required=True)
    x = a.parse_args()
    root = Path(x.project_root).resolve()
    if x.command == 'preflight':
        preflight(root)
        print('PASS_FROZEN_FEATURES_CPU_NO_TRAINING')
    else:
        globals()[x.command](root)
