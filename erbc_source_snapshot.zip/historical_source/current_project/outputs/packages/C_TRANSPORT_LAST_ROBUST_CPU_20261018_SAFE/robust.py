"""One bounded SAM refinement, with frozen successful-head retention."""
import math
from core import need

def preservation(prediction, teacher, target):
    y = prediction.new_tensor(target)
    t = prediction.new_tensor(teacher)
    return 0.5 * ((prediction - y).abs() - (t - y).abs()).clamp_min(0) + 0.02 * (prediction - t).abs()

def sam_step(model, optimizer, closure, rho=0.01):
    import torch
    optimizer.zero_grad(set_to_none=True)
    first = closure()
    params = [p for p in model.parameters() if p.requires_grad]
    need(all((p.grad is None or bool(torch.isfinite(p.grad).all()) for p in params)), 'NONFINITE_FIRST_GRADIENT')
    norm = torch.sqrt(sum((p.grad.double().square().sum() for p in params if p.grad is not None)))
    need(bool(torch.isfinite(norm)), 'NONFINITE_GRAD_NORM')
    saved = [p.detach().clone() for p in params]
    try:
        with torch.no_grad():
            for p in params:
                if p.grad is not None:
                    p.add_(p.grad, alpha=rho / (float(norm) + 1e-12))
        optimizer.zero_grad(set_to_none=True)
        second = closure()
        torch.nn.utils.clip_grad_norm_(params, 1.0, error_if_nonfinite=True)
    finally:
        with torch.no_grad():
            for p, v in zip(params, saved):
                p.copy_(v)
    optimizer.step()
    need(all((bool(torch.isfinite(p).all()) for p in params)), 'NONFINITE_UPDATED_HEAD')
    return {'loss': first, 'perturbed_loss': second, 'gradient_norm': float(norm)}

def output(head, row, feature, entry):
    import torch
    ctx = torch.cat([feature['operations'], feature['last'][None]], 0)
    anchor = (entry['first'] + entry['second']) / 2
    return head(feature['operations'], ctx, torch.tensor(row['b_share']), torch.tensor(anchor, dtype=torch.float64))

def batch_backward(head, items, rows, features, caches, supervision, teacher_predictions, loss_terms, check):
    """Unit-balanced view averaging; no development or official labels in updates."""
    value = 0.0
    for i in items:
        check()
        x = rows['clean_train'][i]
        u = x['unit_id']
        pred = rows['pred_by_id'][u]
        paired = pred['status'] == 'READY'
        scale = 1 / (len(items) * (2 if paired else 1))
        z = output(head, x, features['clean_train'][u], caches['clean_train'][u])
        q = z['responsibility'].detach()
        loss = loss_terms(z, x['target_fraction'], supervision[u]['clean'], protect_clean=True)
        loss = loss + preservation(z['prediction'], teacher_predictions['clean_train'][u], x['target_fraction'])
        value += float(loss.detach()) * scale
        (loss * scale).backward()
        if paired:
            z = output(head, pred, features['pred_train'][u], caches['pred_train'][u])
            loss = loss_terms(z, pred['target_fraction'], supervision[u]['predicted'], q, supervision[u]['mapping'])
            loss = loss + preservation(z['prediction'], teacher_predictions['pred_train'][u], pred['target_fraction'])
            value += float(loss.detach()) * scale
            (loss * scale).backward()
    need(math.isfinite(value), 'NONFINITE_LOSS')
    return value

def official_decision(candidate, retained):
    delta = {g: candidate[g]['failure_penalized_MAE_pp'] - retained[g]['failure_penalized_MAE_pp'] for g in ('overall', 'computer_science')}
    ok = all((x <= 0 for x in delta.values())) and any((x < 0 for x in delta.values()))
    return {'improved': ok, 'delta_vs_retained_MAE_pp': delta, 'decision': 'NEW_CANDIDATE_IMPROVES_RETAINED' if ok else 'STOP_OPTIMIZATION_KEEP_RETAINED'}
