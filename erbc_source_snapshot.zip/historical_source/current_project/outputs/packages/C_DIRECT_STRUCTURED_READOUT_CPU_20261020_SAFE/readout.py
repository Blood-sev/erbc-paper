"""Input-only responsibility/mass learning; readout is the only arm difference."""
import torch
from torch import nn
import torch.nn.functional as F
ARMS = ('anchored', 'direct')
WEIGHTS = {'MAE': 1.0, 'excess': 0.1, 'pred_drift': 0.02, 'clean_drift': 0.05, 'q_KL': 0.01, 'm_KL': 0.01, 'ordinal': 0.05, 'relative_count': 0.02}

class StructuredReadout(nn.Module):

    def __init__(self, dim=2560, width=32, arm='direct'):
        super().__init__()
        if arm not in ARMS:
            raise ValueError('ARM')
        self.arm = arm
        self.project = nn.Linear(dim, width)
        self.context = nn.Sequential(nn.Linear(3 * width + 7, 64), nn.GELU(), nn.Linear(64, width), nn.GELU())
        self.q_head = nn.Linear(width, 3)
        self.m_head = nn.Linear(width, 1)
        for head in (self.q_head, self.m_head):
            nn.init.zeros_(head.weight)
            nn.init.zeros_(head.bias)

    def forward(self, s):
        h = s['operations'].float()
        last = s['last'].float()
        x = F.gelu(self.project(F.layer_norm(h, (h.shape[-1],))))
        glob = F.gelu(self.project(F.layer_norm(last, (last.shape[-1],))))
        q0 = s['responsibility'].double().clamp_min(1e-12)
        q0 = q0 / q0.sum(-1, keepdim=True)
        m0 = s['mass'].double().clamp_min(1e-12)
        m0 = m0 / m0.sum()
        z = self.context(torch.cat((x, x.mean(0).expand_as(x), glob.expand_as(x), s['b_onehot'].float(), q0.float(), m0.float()[:, None]), -1))
        dq = self.q_head(z).double()
        dm = self.m_head(z).squeeze(-1).double()
        q = (q0.log() + dq).softmax(-1)
        m = (m0.log() + dm).softmax(0)
        v = q.new_tensor([0.0, 0.5, 1.0])
        aggregate = (m * (q @ v)).sum()
        refq = q0.log().softmax(-1)
        refm = m0.log().softmax(0)
        reference = (refm * (refq @ v)).sum()
        raw = s['prediction'].double() + s['gate'].double() * (aggregate - reference)
        p = aggregate if self.arm == 'direct' else raw.clamp(0, 1)
        return dict(prediction=p, responsibility=q, mass=m, aggregate=aggregate, base_responsibility=refq, base_mass=refm, reference_aggregate=reference, q_shift=dq, m_shift=dm, q_KL=(refm * (q * (q.clamp_min(1e-12).log() - refq.log())).sum(-1)).sum().clamp_min(0), m_KL=(m * (m.clamp_min(1e-12).log() - refm.log())).sum().clamp_min(0))

def local_terms(z, sup):
    zero = z['prediction'] * 0
    if sup is None:
        return (zero, zero)
    mask = torch.as_tensor(sup['mask'], dtype=torch.bool)
    if mask.numel() != len(z['mass']):
        raise ValueError('SUPERVISION_SHAPE')
    if not mask.any():
        return (zero, zero)
    r = torch.as_tensor(sup['responsibility'], dtype=torch.float64)[mask]
    c = torch.as_tensor(sup['counts'], dtype=torch.float64)[mask]
    if not (torch.isfinite(r).all() and (r >= 0).all() and torch.allclose(r.sum(-1), torch.ones(len(r), dtype=r.dtype), atol=1e-06) and torch.isfinite(c).all() and (c > 0).all()):
        raise ValueError('LOCAL_TARGET_INVALID')
    q = z['responsibility'][mask]
    ordinal = 0.5 * (q.cumsum(-1)[:, :2] - r.cumsum(-1)[:, :2]).abs().sum(-1).mean()
    omega = c / c.sum()
    partial = z['mass'][mask]
    partial = partial / partial.sum()
    rel = (omega * (omega.log() - partial.clamp_min(1e-12).log())).sum().clamp_min(0)
    return (ordinal, rel)

def loss_parts(head, clean, real, target, sup):
    cz = head(clean)
    zero = cz['prediction'] * 0
    parts = {k: zero for k in WEIGHTS}
    parts['clean_drift'] = (cz['prediction'] - clean['prediction']).abs()
    if real is None:
        parts.update(q_KL=cz['q_KL'], m_KL=cz['m_KL'])
    else:
        z = head(real)
        e = (z['prediction'] - target).abs()
        ordinal, relative = local_terms(z, sup)
        parts.update(MAE=e, excess=(e - (real['prediction'] - target).abs()).clamp_min(0), pred_drift=(z['prediction'] - real['prediction']).abs(), q_KL=z['q_KL'], m_KL=z['m_KL'], ordinal=ordinal, relative_count=relative)
    return (sum((WEIGHTS[k] * v for k, v in parts.items())), parts)

def gradient_diagnostics(head, batch):
    params = list(head.parameters())
    parts = {}
    for clean, real, target, sup in batch:
        _, v = loss_parts(head, clean, real, target, sup)
        for k in WEIGHTS:
            parts[k] = parts.get(k, 0) + WEIGHTS[k] * v[k] / len(batch)
    vectors = {}
    for k, v in parts.items():
        grads = torch.autograd.grad(v, params, retain_graph=True, allow_unused=True)
        vectors[k] = torch.cat([(torch.zeros_like(p) if g is None else g).detach().double().flatten() for p, g in zip(params, grads)])
    norms = {k: float(v.norm()) for k, v in vectors.items()}
    return dict(weighted_norms=norms, cosine_to_MAE={k: float(v @ vectors['MAE'] / (norms[k] * norms['MAE'])) if norms[k] * norms['MAE'] > 1e-15 else None for k, v in vectors.items()}, scope='First shuffled training batch each epoch; not full-training causal attribution.')
