"""Controlled count-gradient coupling study; no labels enter forward()."""
import torch
from torch import nn
import torch.nn.functional as F
from retained_routing import SelectiveRouting, local_loss as old_local_loss, bind_state
ARMS = {'coupled': (True, False, True), 'separated': (True, False, True)}
WEIGHTS = {'MAE': 1.0, 'excess': 0.1, 'pred_drift': 0.02, 'clean_drift': 0.05, 'q_KL': 0.01, 'm_KL': 0.01, 'ordinal': 0.05, 'log_count': 0.02, 'relative_count': 0.02}

class AllocationRefiner(SelectiveRouting):

    def __init__(self, width=32, arm='separated'):
        if arm not in ARMS:
            raise ValueError('ARM')
        super().__init__(width=width, arm='local_global')
        self.study_arm = arm
        self.total_head = nn.Sequential(nn.Linear(2 * width + 2, 16), nn.GELU(), nn.Linear(16, 1))
        nn.init.zeros_(self.total_head[-1].weight)
        nn.init.zeros_(self.total_head[-1].bias)

    def forward(self, s):
        z = super().forward(s)
        logm = s['mass'].clamp_min(1e-12).log()
        m0 = logm.softmax(0)
        m = (logm + z['m_shift']).softmax(0)
        total0 = s['predicted_counts'].sum()
        inp = torch.cat((s['local_channel'].float().mean(0), s['global_channel'].float().mean(0), s['prediction'].float().reshape(1), total0.float().log().reshape(1)))
        total_shift = 2 * self.total_head(inp).squeeze().tanh()
        total = total0 * total_shift.exp()
        counts = total * m
        counts_for_loss = total * (m.detach() if self.study_arm == 'separated' else m)
        q = z['responsibility']
        q0 = z['base_responsibility']
        v = q.new_tensor([0, 0.5, 1.0], dtype=torch.float64)
        delta = s['gate'].double() * (m.double() * (q.double() @ v) - m0.double() * (q0.double() @ v))
        z.update(mass=m, base_mass=m0, predicted_counts=counts, counts_for_loss=counts_for_loss, total_count=total, total_shift=total_shift, operation_delta=delta, prediction=(s['prediction'].double() + delta.sum()).clamp(0, 1), q_KL=(m0 * (q * (q.clamp_min(1e-12).log() - q0.clamp_min(1e-12).log())).sum(-1)).sum().clamp_min(0), m_KL=(m * (m.clamp_min(1e-12).log() - m0.clamp_min(1e-12).log())).sum().clamp_min(0), mass_stabilization_max=(m0 - s['mass']).abs().max())
        return z

def local_components(z, sup):
    ordinal, _ = old_local_loss(z, sup)
    zero = z['responsibility'].sum() * 0
    if sup is None or not any(sup['mask']):
        return (ordinal, zero, zero)
    mask = torch.tensor(sup['mask'], dtype=torch.bool, device=z['mass'].device)
    counts = torch.tensor(sup['counts'], dtype=z['mass'].dtype, device=z['mass'].device)[mask]
    log_count = F.smooth_l1_loss(z['counts_for_loss'][mask].clamp_min(1e-12).log(), counts.log(), beta=0.5)
    omega = counts / counts.sum()
    partial = z['mass'][mask]
    partial = partial / partial.sum()
    relative = (omega * (omega.log() - partial.clamp_min(1e-12).log())).sum().clamp_min(0)
    return (ordinal, log_count, relative)

def local_loss(z, sup):
    a, b, _ = local_components(z, sup)
    return (a, b)

def loss_parts(head, clean, real, target, sup):
    c = head(clean)
    zero = c['prediction'] * 0
    parts = {k: zero for k in WEIGHTS}
    parts['clean_drift'] = (c['prediction'] - clean['prediction']).abs()
    if real is None:
        parts.update(q_KL=c['q_KL'], m_KL=c['m_KL'])
    else:
        z = head(real)
        error = (z['prediction'] - target).abs()
        ordinal, count, relative = local_components(z, sup)
        parts.update(MAE=error, excess=(error - (real['prediction'] - target).abs()).clamp_min(0), pred_drift=(z['prediction'] - real['prediction']).abs(), q_KL=z['q_KL'], m_KL=z['m_KL'], ordinal=ordinal, log_count=count, relative_count=relative)
    return (sum((WEIGHTS[k] * v for k, v in parts.items())), parts)

def gradient_alignment(head, batch):
    params = [p for p in head.parameters() if p.requires_grad]
    totals = {}
    for clean, real, target, sup in batch:
        _, parts = loss_parts(head, clean, real, target, sup)
        for k in WEIGHTS:
            totals[k] = totals.get(k, 0) + WEIGHTS[k] * parts[k] / len(batch)
    vectors = {}
    for key, value in totals.items():
        grads = torch.autograd.grad(value, params, retain_graph=True, allow_unused=True)
        vectors[key] = torch.cat([(torch.zeros_like(p) if g is None else g).detach().double().flatten() for p, g in zip(params, grads)])
    norms = {k: float(v.norm()) for k, v in vectors.items()}
    cos = {}
    for key in WEIGHTS:
        if key == 'MAE':
            continue
        den = norms['MAE'] * norms[key]
        cos['MAE_vs_' + key] = float(vectors['MAE'] @ vectors[key] / den) if den > 1e-15 else None
    groupnorm = {}
    for key, value in totals.items():
        grads = torch.autograd.grad(value, params, retain_graph=True, allow_unused=True)
        groups = {}
        names = [n for n, p in head.named_parameters() if p.requires_grad]
        for name, param, grad in zip(names, params, grads):
            groups[name.split('.')[0]] = groups.get(name.split('.')[0], 0) + (0.0 if grad is None else float(grad.detach().double().square().sum()))
        groupnorm[key] = {k: v ** 0.5 for k, v in groups.items()}
    return dict(weighted_gradient_norms=norms, cosines=cos, per_loss_parameter_group_norms=groupnorm, batch_size=len(batch), scope='First shuffled train batch per epoch; sampled gradient diagnostics, not causal proof.')
