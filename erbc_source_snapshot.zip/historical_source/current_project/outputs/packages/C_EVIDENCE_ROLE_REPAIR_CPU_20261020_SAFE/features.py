"""Only the exact, already retained model messages; no labels or source-ID embeddings."""
import hashlib, json, math, re, zlib
from pathlib import Path
DIM = 512
PARTS = ('clean_train', 'pred_train', 'clean_development', 'pred_development')
ROLES = {'student': 0, 'assistant': 1, 'submission': 2}

def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def digest(x):
    return hashlib.sha256(json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def bag(segments):
    counts = {}
    for segment in segments:
        text = re.sub('\\s+', ' ', segment.casefold()).strip()
        for n in (2, 3):
            for i in range(max(0, len(text) - n + 1)):
                h = zlib.crc32((str(n) + ':' + text[i:i + n]).encode('utf8'))
                k = h % DIM
                counts[k] = counts.get(k, 0) + (1 if h & 2147483648 else -1)
    x = [0.0] * DIM
    for k, c in counts.items():
        if c:
            x[k] = math.copysign(math.log1p(abs(c)), c)
    norm = math.sqrt(math.fsum((v * v for v in x)))
    return [v / norm for v in x] if norm else x

def make_features(body):
    ops = body['confirmed_operations']
    docs = body['evidence']
    need(isinstance(ops, list) and bool(ops) and isinstance(docs, list), 'EMPTY_OR_INVALID_OPERATIONS')
    ids = [d['source_id'] for d in docs]
    need(len(set(ids)) == len(ids), 'DUPLICATE_SOURCE')
    links = []
    missing = []
    for op in ops:
        refs = {str(r.get('source_id') or r.get('message_id')) for r in op.get('evidence_refs', []) if r.get('source_id') or r.get('message_id')}
        links.append([int(k in refs) for k in ids])
        missing.append(len(refs - set(ids)) / max(1, len(refs)))
    if not docs:
        return dict(op_bags=[bag([o['operation']]) for o in ops], doc_bags=[[0.0] * DIM], roles=[3], links=[[0] for _ in ops], missing=missing, lengths=[0.0], real_doc=[0])
    return dict(op_bags=[bag([o['operation']]) for o in ops], doc_bags=[bag([s['text'] for s in d['segments']]) for d in docs], roles=[ROLES.get(d['speaker'], 3) for d in docs], links=links, missing=missing, lengths=[math.log1p(sum((len(s['text']) for s in d['segments']))) / 10 for d in docs], real_doc=[1] * len(docs))

def selected_body(raw, row):
    variants = [v for v in raw['variants'] if v['audit'] == row['input_audit']]
    need(len(variants) == 1, 'EXACT_INPUT_VARIANT')
    msg = variants[0]['messages']
    need(digest(msg) == row['input_audit']['messages_sha256'], 'MESSAGES_CHANGED')
    body = json.loads(msg[1]['content'])
    need([o['operation_id'] for o in body['confirmed_operations']] == row['operation_ids'], 'OPERATION_ORDER')
    return body

def prepare(root, teacher_plan, rows, check=lambda: None, encode=True):
    need(set(rows) == set(PARTS), 'NO_OFFICIAL_DATA_ALLOWED')
    features = {}
    bindings = {}
    counts = {}
    for part in PARTS:
        check()
        base = teacher_plan['predicted_data' if part.startswith('pred') else 'old_data']
        path = root / base / ('train.jsonl' if part.endswith('train') else 'development.jsonl')
        records = [json.loads(l) for l in path.read_text(encoding='utf8').splitlines() if l.strip()]
        raw = {r['unit_id']: r for r in records}
        need(len(raw) == len(records) == len(rows[part]) and set(raw) == {r['unit_id'] for r in rows[part]}, 'RAW_MEMBER_IDS')
        features[part] = {}
        bindings[part] = {}
        counts[part] = dict(valid=0, operations=0, documents=0, top_level_operations_before_evidence=0)
        for row in rows[part]:
            check()
            if row['status'] != 'READY':
                need(row['status'] == 'UPSTREAM_BLOCKED', 'EXECUTION_FAILURE_NOT_SCORE')
                continue
            u = row['unit_id']
            b = selected_body(raw[u], row)
            n = len(b['confirmed_operations'])
            need(n > 0, 'NO_OPERATIONS')
            if encode:
                features[part][u] = make_features(b)
            bindings[part][u] = dict(messages_sha256=row['input_audit']['messages_sha256'], token_ids_sha256=row['token_ids_sha256'], body_sha256=digest(b), operation_ids=row['operation_ids'], source_ids=[d['source_id'] for d in b['evidence']], feature_sha256=digest(features[part][u]) if encode else None)
            c = counts[part]
            c['valid'] += 1
            c['operations'] += n
            c['documents'] += len(b['evidence'])
            c['top_level_operations_before_evidence'] += list(b).index('confirmed_operations') < list(b).index('evidence')
    return (features, bindings, counts)

def select(runs, seeds):
    by = {(r['arm'], r['seed']): r for r in runs}
    need(len(by) == len(runs) == 4 and set(by) == {(a, s) for a in ('hidden', 'evidence') for s in seeds}, 'RUN_SET')
    need(all((r['epoch'] == 4 and all((math.isfinite(v) for view in r['delta'].values() for v in view.values())) for r in runs)), 'INVALID_RESULT')
    report = {}
    for arm in ('hidden', 'evidence'):
        rr = [by[arm, s] for s in seeds]
        report[arm] = dict(mean_delta={view: {k: sum((r['delta'][view][k] for r in rr)) / 2 for k in ('overall', 'computer_science')} for view in ('pred_development', 'clean_development')})
    improves = all((all((by['evidence', s]['delta']['pred_development'][k] <= 0 for k in ('overall', 'computer_science'))) and by['evidence', s]['delta']['pred_development']['overall'] < 0 for s in seeds))
    beats = all((by['evidence', s]['delta']['pred_development']['overall'] < by['hidden', s]['delta']['pred_development']['overall'] for s in seeds))
    return dict(arms=report, both_seeds_improve=improves, evidence_beats_hidden_both=beats, candidate=by['evidence', seeds[0]] if improves and beats else None, official_not_run=True, rule='Epoch4/first seed fixed. Evidence must improve predicted-development overall and not worsen CS in both seeds, and beat paired hidden control overall. Clean view disclosed, not veto. No magnitude/significance guarantee.')
