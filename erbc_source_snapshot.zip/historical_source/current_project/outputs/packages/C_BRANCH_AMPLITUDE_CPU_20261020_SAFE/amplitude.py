"""Independent positive amplitude control of frozen, successful q/count directions."""
import math
import torch
from torch import nn
import torch.nn.functional as F

def probabilities(t):
    v = t.sigmoid()
    a, b = (v[:, 0], v[:, 1])
    return torch.stack([a * b, a * (1 - b), 1 - a], -1)

@torch.no_grad()
def freeze_state(head, s):
    """Reconstruct the pinned last head exactly, then cache unlabeled conditions."""
    h = s['operations'].float()
    n = len(h)
    hp = head.project(head.norm(h))
    global_state = head.project(head.norm(s['last'].float()))
    qh = F.normalize(head.query(hp).reshape(n, 2, -1).transpose(0, 1), dim=-1, eps=1e-06)
    kh = F.normalize(head.key(hp).reshape(n, 2, -1).transpose(0, 1), dim=-1, eps=1e-06)
    vh = head.value(hp).reshape(n, 2, -1).transpose(0, 1)
    logits = 4 * (qh @ kh.transpose(-1, -2))
    if n > 1:
        logits = logits.masked_fill(torch.eye(n, dtype=torch.bool)[None], float('-inf'))
    attention = logits.softmax(-1)
    context = (attention @ vh).transpose(0, 1).reshape(n, head.width)
    q = s['responsibility'].float()
    m = s['mass'].float()
    x = torch.cat([hp, context, global_state.expand(n, -1), head.local_norm(s['local'].float()), q, s['b_onehot'].float(), s['prediction'].float().expand(n, 1), s['gate'].float().expand(n, 1), m.clamp_min(1e-12).log()[:, None]], -1)
    u = (q[:, 0] + q[:, 1]).clamp(1e-05, 1 - 1e-05)
    ratio = (q[:, 0] / (q[:, 0] + q[:, 1]).clamp_min(1e-12)).clamp(1e-05, 1 - 1e-05)
    natural = torch.stack([torch.logit(u), torch.logit(ratio)], -1)
    prior = (n * m).clamp_min(1e-06)
    inv = prior + torch.log(-torch.expm1(-prior))
    dq = 3 * head.responsibility(x).tanh()
    dm = 3 * head.count(x).squeeze(-1).tanh()
    old = head(s)
    qr = probabilities(natural + dq)
    counts = F.softplus(inv + dm)
    mr = counts / counts.sum().clamp_min(1e-12)
    for a, b in ((qr, old['responsibility']), (mr, old['mass']), (counts, old['predicted_counts']), (attention, old['attention'])):
        if not torch.equal(a, b):
            raise RuntimeError('FROZEN_DIRECTION_REPLAY_MISMATCH')
    condition = torch.cat([hp, context, global_state.expand(n, -1), head.local_norm(s['local'].float()), qr, s['b_onehot'].float(), old['prediction'].float().expand(n, 1), s['gate'].float().expand(n, 1), mr.clamp_min(1e-12).log()[:, None]], -1)
    return {k: v.detach().clone() for k, v in dict(condition=condition, q_natural=natural, q_direction=dq, count_natural=inv, count_direction=dm, responsibility=qr, mass=mr, predicted_counts=counts, prediction=old['prediction'], gate=s['gate'], attention=attention).items()}

class AmplitudeRefiner(nn.Module):

    def __init__(self, width=32):
        super().__init__()
        self.width = width
        self.q_enabled = True
        self.m_enabled = True
        self.q_scale = nn.Sequential(nn.Linear(4 * width + 9, width), nn.GELU(), nn.Linear(width, 1))
        self.m_scale = nn.Sequential(nn.Linear(4 * width + 9, width), nn.GELU(), nn.Linear(width, 1))
        for branch in (self.q_scale, self.m_scale):
            nn.init.zeros_(branch[-1].weight)
            nn.init.zeros_(branch[-1].bias)

    def forward(self, s):
        x = s['condition']
        n = len(x)
        if x.shape != (n, 4 * self.width + 9) or n < 1:
            raise RuntimeError('CONDITION_SHAPE')
        aq = torch.exp(math.log(2) * self.q_scale(x).squeeze(-1).tanh())
        am = torch.exp(math.log(2) * self.m_scale(x).squeeze(-1).tanh())
        q = probabilities(s['q_natural'] + aq[:, None] * s['q_direction'])
        counts = F.softplus(s['count_natural'] + am * s['count_direction'])
        m = counts / counts.sum().clamp_min(1e-12)
        q0 = s['responsibility']
        m0 = s['mass']
        value = q.new_tensor([0, 0.5, 1.0], dtype=torch.float64)
        contribution = s['gate'].double() * (m.double() * (q.double() * value).sum(-1) - m0.double() * (q0.double() * value).sum(-1))
        prediction = (s['prediction'].double() + contribution.sum()).clamp(0, 1)
        qkl = (m0 * (q * (q.clamp_min(1e-12).log() - q0.clamp_min(1e-12).log())).sum(-1)).sum().clamp_min(0)
        mkl = (m * (m.clamp_min(1e-12).log() - m0.clamp_min(1e-12).log())).sum().clamp_min(0)
        return dict(prediction=prediction, responsibility=q, mass=m, predicted_counts=counts, base_responsibility=q0, base_mass=m0, attention=s['attention'], q_KL=qkl, m_KL=mkl, operation_delta=contribution, q_scale=aq, m_scale=am)
ARMS = {'amplitude': {}}
WEIGHTS = {'MAE': 1.0, 'excess': 0.1, 'pred_drift': 0.02, 'clean_drift': 0.05, 'q_KL': 0.01, 'm_KL': 0.01, 'ordinal': 0.05, 'log_count': 0.02}

def local_loss(z, sup):
    q = z['responsibility']
    mask = torch.tensor(sup['mask'], dtype=torch.bool)
    zero = q.sum() * 0
    if mask.shape != (len(q),):
        raise RuntimeError('MASK_SHAPE')
    if not bool(mask.any()):
        return (zero, zero)
    r = torch.tensor(sup['responsibility'], dtype=q.dtype)
    c = torch.tensor(sup['counts'], dtype=q.dtype)
    if r.shape != q.shape or c.shape != (len(q),):
        raise RuntimeError('LABEL_SHAPE')
    if not bool(torch.isfinite(r[mask]).all() and (r[mask] >= 0).all() and torch.isfinite(c[mask]).all() and (c[mask] > 0).all()):
        raise RuntimeError('LOCAL_LABEL')
    if not torch.allclose(r[mask].sum(-1), torch.ones_like(c[mask]), atol=1e-06):
        raise RuntimeError('LOCAL_PROBABILITY')
    return (0.5 * (q[mask].cumsum(-1)[:, :2] - r[mask].cumsum(-1)[:, :2]).abs().sum(-1).mean(), F.smooth_l1_loss(z['predicted_counts'][mask].clamp_min(1e-06).log(), c[mask].log(), beta=0.5))

def loss_parts(head, clean, real, target, sup):
    c = head(clean)
    zero = c['prediction'] * 0
    parts = {k: zero for k in WEIGHTS}
    parts['clean_drift'] = (c['prediction'] - clean['prediction']).abs()
    if real is None:
        parts.update(q_KL=c['q_KL'], m_KL=c['m_KL'])
    else:
        z = head(real)
        error = (z['prediction'] - target).abs()
        base = (real['prediction'] - target).abs()
        ordinal, counts = local_loss(z, sup)
        parts.update(MAE=error, excess=(error - base).clamp_min(0), pred_drift=(z['prediction'] - real['prediction']).abs(), q_KL=z['q_KL'], m_KL=z['m_KL'], ordinal=ordinal, log_count=counts)
    return (sum((WEIGHTS[k] * v for k, v in parts.items())), parts)
