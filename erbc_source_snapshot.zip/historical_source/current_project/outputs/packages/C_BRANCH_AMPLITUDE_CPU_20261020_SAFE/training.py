"""One fixed-seed amplitude candidate, structured train/development diagnostics; no official evaluation."""
import gzip, hashlib, json, math, random, time
from pathlib import Path
import torch
from safetensors.torch import save_file
from amplitude import AmplitudeRefiner, ARMS, WEIGHTS, loss_parts, local_loss
PARTITIONS = {'clean_train', 'pred_train', 'clean_development', 'pred_development'}

def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def write(path, obj):
    with Path(path).open('x', encoding='utf8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)

def emit(path, obj):
    with Path(path).open('a', encoding='utf8') as f:
        f.write(json.dumps(obj, ensure_ascii=False, allow_nan=False) + '\n')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def weights_digest(model):
    h = hashlib.sha256()
    for k, v in sorted(model.state_dict().items()):
        h.update(k.encode())
        h.update(v.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()

def avg(xs):
    return math.fsum(xs) / len(xs) if xs else None

def subset_metrics(rows):
    errors = []
    pen = []
    for x in rows:
        if x['status'] == 'PASS':
            e = 100 * (x['prediction_fraction'] - x['target_fraction'])
            errors.append(e)
            pen.append(abs(e))
        else:
            need(x['status'] == 'UPSTREAM_BLOCKED', 'INVALID_METRIC_STATUS')
            pen.append(100.0)
    return {'records': len(rows), 'successes': len(errors), 'failures': len(rows) - len(errors), 'failure_penalized_MAE_pp': avg(pen), 'failure_penalized_RMSE_pp': math.sqrt(avg([x * x for x in pen])) if pen else None, 'successful_only_Bias_pp': avg(errors)}

def select_train_trace_ids(rows, states, limit=64):
    """Input-based fixed strata; no target, error, or candidate prediction used."""
    groups = {}
    for row in rows:
        u = row['unit_id']
        if u not in states:
            continue
        n = len(states[u]['mass'])
        key = (row['subject'], 1 if n == 1 else 2 if n <= 5 else 3)
        groups.setdefault(key, []).append(u)
    for ids in groups.values():
        ids.sort(key=lambda u: hashlib.sha256(('diagnostic:' + u).encode()).hexdigest())
    chosen = []
    while len(chosen) < limit and any(groups.values()):
        for key in sorted(groups):
            if groups[key] and len(chosen) < limit:
                chosen.append(groups[key].pop(0))
    return chosen

def operation_trace(row, state, z, sup=None):
    q = z['responsibility']
    q0 = z['base_responsibility']
    m = z['mass']
    m0 = z['base_mass']
    v = q.new_tensor([0, 0.5, 1.0], dtype=torch.float64)
    g = state['gate'].double()
    eq = q.double() @ v
    eq0 = q0.double() @ v
    dq = g * (m0.double() * (eq - eq0)).sum()
    dm = g * ((m.double() - m0.double()) * eq).sum()
    need(abs(float(dq + dm - z['operation_delta'].sum())) < 1e-12, 'DECOMPOSITION')
    need(abs(float((state['prediction'] + z['operation_delta'].sum()).clamp(0, 1) - z['prediction'])) < 1e-12, 'TRACE_RECONSTRUCTION')
    n = len(m)
    a = z['attention']
    entropy = None
    if a is not None and n > 2:
        entropy = float(-(a * a.clamp_min(1e-12).log()).sum(-1).mean() / math.log(n - 1))
    scalar = {'operation_count': n, 'retained_prediction': float(state['prediction']), 'prediction': float(z['prediction']), 'prediction_shift_pp': 100 * float(z['prediction'] - state['prediction']), 'q_term_pp': 100 * float(dq), 'm_term_pp': 100 * float(dm), 'mass_TV': float(0.5 * (m - m0).abs().sum()), 'responsibility_TV_mean': float(0.5 * (q - q0).abs().sum(-1).mean()), 'expected_responsibility_shift_pp': 100 * float((eq - eq0).mean()), 'estimated_total_KSA_count': float(z['predicted_counts'].sum()), 'attention_entropy_normalized': entropy, 'q_KL': float(z['q_KL']), 'm_KL': float(z['m_KL']), 'q_scale_mean': float(z['q_scale'].mean()), 'm_scale_mean': float(z['m_scale'].mean()), 'q_scale_min': float(z['q_scale'].min()), 'q_scale_max': float(z['q_scale'].max()), 'm_scale_min': float(z['m_scale'].min()), 'm_scale_max': float(z['m_scale'].max()), 'clip_active': bool((state['prediction'] + z['operation_delta'].sum() < 0) | (state['prediction'] + z['operation_delta'].sum() > 1)), 'matched_operations': None, 'local_ordinal_W1': None, 'local_log_count_loss': None}
    if sup is not None:
        ordinal, counts = local_loss(z, sup)
        scalar.update(matched_operations=sum(sup['mask']), local_ordinal_W1=float(ordinal), local_log_count_loss=float(counts))
    trace = {'unit_id': row['unit_id'], 'token_ids_sha256': row['token_ids_sha256'], 'operation_positions': row.get('operation_positions'), 'frozen_gate': float(g), **scalar, **{k: z[k].tolist() for k in ('responsibility', 'base_responsibility', 'mass', 'base_mass', 'predicted_counts', 'operation_delta', 'q_scale', 'm_scale')}, 'attention': a.tolist() if a is not None else None}
    if sup is not None:
        trace['training_matching_supervision'] = sup
    return (scalar, trace)

def evaluate(head, rows, states, metrics, path, kind, check, supervision=None, trace_ids=None):
    """Full membership metrics; full development traces; stratified training traces."""
    path.mkdir(parents=True, exist_ok=True)
    pred = []
    base = []
    scalars = []
    ids = set(trace_ids or [])
    tracepath = path / (kind + '_operation_traces.jsonl.gz')
    with gzip.open(tracepath, 'xt', encoding='utf8', compresslevel=3) as out, torch.no_grad():
        if head is not None:
            head.eval()
        for row in rows:
            check()
            u = row['unit_id']
            p = {k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'status')}
            b = dict(p)
            if row['status'] == 'READY':
                state = states[u]
                reference = float(state['prediction'])
                b.update(status='PASS', prediction_fraction=reference, token_ids_sha256=row['token_ids_sha256'])
                value = reference
                if head is not None:
                    z = head(state)
                    value = float(z['prediction'])
                    need(math.isfinite(value) and 0 <= value <= 1, 'PREDICTION_FINITE')
                    sup = supervision[u]['predicted'] if supervision is not None and kind == 'pred_train' else None
                    scalar, trace = operation_trace(row, state, z, sup)
                    scalar.update(unit_id=u, subject=row['subject'], target=row['target_fraction'], retained_error_pp=100 * abs(reference - row['target_fraction']), error_pp=100 * abs(value - row['target_fraction']))
                    scalars.append(scalar)
                    if 'development' in kind or u in ids:
                        out.write(json.dumps(trace, ensure_ascii=False, allow_nan=False) + '\n')
                p.update(status='PASS', prediction_fraction=value, token_ids_sha256=row['token_ids_sha256'])
            else:
                need(row['status'] == 'UPSTREAM_BLOCKED', 'EXECUTION_FAILURE_IS_NOT_SCORE')
            pred.append(p)
            base.append(b)
    write(path / (kind + '_predictions.json'), pred)
    score = metrics(pred)
    write(path / (kind + '_metrics.json'), score)
    baseby = {x['unit_id']: x for x in base}

    def summary(sub):
        pp = [x for x in pred if x['unit_id'] in sub]
        ss = [x for x in scalars if x['unit_id'] in sub]
        changes = [x['error_pp'] - x['retained_error_pp'] for x in ss]
        numbers = {k: avg([float(x[k]) for x in ss if x[k] is not None]) for k in ('prediction_shift_pp', 'q_term_pp', 'm_term_pp', 'mass_TV', 'responsibility_TV_mean', 'expected_responsibility_shift_pp', 'estimated_total_KSA_count', 'attention_entropy_normalized', 'q_KL', 'm_KL', 'clip_active', 'q_scale_mean', 'm_scale_mean', 'q_scale_min', 'q_scale_max', 'm_scale_min', 'm_scale_max')}
        matched = [x for x in ss if x['matched_operations']]
        numbers.update(local_ordinal_W1_matched_unit_mean=avg([x['local_ordinal_W1'] for x in matched]), local_log_count_loss_matched_unit_mean=avg([x['local_log_count_loss'] for x in matched]), matched_units=len(matched), matched_operations=sum((x['matched_operations'] for x in matched)))
        return {'metrics': subset_metrics(pp), 'retained_metrics': subset_metrics([baseby[x['unit_id']] for x in pp]), 'improved': sum((x < -1e-09 for x in changes)), 'worsened': sum((x > 1e-09 for x in changes)), 'unchanged': sum((abs(x) <= 1e-09 for x in changes)), 'valid_diagnostic_records': len(ss), 'means': numbers}
    groups = {'overall': {x['unit_id'] for x in pred}, 'computer_science': {x['unit_id'] for x in pred if x['subject'].startswith('01_')}}
    for s in sorted({x['subject'] for x in rows}):
        groups['subject:' + s] = {x['unit_id'] for x in rows if x['subject'] == s}
    for name, low, high in [('1', 1, 1), ('2-5', 2, 5), ('6+', 6, 10 ** 9)]:
        groups['operations:' + name] = {x['unit_id'] for x in scalars if low <= x['operation_count'] <= high}
    for i in range(4):
        groups['target_quarter:' + str(i)] = {x['unit_id'] for x in rows if min(3, int(x['target_fraction'] * 4)) == i}
    diagnostics = {k: summary(ids) for k, ids in groups.items() if ids}
    write(path / (kind + '_diagnostics.json'), diagnostics)
    return score

def grad_groups(head):
    groups = {}
    for name, p in head.named_parameters():
        if p.grad is not None:
            groups.setdefault(name.split('.')[0], []).append(float(p.grad.detach().double().square().sum()))
    return {k: math.sqrt(math.fsum(v)) for k, v in groups.items()}

def train_arm(head, states, rows, supervision, p, out, metrics, check, seed, arm, trace_ids):
    need(set(states) == set(rows) == PARTITIONS, 'TRAIN_DEV_ONLY')
    out.mkdir()
    init = weights_digest(head)
    inactive = {k: v.detach().clone() for k, v in head.named_parameters() if not v.requires_grad}
    count = 0
    with torch.no_grad():
        for part in states:
            for s in states[part].values():
                check()
                need(torch.equal(head(s)['prediction'], s['prediction']), 'ZERO_IDENTITY')
                count += 1
    write(out / 'initialization.json', {'seed': seed, 'arm': arm, 'initial_all_weights_sha256': init, 'active_parameters': sum((x.numel() for x in head.parameters() if x.requires_grad)), 'total_parameters': sum((x.numel() for x in head.parameters())), 'zero_identity_records': count, 'flags': ARMS[arm]})
    opt = torch.optim.AdamW([x for x in head.parameters() if x.requires_grad], lr=p['learning_rate'], betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01)
    history = []
    step = 0
    n = len(rows['clean_train'])
    for epoch in range(1, p['epochs'] + 1):
        ep = out / ('epoch' + str(epoch))
        ep.mkdir()
        order = list(range(n))
        random.Random(seed + epoch).shuffle(order)
        write(ep / 'train_order.json', [rows['clean_train'][i]['unit_id'] for i in order])
        head.train()
        for start in range(0, n, p['batch']):
            check()
            indices = order[start:start + p['batch']]
            opt.zero_grad(set_to_none=True)
            means = {k: 0.0 for k in WEIGHTS}
            for i in indices:
                row = rows['clean_train'][i]
                u = row['unit_id']
                loss, parts = loss_parts(head, states['clean_train'][u], states['pred_train'].get(u), row['target_fraction'], supervision[u].get('predicted'))
                need(bool(torch.isfinite(loss)), 'LOSS_FINITE')
                (loss / len(indices)).backward()
                for k, v in parts.items():
                    means[k] += float(v.detach()) / len(indices)
            groups = grad_groups(head)
            grad = torch.nn.utils.clip_grad_norm_(head.parameters(), 1.0, error_if_nonfinite=True)
            opt.step()
            step += 1
            need(all((bool(torch.isfinite(x).all()) for x in head.parameters())), 'PARAMETER_FINITE')
            event = {'event': 'arm_update', 'arm': arm, 'seed': seed, 'epoch': epoch, 'step': step, 'total': p['epochs'] * math.ceil(n / p['batch']), 'batch_positions': len(indices), 'loss_components': means, 'weighted_loss': math.fsum((WEIGHTS[k] * v for k, v in means.items())), 'gradient_norm': float(grad), 'gradient_groups_before_clip': groups, 'time': time.time()}
            emit(out / 'events.jsonl', event)
            emit(out.parent / 'events.jsonl', event)
        for key, value in head.named_parameters():
            if key in inactive:
                need(torch.equal(value, inactive[key]), 'INACTIVE_PARAMETERS_CHANGED')
        save_file(head.state_dict(), str(ep / 'amplitude_head.safetensors'))
        scores = {}
        for kind in ('clean_train', 'pred_train', 'clean_development', 'pred_development'):
            scores[kind] = evaluate(head, rows[kind], states[kind], metrics, ep, kind, check, supervision, trace_ids)
        hist = {'epoch': epoch, 'metrics': scores, 'head_sha256': digest(ep / 'amplitude_head.safetensors'), 'train_order_sha256': digest(ep / 'train_order.json')}
        write(ep / 'epoch_summary.json', hist)
        history.append(hist)
        emit(out.parent / 'events.jsonl', {'event': 'arm_epoch_complete', 'arm': arm, 'seed': seed, 'epoch': epoch, 'metrics': scores['pred_development'], 'time': time.time()})
    result = {'arm': arm, 'seed': seed, 'steps': step, 'initial_sha256': init, 'history': history, 'final': history[-1], 'selection': 'FIXED_EPOCH4_TRAIN_DEVELOPMENT_ONLY'}
    write(out / 'summary.json', result)
    return result
