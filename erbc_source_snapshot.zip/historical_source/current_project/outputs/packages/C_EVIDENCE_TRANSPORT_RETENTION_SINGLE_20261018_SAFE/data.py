"""Freeze paired inputs. Official prompt/token IDs are copied and checked, not redesigned."""
import json
from collections.abc import Mapping
from core import need, read, rows, write, sha, digest, canonical
from algorithm import align, local_labels, supervised_labels
META = ('unit_id', 'subject', 'student_group_id', 'partition', 'target_fraction', 'status')

def extract_ids(x):
    if isinstance(x, Mapping):
        x = x['input_ids']
    if hasattr(x, 'tolist'):
        x = x.tolist()
    if x and isinstance(x[0], list):
        need(len(x) == 1, 'TOKEN_BATCH')
        x = x[0]
    need(isinstance(x, list) and x and all((type(i) == int for i in x)), 'TOKENIZER_FORMAT')
    return x

def array_ends(body, key):
    data = json.loads(body)
    values = data[key]
    prefix = canonical(key) + ':['
    whole = prefix + ','.join((canonical(v) for v in values)) + ']'
    need(body.count(whole) == 1, 'ARRAY_AMBIGUOUS:' + key)
    cursor = body.index(whole) + len(prefix)
    result = []
    for v in values:
        s = canonical(v)
        need(body[cursor:cursor + len(s)] == s, 'ARRAY_SERIALIZATION')
        result.append(cursor + len(s) - 1)
        cursor += len(s) + 1
    return result

def locate(tokenizer, messages, expected=None):
    serialized = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    enc = tokenizer(serialized, add_special_tokens=False, return_offsets_mapping=True)
    ids = extract_ids(enc)
    need(ids == extract_ids(tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)), 'TOKENIZATION_PATH_DIFFERENCE')
    if expected is not None:
        need(ids == expected, 'ORIGINAL_INPUT_TOKEN_CHANGE')
    body = messages[1]['content']
    need(serialized.count(body) == 1, 'BODY_AMBIGUOUS')
    start = serialized.index(body)
    offsets = enc['offset_mapping']

    def position(i):
        hits = [j for j, (lo, hi) in enumerate(offsets) if lo <= start + i < hi]
        need(len(hits) == 1, 'OFFSET_AMBIGUOUS')
        return hits[0]
    op = [position(i) for i in array_ends(body, 'confirmed_operations')]
    ev = [position(i) for i in array_ends(body, 'evidence')]
    ev = sorted(set(ev + [len(ids) - 1]))
    need(op and len(op) == len(set(op)), 'OPERATION_POSITION_COLLISION')
    operations = json.loads(body)['confirmed_operations']
    need(all((x['ai_share'] in (0, 0.5, 1) for x in operations)), 'B_SHARE_SCHEMA')
    return (ids, {'operation_positions': op, 'evidence_positions': ev, 'b_share': [x['ai_share'] for x in operations], 'operation_ids': [x['operation_id'] for x in operations]}, operations)

def select(tokenizer, raw, old=None, old_positions=None):
    r = {k: raw[k] for k in META}
    if r['status'] != 'READY':
        need(r['status'] == 'UPSTREAM_BLOCKED', 'UNKNOWN_INPUT_STATUS')
        return (r, [])
    for variant in raw['variants']:
        if old is not None and variant['audit'] != old['input_audit']:
            continue
        if old is not None:
            need(digest(variant['messages']) == old['input_audit']['messages_sha256'], 'OLD_MESSAGE_HASH')
            need(digest(old['input_ids']) == old['token_ids_sha256'], 'OLD_INPUT_HASH')
            ops = json.loads(variant['messages'][1]['content'])['confirmed_operations']
            need([x['operation_id'] for x in ops] == old_positions['operation_ids'], 'OLD_OP_ORDER')
            need(old_positions['token_ids_sha256'] == old['token_ids_sha256'], 'OLD_POS_HASH')
            need(all((r[k] == old[k] for k in META)), 'OLD_METADATA_CHANGED')
            r.update(input_ids=old['input_ids'], token_ids_sha256=old['token_ids_sha256'], input_audit=old['input_audit'], operation_positions=old_positions['positions'], evidence_positions=[len(old['input_ids']) - 1], b_share=[x['ai_share'] for x in ops], operation_ids=old_positions['operation_ids'])
            return (r, ops)
        ids = extract_ids(tokenizer.apply_chat_template(variant['messages'], tokenize=True, add_generation_prompt=True))
        if len(ids) > 32768:
            continue
        ids, locations, ops = locate(tokenizer, variant['messages'], old['input_ids'] if old else None)
        r.update(input_ids=ids, token_ids_sha256=digest(ids), input_audit=variant['audit'], **locations)
        if old:
            need(all((r[k] == old[k] for k in META)), 'OLD_METADATA_CHANGED')
            need(r['token_ids_sha256'] == old['token_ids_sha256'], 'OLD_TOKEN_HASH_CHANGED')
        return (r, ops)
    raise RuntimeError('FULL_AB_EXCEEDS_FROZEN_TOKEN_BUDGET_NO_SAMPLE_DROPPED:' + r['unit_id'])

def prepare(root, out, plan, tokenizer):
    need(tokenizer.is_fast, 'FAST_TOKENIZER_REQUIRED')
    need([tokenizer.encode(str(i), add_special_tokens=False) for i in range(10)] == [[i] for i in range(15, 25)], 'DIGIT_VOCAB')
    files = {}
    tokens = {}
    opmap = {}
    for part, n in [('train', 925), ('development', 156), ('official', 148)]:
        raw = rows(root / plan['old_data'] / (part + '.jsonl'))
        old = {r['unit_id']: r for r in rows(root / plan['source_output'] / (part + '_tokens.jsonl'))}
        oldpos = {r['unit_id']: r for r in read(root / plan['source_output'] / (part + '_operations.json'))}
        need(len(raw) == len(old) == n and {r['unit_id'] for r in raw} == set(old), 'ORIGINAL_MEMBERSHIP')
        result = []
        opmap['clean_' + part] = {}
        for r in raw:
            x, ops = select(tokenizer, r, old[r['unit_id']], oldpos.get(r['unit_id']))
            result.append(x)
            opmap['clean_' + part][r['unit_id']] = ops
        tokens['clean_' + part] = result
    for part, n in [('train', 925), ('development', 156)]:
        raw = rows(root / plan['predicted_data'] / (part + '.jsonl'))
        result = []
        opmap['pred_' + part] = {}
        clean = {r['unit_id']: r for r in tokens['clean_' + part]}
        need(len(raw) == n and {r['unit_id'] for r in raw} == set(clean), 'PREDICTED_MEMBERSHIP')
        for r in raw:
            need(all((r[k] == clean[r['unit_id']][k] for k in META if k != 'status')), 'PREDICTED_METADATA')
            x, ops = select(tokenizer, r)
            result.append(x)
            opmap['pred_' + part][r['unit_id']] = ops
        tokens['pred_' + part] = result
    annotation = {r['unit_id']: r for r in rows(root / plan['training_annotations'])}
    supervision = {}
    matched = 0
    totalops = 0
    for r in tokens['clean_train']:
        u = r['unit_id']
        cleanops = opmap['clean_train'][u]
        predicted = opmap['pred_train'][u]
        target = local_labels(cleanops, annotation[u]['target']['ksa'])
        scalar = sum((c * (q[1] / 2 + q[2]) for c, q in zip(target['counts'], target['responsibility']))) / sum(target['counts'])
        need(abs(scalar - r['target_fraction']) < 1e-10, 'KSA_SCALAR_LABEL_MISMATCH')
        mapping = align(predicted, cleanops)
        matched += sum((i >= 0 for i in mapping))
        totalops += len(mapping)
        supervision[u] = {'clean': supervised_labels(target, list(range(len(cleanops)))), 'predicted': supervised_labels(target, mapping), 'mapping': mapping}
    idsets = {p: {r['unit_id'] for r in tokens['clean_' + p]} for p in ('train', 'development', 'official')}
    students = {p: {r['student_group_id'] for r in tokens['clean_' + p]} for p in idsets}
    for a, b in [('train', 'development'), ('train', 'official'), ('development', 'official')]:
        need(not idsets[a] & idsets[b] and (not students[a] & students[b]), 'SPLIT_OVERLAP')
    counts = {name: {'records': len(rr), 'ready': sum((r['status'] == 'READY' for r in rr)), 'max_tokens': max((len(r.get('input_ids', [])) for r in rr))} for name, rr in tokens.items()}
    need(counts['pred_train']['ready'] == 856 and counts['pred_development']['ready'] == 141, 'PREDICTED_STATUS_CHANGE')
    need(counts['clean_official']['ready'] == 141, 'OFFICIAL_STATUS_CHANGE')
    for name, rr in tokens.items():
        path = out / (name + '.json')
        write(path, rr)
        files[path.name] = sha(path)
    write(out / 'supervision.json', supervision)
    files['supervision.json'] = sha(out / 'supervision.json')
    report = {'status': 'PASS_TOKENIZED_INPUTS_AND_TRAIN_ONLY_SUPERVISION', 'counts': counts, 'matched_predicted_operations': matched, 'predicted_operations': totalops, 'training_units': 925, 'blocked_predicted_training_views': 69, 'blocked_policy': 'No predicted view for blocked units; keep their clean view, equal unit weight. Never replace failed predicted inputs.', 'official_tokens_unchanged': True, 'files': files, 'plan_sha256': sha(out / 'plan.json')}
    write(out / 'prepared.json', report)
    return report

def verify(out):
    p = read(out / 'prepared.json')
    need(p['plan_sha256'] == sha(out / 'plan.json'), 'PREPARED_PLAN_DRIFT')
    for name, h in p['files'].items():
        need(sha(out / name) == h, 'PREPARED_HASH:' + name)
    return p
