"""User-launched, bounded single-H100 feature extraction and small C-head fitting.

Never generates A/B, never updates a backbone/adapter, never terminates other tasks.
"""
import argparse, csv, gc, io, json, os, signal, socket, subprocess, sys, time, traceback
from pathlib import Path
from core import need, read, write, sha, digest, log, metrics, batches
from data import prepare, verify
from algorithm import make_head, loss_terms, eligibility
HERE = Path(__file__).resolve().parent
OUT = 'outputs/C\u7b97\u6cd5\u5019\u9009_\u8d23\u4efb\u8fc1\u79fb247\u56de\u9000\u4fdd\u62a4_20261018_v2'

def sources(root, weights=True):
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_CHANGED:' + n)
    p = read(HERE / 'plan.json')
    for rel, h in p['pins'].items():
        need(not Path(rel).is_absolute() and '..' not in Path(rel).parts, 'SOURCE_ESCAPE')
        if weights or not rel.endswith('.safetensors'):
            need(sha(root / rel) == h, 'SOURCE_CHANGED:' + rel)
    snap = root / p['snapshot']
    s = read(snap / 'summary.json')
    for n, h in s['artifacts'].items():
        need(sha(snap / n) == h, 'SNAPSHOT_CHANGED:' + n)
    review = root / p['review']
    summary = read(review / 'summary.json')
    need(summary['approved_representative_replay_gate_passed'] and summary['snapshot_unchanged'], 'REVIEW_NOT_PASS')
    expected = read(review / 'plan.json')['references']
    actual = summary['comparisons']
    need(len(actual) == len(expected) == 3, 'REVIEW_COVERAGE')

    def comparable(x):
        if isinstance(x, dict):
            return {k: comparable(v) for k, v in x.items() if k != 'generation_seconds'}
        if isinstance(x, list):
            return [comparable(v) for v in x]
        return x
    for ref, comp in zip(expected, actual):
        need(comp['unit_id'] == ref['unit_id'] and comp['all_AB_content_equal_except_timing'], 'REVIEW_IDENTITY')
        f = review / 'replays' / (digest(ref['unit_id']) + '.json')
        need(sha(f) == comp['replay_sha256'] and sha(snap / ref['snapshot_path']) == ref['sha256'] == comp['reference_sha256'], 'REPLAY_HASH')
        a = read(f)
        b = read(snap / ref['snapshot_path'])
        a.pop('layout', None)
        b.pop('layout', None)
        need(comparable(a) == comparable(b), 'REPLAY_CONTENT_DIFFERENCE')
    need(p['steps'] == 464 and p['epochs'] == 4 and (p['max_wall_seconds'] == 10800), 'BUDGET_CHANGED')
    return p

def table():
    s = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,name,memory.free,memory.total,utilization.gpu', '--format=csv,noheader,nounits'], capture_output=True, text=True, check=True, timeout=20).stdout
    return [{'index': int(x[0]), 'uuid': x[1].strip(), 'name': x[2].strip(), 'free_GiB': float(x[3]) / 1024, 'total_MiB': float(x[4]), 'util': float(x[5])} for x in csv.reader(io.StringIO(s)) if x]

def admission(p):
    need(socket.gethostname() == p['hostname'], 'WRONG_SINGLE_CARD_HOST')
    rr = table()
    need(len(rr) == 1 and rr[0]['index'] == 0 and (rr[0]['uuid'] == p['gpu_uuid']) and ('H100' in rr[0]['name']), 'GPU_IDENTITY')
    need(rr[0]['total_MiB'] >= 80000 and rr[0]['free_GiB'] >= 33.35, 'GPU_MEMORY_NOT_READY')
    active = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader,nounits'], capture_output=True, text=True, check=True, timeout=20).stdout.strip()
    need(not active, 'GPU_PROCESS_PRESENT_WAIT_FOR_REVIEW_TO_EXIT')
    return rr[0]

def launch(root):
    p = sources(root)
    out = root / OUT
    need(not out.exists(), 'OUTPUT_EXISTS_USE_SHOW_NO_DUPLICATE_LAUNCH')
    gpu = admission(p)
    time.sleep(1)
    admission(p)
    out.mkdir(parents=True)
    write(out / 'plan.json', p)
    write(out / 'gpu.json', gpu)
    write(out / 'started.json', {'time': time.time(), 'max_wall_seconds': p['max_wall_seconds']})
    env = dict(os.environ, CUDA_VISIBLE_DEVICES=gpu['uuid'], PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', TOKENIZERS_PARALLELISM='false')
    with (out / 'coordinator.log').open('x', encoding='utf-8') as f:
        proc = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'coordinate', '--project-root', str(root)], env=env, stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'pid.json', {'pid': proc.pid})
    print('C_SINGLE_BOUNDED_PID=' + str(proc.pid))
    print('\u590d\u7528\u5168\u90e8NTL\u7279\u5f81\uff0c\u4ec5\u8865856\u6761232\u8bad\u7ec3\u53c2\u8003\uff1b\u4e0d\u91cd\u8dd1A/B\uff0c\u6700\u957f3\u5c0f\u65f6\uff0c\u7f13\u5b58\u4fdd\u7559\u3002')

def coordinate(root):
    out = root / OUT
    p = read(out / 'plan.json')
    deadline = read(out / 'started.json')['time'] + p['max_wall_seconds']
    with (out / 'worker.log').open('x', encoding='utf-8') as f:
        proc = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'work', '--project-root', str(root)], stdout=f, stderr=subprocess.STDOUT)
    write(out / 'worker_pid.json', {'pid': proc.pid})
    try:
        rc = proc.wait(timeout=max(1, deadline - time.time()))
        if rc != 0 and (not (out / 'failure.json').exists()):
            write(out / 'failure.json', {'error': 'WORKER_EXIT_' + str(rc), 'not_model_score': True})
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=30)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=30)
        write(out / 'time_limit.json', {'status': 'TIME_BUDGET_REACHED_RESULTS_RETAINED', 'seconds': p['max_wall_seconds'], 'not_model_score': True})

def cache_sources(root, out, p):
    """Old features are read-only; explicit per-record identity and checksum checks."""
    result = {}
    for part, basepath in p['feature_roots'].items():
        base = root / basepath
        manifest = read(base / ('features_' + part) / 'manifest.json')
        source = {x['unit_id']: x for x in read(out / ('clean_' + part + '.json')) if x['status'] == 'READY'}
        rr = manifest['records']
        need(len(rr) == len(source) == len({x['unit_id'] for x in rr}), 'OLD_FEATURE_COVERAGE')
        bound = {}
        for r in rr:
            s = source[r['unit_id']]
            need(all((r[k] == s[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256'))), 'OLD_FEATURE_IDENTITY')
            need(r['operation_positions'] == s['operation_positions'], 'OLD_FEATURE_POSITIONS')
            f = (base / r['feature_path']).resolve()
            need(f.is_relative_to(base.resolve()) and sha(f) == r['feature_sha256'], 'OLD_FEATURE_HASH')
            need(0 <= r['first'] <= 1 and 0 <= r['second'] <= 1 and (r['anchor'] == (r['first'] + r['second']) / 2), 'OLD_FEATURE_PREDICTION')
            bound[r['unit_id']] = dict(r, absolute_feature_path=str(f))
        result['clean_' + part] = bound
    write(out / 'feature_sources.json', result)
    return result

def checkpoint_time(out, reserve=0):
    started = read(out / 'started.json')
    need(time.time() + reserve < started['time'] + started['max_wall_seconds'], 'TIME_BUDGET_REACHED_RESULTS_RETAINED')

def fit(root, out, p, old, predicted):
    import torch
    from safetensors.torch import load_file, save_file
    torch.set_num_threads(2)
    torch.manual_seed(p['seed'])
    feature = {}
    caches = dict(old)
    for part in ('train', 'development'):
        caches['pred_' + part] = {u: x for u, x in predicted.items() if x['partition'] == part}
    datasets = {k: read(out / (k + '.json')) for k in caches}
    supervision = read(out / 'supervision.json')
    for kind, cache in caches.items():
        feature[kind] = {}
        for u, x in cache.items():
            need(sha(x['absolute_feature_path']) == x['feature_sha256'], 'FEATURE_CHANGED_BEFORE_FIT')
            f = load_file(x['absolute_feature_path'])
            need(set(f) == {'last', 'operations'}, 'FEATURE_KEYS')
            need(f['last'].shape == (2560,) and f['operations'].shape == (len(x['operation_positions']), 2560), 'FEATURE_SHAPE')
            need(all((bool(torch.isfinite(v).all()) for v in f.values())), 'NONFINITE_FEATURE')
            feature[kind][u] = f

    def reference(kind):
        rr = []
        for x in datasets[kind]:
            v = dict(x)
            v.pop('input_ids', None)
            if x['status'] == 'READY':
                r = caches[kind][x['unit_id']]
                v.update(status='PASS', prediction_fraction=(r['first'] + r['second']) / 2)
            rr.append(v)
        return metrics(rr)
    clean_reference = reference('clean_development')
    predicted_reference = reference('pred_development')
    write(out / 'same_input_references.json', {'clean': clean_reference, 'predicted': predicted_reference})

    def output(head, kind, row):
        u = row['unit_id']
        f = feature[kind][u]
        context = torch.cat([f['operations'], f['last'][None]], 0)
        ref = caches[kind][u]
        anchor = (ref['first'] + ref['second']) / 2
        return head(f['operations'], context, torch.tensor(row['b_share']), torch.tensor(anchor, dtype=torch.float64))

    def evaluate(head, kind):
        result = []
        head.eval()
        with torch.no_grad():
            for x in datasets[kind]:
                checkpoint_time(out)
                v = {k: x[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'status')}
                if x['status'] == 'READY':
                    z = output(head, kind, x)
                    v.update(status='PASS', prediction_fraction=float(z['prediction']), gate=float(z['gate']), token_ids_sha256=x['token_ids_sha256'])
                result.append(v)
        return (result, metrics(result))
    train = datasets['clean_train']
    real = {x['unit_id']: x for x in datasets['pred_train']}

    def update(head, optimizer, batch):
        head.train()
        optimizer.zero_grad(set_to_none=True)
        value = 0.0
        for i in batch:
            checkpoint_time(out)
            x = train[i]
            u = x['unit_id']
            paired = real[u]['status'] == 'READY'
            scale = 1 / (len(batch) * (2 if paired else 1))
            z = output(head, 'clean_train', x)
            teacher = z['responsibility'].detach()
            loss = loss_terms(z, x['target_fraction'], supervision[u]['clean'], protect_clean=True)
            value += float(loss.detach()) * scale
            (loss * scale).backward()
            del z, loss
            if paired:
                z = output(head, 'pred_train', real[u])
                loss = loss_terms(z, x['target_fraction'], supervision[u]['predicted'], teacher, supervision[u]['mapping'])
                value += float(loss.detach()) * scale
                (loss * scale).backward()
                del z, loss
        torch.nn.utils.clip_grad_norm_(head.parameters(), 1.0, error_if_nonfinite=True)
        optimizer.step()
        return value
    head = make_head(2560)
    optimizer = torch.optim.AdamW(head.parameters(), lr=0.001, weight_decay=0.01)
    head.eval()
    with torch.no_grad():
        for kind in ('clean_development', 'pred_development'):
            for row in datasets[kind]:
                if row['status'] == 'READY':
                    z = output(head, kind, row)
                    r = caches[kind][row['unit_id']]
                    need(float(z['prediction']) == (r['first'] + r['second']) / 2, 'ZERO_HEAD_NOT_EXACT_247')
    write(out / 'initial_identity.json', {'status': 'PASS_EXACT_247_BOTH_DEVELOPMENT_INPUTS', 'clean': 156, 'predicted_ready': 141, 'not_a_trained_gain': True})
    initial = {k: v.clone() for k, v in head.state_dict().items()}
    for batch in (list(range(8)), list(range(5))):
        update(head, optimizer, batch)
    need(any((not torch.equal(v, initial[k]) for k, v in head.state_dict().items())), 'HEAD_DID_NOT_UPDATE')
    temp = out / 'discarded_head_smoke.safetensors'
    save_file(head.state_dict(), str(temp))
    restored = make_head(2560)
    restored.load_state_dict(load_file(str(temp)))
    need(all((torch.equal(v, restored.state_dict()[k]) for k, v in head.state_dict().items())), 'HEAD_RELOAD')
    del head, optimizer, restored, initial
    torch.manual_seed(p['seed'])
    head = make_head(2560)
    optimizer = torch.optim.AdamW(head.parameters(), lr=p['learning_rate'], betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01)
    candidates = []
    step = 0
    for epoch in range(4):
        for batch in batches(925, epoch):
            factor = max(1e-08, step / 24) if step < 24 else 0.5 * (1 + __import__('math').cos(__import__('math').pi * (step - 24) / 440))
            for group in optimizer.param_groups:
                group['lr'] = p['learning_rate'] * factor
            value = update(head, optimizer, batch)
            step += 1
            log(out / 'events.jsonl', {'event': 'head_step', 'step': step, 'total': 464, 'loss': value, 'time': time.time()})
        folder = out / ('epoch' + str(epoch + 1))
        folder.mkdir()
        save_file(head.state_dict(), str(folder / 'head.safetensors'))
        cp, cm = evaluate(head, 'clean_development')
        pp, pm = evaluate(head, 'pred_development')
        gate = eligibility(pm, predicted_reference, cm, clean_reference)
        write(folder / 'clean_development.json', cp)
        write(folder / 'predicted_development.json', pp)
        row = {'epoch': epoch + 1, 'clean_metrics': cm, 'predicted_metrics': pm, 'gate': gate, 'head_sha256': sha(folder / 'head.safetensors')}
        write(folder / 'metrics.json', row)
        candidates.append(row)
    need(step == 464, 'STEP_BUDGET')
    eligible = [x for x in candidates if x['gate']['pass']]
    write(out / 'development_selection.json', {'candidates': candidates, 'eligible_epochs': [x['epoch'] for x in eligible]})
    if not eligible:
        write(out / 'summary.json', {'status': 'COMPLETE_NEGATIVE_DEVELOPMENT_GATE', 'B247_unchanged': True, 'candidate_official_evaluated': False, 'elapsed_seconds': time.time() - read(out / 'started.json')['time']})
        return
    best = min(eligible, key=lambda x: (x['predicted_metrics']['overall']['failure_penalized_MAE_pp'], x['predicted_metrics']['computer_science']['failure_penalized_MAE_pp'], x['epoch']))
    selected = out / ('epoch' + str(best['epoch'])) / 'head.safetensors'
    need(sha(selected) == best['head_sha256'], 'SELECTED_HEAD_HASH')
    write(out / 'selected.json', best)
    head.load_state_dict(load_file(str(selected)))
    pp, mm = evaluate(head, 'clean_official')
    write(out / 'official_predictions.json', pp)
    ref = reference('clean_official')
    delta = {g: mm[g]['failure_penalized_MAE_pp'] - ref[g]['failure_penalized_MAE_pp'] for g in mm}
    write(out / 'summary.json', {'status': 'COMPLETE', 'B247_unchanged': True, 'official_metrics': mm, 'official_delta_vs_old247_pp': delta, 'official_both_MAE_improved': all((x < 0 for x in delta.values())), 'official_adaptive_use': True, 'training_protocol_changed': True, 'single_card_representative_review_only': True, 'backbone_trained': False, 'elapsed_seconds': time.time() - read(out / 'started.json')['time']})

def work(root):
    out = root / OUT
    try:
        p = sources(root, weights=False)
        from reuse import prepare_reuse, supplement_232
        log(out / 'events.jsonl', {'event': 'verify_and_reuse_existing_tokens_features', 'time': time.time()})
        predicted = prepare_reuse(root, out, p)
        verify(out)
        old = cache_sources(root, out, p)
        checkpoint_time(out, 900)
        predicted = supplement_232(root, out, p, old, predicted)
        checkpoint_time(out, 600)
        fit(root, out, p, old, predicted)
        sources(root, weights=True)
        write(out / 'verified_exit.json', {'status': 'PASS', 'frozen_sources_unchanged': True})
    except BaseException as exc:
        write(out / 'failure.json', {'error': repr(exc), 'traceback': traceback.format_exc(), 'not_model_score': True, 'caches_preserved': True})
        raise

def show(root):
    out = root / OUT
    if not out.exists():
        print('\u5c1a\u672a\u542f\u52a8')
        return
    for name in ('time_limit.json', 'failure.json'):
        if (out / name).exists():
            d = read(out / name)
            print('\u6267\u884c\u505c\u6b62\uff0c\u7f13\u5b58\u4fdd\u7559\uff5c' + str(d.get('error', d.get('status'))))
            return
    if (out / 'summary.json').exists():
        s = read(out / 'summary.json')
        final = (out / 'verified_exit.json').exists()
        print('\u72b6\u6001\uff1a' + s['status'] + ('\uff5c\u6700\u7ec8\u6765\u6e90\u6838\u9a8c\u901a\u8fc7' if final else '\uff5c\u5f85\u6700\u7ec8\u6765\u6e90\u6838\u9a8c'))
        if s.get('official_metrics'):
            print('\u5b98\u65b9\u60e9\u7f5aMAE\uff1a\u603b\u4f53 %.4f\uff5c\u8ba1\u7b97\u673a %.4f' % (s['official_metrics']['overall']['failure_penalized_MAE_pp'], s['official_metrics']['computer_science']['failure_penalized_MAE_pp']))
            print('\u76f8\u5bf9\u65e7247\uff08\u8d1f\u503c\u6539\u5584\uff09\uff1a' + str(s['official_delta_vs_old247_pp']))
        return
    f = out / 'events.jsonl'
    last = f.read_text(encoding='utf-8').splitlines()[-1] if f.exists() else '\u51c6\u5907\u542f\u52a8'
    print('\u5355\u5361\u9650\u65f6C\uff5c\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u5b58\u6d3b\uff5c' + last)
if __name__ == '__main__':
    a = argparse.ArgumentParser()
    a.add_argument('command', choices=['preflight', 'launch', 'coordinate', 'work', 'show'])
    a.add_argument('--project-root', required=True)
    x = a.parse_args()
    root = Path(x.project_root).resolve()
    if x.command == 'preflight':
        sources(root)
        print('PASS_SOURCE_AND_REVIEW_CPU_ONLY_NO_GPU')
    else:
        globals()[x.command](root)
