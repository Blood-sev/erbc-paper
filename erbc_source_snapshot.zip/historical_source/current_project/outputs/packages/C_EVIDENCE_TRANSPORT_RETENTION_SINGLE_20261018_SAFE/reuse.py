"""Reuse the completed first candidate; only compute the missing frozen232 train branch."""
import gc, os, shutil, time
from pathlib import Path
from core import need, read, write, sha, digest, log

def validate_reference(entry, row):
    need(all((entry[k] == row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256'))), 'REFERENCE_IDENTITY')
    need(entry['operation_positions'] == row['operation_positions'], 'REFERENCE_POSITIONS')
    need(type(entry['first']) in (int, float) and 0 <= entry['first'] <= 1, 'FIRST_REFERENCE')
    if 'second' in entry:
        need(type(entry['second']) in (int, float) and 0 <= entry['second'] <= 1, 'SECOND_REFERENCE')

def prepare_reuse(root, out, p):
    src = root / p['reuse_output']
    report = read(src / 'prepared.json')
    need(read(src / 'summary.json')['status'] == 'COMPLETE_NEGATIVE_DEVELOPMENT_GATE', 'REUSE_STATUS')
    need(read(src / 'verified_exit.json')['frozen_sources_unchanged'], 'REUSE_SOURCES_NOT_VERIFIED')
    for name, h in report['files'].items():
        need(Path(name).name == name and sha(src / name) == h, 'REUSE_INPUT_HASH')
        shutil.copyfile(src / name, out / name)
        need(sha(out / name) == h, 'COPIED_INPUT_HASH')
    report.update(plan_sha256=sha(out / 'plan.json'), reused_from=p['reuse_output'], original_prepared_sha256=sha(src / 'prepared.json'))
    write(out / 'prepared.json', report)
    records = read(src / 'predicted_feature_manifest.json')
    rows = {r['unit_id']: r for part in ('train', 'development') for r in read(out / ('pred_' + part + '.json')) if r['status'] == 'READY'}
    need(set(records) == set(rows) and len(rows) == 997, 'REUSED_FEATURE_MEMBERSHIP')
    for u, entry in records.items():
        row = rows[u]
        validate_reference(entry, row)
        need(entry['partition'] == row['partition'], 'REUSE_PARTITION')
        f = Path(entry['absolute_feature_path']).resolve()
        need(f.is_relative_to(src.resolve()) and sha(f) == entry['feature_sha256'], 'REUSE_FEATURE_PATH_OR_HASH')
        need(('second' in entry) == (row['partition'] == 'development'), 'REUSE_BRANCH_MEMBERSHIP')
    write(out / 'reuse_audit.json', {'NTL_features_reused': 997, '232_development_reused': 141, '232_train_missing': 856, 'tokens_reused_without_retokenization': True, 'A_B_generation': False, 'original_files_unchanged': True})
    return records

def supplement_232(root, out, p, old, records):
    import torch, transformers, peft
    from transformers import AutoModelForCausalLM
    from peft import PeftModel
    from run import checkpoint_time
    need({'torch': torch.__version__, 'transformers': transformers.__version__, 'peft': peft.__version__} == p['runtime'], 'RUNTIME_DRIFT')
    need(torch.cuda.device_count() == 1 and os.environ['CUDA_VISIBLE_DEVICES'] == p['gpu_uuid'], 'GPU_IDENTITY')
    torch.set_num_threads(2)
    torch.manual_seed(p['seed'])
    free, total = torch.cuda.mem_get_info()
    need(free / 1024 ** 3 >= 33.35, 'PRELOAD_MEMORY')
    torch.cuda.set_per_process_memory_fraction(min(0.99, (free - 6 * 1024 ** 3) / total))

    def guard():
        checkpoint_time(out, 900)
        need(torch.cuda.mem_get_info()[0] / 1024 ** 3 >= 5, 'RESOURCE_BELOW_5GiB')
    log(out / 'events.jsonl', {'event': 'loading_frozen232_only', 'time': time.time()})
    base = AutoModelForCausalLM.from_pretrained(root / p['model'], local_files_only=True, dtype=torch.bfloat16, attn_implementation='flash_attention_2', device_map={'': 0})
    model = PeftModel.from_pretrained(base, root / p['checkpoints']['232'], is_trainable=False, local_files_only=True)
    model.requires_grad_(False)
    model.eval()
    model.config.use_cache = False

    def forward(row):
        guard()
        need(not any((x.requires_grad for x in model.parameters())), 'FROZEN_MODEL_TRAINABLE')
        ids = torch.tensor([row['input_ids']], device='cuda:0', dtype=torch.long)
        with torch.no_grad():
            lm = model.get_base_model()
            states = lm.model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, return_dict=True).last_hidden_state
            prob = lm.get_output_embeddings()(states[:, -1:, :])[0, 0, 15:25].float().softmax(-1)
            value = float((prob * torch.arange(10, device=prob.device)).sum() / 9)
            del ids, states, prob
        guard()
        return value
    clean = sorted(read(out / 'clean_train.json'), key=lambda x: len(x['input_ids']))
    for row in (clean[0], clean[-1]):
        value = forward(row)
        need(abs(value - old['clean_train'][row['unit_id']]['second']) <= 1e-06, 'FROZEN232_REPLAY_DRIFT')
    write(out / '232_replay.json', {'status': 'PASS_TWO_REPRESENTATIVES', 'not_all_samples_bitwise_proof': True})
    queue = sorted([r for r in read(out / 'pred_train.json') if r['status'] == 'READY'], key=lambda x: (len(x['input_ids']), x['unit_id']))
    pilot = list(dict.fromkeys((round(i * (len(queue) - 1) / 31) for i in range(32))))
    indexes = pilot + [i for i in range(len(queue)) if i not in set(pilot)]
    folder = out / '232_training_cache'
    folder.mkdir()
    timings = []
    for j, i in enumerate(indexes):
        row = queue[i]
        checkpoint_time(out, 900)
        started = time.monotonic()
        value = forward(row)
        seconds = time.monotonic() - started
        entry = {k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256', 'partition')}
        entry.update(prediction_fraction=value, status='PASS', seconds=seconds, adapter_sha256=p['pins'][p['checkpoints']['232'] + '/adapter_model.safetensors'])
        write(folder / (digest(row['unit_id']) + '.json'), entry)
        records[row['unit_id']]['second'] = value
        timings.append((len(row['input_ids']), seconds))
        log(out / 'events.jsonl', {'event': '232_training_reference', 'done': j + 1, 'total': 856, 'seconds': seconds, 'time': time.time()})
        if j + 1 == len(pilot):
            rate = sum((t for _, t in timings)) / sum((n for n, _ in timings))
            estimate = 1.5 * rate * (sum((len(x['input_ids']) for x in queue)) - sum((n for n, _ in timings))) + 900
            remaining = read(out / 'started.json')['time'] + p['max_wall_seconds'] - time.time()
            write(out / 'timing_pilot.json', {'samples': len(pilot), 'estimated_remaining_seconds': estimate, 'remaining_budget_seconds': remaining})
            need(estimate <= remaining, 'PROJECTED_RUNTIME_EXCEEDS_BUDGET_CACHES_RETAINED')
    need(all(('second' in x for x in records.values())), 'INCOMPLETE_FROZEN247_REFERENCES')
    write(out / 'predicted_feature_manifest.json', records)
    del model, base
    gc.collect()
    torch.cuda.empty_cache()
    return records
