"""Memory/identity are gates; utilization is telemetry, never an admission threshold."""
import math

def validate_plan_policy(plan):
    method = 'RAFT' if plan['GPU_scope'] == [0, 1, 2, 3] else 'TRACT'
    expected = {'mode': 'advisory_only', 'previous_retry_output': f'outputs/C\u72ec\u7acb\u6570\u503c\u57fa\u7ebf_{method}\u8d44\u6e90\u6062\u590d\u56db\u5361DDP_20261015_v2', 'start_minimum_free_GiB': 33.35, 'load_minimum_free_GiB': 18, 'runtime_minimum_free_GiB': 5, 'extra_allocator_reserve_GiB': 1, 'high_two_sample_warning_percent': 90, 'invalid_telemetry_rejected': True}
    if plan.get('utilization_policy') != expected:
        raise RuntimeError('UTILIZATION_POLICY_DRIFT')

def valid(row):
    try:
        return type(row['index']) is int and isinstance(row['uuid'], str) and bool(row['uuid']) and all((type(row[k]) in (int, float) and math.isfinite(row[k]) for k in ('free_GiB', 'util'))) and (row['free_GiB'] >= 0) and (0 <= row['util'] <= 100)
    except (KeyError, TypeError):
        return False

def ready(first, second, selected, minimum):
    if not selected or not math.isfinite(minimum) or minimum < 0:
        return False
    if len({g['index'] for g in selected}) != len(selected) or len({g['uuid'] for g in selected}) != len(selected):
        return False
    for g in selected:
        for snapshot in (first, second):
            by_index = [r for r in snapshot if r.get('index') == g['index']]
            by_uuid = [r for r in snapshot if r.get('uuid') == g['uuid']]
            if len(by_index) != 1 or len(by_uuid) != 1 or by_index[0] != by_uuid[0]:
                return False
            r = by_index[0]
            if not valid(r) or r['free_GiB'] < minimum:
                return False
    return True

def select(first, second, scope, minimum=18):
    return [r for r in second if r.get('index') in scope and ready(first, second, [r], minimum)]

def advisory(first, second, selected):
    ids = {g['index'] for g in selected}
    active = [{'index': r['index'], 'uuid': r['uuid'], 'util_percent': r['util']} for r in second if r.get('index') in ids and valid(r) and (r['util'] > 5)]
    repeated = [r['index'] for r in second if r.get('index') in ids and valid(r) and (r['util'] >= 90) and any((valid(p) and p['index'] == r['index'] and (p['uuid'] == r['uuid']) and (p['util'] >= 90) for p in first))]
    return {'utilization_is_advisory_only': True, 'active_selected_gpus': active, 'high_in_two_samples_gpus': repeated, 'warning': 'Concurrent activity may reduce throughput; free memory can change.' if active else None}
