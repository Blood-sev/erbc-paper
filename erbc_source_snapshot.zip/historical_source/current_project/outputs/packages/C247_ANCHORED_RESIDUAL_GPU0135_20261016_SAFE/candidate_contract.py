from core import need, sha, read, rows
import math

def verify_B247(folder, official_tokens):
    pins = {'B247_predictions_148.jsonl': '17ecafb5595fdfc6a8e8e4cb575e5dc464331f688e0ef1cfab19d78f9bf59dd1', 'B247_summary.json': '8f5ab724862fdcd401bebcd478aa81d6d818d1cedd377644d2cb85f972ea8917'}
    for n, h in pins.items():
        need(sha(folder / n) == h, 'B247_FROZEN_HASH:' + n)
    rr = rows(folder / 'B247_predictions_148.jsonl')
    by = {r['unit_id']: r for r in official_tokens}
    need(len(rr) == len({r['unit_id'] for r in rr}) == len(by) == 148 and {r['unit_id'] for r in rr} == set(by), 'B247_C_MEMBERSHIP')
    need(all((r['subject'] == by[r['unit_id']]['subject'] for r in rr)), 'B247_C_SUBJECT')
    saved = read(folder / 'B247_summary.json')['metrics']['fixed_mean']
    for g, n in [('overall', 148), ('computer_science', 85)]:
        group = [r for r in rr if g == 'overall' or r['subject'].startswith('01_')]
        need(len(group) == n, 'B247_DENOMINATOR')
        errors = [100 * (r['prediction_fraction'] - r['target_fraction']) for r in group]
        need(abs(math.fsum((abs(x) for x in errors)) / n - saved[g]['mae_percent_points']) < 1e-11, 'B247_METRICS')
    return {'files': pins, 'metrics': saved, 'unchanged': True, 'B_is_not_C_target': True, 'C_input': 'Frozen structured A/E3-B; B247 scalar is not substituted into C input'}

def development_gate(candidate, reference):
    """Freeze before official: both MAEs no worse, at least one strictly lower."""
    deltas = []
    for g, n in [('overall', 156), ('computer_science', 112)]:
        a = candidate[g]
        b = reference[g]
        need(a['records'] == b['records'] == n and a['failures'] == b['failures'] == 0, 'DEV_GATE_DENOMINATOR')
        v = a['failure_penalized_MAE_pp'] - b['failure_penalized_MAE_pp']
        need(math.isfinite(v), 'NONFINITE_GATE')
        deltas.append(v)
    return {'pass': all((d <= 0 for d in deltas)) and any((d < 0 for d in deltas)), 'overall_delta_pp': deltas[0], 'CS_delta_pp': deltas[1], 'rule': 'Both development MAEs <= frozen 247 control C; at least one <. No official tuning.'}
