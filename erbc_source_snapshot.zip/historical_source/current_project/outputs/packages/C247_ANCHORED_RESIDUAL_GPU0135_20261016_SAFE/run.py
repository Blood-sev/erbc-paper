"""User-launched anchored C residual; CPU staging never starts this runner."""
import argparse, csv, io, os, sys, subprocess, time, traceback, shutil, math
from pathlib import Path
from core import need, read, rows, write, log, sha, digest, canonical, metrics, batches
from gpu_advisory_20261015 import ready, select, advisory
from candidate_contract import verify_B247, development_gate
HERE = Path(__file__).resolve().parent
OUT = 'outputs/C\u7b97\u6cd5\u5019\u9009_247\u51bb\u7ed3\u951a\u5b9a\u6b8b\u5dee_20261016_v1'
SCOPE = (0, 1, 3, 5)

def package():
    for line in (HERE / 'SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ', 1)
        need(Path(n).name == n and sha(HERE / n) == h, 'PACKAGE_CHANGED:' + n)

def validate(row, source):
    need(all((row[k] == source[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256'))), 'IDENTITY_DRIFT')
    need(source['status'] == 'READY' and row['status'] == 'PASS', 'STATUS_DRIFT')

def sources(root, weights=True):
    package()
    p = read(HERE / 'plan.json')
    for n, h in p['pins'].items():
        need(not Path(n).is_absolute() and '..' not in Path(n).parts, 'PIN_ESCAPE')
        if weights or not n.endswith('.safetensors'):
            need(sha(root / n) == h, 'SOURCE_DRIFT:' + n)
    need(p['GPU_scope'] == list(SCOPE) and p['retention'] == 0.05 and (p['epochs'] == 4) and (p['steps'] == 464), 'PLAN_DRIFT')
    need(p['effective_batch'] == 8 and p['head_attention_size'] == 128 and (p['seed'] == 20261014), 'HEAD_PROTOCOL')
    src = root / p['source_output']
    parts = {s: rows(src / (s + '_tokens.jsonl')) for s in ('train', 'development', 'official')}
    ids = {}
    students = {}
    for s, n in [('train', 925), ('development', 156), ('official', 148)]:
        rr = parts[s]
        ids[s] = {x['unit_id'] for x in rr}
        students[s] = {x['student_group_id'] for x in rr}
        need(len(rr) == len(ids[s]) == n, 'MEMBERSHIP')
        om = {x['unit_id']: x for x in read(src / (s + '_operations.json'))}
        good = [x for x in rr if x['status'] == 'READY']
        need(set(om) == {x['unit_id'] for x in good}, 'OP_MEMBERSHIP')
        for x in rr:
            need(type(x['target_fraction']) in (int, float) and math.isfinite(x['target_fraction']) and (0 <= x['target_fraction'] <= 1), 'TARGET')
            if x['status'] == 'READY':
                need(digest(x['input_ids']) == x['token_ids_sha256'] == om[x['unit_id']]['token_ids_sha256'], 'TOKEN_BINDING')
                positions = om[x['unit_id']]['positions']
                need(positions and len(positions) == len(set(positions)) and all((type(i) == int and 0 <= i < len(x['input_ids']) for i in positions)), 'POSITIONS')
            else:
                need(s == 'official' and x['status'] == 'UPSTREAM_BLOCKED', 'SOURCE_STATUS')
    for a, b in [('train', 'development'), ('train', 'official'), ('development', 'official')]:
        need(not ids[a] & ids[b] and (not students[a] & students[b]), 'PARTITION_LEAK')
    need(sum((x['subject'].startswith('01_') for x in parts['development'])) == 112, 'DEV_CS')
    need(sum((x['subject'].startswith('01_') for x in parts['official'])) == 85, 'OFFICIAL_CS')
    need(sum((x['status'] == 'UPSTREAM_BLOCKED' for x in parts['official'])) == 7, 'OFFICIAL_FAILURES')
    verify_B247(HERE, parts['official'])
    return (p, parts)

def table():
    result = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,memory.free,utilization.gpu', '--format=csv,noheader,nounits'], capture_output=True, text=True, check=True, timeout=20)
    return [{'index': int(v[0]), 'uuid': v[1].strip(), 'free_GiB': float(v[2]) / 1024, 'util': float(v[3])} for v in csv.reader(io.StringIO(result.stdout)) if v]

def gpu_pair(minimum=33.35):
    a = table()
    time.sleep(1)
    b = table()
    picked = select(a, b, SCOPE, minimum)
    need([x['index'] for x in picked] == list(SCOPE), 'GPU0135_MEMORY_NOT_READY_NO_LAUNCH')
    return (picked, [a, b])

def expected(root, p, part):
    if part == 'train':
        return {}
    return {x['unit_id']: x for x in read(root / p['control_output'] / '247_control' / (part + '_predictions.json'))}

def outrows(root, part):
    return rows(root / OUT / (part + '_tokens.jsonl'))

def cache_record(source, a, b, first_fresh, second_fresh, filename, filehash, positions):
    r = {k: source[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256')}
    r.update(status='PASS', first=a, second=b, anchor=(a + b) / 2, first_fresh=first_fresh, second_fresh=second_fresh, feature_path=filename, feature_sha256=filehash, operation_positions=positions)
    return r

def checked_canonical(source, reference, a, b, tolerance=1e-06):
    need(all((math.isfinite(x) and 0 <= x <= 1 for x in (a, b))), 'INVALID_BRANCH')
    if reference is None:
        return (a, b)
    validate(reference, source)
    x = reference['reference_prediction_fraction']
    y = reference['replica_prediction_fraction']
    need(abs(a - x) <= tolerance and abs(b - y) <= tolerance, 'FROZEN_BRANCH_REPLAY_DRIFT')
    need(reference['prediction_fraction'] == (x + y) / 2, 'CONTROL_NOT_EQUAL_MEAN')
    return (x, y)

def worker(root, args):
    import torch
    folder = Path(args.folder)
    p = read(HERE / 'plan.json')
    out = root / OUT
    assignment = read(folder / 'assignment.json')
    gpus = assignment['gpus']
    width = len(gpus)
    try:
        from transformers import AutoModelForCausalLM
        from peft import PeftModel
        from safetensors.torch import save_file, load_file
        import transformers, peft
        need(os.environ['CUDA_VISIBLE_DEVICES'] == ','.join((g['uuid'] for g in gpus)) and width in (1, 2, 4), 'GPU_BINDING')
        need({'torch': torch.__version__, 'transformers': transformers.__version__, 'peft': peft.__version__} == p['runtime'], 'RUNTIME_DRIFT')
        torch.set_num_threads(1)
        torch.manual_seed(p['seed'])
        torch.cuda.manual_seed_all(p['seed'])
        snap = table()
        need(ready(snap, snap, gpus, 18), 'PRELOAD_MEMORY_OR_IDENTITY')
        for i in range(width):
            free, total = torch.cuda.mem_get_info(i)
            need(free > 6 * 1024 ** 3, 'MEMORY_BUDGET')
            torch.cuda.set_per_process_memory_fraction(min(0.99, (free - 6 * 1024 ** 3) / total), i)

        def guard(phase):
            for i, g in enumerate(gpus):
                free = torch.cuda.mem_get_info(i)[0] / 1024 ** 3
                log(folder / 'resources.jsonl', {'phase': phase, 'physical_gpu': g['index'], 'free_GiB': free, 'reserved_GiB': torch.cuda.memory_reserved(i) / 1024 ** 3, 'time': time.time()})
                need(free >= 5, 'RESOURCE_BELOW_5GiB')
        placement = {'model.embed_tokens': 0, 'model.norm': 0, 'lm_head': 0}
        placement.update({f'model.layers.{i}': i * width // 36 for i in range(36)})
        base = AutoModelForCausalLM.from_pretrained(root / p['model'], local_files_only=True, dtype=torch.bfloat16, attn_implementation='flash_attention_2', device_map=placement, low_cpu_mem_usage=True)
        model = PeftModel.from_pretrained(base, root / p['checkpoints']['NTL'], adapter_name='ntl', is_trainable=False, local_files_only=True)
        model.load_adapter(root / p['checkpoints']['232'], adapter_name='replica', is_trainable=False, local_files_only=True)
        model.config.use_cache = False
        model.requires_grad_(False)
        model.eval()
        need(all((x.device.type == 'cuda' for x in model.parameters())), 'CPU_OFFLOAD_FORBIDDEN')
        for i, layer in enumerate(model.get_base_model().model.layers):
            need(all((x.device.index == i * width // 36 for x in layer.parameters())), 'LAYOUT_DRIFT')
        if args.part == 'official':
            need(read(out / 'development_gate.json')['pass'], 'OFFICIAL_BEFORE_GATE')
        source = {x['unit_id']: x for x in outrows(root, args.part)}
        om = {x['unit_id']: x for x in read(out / (args.part + '_operations.json'))}
        exp = expected(root, p, args.part)

        def freeze(name):
            model.set_adapter(name)
            model.requires_grad_(False)
            model.eval()
            need(not any((x.requires_grad for x in model.parameters())), 'FROZEN_WEIGHT_GRAD')

        def get(row, check=False):
            guard('before_forward')
            ids = torch.tensor([row['input_ids']], device='cuda:0', dtype=torch.long)
            pos = om[row['unit_id']]['positions']
            with torch.no_grad():
                freeze('ntl')
                lm = model.get_base_model()
                states = lm.model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, output_hidden_states=False, return_dict=True).last_hidden_state
                logits = lm.get_output_embeddings()(states[:, -1:, :].to(lm.get_output_embeddings().weight.device))[0, 0, 15:25].float()
                probability = logits.softmax(-1)
                a = float((probability * torch.arange(10, device=logits.device)).sum() / 9)
                features = {'last': states[0, -1].float().cpu().contiguous(), 'operations': states[0, pos].float().cpu().contiguous()}
                del states, logits
                if check:
                    replay = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1).logits[0, -1, 15:25].float().softmax(-1)
                    need(float((replay - probability).abs().max()) <= 1e-06, 'LAST_POSITION_READOUT')
                    del replay
                freeze('replica')
                prob = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1).logits[0, -1, 15:25].float().softmax(-1)
                b = float((prob * torch.arange(10, device=prob.device)).sum() / 9)
                if check:
                    freeze('ntl')
                    replay = model(input_ids=ids, attention_mask=torch.ones_like(ids), use_cache=False, logits_to_keep=1).logits[0, -1, 15:25].float().softmax(-1)
                    need(float((replay - probability).abs().max()) <= 1e-06, 'ADAPTER_SWITCH_REPLAY')
                    del replay
                del ids, prob, probability
            guard('after_forward')
            aa, bb = checked_canonical(row, exp.get(row['unit_id']), a, b)
            return (features, aa, bb, a, b)
        replay_ids = assignment.get('replay', [])
        for entry in replay_ids:
            f, a, b, _, _ = get(source[entry['unit_id']])
            old = load_file(str(out / entry['feature_path']))
            need(abs(a - entry['first']) <= 1e-06 and abs(b - entry['second']) <= 1e-06, 'LAYOUT_BRANCH_DRIFT')
            need(all((torch.allclose(f[k], old[k], atol=0.0001, rtol=0.0001) for k in f)), 'LAYOUT_FEATURE_DRIFT')
            log(folder / 'events.jsonl', {'event': 'layout_replay_pass', 'unit_id': entry['unit_id']})
        queue = read(args.queue)
        for j, u in enumerate(queue):
            row = source[u]
            log(folder / 'events.jsonl', {'event': 'feature_start', 'unit_id': u, 'part': args.part, 'time': time.time()})
            f, a, b, af, bf = get(row, check=j == 0)
            filename = folder / (digest(u) + '.safetensors')
            need(not filename.exists(), 'FEATURE_EXISTS')
            save_file(f, str(filename))
            entry = cache_record(row, a, b, af, bf, str(filename.relative_to(out)), sha(filename), om[u]['positions'])
            log(folder / 'records.jsonl', entry)
            log(folder / 'events.jsonl', {'event': 'feature_complete', 'unit_id': u, 'time': time.time()})
        write(folder / 'exit.json', {'status': 'PASS'})
        return 0
    except BaseException as exc:
        traceback.print_exc()
        oom = isinstance(exc, torch.cuda.OutOfMemoryError)
        write(folder / 'exit.json', {'status': 'OOM' if oom else 'EXECUTION_ERROR', 'exception': repr(exc), 'traceback': traceback.format_exc()})
        return 1

def extract(root, part, picked):
    out = root / OUT
    dest = out / ('features_' + part)
    dest.mkdir()
    data = {x['unit_id']: x for x in outrows(root, part)}
    pending = [u for u, x in data.items() if x['status'] == 'READY']
    complete = {}
    for width in (1, 2, 4):
        if not pending:
            break
        snap = table()
        eligible = select(snap, snap, [g['index'] for g in picked], 18)
        for g in eligible:
            need(any((g['index'] == x['index'] and g['uuid'] == x['uuid'] for x in picked)), 'GPU_UUID_CHANGED')
        eligible.sort(key=lambda x: x['index'])
        need(len(eligible) >= width, 'FEATURE_GPU_MEMORY_WAIT_REQUIRED')
        groups = [eligible[i:i + width] for i in range(0, len(eligible) - width + 1, width)]
        queues = [[] for _ in groups]
        loads = [0] * len(groups)
        for u in sorted(pending, key=lambda u: (-len(data[u]['input_ids']), u)):
            i = min(range(len(groups)), key=lambda i: (loads[i], i))
            queues[i].append(u)
            loads[i] += len(data[u]['input_ids'])
        replay = []
        if width > 1:
            need(complete, 'NO_SINGLE_CARD_REPLAY_REFERENCE')
            ordered = sorted(complete.values(), key=lambda x: len(data[x['unit_id']]['input_ids']))
            replay = [ordered[0], ordered[-1]] if len(ordered) > 1 else ordered
        children = []
        for i, (g, q) in enumerate(zip(groups, queues)):
            if not q:
                continue
            shortest = min(q, key=lambda u: (len(data[u]['input_ids']), u))
            q.remove(shortest)
            q.insert(0, shortest)
            f = dest / f'width{width}_worker{i}'
            f.mkdir()
            write(f / 'queue.json', q)
            write(f / 'assignment.json', {'gpus': g, 'replay': replay})
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((x['uuid'] for x in g)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TOKENIZERS_PARALLELISM='false', FLASH_ATTENTION_DETERMINISTIC='1')
            with (f / 'worker.log').open('x', encoding='utf-8') as logf:
                proc = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'worker', '--project-root', str(root), '--folder', str(f), '--part', part, '--queue', str(f / 'queue.json')], env=env, stdout=logf, stderr=subprocess.STDOUT)
            children.append((proc, f))
        failures = []
        for proc, f in children:
            code = proc.wait()
            result = read(f / 'exit.json') if (f / 'exit.json').exists() else {'status': 'MISSING_EXIT'}
            if (f / 'records.jsonl').exists():
                for x in rows(f / 'records.jsonl'):
                    validate(x, data[x['unit_id']])
                    need(x['unit_id'] not in complete, 'DUPLICATE_FEATURE')
                    need(sha(out / x['feature_path']) == x['feature_sha256'], 'FEATURE_HASH')
                    complete[x['unit_id']] = x
            if result['status'] not in ('PASS', 'OOM') or (code == 0) != (result['status'] == 'PASS'):
                failures.append(result)
        need(not failures, 'FEATURE_EXECUTION_FAILED_RESULTS_RETAINED:' + str(failures))
        pending = [u for u in pending if u not in complete]
    need(not pending, 'FEATURE_OOM_ALL_LAYOUTS_RESULTS_RETAINED')
    result = [complete[x['unit_id']] for x in data.values() if x['status'] == 'READY']
    write(dest / 'manifest.json', {'part': part, 'records': result, 'rows': len(result), 'plan_sha256': sha(HERE / 'plan.json')})
    return result

def verified_features(root, part):
    out = root / OUT
    d = read(out / ('features_' + part) / 'manifest.json')
    need(d['part'] == part and d['plan_sha256'] == sha(HERE / 'plan.json'), 'FEATURE_MANIFEST')
    data = {x['unit_id']: x for x in outrows(root, part) if x['status'] == 'READY'}
    rr = d['records']
    need(len(rr) == len({x['unit_id'] for x in rr}) == len(data) and {x['unit_id'] for x in rr} == set(data), 'FEATURE_COVERAGE')
    for x in rr:
        validate(x, data[x['unit_id']])
        f = (out / x['feature_path']).resolve()
        need(f.is_relative_to(out.resolve()) and sha(f) == x['feature_sha256'], 'FEATURE_ESCAPE_OR_HASH')
        need(x['anchor'] == (x['first'] + x['second']) / 2, 'ANCHOR_DRIFT')
    return rr

def coordinate(root):
    out = root / OUT
    try:
        p, parts = sources(root)
        src = root / p['source_output']
        for s in parts:
            for tail in ('_tokens.jsonl', '_operations.json'):
                shutil.copyfile(src / (s + tail), out / (s + tail))
        for n in ('B247_predictions_148.jsonl', 'B247_summary.json'):
            shutil.copyfile(HERE / n, out / n)
        write(out / 'B247_binding.json', verify_B247(out, parts['official']))
        picked = read(out / 'startup_resources.json')['selected']
        for part in ('train', 'development'):
            log(out / 'events.jsonl', {'event': 'feature_extraction', 'part': part, 'time': time.time()})
            extract(root, part, picked)
        train = verified_features(root, 'train')
        dev = verified_features(root, 'development')
        train_errors = sorted((abs(x['anchor'] - x['target_fraction']) * 100 for x in train))
        write(out / 'training_residual_audit.json', {'records': 925, 'mean_abs_residual_pp': sum(train_errors) / 925, 'median_abs_residual_pp': train_errors[462], 'max_abs_residual_pp': max(train_errors), 'train_predictions_in_sample_not_OOF': True, 'descriptive_not_generalization_evidence': True, 'all_zero_no_learning_signal': max(train_errors) == 0})
        need(max(train_errors) > 0, 'NO_TRAINING_RESIDUAL_SIGNAL_KEEP247')
        folder = out / 'head_training'
        folder.mkdir()
        a = table()
        time.sleep(1)
        b = table()
        need(ready(a, b, picked, 6), 'HEAD_TRAINING_GPU_MEMORY_NOT_READY')
        env = dict(os.environ, CUDA_VISIBLE_DEVICES=','.join((x['uuid'] for x in picked)), PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', TORCH_NCCL_ASYNC_ERROR_HANDLING='1')
        with (folder / 'worker.log').open('x', encoding='utf-8') as f:
            proc = subprocess.Popen([sys.executable, '-m', 'torch.distributed.run', '--standalone', '--nnodes=1', '--nproc_per_node=4', '--max_restarts=0', str(HERE / 'train_head.py'), '--project-root', str(root)], env=env, stdout=f, stderr=subprocess.STDOUT)
        write(folder / 'launcher.json', {'pid': proc.pid, 'selected': picked})
        need(proc.wait() == 0 and read(folder / 'exit.json')['status'] == 'PASS', 'HEAD_TRAINING_FAILED_RESULTS_RETAINED')
        selection = read(folder / 'selection.json')
        control = read(root / p['control_output'] / '247_control/summary.json')
        need(sha(folder / selection['checkpoint']) == selection['sha256'], 'SELECTED_HEAD_HASH')
        gate = development_gate(selection['metrics'], control['development']['247_control_C'])
        write(out / 'development_gate.json', gate)
        write(out / 'candidate_frozen.json', {'selection': selection, 'gate': gate, 'plan_sha256': sha(HERE / 'plan.json'), 'time': time.time()})
        result = {'status': 'COMPLETE_NEGATIVE_DEVELOPMENT_GATE', 'B247_unchanged': True, 'frozen_C247_weights_unchanged': True, 'selection': selection, 'development_gate': gate, 'official_adaptive_use': True, 'input_protocol': 'OLD_COMMON_AB_COMPONENT_NOT_OWN_B_LINKED', 'candidate_official_evaluated': False, 'train_features_in_sample_not_OOF': True, 'novelty_or_superiority_established': False}
        if gate['pass']:
            extract(root, 'official', picked)
            need(sha(folder / selection['checkpoint']) == selection['sha256'], 'FROZEN_HEAD_CHANGED')
            from train_head import evaluate_saved
            predictions = evaluate_saved(root, 'official', folder / selection['checkpoint'])
            write(out / 'official_predictions.json', predictions)
            candidate = metrics(predictions)
            result.update(status='COMPLETE', candidate_official_evaluated=True, candidate_C=candidate, control247_C=control['official']['247_control_C'], NTL_C=control['official']['NTL_C'])
            result['candidate_minus_247'] = {g: candidate[g]['failure_penalized_MAE_pp'] - control['official']['247_control_C'][g]['failure_penalized_MAE_pp'] for g in ('overall', 'computer_science')}
        sources(root)
        verify_B247(out, parts['official'])
        write(out / 'summary.json', result)
        write(out / 'exit.json', {'exit_code': 0})
    except BaseException as exc:
        traceback.print_exc()
        write(out / 'failure.json', {'status': 'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE', 'exception': repr(exc), 'traceback': traceback.format_exc()})
        write(out / 'exit.json', {'exit_code': 1})
        raise

def launch(root):
    sources(root)
    out = root / OUT
    need(not out.exists(), 'OUTPUT_EXISTS_USE_SHOW_NO_DUPLICATE')
    picked, snaps = gpu_pair()
    out.mkdir(parents=True)
    write(out / 'startup_resources.json', {'selected': picked, 'snapshots': snaps, **advisory(*snaps, picked)})
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1')
    with (out / 'worker.log').open('x', encoding='utf-8') as f:
        proc = subprocess.Popen([sys.executable, '-B', str(HERE / 'run.py'), 'coordinate', '--project-root', str(root)], env=env, stdout=f, stderr=subprocess.STDOUT, start_new_session=True)
    write(out / 'worker.json', {'pid': proc.pid, 'plan_sha256': sha(HERE / 'plan.json')})
    print('C247_RESIDUAL_PID=' + str(proc.pid))
    print('LOG=' + str(out / 'worker.log'))

def show(root):
    out = root / OUT
    if (out / 'summary.json').exists():
        d = read(out / 'summary.json')
        print('\u72b6\u6001\uff1a' + d['status'] + '\uff5cB247\u53ca\u539fC\u6743\u91cd\u4fdd\u6301\u4e0d\u53d8')
        g = d['development_gate']
        print(f"\u5f00\u53d1\u76f8\u5bf9247 MAE\u5dee：\u603b\u4f53 {g['overall_delta_pp']:.4f}｜\u8ba1\u7b97\u673a {g['CS_delta_pp']:.4f}（\u8d1f\u503c\u6539\u5584）")
        if d['candidate_official_evaluated']:
            m = d['candidate_C']
            print(f"\u5b98\u65b9\u60e9\u7f5aMAE：\u603b\u4f53 {m['overall']['failure_penalized_MAE_pp']:.4f}｜\u8ba1\u7b97\u673a {m['computer_science']['failure_penalized_MAE_pp']:.4f}")
        else:
            print('\u5f00\u53d1\u672a\u901a\u8fc7\uff1b\u672a\u8fdb\u884c\u5019\u9009\u5b98\u65b9\u63a8\u7406\uff0c\u4e0d\u6539\u4fdd\u7559\u65b9\u6848')
        return
    if (out / 'failure.json').exists():
        print('\u72b6\u6001\uff1a\u6267\u884c\u4e2d\u65ad\uff0c\u7ed3\u679c\u4fdd\u7559\uff5c' + read(out / 'failure.json')['exception'])
        return
    print('\u72b6\u6001\uff1a\u6267\u884c\u8bb0\u5f55\u5982\u4e0b\uff08\u65e5\u5fd7\u4e0d\u4fdd\u8bc1\u8fdb\u7a0b\u5b58\u6d3b\uff09\uff5cGPU\uff1a0\u30011\u30013\u30015' if out.exists() else '\u72b6\u6001\uff1a\u672a\u542f\u52a8')
    for part, n in [('train', 925), ('development', 156), ('official', 141)]:
        files = list((out / ('features_' + part)).glob('width*_worker*/records.jsonl'))
        if files:
            print(f'{part}\u51bb\u7ed3\u7279\u5f81：' + str(sum((len(rows(f)) for f in files))) + f'/{n}')
    f = out / 'head_training/events.jsonl'
    if f.exists():
        events = rows(f)
        if events:
            print('\u4fee\u6b63\u5934\uff1a' + str(events[-1].get('step', 0)) + '/464｜' + events[-1]['event'])
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['launch', 'coordinate', 'show', 'verify', 'worker'])
    parser.add_argument('--project-root', required=True)
    parser.add_argument('--part', choices=['train', 'development', 'official'])
    parser.add_argument('--folder')
    parser.add_argument('--queue')
    args = parser.parse_args()
    root = Path(args.project_root).resolve()
    if args.command == 'worker':
        sys.exit(worker(root, args))
    elif args.command == 'verify':
        sources(root)
        print('CPU_SOURCE_CONTRACT_PASS_NO_GPU')
    else:
        globals()[args.command](root)
