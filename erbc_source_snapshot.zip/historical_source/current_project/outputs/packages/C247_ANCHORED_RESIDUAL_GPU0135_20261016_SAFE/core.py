"""Shared numerical-C input/readout contract, independent of C labels."""
import hashlib, json, math, random
from pathlib import Path
VERSION = 'C_NUMERIC_AB_EVIDENCE_V1'
SYSTEM = '\u4f60\u8bc4\u4f30\u5b66\u751f\u5728AI\u8f85\u52a9\u4f5c\u4e1a\u4e2d\u7684KSA\u8ba4\u77e5\u5916\u5305\u7387\uff0c\u4e0d\u662f\u64cd\u4f5c\u51cf\u8d1f\u7387\u3002\u6839\u636e\u51bb\u7ed3\u77e5\u8bc6\u84dd\u56fe\u3001\u64cd\u4f5c\u53ca\u6240\u5217\u8bc1\u636e\uff0c\u4f30\u8ba1\u7ec6\u7c92\u5ea6\u77e5\u8bc6/\u6280\u80fd/\u884c\u52a8\u4e2dAI\u627f\u62c5\u6bd4\u4f8b\u7684\u5747\u503c\u3002\u8bc1\u636e\u4e3a\u957f\u5ea6\u53d7\u63a7\u6458\u5f55\uff0c\u7f3a\u5931\u5185\u5bb9\u4e0d\u80fd\u89c6\u4e3a\u4e0d\u5b58\u5728\uff1b\u64cd\u4f5c\u6bd4\u4f8b\u4e0d\u80fd\u76f4\u63a5\u5f53KSA\u6bd4\u4f8b\u3002\u8f93\u51fa\u5355\u4e2a\u6570\u5b57\u69fd0\u81f39\uff1a0\u8868\u793a0%\uff0c9\u8868\u793a100%\uff0c\u63090\u81f39\u7684\u6982\u7387\u5206\u5e03\u8ba1\u7b97\u8fde\u7eed\u671f\u671b\u3002'
MAX_TOKENS = 32768
SEED = 20261014

def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)

def digest(x):
    return hashlib.sha256(canonical(x).encode()).hexdigest()

def sha(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda: f.read(8 * 1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def read(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def rows(p):
    return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]

def write(p, x):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8') as f:
        f.write(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False) + '\n')

def log(p, x):
    with Path(p).open('a', encoding='utf-8') as f:
        f.write(canonical(x) + '\n')

def excerpts(text, budget):
    """Original character intervals; no invented connective content."""
    need(isinstance(text, str) and budget >= 0, 'EXCERPT_ARGUMENT')
    if not text or budget == 0:
        return []
    if len(text.encode()) <= budget:
        return [{'start': 0, 'end': len(text), 'text': text}]
    head = text.encode()[:budget // 2].decode('utf-8', 'ignore')
    tail = text.encode()[-(budget - budget // 2):].decode('utf-8', 'ignore')
    return [x for x in [{'start': 0, 'end': len(head), 'text': head}, {'start': len(text) - len(tail), 'end': len(text), 'text': tail}] if x['text']]

def render(payload, evidence_budget=24000, question_budget=6000):
    allowed = {'subject', 'question', 'blueprint', 'operations', 'sources'}
    need(set(payload) == allowed, 'INPUT_ALLOWLIST')
    refs = {str(r.get('message_id') or r.get('source_id')) for z in payload['operations'] for r in z.get('evidence_refs', [])}
    sources = payload['sources']
    need(len({x['source_id'] for x in sources}) == len(sources), 'DUPLICATE_SOURCE_ID')
    ordered = sorted(enumerate(sources), key=lambda z: (z[1]['source_id'] not in refs, z[0]))
    selected = ordered[:64]
    remaining = evidence_budget
    documents = []
    audit = []
    for i, (_, s) in enumerate(selected):
        budget = min(1536 if s['source_id'] in refs else 512, remaining // max(1, len(selected) - i))
        seg = excerpts(s['content'], budget)
        used = sum((len(x['text'].encode()) for x in seg))
        remaining -= used
        if seg:
            documents.append({'source_id': s['source_id'], 'speaker': s['speaker'], 'segments': seg})
            audit.append({'source_id': s['source_id'], 'original_sha256': hashlib.sha256(s['content'].encode()).hexdigest(), 'original_characters': len(s['content']), 'ranges': [[x['start'], x['end']] for x in seg]})
    body = {'task': 'C_KSA_COGNITIVE_OUTSOURCING_RATE', 'subject': payload['subject'], 'question_segments': excerpts(payload['question'], question_budget), 'confirmed_blueprint': payload['blueprint'], 'confirmed_operations': payload['operations'], 'evidence': documents, 'evidence_policy': 'AB-referenced sources first; original order within groups; at most64 sources; bounded original head/tail spans.'}
    messages = [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': canonical(body)}]
    return (messages, {'protocol': VERSION, 'AB_sha256': digest([payload['blueprint'], payload['operations']]), 'source_count': len(sources), 'retained_source_count': len(documents), 'omitted_source_ids': [s['source_id'] for s in sources if s['source_id'] not in {x['source_id'] for x in documents}], 'evidence_byte_budget': evidence_budget, 'question_byte_budget': question_budget, 'evidence_ranges': audit, 'messages_sha256': digest(messages)})

def extract_ids(value):
    """Normalize only containers; never truncate, coerce floats or drop batch members."""
    from collections.abc import Mapping
    from numbers import Integral
    if isinstance(value, Mapping) or hasattr(value, 'keys'):
        need('input_ids' in value, 'TOKENIZER_MISSING_INPUT_IDS')
        value = value['input_ids']
    if hasattr(value, 'tolist'):
        value = value.tolist()
    need(isinstance(value, (list, tuple)) and len(value) > 0, 'TOKENIZER_EMPTY_OR_TYPE')
    if isinstance(value[0], (list, tuple)):
        need(len(value) == 1, 'TOKENIZER_MULTIPLE_SAMPLES')
        value = value[0]
    need(len(value) > 0 and all((isinstance(t, Integral) and (not isinstance(t, bool)) and (t >= 0) for t in value)), 'TOKENIZER_INVALID_ID')
    return [int(t) for t in value]

def tokenized(tokenizer, payload):
    for eb, qb in [(24000, 6000), (12000, 4000), (6000, 2000), (2000, 1000), (0, 0)]:
        messages, audit = render(payload, eb, qb)
        ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
        ids = extract_ids(ids)
        if 0 < len(ids) <= MAX_TOKENS:
            return ([int(x) for x in ids], dict(audit, tokens=len(ids), token_ids_sha256=digest(ids)))
    raise RuntimeError('FULL_AB_EXCEEDS_FROZEN_TOKEN_BUDGET_NO_SAMPLE_DROPPED')

def batches(n, epoch):
    a = list(range(n))
    random.Random(SEED + epoch).shuffle(a)
    return [a[i:i + 8] for i in range(0, n, 8)]

def metrics(predictions):
    need(len({x['unit_id'] for x in predictions}) == len(predictions), 'DUPLICATE_PREDICTION')
    out = {}
    for name in ('overall', 'computer_science'):
        rr = [x for x in predictions if name == 'overall' or x['subject'].startswith('01_')]
        need(rr, 'EMPTY_METRIC_GROUP')
        errors = []
        pen = []
        for x in rr:
            y = x['target_fraction']
            need(type(y) in (int, float) and math.isfinite(y) and (0 <= y <= 1), 'TARGET')
            if x['status'] == 'PASS':
                p = x['prediction_fraction']
                need(type(p) in (int, float) and math.isfinite(p) and (0 <= p <= 1), 'PREDICTION')
                e = 100 * (p - y)
                errors.append(e)
                pen.append(abs(e))
            else:
                need(x['status'] == 'UPSTREAM_BLOCKED', 'EXECUTION_INCOMPLETE_NOT_MODEL_FAILURE')
                pen.append(100.0)
        out[name] = {'records': len(rr), 'successes': len(errors), 'failures': len(rr) - len(errors), 'pass_rate': len(errors) / len(rr), 'failure_penalized_MAE_pp': math.fsum(pen) / len(rr), 'failure_penalized_RMSE_pp': math.sqrt(math.fsum((x * x for x in pen)) / len(rr)), 'Bias_pp': math.fsum(errors) / len(errors) if len(errors) == len(rr) else None, 'successful_only': {'MAE_pp': math.fsum(map(abs, errors)) / len(errors) if errors else None, 'RMSE_pp': math.sqrt(math.fsum((x * x for x in errors)) / len(errors)) if errors else None, 'Bias_pp': math.fsum(errors) / len(errors) if errors else None}}
    return out

def ntl_loss(probability, target):
    import torch
    y = target * 9
    lo = y.floor().long()
    hi = y.ceil().long()
    w = y - lo.float()
    soft = torch.zeros_like(probability, dtype=torch.float32)
    soft.scatter_add_(-1, lo[:, None], (1 - w)[:, None])
    soft.scatter_add_(-1, hi[:, None], w[:, None])
    ce = -(soft * probability.clamp_min(1e-12).log()).sum(-1).mean()
    w1 = (probability.cumsum(-1) - soft.cumsum(-1)).abs()[:, :-1].sum(-1).mean() / 9
    return 0.1 * ce + w1
