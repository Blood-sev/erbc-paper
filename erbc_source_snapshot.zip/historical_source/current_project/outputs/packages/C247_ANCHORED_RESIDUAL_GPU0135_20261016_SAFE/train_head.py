"""Train only small head on immutable frozen features; four-rank DDP."""
import argparse, os, math, time, datetime, contextlib, traceback, hashlib
from pathlib import Path
import run as e
from c247_anchored_residual_20261016 import make_head, tensor_loss, tensor_correct
from ddp_c_layout_20261014 import layout

def load_features(root, part, device='cpu'):
    import torch
    from safetensors.torch import load_file
    rr = e.verified_features(root, part)
    p = e.read(e.HERE / 'plan.json')
    result = []
    for r in rr:
        f = load_file(str(root / e.OUT / r['feature_path']))
        e.need(set(f) == {'last', 'operations'} and f['last'].shape == (p['hidden_size'],) and (f['operations'].shape == (len(r['operation_positions']), p['hidden_size'])), 'FEATURE_SHAPE')
        e.need(all((x.dtype == torch.float32 and torch.isfinite(x).all() for x in f.values())), 'FEATURE_VALUES')
        result.append((r, {k: v.to(device) for k, v in f.items()}))
    return result

def inputs(row, features, device):
    import torch
    return (features['last'], features['operations'], torch.tensor(row['first'], device=device, dtype=torch.float64), torch.tensor(row['second'], device=device, dtype=torch.float64))

def evaluate_saved(root, part, checkpoint):
    import torch
    from safetensors.torch import load_file
    p = e.read(e.HERE / 'plan.json')
    torch.set_num_threads(1)
    binding = e.read(checkpoint.with_suffix('.json'))
    e.need(binding['plan_sha256'] == e.sha(e.HERE / 'plan.json') and binding['sha256'] == e.sha(checkpoint), 'HEAD_CHECKPOINT_BINDING')
    model = make_head(p['hidden_size'], p['head_attention_size'])
    model.load_state_dict(load_file(str(checkpoint)), strict=True)
    model.eval()
    pred = {}
    with torch.no_grad():
        for row, f in load_features(root, part):
            base, z = model(*inputs(row, f, 'cpu'))
            value = float(tensor_correct(base, z))
            e.need(float(base) == row['anchor'] and math.isfinite(value) and (-1e-12 <= value <= 1 + 1e-12), 'EVALUATION_RANGE_OR_ANCHOR')
            e.need(0 <= value <= 1, 'EVALUATION_RANGE')
            pred[row['unit_id']] = {k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction', 'token_ids_sha256')} | {'status': 'PASS', 'prediction_fraction': value, 'anchor_prediction_fraction': row['anchor'], 'residual_logit': float(z), 'feature_sha256': row['feature_sha256']}
    result = []
    for row in e.outrows(root, part):
        if row['status'] == 'UPSTREAM_BLOCKED':
            result.append({k: row[k] for k in ('unit_id', 'subject', 'student_group_id', 'target_fraction')} | {'status': 'UPSTREAM_BLOCKED', 'prediction_fraction': None})
        else:
            result.append(pred[row['unit_id']])
    return result

def main(root):
    import torch, torch.distributed as dist
    from torch.nn.parallel import DistributedDataParallel as DDP
    from safetensors.torch import save_file, load_file
    p = e.read(e.HERE / 'plan.json')
    out = root / e.OUT
    folder = out / 'head_training'
    rank = int(os.environ['RANK'])
    local = int(os.environ['LOCAL_RANK'])
    e.need(int(os.environ['WORLD_SIZE']) == 4 and rank == local and (rank in range(4)), 'DDP_WORLD')
    picked = e.read(out / 'startup_resources.json')['selected']
    e.need([x['index'] for x in picked] == [0, 1, 3, 5] and os.environ['CUDA_VISIBLE_DEVICES'] == ','.join((x['uuid'] for x in picked)), 'HEAD_GPU_BINDING')
    torch.cuda.set_device(local)
    torch.set_num_threads(1)
    device = torch.device('cuda', local)
    free, total = torch.cuda.mem_get_info(local)
    e.need(free > 6 * 1024 ** 3, 'HEAD_FREE_MARGIN')
    torch.cuda.set_per_process_memory_fraction(min(0.99, (free - 6 * 1024 ** 3) / total), local)
    dist.init_process_group('nccl', device_id=device, timeout=datetime.timedelta(seconds=600))

    def guard(phase):
        free = torch.cuda.mem_get_info(local)[0] / 1024 ** 3
        e.log(folder / f'resources_rank{rank}.jsonl', {'phase': phase, 'physical_gpu': picked[rank]['index'], 'free_GiB': free, 'reserved_GiB': torch.cuda.memory_reserved(local) / 1024 ** 3, 'time': time.time()})
        e.need(free >= 5, 'RESOURCE_BELOW_5GiB')
    try:
        train = load_features(root, 'train')
        e.need(len(train) == 925, 'TRAIN_COUNT')

        def create():
            torch.manual_seed(p['seed'] + rank)
            torch.cuda.manual_seed_all(p['seed'] + rank)
            model = make_head(p['hidden_size'], p['head_attention_size']).to(device)
            ddp = DDP(model, device_ids=[local], output_device=local, broadcast_buffers=False, find_unused_parameters=False)
            opt = torch.optim.AdamW(model.parameters(), lr=0.0001, betas=(0.9, 0.95), eps=1e-08, weight_decay=0.01, foreach=False)
            return (model, ddp, opt)

        def synced_hash(model):
            h = hashlib.sha256()
            for n, v in model.state_dict().items():
                h.update(n.encode())
                h.update(v.detach().cpu().contiguous().view(torch.uint8).numpy().tobytes())
            allhash = [None] * 4
            dist.all_gather_object(allhash, h.hexdigest())
            e.need(len(set(allhash)) == 1, 'HEAD_DDP_DIVERGENCE')
            return allhash[0]

        def output(network, index):
            row, features = train[index]
            f = {k: x.to(device) for k, x in features.items()}
            return (row, network(*inputs(row, f, device)))

        def update(model, ddp, opt, batch, lr):
            guard('before_update')
            opt.zero_grad(set_to_none=True)
            for group in opt.param_groups:
                group['lr'] = lr
            stats = torch.zeros(2, device=device, dtype=torch.float64)
            for micro, (index, weight) in enumerate(layout(batch, rank)):
                actual = batch[0] if index is None else index
                with ddp.no_sync() if micro == 0 else contextlib.nullcontext():
                    row, (base, z) = output(ddp, actual)
                    target = torch.tensor(row['target_fraction'], device=device, dtype=torch.float64)
                    loss, _ = tensor_loss(base, z, target, retention=p['retention'])
                    e.need(bool(torch.isfinite(loss)), 'HEAD_NONFINITE_LOSS')
                    (loss * weight).backward()
                if index is not None:
                    stats += torch.tensor([float(loss.detach()), 1.0], device=device, dtype=torch.float64)
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0, foreach=False, error_if_nonfinite=True)
            opt.step()
            guard('after_update')
            dist.all_reduce(stats)
            e.need(int(stats[1]) == len(batch), 'BATCH_COUNT')
            return (float(stats[0] / stats[1]), float(norm))
        model, ddp, opt = create()
        initial = synced_hash(model)
        with torch.no_grad():
            for i in range(rank, len(train), 4):
                row, (base, z) = output(model, i)
                e.need(float(z) == 0 and float(tensor_correct(base, z)) == row['anchor'], 'INITIAL_NOT_C247')
        fixture = max(range(len(train)), key=lambda i: abs(train[i][0]['anchor'] - train[i][0]['target_fraction']))
        largest = max(range(len(train)), key=lambda i: len(train[i][1]['operations']))
        with torch.no_grad():
            output(model, largest)
        for k, n in enumerate((8, 5, 8, 5), 1):
            update(model, ddp, opt, [fixture] * n, 0.0001)
            synced_hash(model)
        e.need(synced_hash(model) != initial, 'SMOKE_NO_HEAD_UPDATE')
        cp = folder / 'discarded_smoke.safetensors'
        if rank == 0:
            save_file({k: v.detach().cpu().contiguous() for k, v in model.state_dict().items()}, str(cp))
        dist.barrier()
        before = output(model, fixture)[1][1].detach()
        model.load_state_dict(load_file(str(cp)), strict=True)
        e.need(torch.equal(before, output(model, fixture)[1][1].detach()), 'HEAD_SAVE_RELOAD')
        if rank == 0:
            e.write(folder / 'smoke.json', {'status': 'PASS_REAL_DDP_HEAD_ONLY', 'full_batch': 8, 'tail_batch': 5, 'steps': 4, 'initial_exact_C247': True, 'backbones_not_loaded': True, 'head_save_reload': True, 'maximum_train_operation_positions': len(train[largest][1]['operations'])})
        del model, ddp, opt
        torch.cuda.empty_cache()
        dist.barrier()
        model, ddp, opt = create()
        e.need(synced_hash(model) == initial, 'FRESH_HEAD_INIT_DRIFT')
        step = 0
        candidates = []
        for epoch in range(4):
            model.train()
            for batch in batches(925, epoch):
                factor = max(1e-08, step / 24) if step < 24 else 0.5 * (1 + math.cos(math.pi * (step - 24) / (464 - 24)))
                loss, norm = update(model, ddp, opt, batch, 0.0001 * factor)
                step += 1
                if rank == 0:
                    e.log(folder / 'events.jsonl', {'event': 'optimizer_step', 'epoch': epoch + 1, 'step': step, 'loss': loss, 'gradient_norm': norm, 'time': time.time()})
            synced_hash(model)
            model.eval()
            cp = folder / f'epoch{epoch + 1}.safetensors'
            if rank == 0:
                save_file({k: v.detach().cpu().contiguous() for k, v in model.state_dict().items()}, str(cp))
                e.write(cp.with_suffix('.json'), {'sha256': e.sha(cp), 'plan_sha256': e.sha(e.HERE / 'plan.json')})
                pred = evaluate_saved(root, 'development', cp)
                m = e.metrics(pred)
                e.write(folder / f'epoch{epoch + 1}_development.json', pred)
                candidates.append({'epoch': epoch + 1, 'checkpoint': cp.name, 'sha256': e.sha(cp), 'metrics': m})
                e.log(folder / 'events.jsonl', {'event': 'epoch_evaluation_complete', 'epoch': epoch + 1, 'step': step, 'metrics': m, 'time': time.time()})
            dist.barrier()
        e.need(step == 464, 'FORMAL_STEP_COUNT')
        synced_hash(model)
        if rank == 0:
            best = min(candidates, key=lambda x: (x['metrics']['overall']['failure_penalized_MAE_pp'], x['metrics']['computer_science']['failure_penalized_MAE_pp'], x['epoch']))
            e.write(folder / 'selection.json', best)
            e.write(folder / 'summary.json', {'steps': 464, 'epochs': candidates, 'trainable_parameters': sum((v.numel() for v in model.parameters())), 'backbones_frozen': True, 'initial_parameter_sha256': initial, 'full_finetuning_compute_equivalence_claimed': False, 'head_only_training': True})
            e.write(folder / 'exit.json', {'status': 'PASS'})
        dist.barrier()
    except BaseException:
        e.write(folder / f'failure_rank{rank}.json', {'traceback': traceback.format_exc()})
        raise
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', required=True)
    args = parser.parse_args()
    main(Path(args.project_root).resolve())
