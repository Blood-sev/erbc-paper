"""C-only anchored signed residual prototype, NOT a deployed runner.

Frozen NTL-C/232-C mean is the anchor, not B247. Evidence features are from
the existing common-AB input, with both backbones in eval/no_grad mode.
No official-data fitting, inferred correctness label, or subject routing.
"""
import math

def need(ok, message):
    if not ok:
        raise ValueError(message)

def fraction(x):
    need(type(x) in (int, float) and math.isfinite(x) and (0 <= x <= 1), 'FRACTION')

def anchor(first, second):
    fraction(first)
    fraction(second)
    return (first + second) / 2

def correct(base, residual_logit):
    """Identity at zero; signed correction reaches either side of the anchor.

    In fraction units. Positive correction uses remaining distance to 1,
    negative correction uses distance to 0. No clipping or epsilon label edits.
    """
    fraction(base)
    need(type(residual_logit) in (int, float) and math.isfinite(residual_logit), 'RESIDUAL')
    t = math.tanh(residual_logit)
    return base + (1 - base) * t if t >= 0 else base * (1 + t)

def loss(base, residual_logit, target, retention=0.05):
    fraction(target)
    need(type(retention) in (int, float) and math.isfinite(retention) and (0 <= retention < 1), 'RETENTION')
    prediction = correct(base, residual_logit)
    return (abs(prediction - target) + retention * abs(prediction - base), prediction)

def gradient(base, residual_logit, target, retention=0.05):
    value, prediction = loss(base, residual_logit, target, retention)
    t = math.tanh(residual_logit)
    slope = (1 - base if t > 0 else base if t < 0 else 0.5) * (1 - t * t)
    sign = lambda v: float(v > 0) - float(v < 0)
    return (sign(prediction - target) + retention * sign(prediction - base)) * slope

def tensor_correct(base, residual_logit):
    import torch
    need(base.shape == residual_logit.shape, 'SHAPE')
    need(not base.requires_grad, 'ANCHOR_MUST_BE_FROZEN')
    need(bool(torch.isfinite(base).all()) and bool(((base >= 0) & (base <= 1)).all()), 'FRACTION')
    need(bool(torch.isfinite(residual_logit).all()), 'RESIDUAL')
    t = residual_logit.tanh()
    return torch.where(t == 0, base + 0.5 * t, torch.where(t > 0, base + (1 - base) * t, base * (1 + t)))

def tensor_loss(base, residual_logit, target, retention=0.05):
    import torch
    need(math.isfinite(retention) and 0 <= retention < 1, 'RETENTION')
    need(target.shape == base.shape and (not target.requires_grad), 'TARGET_SHAPE_OR_GRAD')
    need(bool(torch.isfinite(target).all()) and bool(((target >= 0) & (target <= 1)).all()), 'TARGET')
    prediction = tensor_correct(base, residual_logit)
    return ((prediction - target).abs() + retention * (prediction - base).abs(), prediction)

def make_head(hidden_size, attention_size=128):
    """Small evidence attention head. Backbones are not part of this module.

    Frozen final-token and operation-position features from NTL-C are required;
    neither C targets nor gold KSA counts/allocations enter forward().
    No global token features are saved, to keep feature storage bounded.
    """
    import torch
    from torch import nn

    class ResidualHead(nn.Module):

        def __init__(self):
            super().__init__()
            self.norm = nn.LayerNorm(hidden_size)
            self.query = nn.Linear(hidden_size, attention_size, bias=False)
            self.key = nn.Linear(hidden_size, attention_size, bias=False)
            self.value = nn.Linear(hidden_size, attention_size, bias=False)
            self.hidden = nn.Sequential(nn.Linear(hidden_size + attention_size + 2, attention_size), nn.GELU())
            self.output = nn.Linear(attention_size, 1)
            nn.init.zeros_(self.output.weight)
            nn.init.zeros_(self.output.bias)

        def forward(self, last, operations, first, second):
            need(last.ndim == 1 and len(last) == hidden_size and (operations.ndim == 2) and (operations.shape[1] == hidden_size) and (len(operations) > 0), 'FEATURE_SHAPE')
            need(first.numel() == second.numel() == 1, 'BRANCH_SHAPE')
            need(not any((x.requires_grad for x in (last, operations, first, second))), 'FEATURES_MUST_BE_FROZEN')
            need(all((bool(torch.isfinite(x).all()) for x in (last, operations, first, second))), 'NONFINITE_FEATURE')
            need(bool(((first >= 0) & (first <= 1)).all()) and bool(((second >= 0) & (second <= 1)).all()), 'BRANCH_RANGE')
            last = self.norm(last)
            op = self.norm(operations)
            weights = ((self.key(op) * self.query(last)).sum(-1) / math.sqrt(attention_size)).softmax(-1)
            pooled = (weights[:, None] * self.value(op)).sum(0)
            base = (first.reshape(()).double() + second.reshape(()).double()) / 2
            numeric = torch.stack([base, (first - second).reshape(()).double()]).to(last.dtype)
            residual = self.output(self.hidden(torch.cat([last, pooled, numeric]))).reshape(())
            return (base, residual)
    return ResidualHead()
