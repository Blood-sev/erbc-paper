"""Role-separated, citation-conditioned lexical evidence correction, NOT a semantic verifier."""
import torch
from torch import nn
import torch.nn.functional as F
from features import DIM
def tensor_features(f):
    return {k:torch.tensor(v,dtype=torch.long if k=='roles' else torch.float32) for k,v in f.items()}
class EvidenceHead(nn.Module):
    def __init__(self,arm='evidence',hidden=2560,width=16):
        super().__init__()
        if arm not in ('hidden','evidence'):raise ValueError(arm)
        self.arm=arm;self.width=width
        self.op=nn.Sequential(nn.LayerNorm(hidden),nn.Linear(hidden,width),nn.GELU())
        self.global_=nn.Sequential(nn.LayerNorm(hidden),nn.Linear(hidden,width),nn.GELU())
        self.text=nn.Linear(DIM,width,bias=False)
        self.query=nn.Linear(2*width,width,bias=False)
        self.key=nn.Linear(width,width,bias=False)
        self.body=nn.Sequential(nn.Linear(11*width+26,32),nn.GELU(),nn.Linear(32,3))
        nn.init.zeros_(self.body[-1].weight);nn.init.zeros_(self.body[-1].bias)
    def forward(self,s,f):
        h=self.op(s['operations'].float());n=len(h);w=self.width
        glob=self.global_(s['last'].float()).expand(n,-1)
        att=h.new_zeros((n,4,len(f['roles'])))
        if self.arm=='evidence':
            ot=self.text(f['op_bags']);doc=self.text(f['doc_bags'])
            score=(self.query(torch.cat((h,ot),-1))@self.key(doc).T)/(w**.5)
            contexts=[];global_contexts=[];stats=[]
            for role in range(4):
                mask=(f['roles']==role).float()*f['real_doc']
                linked=f['links']*mask[None]
                a=torch.softmax(score.masked_fill(linked==0,-1e4),-1)*linked
                a=a/a.sum(-1,keepdim=True).clamp_min(1e-12);att[:,role,:]=a
                contexts.append(a@doc)
                global_contexts.append(((mask[:,None]*doc).sum(0)/mask.sum().clamp_min(1)).expand(n,-1))
                cnt=linked.sum(-1)
                stats.extend([(cnt>0).float(),torch.log1p(cnt)/5,
                  torch.log1p(mask.sum()).expand(n)/5,
                  ((mask*f['lengths']).sum()/mask.sum().clamp_min(1)).expand(n)])
            stats.append(f['missing'])
            ev=torch.cat([ot,*contexts,*global_contexts,torch.stack(stats,-1)],-1)
        else:
            ev=h.new_zeros((n,9*w+17))
        q=s['responsibility'].double()
        ell=q.clamp_min(1e-6).log();q0=torch.softmax(ell,-1)
        fixed=torch.cat((q.float(),s['b_onehot'].float(),s['mass'].float()[:,None],
          s['prediction'].float().expand(n,1),s['gate'].float().expand(n,1)),-1)
        shift=6*torch.tanh(self.body(torch.cat((h,glob,ev,fixed),-1))).double()
        qnew=torch.softmax(ell+shift,-1)
        m=s['mass'].double();v=qnew.new_tensor([0.,.5,1.])
        delta=(m*((qnew-q0)@v)).sum()
        # Positive semantic responsibility residual; old scalar remains the anchor.
        # No old signed gate inversion, no hard "boundary cannot change" rule.
        p=(s['prediction'].double()+delta).clamp(0,1)
        kl=(m*(qnew*(qnew.clamp_min(1e-12).log()-q0.log())).sum(-1)).sum()
        return dict(prediction=p,responsibility=qnew,mass=m,reference_q=q0,
          delta=delta,shift=shift,q_KL=kl,attention=att)
def ordinal(q,supervision):
    if supervision is None:return q.sum()*0
    mask=torch.tensor(supervision['mask'],dtype=torch.bool)
    if len(mask)!=len(q):raise RuntimeError('LOCAL_MASK_SHAPE')
    if not bool(mask.any()):return q.sum()*0
    r=q.new_tensor(supervision['responsibility'])
    if r.shape!=q.shape or not bool(torch.isfinite(r).all()):raise RuntimeError('LOCAL_TARGET_SHAPE')
    return .5*(q[mask].cumsum(-1)[:,:2]-r[mask].cumsum(-1)[:,:2]).abs().sum(-1).mean()
def loss_parts(head,clean,pred,fc,fp,y,sup):
    c=head(clean,fc);driftc=(c['prediction']-clean['prediction']).abs()
    terms=dict(clean_drift=.1*driftc,clean_local=.05*ordinal(c['responsibility'],sup['clean']),
      clean_KL=.01*c['q_KL'])
    if pred is not None:
        z=head(pred,fp);err=(z['prediction']-y).abs();old=(pred['prediction']-y).abs()
        terms.update(MAE=err,excess=.1*F.relu(err-old),
          predicted_drift=.02*(z['prediction']-pred['prediction']).abs(),
          predicted_local=.05*ordinal(z['responsibility'],sup['predicted']),predicted_KL=.01*z['q_KL'])
    # One unit, one summed multi-view objective; no doubled sampling.
    # Blocked predicted view uses clean local labels + retention only, never a fabricated view.
    return sum(terms.values()),terms
