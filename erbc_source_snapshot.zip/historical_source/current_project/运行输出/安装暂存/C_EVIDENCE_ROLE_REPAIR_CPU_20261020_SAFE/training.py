import gzip,hashlib,json,math,random,time
from pathlib import Path
import torch
from safetensors.torch import save_file
from features import PARTS,need
from evidence_head import loss_parts,ordinal
def write(p,x):
    with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def emit(p,x):
    with Path(p).open('a',encoding='utf8') as f:f.write(json.dumps(dict(time=time.time(),**x),ensure_ascii=False,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def weights_sha(head):
    h=hashlib.sha256()
    for k,v in sorted(head.state_dict().items()):h.update(k.encode());h.update(v.detach().numpy().tobytes())
    return h.hexdigest()
def channel_checks(head,rows,states,features,out,check):
    report={}
    # Frozen diagnostic interventions, never used to select a candidate.
    for mode in ('text_off','links_off','student_assistant_swapped'):
        shifts=[];changes=[]
        with torch.no_grad():
            for row in rows:
                check()
                if row['status']!='READY':continue
                u=row['unit_id'];f=features[u];altered={k:v.clone() for k,v in f.items()}
                if mode=='text_off':
                    altered['op_bags'].zero_();altered['doc_bags'].zero_()
                elif mode=='links_off':altered['links'].zero_()
                else:
                    roles=f['roles']
                    altered['roles']=torch.where(roles==0,1,torch.where(roles==1,0,roles))
                p=float(head(states[u],f)['prediction']);q=float(head(states[u],altered)['prediction'])
                shifts.append(100*abs(p-q));changes.append(100*(abs(q-row['target_fraction'])-abs(p-row['target_fraction'])))
        report[mode]=dict(valid=len(shifts),mean_absolute_shift_pp=math.fsum(shifts)/len(shifts) if shifts else None,
          fixed_denominator_MAE_difference_pp=math.fsum(changes)/len(rows))
    write(out/'pred_development_channel_checks.json',dict(results=report,
      note='Frozen off-distribution interventions, not retrained ablations/causal proof. No selection by these scores. Blocked states unchanged.'))
def evaluate(head,rows,states,features,metrics,out,part,check,sups=None):
    out.mkdir(parents=True,exist_ok=True);predictions=[];diagnostics=[]
    with gzip.open(out/(part+'_traces.jsonl.gz'),'xt',encoding='utf8') as f,torch.no_grad():
        head.eval()
        for row in rows:
            check();u=row['unit_id']
            rec={k:row[k] for k in ('unit_id','subject','student_group_id','target_fraction','status')}
            if row['status']=='READY':
                s=states[u];z=head(s,features[u]);p=float(z['prediction']);q=z['responsibility'];m=z['mass']
                need(math.isfinite(p) and 0<=p<=1 and bool(torch.isfinite(q).all()),'OUTPUT_INVALID')
                need(torch.equal(m,s['mass'].double()) and bool(torch.allclose(q.sum(-1),torch.ones(len(q),dtype=q.dtype),atol=1e-12)),'FROZEN_MASS_OR_SIMPLEX')
                rec.update(status='PASS',prediction_fraction=p,token_ids_sha256=row['token_ids_sha256'])
                e=100*abs(p-row['target_fraction']);old=100*abs(float(s['prediction'])-row['target_fraction'])
                local=sups[u]['predicted' if part.startswith('pred') else 'clean'] if sups is not None and part.endswith('train') else None
                d=dict(unit_id=u,error_pp=e,old_error_pp=old,change_pp=e-old,
                  prediction_shift_pp=100*(p-float(s['prediction'])),operation_count=len(q),
                  matched=sum(local['mask']) if local else 0,
                  local_W1=float(ordinal(q,local)) if local else None,
                  retained_local_W1=float(ordinal(z['reference_q'],local)) if local else None)
                diagnostics.append(d)
                f.write(json.dumps(dict(**d,token_ids_sha256=row['token_ids_sha256'],
                  target_fraction=row['target_fraction'],prediction=p,retained_prediction=float(s['prediction']),
                  responsibility=q.tolist(),reference_q=z['reference_q'].tolist(),mass=m.tolist(),
                  responsibility_shift=z['shift'].tolist(),unclipped_delta=float(z['delta']),
                  role_attention=z['attention'].tolist()),allow_nan=False)+'\n')
            else:need(row['status']=='UPSTREAM_BLOCKED','INVALID_FAILURE_STATUS')
            predictions.append(rec)
    write(out/(part+'_predictions.json'),predictions);score=metrics(predictions);write(out/(part+'_metrics.json'),score)
    def group(xs):
        avg=lambda k:math.fsum(x[k] for x in xs if x[k] is not None)/sum(x[k] is not None for x in xs) if any(x[k] is not None for x in xs) else None
        return dict(n=len(xs),MAE_valid=avg('error_pp'),delta=avg('change_pp'),
          improved=sum(x['change_pp']< -1e-9 for x in xs),worsened=sum(x['change_pp']>1e-9 for x in xs),
          severe_harm_gt5pp=sum(x['change_pp']>5 for x in xs),local_W1=avg('local_W1'),retained_local_W1=avg('retained_local_W1'))
    write(out/(part+'_diagnostics.json'),dict(all=group(diagnostics),
      old_error_le5=group([d for d in diagnostics if d['old_error_pp']<=5]),
      old_error_gt20=group([d for d in diagnostics if d['old_error_pp']>20]),
      note='All valid traces saved. Error groups retrospective, never inputs/weights. Local labels only training; partial weak matches. Attention is not verified semantic evidence.'))
    return score
def train(head,states,features,rows,sup,plan,out,metrics,check,seed,arm):
    need(set(states)==set(features)==set(rows)==set(PARTS),'NO_OFFICIAL')
    out.mkdir();write(out/'initialization.json',dict(weights_sha256=weights_sha(head),seed=seed,arm=arm,
      parameters=sum(p.numel() for p in head.parameters())))
    with torch.no_grad():
        for part in PARTS:
            for u,s in states[part].items():
                check();need(torch.equal(head(s,features[part][u])['prediction'],s['prediction'].double()),'ZERO_HEAD_NOT_IDENTITY')
    opt=torch.optim.AdamW(head.parameters(),lr=plan['learning_rate'],betas=(.9,.95),eps=1e-8,weight_decay=.01)
    step=0;history=[];n=len(rows['clean_train'])
    for epoch in range(1,plan['epochs']+1):
        ep=out/('epoch'+str(epoch));ep.mkdir();order=list(range(n));random.Random(seed+epoch).shuffle(order)
        write(ep/'train_order.json',[rows['clean_train'][i]['unit_id'] for i in order]);head.train()
        for start in range(0,n,plan['batch']):
            check();batch=order[start:start+plan['batch']];opt.zero_grad(set_to_none=True);parts={}
            for i in batch:
                r=rows['clean_train'][i];u=r['unit_id']
                loss,terms=loss_parts(head,states['clean_train'][u],states['pred_train'].get(u),
                  features['clean_train'][u],features['pred_train'].get(u),r['target_fraction'],sup[u])
                need(bool(torch.isfinite(loss)),'LOSS_FINITE');(loss/len(batch)).backward()
                for k,v in terms.items():parts[k]=parts.get(k,0)+float(v.detach())/len(batch)
            norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1,error_if_nonfinite=True);opt.step();step+=1
            need(all(bool(torch.isfinite(p).all()) for p in head.parameters()),'PARAM_FINITE')
            event=dict(event='update',arm=arm,seed=seed,epoch=epoch,step=step,total=plan['epochs']*math.ceil(n/plan['batch']),
              batch_size=len(batch),gradient_norm=float(norm),loss_parts=parts)
            emit(out/'events.jsonl',event);emit(out.parent.parent/'events.jsonl',event)
        save_file(head.state_dict(),str(ep/'evidence_head.safetensors'))
        scores={part:evaluate(head,rows[part],states[part],features[part],metrics,ep,part,check,sup) for part in PARTS}
        if epoch==plan['epochs']:
            channel_checks(head,rows['pred_development'],states['pred_development'],features['pred_development'],ep,check)
        record=dict(epoch=epoch,metrics=scores,head_sha256=sha(ep/'evidence_head.safetensors'))
        write(ep/'summary.json',record);history.append(record)
    result=dict(steps=step,seed=seed,arm=arm,history=history,final=history[-1])
    write(out/'summary.json',result);return result
