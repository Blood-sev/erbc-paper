"""Replay full retained stack; only input features reach the candidate."""
import importlib.util
import torch
from safetensors.torch import load_file
import model_v2
from amplitude import AmplitudeRefiner,freeze_state
from retained_routing import SelectiveRouting,bind_state
from allocation import AllocationRefiner
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

class FrozenStack:
    def __init__(self,root,mp,rp,cp,ap,tp,op,caches):
        self.caches=caches
        self.repair_code=load('direct_eval_ordinal',root/op['prior_package']/'correction.py')
        joint_code=load('direct_eval_joint',root/tp['joint_package']/'joint.py')
        original=load('direct_eval_ablation',root/ap['source_package']/'ablation.py')
        self.teacher=model_v2.make_head(2560);self.teacher.load_state_dict(load_file(str(root/tp['teacher_source']/'epoch1/head.safetensors')))
        self.repair=self.repair_code.ResponsibilityRepair();self.repair.load_state_dict(load_file(str(root/tp['ordinal_source']/'epoch4/repair_head.safetensors')))
        self.joint=joint_code.JointRefiner();self.joint.load_state_dict(load_file(str(root/tp['retained_source']/'epoch4/joint_head.safetensors')))
        self.base=original.AblationRefiner();self.base.load_state_dict(load_file(str(root/ap['source_output']/ap['selected_run']/'epoch4/ablation_head.safetensors')))
        self.amp=AmplitudeRefiner();self.amp.load_state_dict(load_file(str(root/cp['source_output']/'candidate/epoch4/amplitude_head.safetensors')))
        self.router=SelectiveRouting(arm='local_global');self.router.load_state_dict(load_file(str(root/rp['source_output']/rp['selected_run']/'epoch4/routing_head.safetensors')))
        self.allocation=AllocationRefiner(arm='separated');self.allocation.load_state_dict(load_file(str(root/mp['source_output']/mp['selected_run']/'epoch4/allocation_head.safetensors')))
        for m in (self.teacher,self.repair,self.joint,self.base,self.amp,self.router,self.allocation):m.eval();m.requires_grad_(False)
    def state(self,part,row):
        entry=self.caches[part][row['unit_id']];f=load_file(entry['absolute_feature_path'],device='cpu')
        need(set(f)=={'operations','last'} and f['operations'].shape==(len(row['operation_positions']),2560) and f['last'].shape==(2560,),'FEATURE_SHAPE')
        need(all(bool(torch.isfinite(v).all()) for v in f.values()),'FEATURE_FINITE')
        with torch.no_grad():
            s=self.repair_code.make_state(self.teacher,f['operations'],torch.cat([f['operations'],f['last'][None]],0),
               torch.tensor(row['b_share']),torch.tensor((entry['first']+entry['second'])/2,dtype=torch.float64))
            z=self.repair(s);s.update(prediction=z['prediction'],responsibility=z['responsibility'],operations=f['operations'],last=f['last'])
            z=self.joint(s);s.update(prediction=z['prediction'],responsibility=z['responsibility'],mass=z['mass'])
            context=freeze_state(self.base,s);z=self.amp(context)
            def bind(value):
                return bind_state(dict(operations=f['operations'],last=f['last'],local=s['local'],b_onehot=s['b_onehot'],
                  gate=s['gate'],prediction=value['prediction'],responsibility=value['responsibility'],
                  mass=value['mass'],predicted_counts=value['predicted_counts']),context['condition'],context['attention'])
            z=self.router(bind(z));z=self.allocation(bind(z))
            return {k:v.detach() for k,v in dict(operations=f['operations'],last=f['last'],b_onehot=s['b_onehot'],
                gate=s['gate'],prediction=z['prediction'],responsibility=z['responsibility'],mass=z['mass']).items()}
