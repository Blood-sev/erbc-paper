"""Reallocate operation contributions after successful responsibility/bias readout."""
import math
import torch
from torch import nn
import torch.nn.functional as F
from bias_model import BiasReadout,ordinal
ARMS=('continuation','mass_only','joint')
KEYS=('overall','computer_science')
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
class JointMass(nn.Module):
    def __init__(self,checkpoint,arm):
        super().__init__();need(arm in ARMS,'ARM');self.arm=arm
        self.core=BiasReadout('joint');self.core.load_state_dict(checkpoint)
        if arm=='mass_only':self.core.requires_grad_(False)
        self.norm=nn.LayerNorm(32)
        self.mass_head=nn.Sequential(nn.Linear(101,32),nn.GELU(),nn.Linear(32,1))
        nn.init.zeros_(self.mass_head[-1].weight);nn.init.zeros_(self.mass_head[-1].bias)
        if arm=='continuation':
            self.norm.requires_grad_(False);self.mass_head.requires_grad_(False)
    def forward(self,s):
        z=self.core(s);m=z['mass'];q=z['responsibility'];h=self.norm(s['latent'].float())
        v=q.new_tensor([0.,.5,1.]);values=q@v
        pooled=(m.float()[:,None]*h).sum(0);avg=h.mean(0)
        x=torch.cat((h,pooled.expand(len(h),-1),avg.expand(len(h),-1),q.float(),m.float()[:,None],values.float()[:,None]),-1)
        raw=self.mass_head(x).squeeze(-1).double()
        shift=2*raw.tanh()
        if self.arm=='continuation' or len(m)==1:
            newm=m+shift.sum()*0
        else:
            weighted=m*shift.exp()
            # Keep the source float32 mass sum, including tiny rounding error.
            # shift==0 gives denominator exactly1 and restores every source weight.
            newm=weighted/(weighted.sum()/m.sum())
        dm=((newm-m)*values).sum()
        newz=dict(z);newz.update(mass=newm,reference_mass=m,mass_shift=shift,delta_mass=dm,
          aggregate=z['aggregate']+dm,unbounded=z['unbounded']+dm,
          prediction=(z['unbounded']+dm).clamp(0,1))
        return newz
def loss_parts(head,clean,pred,y,sup,tc,tp):
    c=head(clean)
    def qkl(z,t):
        q=z['responsibility'];ref=t['responsibility'].clamp_min(1e-12)
        # Fixed teacher weighting prevents reducing the penalty by hiding operations.
        return (t['mass']*(q*(q.clamp_min(1e-12).log()-ref.log())).sum(-1)).sum()
    def mkl(z,t):
        m=z['mass']/z['mass'].sum();ref=t['mass']/t['mass'].sum()
        return (m*(m.clamp_min(1e-12).log()-ref.clamp_min(1e-12).log())).sum()
    terms=dict(clean_drift=.1*(c['prediction']-tc['prediction']).abs(),
      clean_local=.05*ordinal(c['responsibility'],sup['clean']),clean_qKL=.01*qkl(c,tc),
      clean_bias=.02*(c['delta_bias']-tc['delta_bias']).abs(),clean_massKL=.01*mkl(c,tc))
    if pred is not None:
        need(tp is not None,'TEACHER_REQUIRED');z=head(pred);e=(z['prediction']-y).abs();old=(tp['prediction']-y).abs()
        terms.update(MAE=e,excess=.1*F.relu(e-old),pred_drift=.02*(z['prediction']-tp['prediction']).abs(),
          pred_local=.05*ordinal(z['responsibility'],sup['predicted']),pred_qKL=.01*qkl(z,tp),
          pred_bias=.02*(z['delta_bias']-tp['delta_bias']).abs(),pred_massKL=.01*mkl(z,tp))
    return sum(terms.values()),terms
def choose(runs,seeds):
    by={(r['arm'],r['seed']):r for r in runs}
    need(len(by)==len(runs)==len(ARMS)*len(seeds) and set(by)=={(a,s) for a in ARMS for s in seeds},'RUNS')
    checks=[]
    for seed in seeds:
        for arm in ARMS:
            rec=by[arm,seed];need(rec['epoch']==4,'EPOCH')
            for d in rec['delta'].values():need(set(d)==set(KEYS) and all(math.isfinite(x) for x in d.values()),'METRICS')
        a=by['joint',seed]['delta'];b=by['continuation',seed]['delta']
        checks.append(dict(seed=seed,audit_nonworse=all(x<=1e-10 for x in a['pred_audit'].values()),
          dev_improves=all(x<=1e-10 for x in a['pred_development'].values()) and any(x< -1e-10 for x in a['pred_development'].values()),
          beats_continuation_audit=a['pred_audit']['overall']<b['pred_audit']['overall']-1e-10,
          beats_continuation_dev=a['pred_development']['overall']<b['pred_development']['overall']-1e-10))
    passed=all(all(v for k,v in c.items() if k!='seed') for c in checks)
    return dict(candidate=by['joint',seeds[0]] if passed else None,checks=checks,
      rule='Fixed joint first seed epoch4; both seeds audit nonworse and predicted dev improves; beats paired continuation overall in audit/dev. mass_only diagnostic, never substituted. Reused audit not independent.')
