import gzip,hashlib,json,math,random,time
from pathlib import Path
import torch
from safetensors.torch import save_file
from refinement import need,new_loss
def write(p,x):
    with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def emit(p,**x):
    with Path(p).open('a',encoding='utf8') as f:f.write(json.dumps(dict(time=time.time(),**x),ensure_ascii=False,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sections(rows,split):
    return {v+'_'+k:rows[v+'_development'] if k=='development' else [r for r in rows[v+'_train'] if r['unit_id'] in set(split[k])]
            for v in ('clean','pred') for k in ('fit','audit','development')}
def statepart(part):return part if part.endswith('development') else part.split('_')[0]+'_train'
def record(row,p=None):
    z={k:row[k] for k in ('unit_id','subject','student_group_id','target_fraction','status')}
    if row['status']=='READY':
        need(p is not None and math.isfinite(p) and 0<=p<=1,'PREDICTION')
        z.update(status='PASS',prediction_fraction=p,token_ids_sha256=row['token_ids_sha256'])
    else:need(row['status']=='UPSTREAM_BLOCKED','EXECUTION_NOT_SCORE')
    return z
def evaluate(head,rr,states,teachers,metrics,out,part,check):
    pp=[];base=[];tr=[]
    with torch.no_grad():
        for row in rr:
            check();u=row['unit_id']
            if row['status']=='READY':
                s=states[u];t=teachers[u];z=head(s);p=float(z['prediction']);p0=float(t['prediction']);y=row['target_fraction']
                need(torch.equal(z['mass'],s['mass'].double()),'MASS_CHANGED')
                need(abs(max(0,min(1,float(z['aggregate']+z['corrected_bias'])))-p)<1e-12,'DECOMPOSITION')
                tr.append(dict(unit_id=u,target_fraction=y,prediction=p,teacher_prediction=p0,
                  error_pp=100*abs(p-y),teacher_error_pp=100*abs(p0-y),
                  change_pp=100*(abs(p-y)-abs(p0-y)),
                  actual_output_change_pp=100*(p-p0),
                  q_change_pp=100*float(z['delta_q']-t['delta_q']),
                  bias_change_pp=100*float(z['delta_bias']-t['delta_bias']),
                  unbounded=float(z['unbounded']),teacher_unbounded=float(t['unbounded']),
                  clipped=abs(float(z['unbounded'])-p)>1e-10,
                  responsibility=z['responsibility'].tolist(),teacher_q=t['responsibility'].tolist(),mass=z['mass'].tolist()))
                pp.append(record(row,p));base.append(record(row,p0))
            else:pp.append(record(row));base.append(record(row))
    score=metrics(pp);old=metrics(base)
    write(out/(part+'_predictions.json'),pp);write(out/(part+'_metrics.json'),score)
    with gzip.open(out/(part+'_traces.jsonl.gz'),'xt',encoding='utf8') as f:
        for t in tr:f.write(json.dumps(t,ensure_ascii=False,allow_nan=False)+'\n')
    def group(xs):
        return dict(n=len(xs),mean_change_pp=math.fsum(x['change_pp'] for x in xs)/len(xs) if xs else None,
          improved=sum(x['change_pp']< -1e-9 for x in xs),worsened=sum(x['change_pp']>1e-9 for x in xs),
          severe_harm_gt5pp=sum(x['change_pp']>5 for x in xs))
    write(out/(part+'_diagnostics.json'),dict(all=group(tr),
      teacher_error_le5=group([x for x in tr if x['teacher_error_pp']<=5]),
      teacher_error_gt20=group([x for x in tr if x['teacher_error_pp']>20]),
      note='Retrospective label-based diagnostics only; never prediction inputs or sampling rules. q/bias changes are preclip; actual output change includes clipping.'))
    return score,{k:score[k]['failure_penalized_MAE_pp']-old[k]['failure_penalized_MAE_pp'] for k in ('overall','computer_science')}
def train(head,states,teachers,rows,sup,plan,out,metrics,check,seed,arm):
    out.mkdir();sec=sections(rows,plan['split']);fit=sec['clean_fit']
    save_file(head.state_dict(),str(out/'initial.safetensors'))
    opt=torch.optim.AdamW(head.parameters(),lr=plan['learning_rate'],betas=(.9,.95),eps=1e-8,weight_decay=.01)
    steps=0;history=[]
    for epoch in range(1,5):
        ep=out/('epoch'+str(epoch));ep.mkdir();order=list(range(len(fit)));random.Random(seed+epoch).shuffle(order)
        write(ep/'train_order.json',[fit[i]['unit_id'] for i in order])
        for start in range(0,len(order),8):
            check();batch=order[start:start+8];opt.zero_grad(set_to_none=True);terms={}
            for i in batch:
                r=fit[i];u=r['unit_id']
                loss,parts=new_loss(head,states['clean_train'][u],states['pred_train'].get(u),r['target_fraction'],sup[u],
                  teachers['clean_train'][u],teachers['pred_train'].get(u),arm)
                need(bool(torch.isfinite(loss)),'LOSS');(loss/len(batch)).backward()
                for k,v in parts.items():terms[k]=terms.get(k,0)+float(v.detach())/len(batch)
            norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1,error_if_nonfinite=True);opt.step();steps+=1
            need(all(bool(torch.isfinite(v).all()) for v in head.parameters()),'PARAMETERS')
            event=dict(event='update',arm=arm,seed=seed,epoch=epoch,step=steps,total=356,batch_size=len(batch),gradient_norm=float(norm),terms=terms)
            emit(out/'events.jsonl',**event);emit(out.parent.parent/'events.jsonl',**event)
        save_file(head.state_dict(),str(ep/'bias_head.safetensors'))
        scores={};deltas={}
        for part,rr in sec.items():
            scores[part],deltas[part]=evaluate(head,rr,states[statepart(part)],teachers[statepart(part)],metrics,ep,part,check)
        rec=dict(epoch=epoch,metrics=scores,delta=deltas,head_sha256=sha(ep/'bias_head.safetensors'))
        write(ep/'summary.json',rec);history.append(rec)
    result=dict(steps=steps,history=history,final=history[-1]);write(out/'summary.json',result);return result
