"""Separate local/relation/global routes for q and m; frozen successful input states."""
import math
import torch
from torch import nn
import torch.nn.functional as F

ARMS={
    'local':(True,False,False),
    'local_global':(True,False,True),
    'local_relation':(True,True,False),
    'full':(True,True,True),
}
WEIGHTS={'MAE':1.,'excess':.1,'pred_drift':.02,'clean_drift':.05,
         'q_KL':.01,'m_KL':.01,'ordinal':.05,'log_count':.02}

def probabilities(t):
    u,r=t.sigmoid().unbind(-1)
    return torch.stack((u*r,u*(1-r),1-u),-1)

def local_loss(z,sup):
    q=z['responsibility'];zero=q.sum()*0
    if sup is None:return zero,zero
    mask=torch.tensor(sup['mask'],dtype=torch.bool,device=q.device)
    if mask.shape!=(len(q),):raise RuntimeError('MASK_SHAPE')
    if not bool(mask.any()):return zero,zero
    target=torch.tensor(sup['responsibility'],dtype=q.dtype,device=q.device)
    counts=torch.tensor(sup['counts'],dtype=q.dtype,device=q.device)
    if target.shape!=q.shape or counts.shape!=(len(q),):raise RuntimeError('LABEL_SHAPE')
    if not bool(torch.isfinite(target[mask]).all() and (target[mask]>=0).all()
                and torch.isfinite(counts[mask]).all() and (counts[mask]>0).all()):
        raise RuntimeError('LOCAL_LABEL')
    if not torch.allclose(target[mask].sum(-1),torch.ones_like(counts[mask]),atol=1e-6):
        raise RuntimeError('LOCAL_PROBABILITY')
    ordinal=.5*(q[mask].cumsum(-1)[:,:2]-target[mask].cumsum(-1)[:,:2]).abs().sum(-1).mean()
    count=F.smooth_l1_loss(z['predicted_counts'][mask].clamp_min(1e-6).log(),counts[mask].log(),beta=.5)
    return ordinal,count

@torch.no_grad()
def bind_state(s,condition,attention,width=32):
    """condition is replayed from frozen successful structural head, never labels."""
    n=len(s['mass'])
    if n<1 or condition.shape!=(n,4*width+9):raise RuntimeError('CONDITION_SHAPE')
    out={k:v.detach().clone() for k,v in s.items()}
    if not all(bool(torch.isfinite(v).all()) for v in out.values()):raise RuntimeError('NONFINITE_STATE')
    q=s['responsibility'];u=q[:,:2].sum(-1).clamp(1e-5,1-1e-5)
    r=(q[:,0]/q[:,:2].sum(-1).clamp_min(1e-12)).clamp(1e-5,1-1e-5)
    c=s['predicted_counts']
    if not bool((c>0).all()):raise RuntimeError('POSITIVE_COUNTS')
    if not torch.allclose(c/c.sum(),s['mass'],atol=1e-6,rtol=1e-6):raise RuntimeError('MASS_COUNT_BINDING')
    out.update(local_channel=condition[:,:width].detach().clone(),
               relation_channel=condition[:,width:2*width].detach().clone(),
               global_channel=condition[:,2*width:3*width].detach().clone(),
               auxiliary_local=condition[:,3*width:4*width].detach().clone(),
               q_natural=torch.stack((torch.logit(u),torch.logit(r)),-1).detach(),
               count_natural=(c+torch.log(-torch.expm1(-c))).detach(),
               reference_attention=attention.detach().clone())
    return out

class SelectiveRouting(nn.Module):
    def __init__(self,width=32,arm='full'):
        super().__init__()
        if arm not in ARMS:raise ValueError('ARM')
        self.width=width;self.arm=arm
        # Independent route adaptations and routers. All arms consume identical RNG draws.
        self.q_adapters=nn.ModuleList([nn.Sequential(nn.Linear(width,width),nn.GELU()) for _ in range(3)])
        self.m_adapters=nn.ModuleList([nn.Sequential(nn.Linear(width,width),nn.GELU()) for _ in range(3)])
        self.q_router=nn.Linear(4*width+9,3);self.m_router=nn.Linear(4*width+9,3)
        self.q_output=nn.Sequential(nn.Linear(2*width+9,width),nn.GELU(),nn.Linear(width,2))
        self.m_output=nn.Sequential(nn.Linear(2*width+9,width),nn.GELU(),nn.Linear(width,1))
        for module in (self.q_router,self.m_router,self.q_output[-1],self.m_output[-1]):
            nn.init.zeros_(module.weight);nn.init.zeros_(module.bias)
        for enabled,qa,ma in zip(ARMS[arm],self.q_adapters,self.m_adapters):
            if not enabled:qa.requires_grad_(False);ma.requires_grad_(False)
        if arm=='local':
            self.q_router.requires_grad_(False);self.m_router.requires_grad_(False)

    def forward(self,s):
        n=len(s['mass']);w=self.width
        if n<1:raise RuntimeError('EMPTY_OPERATIONS')
        available=list(ARMS[self.arm]);available[1]=available[1] and n>1
        mask=torch.tensor(available,device=s['mass'].device,dtype=torch.bool)
        channels=[s[k].float() for k in ('local_channel','relation_channel','global_channel')]
        if any(t.shape!=(n,w) for t in channels):raise RuntimeError('CHANNEL_SHAPE')
        channels=[x if use else torch.zeros_like(x) for x,use in zip(channels,available)]
        auxiliary=s['auxiliary_local'].float()
        side=torch.cat([auxiliary,s['responsibility'].float(),s['b_onehot'].float(),
                        s['prediction'].float().expand(n,1),s['gate'].float().expand(n,1),
                        s['mass'].float().clamp_min(1e-12).log()[:,None]],-1)
        condition=torch.cat(channels+[side],-1)
        def branch(adapters,router,output):
            weights=router(condition).masked_fill(~mask[None],float('-inf')).softmax(-1)
            values=torch.stack([a(x) if use else torch.zeros_like(x)
                               for a,x,use in zip(adapters,channels,available)],1)
            fused=(weights[:,:,None]*values).sum(1)
            return 3*output(torch.cat((fused,side),-1)).tanh(),weights
        dq,rq=branch(self.q_adapters,self.q_router,self.q_output)
        dc,rm=branch(self.m_adapters,self.m_router,self.m_output);dc=dc.squeeze(-1)
        q0=probabilities(s['q_natural']);q=probabilities(s['q_natural']+dq)
        c0=F.softplus(s['count_natural']);c=F.softplus(s['count_natural']+dc)
        m0=c0/c0.sum();m=c/c.sum()
        v=q.new_tensor([0.,.5,1.],dtype=torch.float64)
        delta=s['gate'].double()*(m.double()*(q.double()@v)-m0.double()*(q0.double()@v))
        prediction=(s['prediction'].double()+delta.sum()).clamp(0,1)
        qkl=(m0*(q*(q.clamp_min(1e-12).log()-q0.clamp_min(1e-12).log())).sum(-1)).sum().clamp_min(0)
        mkl=(m*(m.clamp_min(1e-12).log()-m0.clamp_min(1e-12).log())).sum().clamp_min(0)
        return dict(prediction=prediction,responsibility=q,base_responsibility=q0,mass=m,base_mass=m0,
                    predicted_counts=c,operation_delta=delta,q_shift=dq,m_shift=dc,q_KL=qkl,m_KL=mkl,
                    attention=s['reference_attention'],base_attention=s['reference_attention'],
                    q_routes=rq,m_routes=rm,route_available=mask,
                    responsibility_stabilization_max=(q0-s['responsibility']).abs().max(),
                    mass_stabilization_max=(m0-s['mass']).abs().max())

def loss_parts(head,clean,real,target,sup):
    c=head(clean);zero=c['prediction']*0;parts={k:zero for k in WEIGHTS}
    parts['clean_drift']=(c['prediction']-clean['prediction']).abs()
    if real is None:parts.update(q_KL=c['q_KL'],m_KL=c['m_KL'])
    else:
        z=head(real);error=(z['prediction']-target).abs()
        ordinal,count=local_loss(z,sup)
        parts.update(MAE=error,excess=(error-(real['prediction']-target).abs()).clamp_min(0),
                     pred_drift=(z['prediction']-real['prediction']).abs(),q_KL=z['q_KL'],m_KL=z['m_KL'],
                     ordinal=ordinal,log_count=count)
    return sum(WEIGHTS[k]*v for k,v in parts.items()),parts

def gradient_alignment(head,batch):
    params=[p for p in head.parameters() if p.requires_grad];totals={}
    for clean,real,target,sup in batch:
        _,parts=loss_parts(head,clean,real,target,sup)
        values={'main':parts['MAE'],'local':.05*parts['ordinal']+.02*parts['log_count'],
                'preservation':sum(WEIGHTS[k]*parts[k] for k in ('excess','pred_drift','clean_drift','q_KL','m_KL'))}
        for k,v in values.items():totals[k]=totals.get(k,0)+v/len(batch)
    vectors={}
    for key,value in totals.items():
        grads=torch.autograd.grad(value,params,retain_graph=True,allow_unused=True)
        vectors[key]=torch.cat([(torch.zeros_like(p) if g is None else g).detach().double().flatten() for p,g in zip(params,grads)])
    norms={k:float(v.norm()) for k,v in vectors.items()}
    cos={}
    for key in ('local','preservation'):
        den=norms['main']*norms[key];cos['main_vs_'+key]=float(vectors['main']@vectors[key]/den) if den>1e-15 else None
    return dict(weighted_gradient_norms=norms,cosines=cos,batch_size=len(batch),
                scope='First shuffled training batch per epoch; local includes ordinal and log-count. Not whole-training attribution.')
