import json,tempfile,subprocess,unittest
from pathlib import Path
from unittest.mock import patch,Mock
import driver

class Contracts(unittest.TestCase):
    def test_duplicate_launch_rejected(self):
        with tempfile.TemporaryDirectory() as td,patch.object(driver,'package_check'),patch.dict(driver.os.environ,{'CUDA_VISIBLE_DEVICES':''}),patch.object(driver.subprocess,'Popen') as spawn:
            (Path(td)/driver.OUT).mkdir(parents=True)
            with self.assertRaisesRegex(RuntimeError,'OUTPUT_EXISTS'):driver.launch(Path(td))
            spawn.assert_not_called()
    def test_manifest_escape_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'SHA256SUMS').write_text('0  ../outside\n')
            with patch.object(driver,'HERE',p),self.assertRaisesRegex(RuntimeError,'PACKAGE_HASH'):driver.package_check()
    def monitor_fixture(self,kill=False):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);out=root/driver.OUT;out.mkdir(parents=True);here=root/'pkg';here.mkdir()
            (here/'plan.json').write_text(json.dumps({'max_seconds':1800}))
            child=Mock();child.pid=123
            child.wait.side_effect=[subprocess.TimeoutExpired('owned',1800),subprocess.TimeoutExpired('owned',15),0] if kill else [subprocess.TimeoutExpired('owned',1800),0]
            with patch.object(driver,'HERE',here),patch.object(driver.subprocess,'Popen',return_value=child) as spawn:
                driver.monitor(root)
            child.terminate.assert_called_once()
            if kill:child.kill.assert_called_once()
            else:child.kill.assert_not_called()
            self.assertEqual(driver.read(out/'failure.json')['status'],'EXECUTION_INCOMPLETE_NOT_MODEL_SCORE')
            self.assertEqual(spawn.call_count,1)
    def test_timeout_only_own_child(self):self.monitor_fixture()
    def test_timeout_kills_only_unresponsive_own_child(self):self.monitor_fixture(True)
    def test_cpu_environment_required(self):
        with tempfile.TemporaryDirectory() as td,patch.object(driver,'package_check'),patch.dict(driver.os.environ,{'CUDA_VISIBLE_DEVICES':'0'}):
            with self.assertRaisesRegex(RuntimeError,'CPU_ONLY'):driver.launch(Path(td))
            self.assertFalse((Path(td)/driver.OUT).exists())

if __name__=='__main__':unittest.main()
