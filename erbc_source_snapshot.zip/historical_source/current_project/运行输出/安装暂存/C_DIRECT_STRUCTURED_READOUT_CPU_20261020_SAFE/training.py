"""Bounded CPU controlled readout study. Train/development only."""
import gzip,hashlib,json,math,random,time
from pathlib import Path
import torch
from safetensors.torch import save_file
from readout import WEIGHTS,loss_parts,local_terms,gradient_diagnostics

PARTS=('clean_train','pred_train','clean_development','pred_development')
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def write(p,x):
    with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def emit(p,x):
    with Path(p).open('a',encoding='utf8') as f:f.write(json.dumps(dict(time=time.time(),**x),ensure_ascii=False,allow_nan=False)+'\n')
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def weights_digest(head):
    h=hashlib.sha256()
    for k,v in sorted(head.state_dict().items()):h.update(k.encode());h.update(v.detach().numpy().tobytes())
    return h.hexdigest()
def average(xs):return math.fsum(xs)/len(xs) if xs else None

def evaluate(head,rows,states,metrics,path,part,check,sups=None):
    path.mkdir(parents=True,exist_ok=True);pp=[];diagnostics=[]
    with gzip.open(path/(part+'_traces.jsonl.gz'),'xt',encoding='utf8') as f,torch.no_grad():
        head.eval()
        for row in rows:
            check();u=row['unit_id']
            rec={k:row[k] for k in ('unit_id','subject','student_group_id','target_fraction','status')}
            if row['status']=='READY':
                s=states[u];z=head(s);p=float(z['prediction']);y=row['target_fraction']
                need(math.isfinite(p) and 0<=p<=1,'INVALID_PREDICTION')
                q=z['responsibility'];m=z['mass']
                need(bool(torch.isfinite(q).all() and torch.isfinite(m).all()),'NONFINITE_STRUCTURES')
                need(bool((q>=0).all() and (m>=0).all() and torch.allclose(q.sum(-1),torch.ones(len(q),dtype=q.dtype),atol=1e-10) and abs(m.sum()-1)<1e-10),'SIMPLEX')
                if head.arm=='direct':need(abs(p-float((m*(q@q.new_tensor([0,.5,1.]))).sum()))<1e-12,'DIRECT_EXPLANATION')
                rec.update(status='PASS',prediction_fraction=p,token_ids_sha256=row['token_ids_sha256'])
                olderr=100*abs(float(s['prediction'])-y);err=100*abs(p-y)
                a=dict(unit_id=u,operation_count=len(m),retained_error_pp=olderr,error_pp=err,
                       change_pp=err-olderr,prediction_shift_pp=100*(p-float(s['prediction'])),
                       q_KL=float(z['q_KL']),m_KL=float(z['m_KL']),ordinal=None,relative_count=None,
                       old_ordinal=None,old_relative_count=None,matched=0)
                if sups is not None and part=='pred_train':
                    sup=sups[u]['predicted'];o,r=local_terms(z,sup)
                    ro,rr=local_terms(dict(prediction=s['prediction'],responsibility=s['responsibility'].double(),mass=s['mass'].double()),sup)
                    a.update(ordinal=float(o),relative_count=float(r),old_ordinal=float(ro),
                             old_relative_count=float(rr),matched=sum(sup['mask']) if sup else 0)
                diagnostics.append(a)
                # ALL valid train/development traces, no 64-unit subsampling.
                f.write(json.dumps(dict(**a,target_fraction=y,retained_prediction=float(s['prediction']),
                  prediction=p,gate=float(s['gate']),token_ids_sha256=row['token_ids_sha256'],
                  operation_positions=row['operation_positions'],
                  **{k:z[k].tolist() for k in ('responsibility','mass','aggregate','reference_aggregate','q_shift','m_shift')}),allow_nan=False)+'\n')
            else:need(row['status']=='UPSTREAM_BLOCKED','EXECUTION_FAILURE_NOT_SCORE')
            pp.append(rec)
    write(path/(part+'_predictions.json'),pp);score=metrics(pp);write(path/(part+'_metrics.json'),score)
    def group(xs):
        matched=[x for x in xs if x['matched']]
        return dict(valid=len(xs),retained_MAE_pp=average([x['retained_error_pp'] for x in xs]),
                    MAE_pp=average([x['error_pp'] for x in xs]),delta_MAE_pp=average([x['change_pp'] for x in xs]),
                    improved=sum(x['change_pp']< -1e-9 for x in xs),worsened=sum(x['change_pp']>1e-9 for x in xs),
                    mean_absolute_prediction_shift_pp=average([abs(x['prediction_shift_pp']) for x in xs]),
                    matched_units=len(matched),
                    **{k:average([x[k] for x in matched]) for k in ('ordinal','relative_count','old_ordinal','old_relative_count')})
    write(path/(part+'_diagnostics.json'),dict(all_valid=group(diagnostics),
      single=group([x for x in diagnostics if x['operation_count']==1]),
      multi=group([x for x in diagnostics if x['operation_count']>1]),
      retained_error_ge20=group([x for x in diagnostics if x['retained_error_pp']>=20]),
      note='Error-based groups are retrospective diagnostics only; not model inputs or sampling weights. Matching supervision is training-only and partial.'))
    return score

def baseline_diagnostics(rows,states,path):
    result={}
    for part in PARTS:
        rr=[]
        for row in rows[part]:
            if row['status']!='READY':continue
            s=states[part][row['unit_id']];p=float(s['prediction']);g=float(s['gate'])
            v=float((s['mass'].double()*(s['responsibility'].double()@torch.tensor([0.,.5,1.],dtype=torch.float64))).sum())
            clip=lambda a:max(0.,min(1.,a))
            lo,hi=sorted((clip(p-g*v),clip(p+g*(1-v))))
            y=row['target_fraction'];floor=100*max(lo-y,y-hi,0.)
            rr.append(dict(unit_id=row['unit_id'],n=len(s['mass']),target=y,prediction=p,lower=lo,upper=hi,
                           error_pp=100*abs(p-y),irreducible_error_pp=floor))
        result[part]=dict(valid=len(rr),outside=sum(x['irreducible_error_pp']>1e-8 for x in rr),
          error_sum_pp=math.fsum(x['error_pp'] for x in rr),irreducible_sum_pp=math.fsum(x['irreducible_error_pp'] for x in rr),records=rr)
    paired={}
    for split in ('train','development'):
        c={x['unit_id']:x for x in result['clean_'+split]['records']}
        p=result['pred_'+split]['records']
        need(all(x['target']==c[x['unit_id']]['target'] for x in p),'PAIR_LABEL')
        paired[split]=dict(same_valid_ids=len(p),clean_MAE_pp=average([c[x['unit_id']]['error_pp'] for x in p]),
                          predicted_MAE_pp=average([x['error_pp'] for x in p]))
    write(path/'full_baseline_diagnostics.json',dict(partitions=result,paired=paired,
      note='Label-assisted analytical reachability lower bound, not an achievable candidate or guaranteed gain. Full training/development, no official examples.'))

def train_arm(head,states,rows,sups,p,out,metrics,check,seed,arm):
    need(set(states)==set(rows)==set(PARTS),'TRAIN_DEVELOPMENT_ONLY')
    out.mkdir();write(out/'initialization.json',dict(seed=seed,arm=arm,
      initial_weights_sha256=weights_digest(head),parameters=sum(x.numel() for x in head.parameters()),
      note='Anchored zero heads preserve best scalar; direct starts from best q/m aggregate and is NOT assumed scalar-identical.'))
    # Initial scores expose the intentional direct-readout discontinuity.
    initial={part:evaluate(head,rows[part],states[part],metrics,out/'initial',part,check,sups) for part in PARTS}
    write(out/'initial_metrics.json',initial)
    opt=torch.optim.AdamW(head.parameters(),lr=p['learning_rate'],betas=(.9,.95),eps=1e-8,weight_decay=.01)
    n=len(rows['clean_train']);step=0;history=[]
    for epoch in range(1,p['epochs']+1):
        ep=out/('epoch'+str(epoch));ep.mkdir();order=list(range(n));random.Random(seed+epoch).shuffle(order)
        write(ep/'train_order.json',[rows['clean_train'][i]['unit_id'] for i in order]);head.train()
        for start in range(0,n,p['batch']):
            check();batch=order[start:start+p['batch']];opt.zero_grad(set_to_none=True);means={k:0. for k in WEIGHTS}
            if start==0:
                examples=[]
                for i in batch:
                    row=rows['clean_train'][i];u=row['unit_id']
                    examples.append((states['clean_train'][u],states['pred_train'].get(u),row['target_fraction'],sups[u].get('predicted')))
                write(ep/'gradient_diagnostics.json',dict(unit_ids=[rows['clean_train'][i]['unit_id'] for i in batch],**gradient_diagnostics(head,examples)))
            for i in batch:
                row=rows['clean_train'][i];u=row['unit_id']
                loss,parts=loss_parts(head,states['clean_train'][u],states['pred_train'].get(u),row['target_fraction'],sups[u].get('predicted'))
                need(bool(torch.isfinite(loss)),'LOSS_FINITE');(loss/len(batch)).backward()
                for k,v in parts.items():means[k]+=float(v.detach())/len(batch)
            norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);opt.step();step+=1
            need(all(bool(torch.isfinite(v).all()) for v in head.parameters()),'PARAMETER_FINITE')
            e=dict(event='update',arm=arm,seed=seed,epoch=epoch,step=step,total=p['epochs']*math.ceil(n/p['batch']),
                   batch_size=len(batch),gradient_norm=float(norm),loss_parts=means)
            emit(out/'events.jsonl',e);emit(out.parent.parent/'events.jsonl',e)
        save_file(head.state_dict(),str(ep/'readout_head.safetensors'))
        scores={part:evaluate(head,rows[part],states[part],metrics,ep,part,check,sups) for part in PARTS}
        h=dict(epoch=epoch,metrics=scores,head_sha256=digest(ep/'readout_head.safetensors'))
        write(ep/'summary.json',h);history.append(h)
        emit(out.parent.parent/'events.jsonl',dict(event='epoch_complete',arm=arm,seed=seed,epoch=epoch))
    r=dict(steps=step,seed=seed,arm=arm,history=history,final=history[-1])
    write(out/'summary.json',r);return r
