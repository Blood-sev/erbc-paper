"""Nonlinear ordinal responsibility repair with frozen successful readout."""
import torch,math
from torch import nn

class ResponsibilityRepair(nn.Module):
    def __init__(self,width=32):
        super().__init__()
        self.local_norm=nn.LayerNorm(width,elementwise_affine=False)
        self.repair=nn.Sequential(nn.Linear(width+8,32),nn.GELU(),nn.Linear(32,3))
        nn.init.zeros_(self.repair[-1].weight);nn.init.zeros_(self.repair[-1].bias)
    def forward(self,state):
        z=state['local'];q=state['responsibility'];m=state['mass'];b=state['b_onehot']
        if z.ndim!=2 or len(z)==0 or q.shape!=(len(z),3) or m.shape!=(len(z),) or b.shape!=q.shape:raise RuntimeError('STATE_SHAPE')
        n=len(z)
        x=torch.cat([self.local_norm(z),q,b,state['prediction'].float().expand(n,1),state['gate'].float().expand(n,1)],-1)
        scores=4*self.repair(x).tanh()
        logits=q.clamp_min(1e-6).log();base=logits.softmax(-1);new=(logits+scores).softmax(-1)
        values=q.new_tensor([0.,.5,1.],dtype=torch.float64)
        delta=(m.double()*((new.double()-base.double())*values).sum(-1)).sum()
        prediction=(state['prediction'].double()+state['gate'].double()*delta).clamp(0,1)
        kl=(m*(new*(new.clamp_min(1e-12).log()-base.clamp_min(1e-12).log())).sum(-1)).sum().clamp_min(0)
        return {'prediction':prediction,'responsibility':new,'base_responsibility':base,'KL':kl,'logit_shift':scores}

def make_state(teacher,operations,context,b_share,anchor):
    captured=[];handle=teacher.local.register_forward_hook(lambda module,args,out:captured.append(out.detach()))
    try:
        with torch.no_grad():result=teacher(operations,context,b_share,anchor)
    finally:handle.remove()
    if len(captured)!=1:raise RuntimeError('LOCAL_CAPTURE_COUNT')
    return {'local':captured[0],'mass':result['mass'].detach(),'responsibility':result['responsibility'].detach(),
      'b_onehot':torch.nn.functional.one_hot((2*b_share).long(),3).float().detach(),
      'gate':result['gate'].detach(),'prediction':result['prediction'].detach()}

def ordinal_loss(pred,supervision):
    mask=torch.tensor(supervision['mask'],dtype=torch.bool,device=pred.device)
    labels=torch.tensor(supervision['responsibility'],dtype=pred.dtype,device=pred.device)
    if mask.shape!=(len(pred),) or labels.shape!=pred.shape:raise RuntimeError('LOCAL_SUPERVISION_SHAPE')
    if not bool(mask.any()):return pred.sum()*0
    q=labels[mask]
    if not bool(torch.isfinite(q).all() and (q>=0).all()) or not torch.allclose(q.sum(-1),torch.ones(len(q),device=q.device),atol=1e-6):raise RuntimeError('LOCAL_SUPERVISION_RANGE')
    # Ordered supports 0,.5,1: joint-vs-AI mistakes cost less than student-vs-AI.
    return .5*(pred[mask].cumsum(-1)[:,:2]-q.cumsum(-1)[:,:2]).abs().sum(-1).mean()

def loss_unit(head,clean_state,predicted_state,target,supervision):
    clean=head(clean_state);clean_drift=(clean['prediction']-clean_state['prediction']).abs()
    if predicted_state is None:return .05*clean_drift+.01*clean['KL']
    pred=head(predicted_state);y=pred['prediction'].new_tensor(target)
    err=(pred['prediction']-y).abs();teacher_err=(predicted_state['prediction']-y).abs()
    return (err+.1*(err-teacher_err).clamp_min(0)+.02*(pred['prediction']-predicted_state['prediction']).abs()
       +.05*clean_drift+.01*pred['KL']+.05*ordinal_loss(pred['responsibility'],supervision))

def update_batch(head,optimizer,indices,train,real_by_id,states,supervision,check=lambda:None):
    optimizer.zero_grad(set_to_none=True);total=0.
    for i in indices:
        check();row=train[i];u=row['unit_id'];real=real_by_id[u]
        if real['status'] not in ('READY','UPSTREAM_BLOCKED'):raise RuntimeError('UNEXPECTED_TRAIN_STATUS')
        state=states['pred_train'][u] if real['status']=='READY' else None
        loss=loss_unit(head,states['clean_train'][u],state,row['target_fraction'],supervision[u]['predicted'])/len(indices)
        if not bool(torch.isfinite(loss)):raise RuntimeError('NONFINITE_LOSS')
        total+=float(loss.detach());loss.backward()
    norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);optimizer.step()
    if not all(bool(torch.isfinite(x).all()) for x in head.parameters()):raise RuntimeError('NONFINITE_PARAMETER')
    return {'loss':total,'gradient_norm':float(norm)}

def select_epoch(candidates):
    if len(candidates)!=4 or [x['epoch'] for x in candidates]!=[1,2,3,4]:raise RuntimeError('DEVELOPMENT_CANDIDATES')
    for c in candidates:
        for g,n in [('overall',156),('computer_science',112)]:
            m=c['predicted_metrics'][g]
            if m['records']!=n or not math.isfinite(m['failure_penalized_MAE_pp']):raise RuntimeError('DEVELOPMENT_METRICS')
    return min(candidates,key=lambda x:(x['predicted_metrics']['overall']['failure_penalized_MAE_pp'],
      x['predicted_metrics']['computer_science']['failure_penalized_MAE_pp'],x['epoch']))
