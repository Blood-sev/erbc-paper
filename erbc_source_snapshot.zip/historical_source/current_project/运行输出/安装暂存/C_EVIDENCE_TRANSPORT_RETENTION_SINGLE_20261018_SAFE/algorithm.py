"""Evidence-conditioned B-responsibility -> KSA-responsibility transport.

No target, gold operation or sample identifier is accepted by the prediction API.
Local KSA labels and paired clean-view outputs are training-only supervision.
"""
import math
from collections import Counter


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def refs(op):
    return {str(r.get('message_id') or r.get('source_id')) for r in op.get('evidence_refs', [])
            if r.get('message_id') or r.get('source_id')}


def align(predicted, clean):
    """Input-only, partial matching. Never use U01 identity or KSA/C targets."""
    pc = Counter(x['operation'] for x in predicted)
    gc = Counter(x['operation'] for x in clean)
    unique = {x['operation']: (i, x) for i, x in enumerate(clean) if gc[x['operation']] == 1}
    matches = []
    for x in predicted:
        found = unique.get(x['operation']) if pc[x['operation']] == 1 else None
        if found is None:
            matches.append(-1)
            continue
        i, y = found
        good = bool(set(x.get('mapped_ku_ids', [])) & set(y.get('mapped_ku_ids', [])))
        good = good and bool(refs(x) & refs(y))
        matches.append(i if good else -1)
    require(len([i for i in matches if i >= 0]) == len(set(i for i in matches if i >= 0)), 'NON_UNIQUE_ALIGNMENT')
    return matches


def local_labels(operations, ksa):
    ids = [x['operation_id'] for x in operations]
    require(len(ids) == len(set(ids)) and ids, 'CLEAN_OPERATION_IDS')
    counts = [[0, 0, 0] for _ in ids]
    index = {u: i for i, u in enumerate(ids)}
    for x in ksa:
        require(x['operation_id'] in index and x['ai_share'] in (0, .5, 1), 'KSA_LABEL_SCHEMA')
        counts[index[x['operation_id']]][int(2*x['ai_share'])] += 1
    require(all(sum(c) > 0 for c in counts), 'KSA_OPERATION_WITHOUT_LABEL')
    return {'counts': [sum(c) for c in counts],
            'responsibility': [[n/sum(c) for n in c] for c in counts]}


def supervised_labels(clean, mapping):
    return {'mask': [i >= 0 for i in mapping],
            'counts': [clean['counts'][i] if i >= 0 else 0 for i in mapping],
            'responsibility': [clean['responsibility'][i] if i >= 0 else [0., 0., 0.] for i in mapping]}


def eligibility(candidate, reference, clean_candidate, clean_reference):
    """Predeclared same-input gate; never compare predicted-AB dev to clean-AB dev."""
    key = 'failure_penalized_MAE_pp'
    groups = ('overall', 'computer_science')
    for c, r, sizes in ((candidate, reference, (156,112)), (clean_candidate,clean_reference,(156,112))):
        for g, n in zip(groups, sizes):
            require(c[g]['records'] == r[g]['records'] == n, 'GATE_DENOMINATOR')
            require(math.isfinite(c[g][key]) and math.isfinite(r[g][key]), 'GATE_NONFINITE')
    delta = [candidate[g][key]-reference[g][key] for g in groups]
    retained = [clean_candidate[g][key]-clean_reference[g][key] for g in groups]
    return {'pass': all(x <= 0 for x in delta) and any(x < 0 for x in delta)
                   and all(x <= 0 for x in retained),
            'predicted_AB_delta_pp': delta, 'clean_AB_delta_pp': retained}


def make_head(hidden, width=32):
    import torch
    from torch import nn
    class Head(nn.Module):
        def __init__(self):
            super().__init__()
            self.norm = nn.LayerNorm(hidden)
            self.query = nn.Linear(hidden, width, bias=False)
            self.key = nn.Linear(hidden, width, bias=False)
            self.value = nn.Linear(hidden, width, bias=False)
            self.local = nn.Sequential(nn.Linear(hidden+width+3, width), nn.GELU())
            self.transport = nn.Linear(width, 9)
            self.mass = nn.Linear(width, 1)
            self.gate = nn.Linear(hidden+width, 1)
            # A stable warm start, NOT an identity constraint or fixed small correction.
            nn.init.zeros_(self.transport.weight)
            with torch.no_grad():
                self.transport.bias.copy_(torch.tensor([[.8,.1,.1],[.1,.8,.1],[.1,.1,.8]]).log().flatten())
            nn.init.zeros_(self.mass.weight); nn.init.zeros_(self.mass.bias)
            nn.init.zeros_(self.gate.weight); nn.init.zeros_(self.gate.bias)

        def forward(self, operations, evidence, b_share, direct_scalar):
            require(operations.ndim == evidence.ndim == 2 and len(operations)>0 and len(evidence)>0, 'HEAD_SHAPE')
            require(len(b_share) == len(operations), 'HEAD_OPERATION_COUNT')
            require(bool(((b_share == 0) | (b_share == .5) | (b_share == 1)).all()), 'B_RESPONSIBILITY_SCHEMA')
            op = self.norm(operations.float()); ev = self.norm(evidence.float())
            b = torch.nn.functional.one_hot((2*b_share).long(),3).float()
            attention = (self.query(op) @ self.key(ev).T / math.sqrt(width)).softmax(-1)
            context = attention @ self.value(ev)
            z = self.local(torch.cat([op,context,b],-1))
            transition = self.transport(z).reshape(-1,3,3).softmax(-1)
            responsibility = torch.einsum('ni,nij->nj', b, transition)
            mass = self.mass(z).flatten().softmax(-1)
            op_scalar = (mass * (responsibility[:,1]/2+responsibility[:,2])).sum()
            # Cached operation states plus final prompt state. This is latent-context
            # attention, NOT access to separately encoded complete source documents.
            require(bool(torch.isfinite(direct_scalar)) and 0 <= float(direct_scalar) <= 1,'DIRECT_RANGE')
            # Signed trust can accept or reverse an operation correction. Zero head
            # starts at the exact float64 247 reference, not at the weaker NTL branch.
            gate = self.gate(torch.cat([ev[-1],(mass[:,None]*z).sum(0)])).tanh().reshape(())
            anchor = direct_scalar.to(torch.float64)
            prediction = (anchor + gate.to(torch.float64)*(op_scalar.to(torch.float64)-anchor)).clamp(0,1)
            return {'prediction':prediction, 'responsibility':responsibility, 'mass':mass,
                    'gate':gate, 'anchor':anchor, 'transition':transition, 'attention':attention}
    return Head()


def loss_terms(output, target, supervision, teacher=None, mapping=None, protect_clean=False):
    import torch
    import torch.nn.functional as F
    y = output['prediction'].new_tensor(target)
    require(0 <= target <= 1, 'TARGET_RANGE')
    loss = (output['prediction']-y).abs()
    if protect_clean:
        # Training-label excess-error penalty only. Not a development-label input,
        # not a guarantee of per-sample or out-of-sample non-degradation.
        loss = loss + .5*((output['prediction']-y).abs()-(output['anchor']-y).abs()).clamp_min(0)
    mask = torch.tensor(supervision['mask'], device=y.device, dtype=torch.bool)
    require(len(mask)==len(output['mass']), 'SUPERVISION_SHAPE')
    if bool(mask.any()):
        q = torch.tensor(supervision['responsibility'],device=y.device,dtype=torch.float32)[mask]
        local = -(q * output['responsibility'][mask].clamp_min(1e-8).log()).sum(-1).mean()
        loss = loss + .1*local
        counts = torch.tensor(supervision['counts'],device=y.device,dtype=torch.float32)[mask]
        weight = counts/counts.sum()
        conditional_mass = output['mass'][mask]/output['mass'][mask].sum().clamp_min(1e-8)
        # Conditional matched mass, not invented targets for unmatched operations.
        loss = loss + .02*(weight*(weight.clamp_min(1e-8).log()-conditional_mass.clamp_min(1e-8).log())).sum()
    if teacher is not None:
        require(mapping is not None and len(mapping)==len(mask), 'PAIR_MAPPING')
        idx = torch.tensor(mapping,device=y.device,dtype=torch.long)
        pair = idx>=0
        if bool(pair.any()):
            clean_q = teacher.detach().to(y.device)[idx[pair]]
            loss = loss + .05*F.smooth_l1_loss(output['responsibility'][pair], clean_q, beta=.1)
    require(bool(torch.isfinite(loss)), 'NONFINITE_LOSS')
    return loss


