from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
import os
import re
import shutil
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(
    r"D:\stress-aware-homework-agent\项目进展\题目知识蓝图与KSA双层外包新方法\模型训练"
)
SOURCE_ROOT = PROJECT_ROOT / "训练数据" / "提交证据增强派生版"
SOURCE_DATA_ROOT = SOURCE_ROOT / "完整流水线评估"
AUDIT_ROOT = PROJECT_ROOT / "本地部署测试" / "提交证据恢复"
ADAPTER_PATH = PROJECT_ROOT / "H100正式基线运行" / "依赖" / "冻结数据严格Schema适配器.py"
RAW_DIALOGUE_ROOT = Path(
    r"D:\stress-aware-homework-agent\项目进展\题目知识蓝图与KSA双层外包新方法"
    r"\跨学科标准库与数据集\01_计算机科学\StudyChat_项目数据"
    r"\studychat_行为操作划分数据"
)
FINAL_ROOT = PROJECT_ROOT / "训练数据" / "提交证据精确追溯派生版_v2"
BUILD_ROOT = PROJECT_ROOT / "训练数据" / "提交证据精确追溯派生版_v2_构建中"
SPLITS = ("train", "validation", "test")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def compact(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip().lower()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载模块：{path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_audit(split: str) -> dict:
    path = AUDIT_ROOT / f"derived_audit_{split}.json"
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def failure_indices(audit: dict) -> dict[str, set[tuple[str, int]]]:
    output: dict[str, set[tuple[str, int]]] = defaultdict(set)
    for failure in audit["failures"]:
        root_key = "operations" if failure["task"] == "B" else "ksa"
        for issue in failure["result"]["issues"]:
            match = re.search(r"\[(\d+)\]\.evidence_refs$", issue["path"])
            if not match:
                raise RuntimeError(
                    f"发现非预期失败路径：{failure['unit_id']} {failure['task']} {issue['path']}"
                )
            output[failure["unit_id"]].add((root_key, int(match.group(1))))
    return output


def index_raw_dialogue_files(required_units: set[str]) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for path in RAW_DIALOGUE_ROOT.rglob("01_AI对话原始记录.jsonl"):
        unit_id = path.parent.name
        if unit_id not in required_units:
            continue
        if unit_id in found:
            raise RuntimeError(f"原始对话文件不唯一：{unit_id}\n{found[unit_id]}\n{path}")
        found[unit_id] = path
    missing = sorted(required_units - set(found))
    if missing:
        raise RuntimeError(f"缺少原始对话文件：{missing}")
    return found


def raw_records(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def strict_results(adapter, validator, row: dict) -> tuple[dict, dict, dict]:
    adapted = adapter.adapt_row(row)
    valid_message_ids = [item["message_id"] for item in adapted["dialogue"]]
    valid_message_ids.extend(adapter.submission_sources(row).keys())
    result_a = validator.validate("A", adapted["subject"], adapted["A"])
    result_b = validator.validate(
        "B",
        adapted["subject"],
        adapted["B"],
        {"blueprint": adapted["A"]["blueprint"], "valid_message_ids": valid_message_ids},
    )
    result_c = validator.validate(
        "C",
        adapted["subject"],
        adapted["C"],
        {
            "blueprint": adapted["A"]["blueprint"],
            "operations": adapted["B"]["operations"],
            "valid_message_ids": valid_message_ids,
        },
    )
    return result_a, result_b, result_c


def evidence_body(item: dict) -> str:
    text = str(
        item.get("evidence")
        or item.get("student_evidence")
        or item.get("ai_evidence")
        or ""
    )
    text = re.sub(r"^第0轮(?:AI|学生)[：:]", "", text).rstrip("…").strip()
    return compact(text)


def find_raw_response(item: dict, records: list[dict]) -> dict:
    body = evidence_body(item)
    signature = body.split("```")[0].strip()[:100]
    matches = [
        record
        for record in records
        if signature
        and signature in compact(str(record.get("response", "")))[: max(180, len(signature))]
    ]
    if len(matches) != 1:
        raise RuntimeError(
            f"第0轮AI证据无法唯一匹配原始回答：operation={item.get('operation_id')} "
            f"ksa={item.get('ksa_id')} matches={len(matches)} signature={signature!r}"
        )
    return matches[0]


def canonical_key(adapter, unit_id: str, message: dict, fallback_turn: int) -> tuple[str, int, str]:
    return (
        str(message.get("chat_id") or unit_id),
        int(message.get("turn", fallback_turn)),
        adapter.speaker_name(message.get("role", "")),
    )


def repair_row(
    adapter,
    split: str,
    row: dict,
    affected: set[tuple[str, int]],
    raw_path: Path | None,
) -> tuple[dict, list[dict], list[dict]]:
    repaired = copy.deepcopy(row)
    dialogue = repaired["input"].get("dialogue", [])
    raw_cache = raw_records(raw_path) if raw_path else []
    missing_messages: dict[tuple[str, int, str], dict] = {}
    ref_records: list[dict] = []
    message_records: list[dict] = []

    for root_key, item_index in sorted(affected):
        item = repaired["target"][root_key][item_index]
        refs = item.get("evidence_refs", [])
        if not refs:
            raise RuntimeError(
                f"待修复项没有原始evidence_refs：{row['unit_id']} {root_key}[{item_index}]"
            )
        for ref_index, ref in enumerate(refs):
            old_ref = copy.deepcopy(ref)
            round_value = int(ref.get("round", -1))
            if round_value > 0:
                if not 1 <= round_value <= len(dialogue):
                    raise RuntimeError(
                        f"全局轮次越界：{row['unit_id']} {root_key}[{item_index}] round={round_value}"
                    )
                message = dialogue[round_value - 1]
                key = canonical_key(adapter, row["unit_id"], message, round_value)
                method = "global_dialogue_index"
                source_record = None
            else:
                if raw_path is None:
                    raise RuntimeError(f"第0轮证据缺少原始文件：{row['unit_id']}")
                source_record = find_raw_response(item, raw_cache)
                turn = int(source_record.get("interactionCount", 0)) * 2 + 3
                key = (str(source_record["chatId"]), turn, "assistant")
                missing_messages[key] = source_record
                method = "raw_studychat_response"
            ref["_canonical_key"] = list(key)
            ref_records.append(
                {
                    "split": split,
                    "unit_id": row["unit_id"],
                    "target_root": root_key,
                    "target_index": item_index,
                    "operation_id": item.get("operation_id"),
                    "ksa_id": item.get("ksa_id"),
                    "ref_index": ref_index,
                    "resolution_method": method,
                    "old_ref": old_ref,
                    "raw_source_path": str(raw_path) if source_record else None,
                    "raw_source_file": source_record.get("source_file") if source_record else None,
                    "raw_source_line": source_record.get("source_line") if source_record else None,
                }
            )

    for key, record in missing_messages.items():
        chat_id, turn, _ = key
        already_present = any(
            str(message.get("chat_id")) == chat_id
            and int(message.get("turn", -1)) == turn
            and adapter.speaker_name(message.get("role", "")) == "assistant"
            for message in dialogue
        )
        if already_present:
            continue
        anchors = [
            index
            for index, message in enumerate(dialogue)
            if str(message.get("chat_id")) == chat_id
            and int(message.get("turn", -1)) == turn - 1
            and adapter.speaker_name(message.get("role", "")) == "student"
        ]
        if len(anchors) != 1:
            raise RuntimeError(
                f"无法唯一定位漏入AI回答的用户提问：{row['unit_id']} chat={chat_id} turn={turn}"
            )
        restored = {
            "chat_id": chat_id,
            "turn": turn,
            "role": "assistant",
            "content": record["response"],
            "restoration": {
                "version": "evidence_exact_trace_v2",
                "source_path": str(raw_path),
                "source_file": record.get("source_file"),
                "source_line": record.get("source_line"),
                "status": "restored_exactly_from_raw_studychat",
            },
        }
        dialogue.insert(anchors[0] + 1, restored)
        message_records.append(
            {
                "split": split,
                "unit_id": row["unit_id"],
                "chat_id": chat_id,
                "turn": turn,
                "role": "assistant",
                "source_path": str(raw_path),
                "source_file": record.get("source_file"),
                "source_line": record.get("source_line"),
                "response_sha256": hashlib.sha256(record["response"].encode("utf-8")).hexdigest(),
            }
        )

    lookup: dict[tuple[str, int, str], list[int]] = defaultdict(list)
    for index, message in enumerate(dialogue):
        lookup[canonical_key(adapter, row["unit_id"], message, index + 1)].append(index)

    record_cursor = 0
    for root_key, item_index in sorted(affected):
        item = repaired["target"][root_key][item_index]
        for ref in item.get("evidence_refs", []):
            key_raw = ref.pop("_canonical_key", None)
            if key_raw is None:
                raise RuntimeError(f"修复引用缺少内部键：{row['unit_id']} {root_key}[{item_index}]")
            key = (str(key_raw[0]), int(key_raw[1]), str(key_raw[2]))
            positions = lookup.get(key, [])
            if len(positions) != 1:
                raise RuntimeError(
                    f"精确消息键不唯一：{row['unit_id']} {root_key}[{item_index}] key={key} count={len(positions)}"
                )
            position = positions[0]
            message = dialogue[position]
            message_id = (
                f"{message.get('chat_id') or row['unit_id']}:turn:{int(message.get('turn', position + 1))}:"
                f"{adapter.speaker_name(message.get('role', ''))}:index:{position}"
            )
            ref.update(
                {
                    "source_chat_id": key[0],
                    "speaker": key[2],
                    "turn": key[1],
                    "dialogue_index": position,
                    "message_id": message_id,
                    "message_id_status": "exact_trace_v2",
                }
            )
            ref_records[record_cursor]["new_ref"] = copy.deepcopy(ref)
            record_cursor += 1

    return repaired, ref_records, message_records


def task_validation_summary(adapter, validator, row: dict) -> dict:
    result_a, result_b, result_c = strict_results(adapter, validator, row)
    return {"A": result_a, "B": result_b, "C": result_c}


def write_json(path: Path, payload: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, default=PROJECT_ROOT)
    args = parser.parse_args()
    if args.project_root.resolve() != PROJECT_ROOT.resolve():
        raise SystemExit("本脚本当前只允许写入已审核的正式项目根目录。")
    if FINAL_ROOT.exists():
        raise SystemExit(f"安全停止：正式目标目录已经存在：{FINAL_ROOT}")
    if BUILD_ROOT.exists():
        raise SystemExit(f"安全停止：构建中目录已经存在，请先人工检查：{BUILD_ROOT}")
    if not SOURCE_DATA_ROOT.is_dir() or not AUDIT_ROOT.is_dir() or not RAW_DIALOGUE_ROOT.is_dir():
        raise SystemExit("安全停止：必要源目录不存在。")

    adapter = load_module("evidence_exact_adapter_v2_builder", ADAPTER_PATH)
    validator = adapter.load_validator()
    audits = {split: load_audit(split) for split in SPLITS}
    affected_by_split = {split: failure_indices(audits[split]) for split in SPLITS}
    round_zero_units: set[str] = set()
    for split in SPLITS:
        source_path = SOURCE_DATA_ROOT / f"{split}.jsonl"
        with source_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                row = json.loads(line)
                if row["unit_id"] not in affected_by_split[split]:
                    continue
                for root_key, item_index in affected_by_split[split][row["unit_id"]]:
                    for ref in row["target"][root_key][item_index].get("evidence_refs", []):
                        if int(ref.get("round", -1)) <= 0:
                            round_zero_units.add(row["unit_id"])
    raw_paths = index_raw_dialogue_files(round_zero_units)

    BUILD_ROOT.mkdir(parents=True, exist_ok=False)
    output_data_root = BUILD_ROOT / "完整流水线评估"
    output_data_root.mkdir(parents=True, exist_ok=False)
    audit_output_root = BUILD_ROOT / "审计"
    audit_output_root.mkdir(parents=True, exist_ok=False)
    script_output_root = BUILD_ROOT / "构建脚本"
    script_output_root.mkdir(parents=True, exist_ok=False)

    repair_refs: list[dict] = []
    restored_messages: list[dict] = []
    split_summaries: dict[str, dict] = {}

    for split in SPLITS:
        source_path = SOURCE_DATA_ROOT / f"{split}.jsonl"
        output_path = output_data_root / f"{split}.jsonl"
        affected = affected_by_split[split]
        counts = Counter()
        invalid_records: list[dict] = []
        seen_units: set[str] = set()
        with source_path.open("r", encoding="utf-8") as source, output_path.open(
            "w", encoding="utf-8", newline="\n"
        ) as output:
            for line in source:
                if not line.strip():
                    continue
                row = json.loads(line)
                unit_id = row["unit_id"]
                if unit_id in seen_units:
                    raise RuntimeError(f"{split}存在重复unit_id：{unit_id}")
                seen_units.add(unit_id)
                if unit_id in affected:
                    row, ref_changes, message_changes = repair_row(
                        adapter,
                        split,
                        row,
                        affected[unit_id],
                        raw_paths.get(unit_id),
                    )
                    repair_refs.extend(ref_changes)
                    restored_messages.extend(message_changes)
                    counts["repaired_units"] += 1
                results = task_validation_summary(adapter, validator, row)
                for task, result in results.items():
                    counts[f"{task}_valid" if result["valid"] else f"{task}_invalid"] += 1
                    if not result["valid"]:
                        invalid_records.append(
                            {"unit_id": unit_id, "task": task, "issues": result["issues"]}
                        )
                if all(results[task]["valid"] for task in ("A", "B", "C")):
                    counts["pipeline_valid"] += 1
                output.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
        if invalid_records:
            raise RuntimeError(
                f"{split}修复后仍有严格Schema失败：{json.dumps(invalid_records[:5], ensure_ascii=False)}"
            )
        split_summaries[split] = {
            "source_path": str(source_path),
            "source_sha256": sha256_file(source_path),
            "source_bytes": source_path.stat().st_size,
            "output_relative_path": str(output_path.relative_to(BUILD_ROOT)),
            "output_sha256": sha256_file(output_path),
            "output_bytes": output_path.stat().st_size,
            "total_units": len(seen_units),
            "repaired_units": counts["repaired_units"],
            "A": {"eligible": counts["A_valid"], "excluded": counts["A_invalid"]},
            "B": {"eligible": counts["B_valid"], "excluded": counts["B_invalid"]},
            "C": {"eligible": counts["C_valid"], "excluded": counts["C_invalid"]},
            "pipeline_ABC": {
                "eligible": counts["pipeline_valid"],
                "excluded": len(seen_units) - counts["pipeline_valid"],
            },
        }

    manifest = {
        "version": "submission_evidence_exact_trace_v2",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "Non-destructive exact evidence-trace repair for aligned A/B/C training and evaluation.",
        "source_version": "submission_evidence_enriched_eligibility_v1",
        "source_root": str(SOURCE_ROOT),
        "output_root": str(FINAL_ROOT),
        "repair_policy": {
            "source_files_immutable": True,
            "no_generated_evidence": True,
            "no_label_changes": True,
            "positive_round_resolution": "本题第N轮按合并对话的全局第N条记录解析，再固定到chat_id+speaker+turn+dialogue_index+message_id。",
            "round_zero_resolution": "从对应StudyChat原始JSONL精确恢复缺失AI response，并记录source_file/source_line与内容哈希。",
            "strict_schema_required_for_all_A_B_C": True,
            "context_length_eligibility_not_changed": True,
        },
        "repair_totals": {
            "affected_units": sum(item["repaired_units"] for item in split_summaries.values()),
            "evidence_refs_repaired": len(repair_refs),
            "assistant_messages_restored": len(restored_messages),
        },
        "splits": split_summaries,
        "dependencies": {
            "adapter_path": str(ADAPTER_PATH),
            "adapter_sha256": sha256_file(ADAPTER_PATH),
            "validator_path": str(adapter.VALIDATOR_PATH),
            "validator_sha256": sha256_file(Path(adapter.VALIDATOR_PATH)),
            "source_audits": {
                split: {
                    "path": str(AUDIT_ROOT / f"derived_audit_{split}.json"),
                    "sha256": sha256_file(AUDIT_ROOT / f"derived_audit_{split}.json"),
                }
                for split in SPLITS
            },
        },
    }
    write_json(audit_output_root / "证据精确追溯修复清单.json", repair_refs)
    write_json(audit_output_root / "原始AI回答恢复清单.json", restored_messages)
    write_json(audit_output_root / "任务准入清单_v2.json", manifest)

    readme = """证据精确追溯派生版 v2

1. 本目录由“提交证据增强派生版”非破坏性生成，原版本未覆盖。
2. 未修改知识蓝图、操作、KSA、责任、份额、REL/SUP/MIXED或FOCAL/SUPPORT标签。
3. 修复仅涉及证据引用的精确定位，以及从StudyChat原始JSONL原样恢复转换阶段漏入的AI回答。
4. train、validation、test均已通过当前严格A/B/C Schema校验。
5. 本准入清单只表示标签与证据结构完整，不改变候选检索和上下文长度准入规则。
6. 正式LoRA训练数据须在本版本之上继续完成候选路径召回审计后生成。
"""
    (BUILD_ROOT / "README_证据精确追溯派生版_v2.txt").write_text(
        readme, encoding="utf-8", newline="\n"
    )
    shutil.copy2(Path(__file__).resolve(), script_output_root / Path(__file__).name)

    checksum_lines = []
    for path in sorted(p for p in BUILD_ROOT.rglob("*") if p.is_file()):
        relative = path.relative_to(BUILD_ROOT).as_posix()
        if relative == "SHA256SUMS.txt":
            continue
        checksum_lines.append(f"{sha256_file(path)}  {relative}")
    (BUILD_ROOT / "SHA256SUMS.txt").write_text(
        "\n".join(checksum_lines) + "\n", encoding="utf-8", newline="\n"
    )

    os.replace(BUILD_ROOT, FINAL_ROOT)
    print(
        json.dumps(
            {
                "status": "PASS",
                "output_root": str(FINAL_ROOT),
                "repair_totals": manifest["repair_totals"],
                "splits": split_summaries,
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
