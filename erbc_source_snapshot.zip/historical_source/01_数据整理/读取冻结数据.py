"""只读检查器：验证冻结训练版本的 JSONL 可读取及任务结构。

该脚本不修改任何数据文件。正式训练代码应在此检查通过后再接入 tokenizer 和 Trainer。
"""
import argparse
import json
from pathlib import Path


TASKS = {
    "A_题目知识蓝图任务": "blueprint",
    "B_粗粒度操作任务": "operations",
    "C_细粒度KSA任务": "ksa",
}


def iter_jsonl(path: Path):
    with path.open("r", encoding="utf-8") as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                yield line_no, json.loads(line)


def check(root: Path):
    summary = {"root": str(root), "tasks": {}, "errors": []}
    all_ids = {}
    for folder, target_key in TASKS.items():
        summary["tasks"][folder] = {}
        for split in ("train", "validation", "test"):
            path = root / folder / f"{split}.jsonl"
            ids = []
            rows = 0
            records = 0
            if not path.exists():
                summary["errors"].append(f"missing: {path}")
                continue
            for line_no, row in iter_jsonl(path):
                rows += 1
                unit_id = row.get("unit_id")
                if not unit_id:
                    summary["errors"].append(f"{path}:{line_no}: missing unit_id")
                ids.append(unit_id)
                if not row.get("metadata", {}).get("standard_library_ref"):
                    summary["errors"].append(f"{path}:{line_no}: missing standard_library_ref")
                try:
                    target = json.loads(row["messages"][-1]["content"])
                except (KeyError, IndexError, json.JSONDecodeError) as exc:
                    summary["errors"].append(f"{path}:{line_no}: invalid messages target: {exc}")
                    continue
                records += len(target.get(target_key, []))
            if len(ids) != len(set(ids)):
                summary["errors"].append(f"{path}: duplicated unit_id")
            summary["tasks"][folder][split] = {"rows": rows, "records": records}
            all_ids[(folder, split)] = set(ids)

    for folder in TASKS:
        train = all_ids.get((folder, "train"), set())
        validation = all_ids.get((folder, "validation"), set())
        test = all_ids.get((folder, "test"), set())
        for left, right, name in ((train, validation, "train-validation"),
                                  (train, test, "train-test"),
                                  (validation, test, "validation-test")):
            overlap = left & right
            if overlap:
                summary["errors"].append(f"{folder}: {name} overlap={len(overlap)}")

    if summary["errors"]:
        summary["status"] = "FAIL"
    else:
        summary["status"] = "PASS"
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(
        r"D:\stress-aware-homework-agent\项目进展\题目知识蓝图与KSA双层外包新方法\模型训练\最终冻结训练版本"
    ))
    args = parser.parse_args()
    result = check(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
