from __future__ import annotations
import argparse
import copy
import hashlib
import importlib.util
import json
import os
import re
import shutil
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
PROJECT_ROOT = Path('D:\\stress-aware-homework-agent\\\u9879\u76ee\u8fdb\u5c55\\\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e0eKSA\u53cc\u5c42\u5916\u5305\u65b0\u65b9\u6cd5\\\u6a21\u578b\u8bad\u7ec3')
SOURCE_ROOT = PROJECT_ROOT / '\u8bad\u7ec3\u6570\u636e' / '\u63d0\u4ea4\u8bc1\u636e\u589e\u5f3a\u6d3e\u751f\u7248'
SOURCE_DATA_ROOT = SOURCE_ROOT / '\u5b8c\u6574\u6d41\u6c34\u7ebf\u8bc4\u4f30'
AUDIT_ROOT = PROJECT_ROOT / '\u672c\u5730\u90e8\u7f72\u6d4b\u8bd5' / '\u63d0\u4ea4\u8bc1\u636e\u6062\u590d'
ADAPTER_PATH = PROJECT_ROOT / 'H100\u6b63\u5f0f\u57fa\u7ebf\u8fd0\u884c' / '\u4f9d\u8d56' / 'record_adapter.py'
RAW_DIALOGUE_ROOT = Path('D:\\stress-aware-homework-agent\\\u9879\u76ee\u8fdb\u5c55\\\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e0eKSA\u53cc\u5c42\u5916\u5305\u65b0\u65b9\u6cd5\\\u8de8\u5b66\u79d1\u6807\u51c6\u5e93\u4e0e\u6570\u636e\u96c6\\01_\u8ba1\u7b97\u673a\u79d1\u5b66\\StudyChat_\u9879\u76ee\u6570\u636e\\studychat_\u884c\u4e3a\u64cd\u4f5c\u5212\u5206\u6570\u636e')
FINAL_ROOT = PROJECT_ROOT / '\u8bad\u7ec3\u6570\u636e' / '\u63d0\u4ea4\u8bc1\u636e\u7cbe\u786e\u8ffd\u6eaf\u6d3e\u751f\u7248_v2'
BUILD_ROOT = PROJECT_ROOT / '\u8bad\u7ec3\u6570\u636e' / '\u63d0\u4ea4\u8bc1\u636e\u7cbe\u786e\u8ffd\u6eaf\u6d3e\u751f\u7248_v2_\u6784\u5efa\u4e2d'
SPLITS = ('train', 'validation', 'test')

def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

def compact(text: str) -> str:
    return re.sub('\\s+', ' ', text or '').strip().lower()

def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f'\u65e0\u6cd5\u52a0\u8f7d\u6a21\u5757：{path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def load_audit(split: str) -> dict:
    path = AUDIT_ROOT / f'derived_audit_{split}.json'
    with path.open('r', encoding='utf-8') as handle:
        return json.load(handle)

def failure_indices(audit: dict) -> dict[str, set[tuple[str, int]]]:
    output: dict[str, set[tuple[str, int]]] = defaultdict(set)
    for failure in audit['failures']:
        root_key = 'operations' if failure['task'] == 'B' else 'ksa'
        for issue in failure['result']['issues']:
            match = re.search('\\[(\\d+)\\]\\.evidence_refs$', issue['path'])
            if not match:
                raise RuntimeError(f"\u53d1\u73b0\u975e\u9884\u671f\u5931\u8d25\u8def\u5f84：{failure['unit_id']} {failure['task']} {issue['path']}")
            output[failure['unit_id']].add((root_key, int(match.group(1))))
    return output

def index_raw_dialogue_files(required_units: set[str]) -> dict[str, Path]:
    found: dict[str, Path] = {}
    for path in RAW_DIALOGUE_ROOT.rglob('01_AI\u5bf9\u8bdd\u539f\u59cb\u8bb0\u5f55.jsonl'):
        unit_id = path.parent.name
        if unit_id not in required_units:
            continue
        if unit_id in found:
            raise RuntimeError(f'\u539f\u59cb\u5bf9\u8bdd\u6587\u4ef6\u4e0d\u552f\u4e00：{unit_id}\n{found[unit_id]}\n{path}')
        found[unit_id] = path
    missing = sorted(required_units - set(found))
    if missing:
        raise RuntimeError(f'\u7f3a\u5c11\u539f\u59cb\u5bf9\u8bdd\u6587\u4ef6：{missing}')
    return found

def raw_records(path: Path) -> list[dict]:
    with path.open('r', encoding='utf-8') as handle:
        return [json.loads(line) for line in handle if line.strip()]

def strict_results(adapter, validator, row: dict) -> tuple[dict, dict, dict]:
    adapted = adapter.adapt_row(row)
    valid_message_ids = [item['message_id'] for item in adapted['dialogue']]
    valid_message_ids.extend(adapter.submission_sources(row).keys())
    result_a = validator.validate('A', adapted['subject'], adapted['A'])
    result_b = validator.validate('B', adapted['subject'], adapted['B'], {'blueprint': adapted['A']['blueprint'], 'valid_message_ids': valid_message_ids})
    result_c = validator.validate('C', adapted['subject'], adapted['C'], {'blueprint': adapted['A']['blueprint'], 'operations': adapted['B']['operations'], 'valid_message_ids': valid_message_ids})
    return (result_a, result_b, result_c)

def evidence_body(item: dict) -> str:
    text = str(item.get('evidence') or item.get('student_evidence') or item.get('ai_evidence') or '')
    text = re.sub('^\u7b2c0\u8f6e(?:AI|\u5b66\u751f)[\uff1a:]', '', text).rstrip('…').strip()
    return compact(text)

def find_raw_response(item: dict, records: list[dict]) -> dict:
    body = evidence_body(item)
    signature = body.split('```')[0].strip()[:100]
    matches = [record for record in records if signature and signature in compact(str(record.get('response', '')))[:max(180, len(signature))]]
    if len(matches) != 1:
        raise RuntimeError(f"\u7b2c0\u8f6eAI\u8bc1\u636e\u65e0\u6cd5\u552f\u4e00\u5339\u914d\u539f\u59cb\u56de\u7b54：operation={item.get('operation_id')} ksa={item.get('ksa_id')} matches={len(matches)} signature={signature!r}")
    return matches[0]

def canonical_key(adapter, unit_id: str, message: dict, fallback_turn: int) -> tuple[str, int, str]:
    return (str(message.get('chat_id') or unit_id), int(message.get('turn', fallback_turn)), adapter.speaker_name(message.get('role', '')))

def repair_row(adapter, split: str, row: dict, affected: set[tuple[str, int]], raw_path: Path | None) -> tuple[dict, list[dict], list[dict]]:
    repaired = copy.deepcopy(row)
    dialogue = repaired['input'].get('dialogue', [])
    raw_cache = raw_records(raw_path) if raw_path else []
    missing_messages: dict[tuple[str, int, str], dict] = {}
    ref_records: list[dict] = []
    message_records: list[dict] = []
    for root_key, item_index in sorted(affected):
        item = repaired['target'][root_key][item_index]
        refs = item.get('evidence_refs', [])
        if not refs:
            raise RuntimeError(f"\u5f85\u4fee\u590d\u9879\u6ca1\u6709\u539f\u59cbevidence_refs：{row['unit_id']} {root_key}[{item_index}]")
        for ref_index, ref in enumerate(refs):
            old_ref = copy.deepcopy(ref)
            round_value = int(ref.get('round', -1))
            if round_value > 0:
                if not 1 <= round_value <= len(dialogue):
                    raise RuntimeError(f"\u5168\u5c40\u8f6e\u6b21\u8d8a\u754c：{row['unit_id']} {root_key}[{item_index}] round={round_value}")
                message = dialogue[round_value - 1]
                key = canonical_key(adapter, row['unit_id'], message, round_value)
                method = 'global_dialogue_index'
                source_record = None
            else:
                if raw_path is None:
                    raise RuntimeError(f"\u7b2c0\u8f6e\u8bc1\u636e\u7f3a\u5c11\u539f\u59cb\u6587\u4ef6：{row['unit_id']}")
                source_record = find_raw_response(item, raw_cache)
                turn = int(source_record.get('interactionCount', 0)) * 2 + 3
                key = (str(source_record['chatId']), turn, 'assistant')
                missing_messages[key] = source_record
                method = 'raw_studychat_response'
            ref['_canonical_key'] = list(key)
            ref_records.append({'split': split, 'unit_id': row['unit_id'], 'target_root': root_key, 'target_index': item_index, 'operation_id': item.get('operation_id'), 'ksa_id': item.get('ksa_id'), 'ref_index': ref_index, 'resolution_method': method, 'old_ref': old_ref, 'raw_source_path': str(raw_path) if source_record else None, 'raw_source_file': source_record.get('source_file') if source_record else None, 'raw_source_line': source_record.get('source_line') if source_record else None})
    for key, record in missing_messages.items():
        chat_id, turn, _ = key
        already_present = any((str(message.get('chat_id')) == chat_id and int(message.get('turn', -1)) == turn and (adapter.speaker_name(message.get('role', '')) == 'assistant') for message in dialogue))
        if already_present:
            continue
        anchors = [index for index, message in enumerate(dialogue) if str(message.get('chat_id')) == chat_id and int(message.get('turn', -1)) == turn - 1 and (adapter.speaker_name(message.get('role', '')) == 'student')]
        if len(anchors) != 1:
            raise RuntimeError(f"\u65e0\u6cd5\u552f\u4e00\u5b9a\u4f4d\u6f0f\u5165AI\u56de\u7b54\u7684\u7528\u6237\u63d0\u95ee：{row['unit_id']} chat={chat_id} turn={turn}")
        restored = {'chat_id': chat_id, 'turn': turn, 'role': 'assistant', 'content': record['response'], 'restoration': {'version': 'evidence_exact_trace_v2', 'source_path': str(raw_path), 'source_file': record.get('source_file'), 'source_line': record.get('source_line'), 'status': 'restored_exactly_from_raw_studychat'}}
        dialogue.insert(anchors[0] + 1, restored)
        message_records.append({'split': split, 'unit_id': row['unit_id'], 'chat_id': chat_id, 'turn': turn, 'role': 'assistant', 'source_path': str(raw_path), 'source_file': record.get('source_file'), 'source_line': record.get('source_line'), 'response_sha256': hashlib.sha256(record['response'].encode('utf-8')).hexdigest()})
    lookup: dict[tuple[str, int, str], list[int]] = defaultdict(list)
    for index, message in enumerate(dialogue):
        lookup[canonical_key(adapter, row['unit_id'], message, index + 1)].append(index)
    record_cursor = 0
    for root_key, item_index in sorted(affected):
        item = repaired['target'][root_key][item_index]
        for ref in item.get('evidence_refs', []):
            key_raw = ref.pop('_canonical_key', None)
            if key_raw is None:
                raise RuntimeError(f"\u4fee\u590d\u5f15\u7528\u7f3a\u5c11\u5185\u90e8\u952e：{row['unit_id']} {root_key}[{item_index}]")
            key = (str(key_raw[0]), int(key_raw[1]), str(key_raw[2]))
            positions = lookup.get(key, [])
            if len(positions) != 1:
                raise RuntimeError(f"\u7cbe\u786e\u6d88\u606f\u952e\u4e0d\u552f\u4e00：{row['unit_id']} {root_key}[{item_index}] key={key} count={len(positions)}")
            position = positions[0]
            message = dialogue[position]
            message_id = f"{message.get('chat_id') or row['unit_id']}:turn:{int(message.get('turn', position + 1))}:{adapter.speaker_name(message.get('role', ''))}:index:{position}"
            ref.update({'source_chat_id': key[0], 'speaker': key[2], 'turn': key[1], 'dialogue_index': position, 'message_id': message_id, 'message_id_status': 'exact_trace_v2'})
            ref_records[record_cursor]['new_ref'] = copy.deepcopy(ref)
            record_cursor += 1
    return (repaired, ref_records, message_records)

def task_validation_summary(adapter, validator, row: dict) -> dict:
    result_a, result_b, result_c = strict_results(adapter, validator, row)
    return {'A': result_a, 'B': result_b, 'C': result_c}

def write_json(path: Path, payload: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='\n') as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write('\n')

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', type=Path, default=PROJECT_ROOT)
    args = parser.parse_args()
    if args.project_root.resolve() != PROJECT_ROOT.resolve():
        raise SystemExit('\u672c\u811a\u672c\u5f53\u524d\u53ea\u5141\u8bb8\u5199\u5165\u5df2\u5ba1\u6838\u7684\u6b63\u5f0f\u9879\u76ee\u6839\u76ee\u5f55\u3002')
    if FINAL_ROOT.exists():
        raise SystemExit(f'\u5b89\u5168\u505c\u6b62：\u6b63\u5f0f\u76ee\u6807\u76ee\u5f55\u5df2\u7ecf\u5b58\u5728：{FINAL_ROOT}')
    if BUILD_ROOT.exists():
        raise SystemExit(f'\u5b89\u5168\u505c\u6b62：\u6784\u5efa\u4e2d\u76ee\u5f55\u5df2\u7ecf\u5b58\u5728，\u8bf7\u5148\u4eba\u5de5\u68c0\u67e5：{BUILD_ROOT}')
    if not SOURCE_DATA_ROOT.is_dir() or not AUDIT_ROOT.is_dir() or (not RAW_DIALOGUE_ROOT.is_dir()):
        raise SystemExit('\u5b89\u5168\u505c\u6b62\uff1a\u5fc5\u8981\u6e90\u76ee\u5f55\u4e0d\u5b58\u5728\u3002')
    adapter = load_module('evidence_exact_adapter_v2_builder', ADAPTER_PATH)
    validator = adapter.load_validator()
    audits = {split: load_audit(split) for split in SPLITS}
    affected_by_split = {split: failure_indices(audits[split]) for split in SPLITS}
    round_zero_units: set[str] = set()
    for split in SPLITS:
        source_path = SOURCE_DATA_ROOT / f'{split}.jsonl'
        with source_path.open('r', encoding='utf-8') as handle:
            for line in handle:
                if not line.strip():
                    continue
                row = json.loads(line)
                if row['unit_id'] not in affected_by_split[split]:
                    continue
                for root_key, item_index in affected_by_split[split][row['unit_id']]:
                    for ref in row['target'][root_key][item_index].get('evidence_refs', []):
                        if int(ref.get('round', -1)) <= 0:
                            round_zero_units.add(row['unit_id'])
    raw_paths = index_raw_dialogue_files(round_zero_units)
    BUILD_ROOT.mkdir(parents=True, exist_ok=False)
    output_data_root = BUILD_ROOT / '\u5b8c\u6574\u6d41\u6c34\u7ebf\u8bc4\u4f30'
    output_data_root.mkdir(parents=True, exist_ok=False)
    audit_output_root = BUILD_ROOT / '\u5ba1\u8ba1'
    audit_output_root.mkdir(parents=True, exist_ok=False)
    script_output_root = BUILD_ROOT / '\u6784\u5efa\u811a\u672c'
    script_output_root.mkdir(parents=True, exist_ok=False)
    repair_refs: list[dict] = []
    restored_messages: list[dict] = []
    split_summaries: dict[str, dict] = {}
    for split in SPLITS:
        source_path = SOURCE_DATA_ROOT / f'{split}.jsonl'
        output_path = output_data_root / f'{split}.jsonl'
        affected = affected_by_split[split]
        counts = Counter()
        invalid_records: list[dict] = []
        seen_units: set[str] = set()
        with source_path.open('r', encoding='utf-8') as source, output_path.open('w', encoding='utf-8', newline='\n') as output:
            for line in source:
                if not line.strip():
                    continue
                row = json.loads(line)
                unit_id = row['unit_id']
                if unit_id in seen_units:
                    raise RuntimeError(f'{split}\u5b58\u5728\u91cd\u590dunit_id：{unit_id}')
                seen_units.add(unit_id)
                if unit_id in affected:
                    row, ref_changes, message_changes = repair_row(adapter, split, row, affected[unit_id], raw_paths.get(unit_id))
                    repair_refs.extend(ref_changes)
                    restored_messages.extend(message_changes)
                    counts['repaired_units'] += 1
                results = task_validation_summary(adapter, validator, row)
                for task, result in results.items():
                    counts[f'{task}_valid' if result['valid'] else f'{task}_invalid'] += 1
                    if not result['valid']:
                        invalid_records.append({'unit_id': unit_id, 'task': task, 'issues': result['issues']})
                if all((results[task]['valid'] for task in ('A', 'B', 'C'))):
                    counts['pipeline_valid'] += 1
                output.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
        if invalid_records:
            raise RuntimeError(f'{split}\u4fee\u590d\u540e\u4ecd\u6709\u4e25\u683cSchema\u5931\u8d25：{json.dumps(invalid_records[:5], ensure_ascii=False)}')
        split_summaries[split] = {'source_path': str(source_path), 'source_sha256': sha256_file(source_path), 'source_bytes': source_path.stat().st_size, 'output_relative_path': str(output_path.relative_to(BUILD_ROOT)), 'output_sha256': sha256_file(output_path), 'output_bytes': output_path.stat().st_size, 'total_units': len(seen_units), 'repaired_units': counts['repaired_units'], 'A': {'eligible': counts['A_valid'], 'excluded': counts['A_invalid']}, 'B': {'eligible': counts['B_valid'], 'excluded': counts['B_invalid']}, 'C': {'eligible': counts['C_valid'], 'excluded': counts['C_invalid']}, 'pipeline_ABC': {'eligible': counts['pipeline_valid'], 'excluded': len(seen_units) - counts['pipeline_valid']}}
    manifest = {'version': 'submission_evidence_exact_trace_v2', 'created_at_utc': datetime.now(timezone.utc).isoformat(), 'purpose': 'Non-destructive exact evidence-trace repair for aligned A/B/C training and evaluation.', 'source_version': 'submission_evidence_enriched_eligibility_v1', 'source_root': str(SOURCE_ROOT), 'output_root': str(FINAL_ROOT), 'repair_policy': {'source_files_immutable': True, 'no_generated_evidence': True, 'no_label_changes': True, 'positive_round_resolution': '\u672c\u9898\u7b2cN\u8f6e\u6309\u5408\u5e76\u5bf9\u8bdd\u7684\u5168\u5c40\u7b2cN\u6761\u8bb0\u5f55\u89e3\u6790\uff0c\u518d\u56fa\u5b9a\u5230chat_id+speaker+turn+dialogue_index+message_id\u3002', 'round_zero_resolution': '\u4ece\u5bf9\u5e94StudyChat\u539f\u59cbJSONL\u7cbe\u786e\u6062\u590d\u7f3a\u5931AI response\uff0c\u5e76\u8bb0\u5f55source_file/source_line\u4e0e\u5185\u5bb9\u54c8\u5e0c\u3002', 'strict_schema_required_for_all_A_B_C': True, 'context_length_eligibility_not_changed': True}, 'repair_totals': {'affected_units': sum((item['repaired_units'] for item in split_summaries.values())), 'evidence_refs_repaired': len(repair_refs), 'assistant_messages_restored': len(restored_messages)}, 'splits': split_summaries, 'dependencies': {'adapter_path': str(ADAPTER_PATH), 'adapter_sha256': sha256_file(ADAPTER_PATH), 'validator_path': str(adapter.VALIDATOR_PATH), 'validator_sha256': sha256_file(Path(adapter.VALIDATOR_PATH)), 'source_audits': {split: {'path': str(AUDIT_ROOT / f'derived_audit_{split}.json'), 'sha256': sha256_file(AUDIT_ROOT / f'derived_audit_{split}.json')} for split in SPLITS}}}
    write_json(audit_output_root / '\u8bc1\u636e\u7cbe\u786e\u8ffd\u6eaf\u4fee\u590d\u6e05\u5355.json', repair_refs)
    write_json(audit_output_root / '\u539f\u59cbAI\u56de\u7b54\u6062\u590d\u6e05\u5355.json', restored_messages)
    write_json(audit_output_root / '\u4efb\u52a1\u51c6\u5165\u6e05\u5355_v2.json', manifest)
    readme = '\u8bc1\u636e\u7cbe\u786e\u8ffd\u6eaf\u6d3e\u751f\u7248 v2\n\n1. \u672c\u76ee\u5f55\u7531\u201c\u63d0\u4ea4\u8bc1\u636e\u589e\u5f3a\u6d3e\u751f\u7248\u201d\u975e\u7834\u574f\u6027\u751f\u6210\uff0c\u539f\u7248\u672c\u672a\u8986\u76d6\u3002\n2. \u672a\u4fee\u6539\u77e5\u8bc6\u84dd\u56fe\u3001\u64cd\u4f5c\u3001KSA\u3001\u8d23\u4efb\u3001\u4efd\u989d\u3001REL/SUP/MIXED\u6216FOCAL/SUPPORT\u6807\u7b7e\u3002\n3. \u4fee\u590d\u4ec5\u6d89\u53ca\u8bc1\u636e\u5f15\u7528\u7684\u7cbe\u786e\u5b9a\u4f4d\uff0c\u4ee5\u53ca\u4eceStudyChat\u539f\u59cbJSONL\u539f\u6837\u6062\u590d\u8f6c\u6362\u9636\u6bb5\u6f0f\u5165\u7684AI\u56de\u7b54\u3002\n4. train\u3001validation\u3001test\u5747\u5df2\u901a\u8fc7\u5f53\u524d\u4e25\u683cA/B/C Schema\u6821\u9a8c\u3002\n5. \u672c\u51c6\u5165\u6e05\u5355\u53ea\u8868\u793a\u6807\u7b7e\u4e0e\u8bc1\u636e\u7ed3\u6784\u5b8c\u6574\uff0c\u4e0d\u6539\u53d8\u5019\u9009\u68c0\u7d22\u548c\u4e0a\u4e0b\u6587\u957f\u5ea6\u51c6\u5165\u89c4\u5219\u3002\n6. \u6b63\u5f0fLoRA\u8bad\u7ec3\u6570\u636e\u987b\u5728\u672c\u7248\u672c\u4e4b\u4e0a\u7ee7\u7eed\u5b8c\u6210\u5019\u9009\u8def\u5f84\u53ec\u56de\u5ba1\u8ba1\u540e\u751f\u6210\u3002\n'
    (BUILD_ROOT / 'README_\u8bc1\u636e\u7cbe\u786e\u8ffd\u6eaf\u6d3e\u751f\u7248_v2.txt').write_text(readme, encoding='utf-8', newline='\n')
    shutil.copy2(Path(__file__).resolve(), script_output_root / Path(__file__).name)
    checksum_lines = []
    for path in sorted((p for p in BUILD_ROOT.rglob('*') if p.is_file())):
        relative = path.relative_to(BUILD_ROOT).as_posix()
        if relative == 'SHA256SUMS.txt':
            continue
        checksum_lines.append(f'{sha256_file(path)}  {relative}')
    (BUILD_ROOT / 'SHA256SUMS.txt').write_text('\n'.join(checksum_lines) + '\n', encoding='utf-8', newline='\n')
    os.replace(BUILD_ROOT, FINAL_ROOT)
    print(json.dumps({'status': 'PASS', 'output_root': str(FINAL_ROOT), 'repair_totals': manifest['repair_totals'], 'splits': split_summaries}, ensure_ascii=False, indent=2))
if __name__ == '__main__':
    main()
