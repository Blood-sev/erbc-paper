'\u53ea\u8bfb\u68c0\u67e5\u5668\uff1a\u9a8c\u8bc1\u51bb\u7ed3\u8bad\u7ec3\u7248\u672c\u7684 JSONL \u53ef\u8bfb\u53d6\u53ca\u4efb\u52a1\u7ed3\u6784\u3002\n\n\u8be5\u811a\u672c\u4e0d\u4fee\u6539\u4efb\u4f55\u6570\u636e\u6587\u4ef6\u3002\u6b63\u5f0f\u8bad\u7ec3\u4ee3\u7801\u5e94\u5728\u6b64\u68c0\u67e5\u901a\u8fc7\u540e\u518d\u63a5\u5165 tokenizer \u548c Trainer\u3002\n'
import argparse
import json
from pathlib import Path
TASKS = {'A_\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4efb\u52a1': 'blueprint', 'B_\u7c97\u7c92\u5ea6\u64cd\u4f5c\u4efb\u52a1': 'operations', 'C_\u7ec6\u7c92\u5ea6KSA\u4efb\u52a1': 'ksa'}

def iter_jsonl(path: Path):
    with path.open('r', encoding='utf-8') as handle:
        for line_no, line in enumerate(handle, 1):
            if line.strip():
                yield (line_no, json.loads(line))

def check(root: Path):
    summary = {'root': str(root), 'tasks': {}, 'errors': []}
    all_ids = {}
    for folder, target_key in TASKS.items():
        summary['tasks'][folder] = {}
        for split in ('train', 'validation', 'test'):
            path = root / folder / f'{split}.jsonl'
            ids = []
            rows = 0
            records = 0
            if not path.exists():
                summary['errors'].append(f'missing: {path}')
                continue
            for line_no, row in iter_jsonl(path):
                rows += 1
                unit_id = row.get('unit_id')
                if not unit_id:
                    summary['errors'].append(f'{path}:{line_no}: missing unit_id')
                ids.append(unit_id)
                if not row.get('metadata', {}).get('standard_library_ref'):
                    summary['errors'].append(f'{path}:{line_no}: missing standard_library_ref')
                try:
                    target = json.loads(row['messages'][-1]['content'])
                except (KeyError, IndexError, json.JSONDecodeError) as exc:
                    summary['errors'].append(f'{path}:{line_no}: invalid messages target: {exc}')
                    continue
                records += len(target.get(target_key, []))
            if len(ids) != len(set(ids)):
                summary['errors'].append(f'{path}: duplicated unit_id')
            summary['tasks'][folder][split] = {'rows': rows, 'records': records}
            all_ids[folder, split] = set(ids)
    for folder in TASKS:
        train = all_ids.get((folder, 'train'), set())
        validation = all_ids.get((folder, 'validation'), set())
        test = all_ids.get((folder, 'test'), set())
        for left, right, name in ((train, validation, 'train-validation'), (train, test, 'train-test'), (validation, test, 'validation-test')):
            overlap = left & right
            if overlap:
                summary['errors'].append(f'{folder}: {name} overlap={len(overlap)}')
    if summary['errors']:
        summary['status'] = 'FAIL'
    else:
        summary['status'] = 'PASS'
    return summary

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path('D:\\stress-aware-homework-agent\\\u9879\u76ee\u8fdb\u5c55\\\u9898\u76ee\u77e5\u8bc6\u84dd\u56fe\u4e0eKSA\u53cc\u5c42\u5916\u5305\u65b0\u65b9\u6cd5\\\u6a21\u578b\u8bad\u7ec3\\\u6700\u7ec8\u51bb\u7ed3\u8bad\u7ec3\u7248\u672c'))
    args = parser.parse_args()
    result = check(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['status'] == 'PASS' else 1)
if __name__ == '__main__':
    main()
