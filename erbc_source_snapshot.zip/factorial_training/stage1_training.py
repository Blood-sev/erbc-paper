import gzip,hashlib,json,math,random,time
from pathlib import Path
import torch
from safetensors.torch import save_file
from bias_contracts import need,KEYS
from bias_model import loss_parts,ordinal
def write(p,x):
    with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def emit(p,**x):
    with Path(p).open('a',encoding='utf8') as f:f.write(json.dumps(dict(time=time.time(),**x),ensure_ascii=False,allow_nan=False)+'\n')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def weights_sha(model):
    h=hashlib.sha256()
    for k,v in sorted(model.state_dict().items()):h.update(k.encode());h.update(v.detach().numpy().tobytes())
    return h.hexdigest()
def sections(rows,split):
    fit=set(split['fit']);audit=set(split['audit']);result={}
    for view in ('clean','pred'):
        result[view+'_fit']=[r for r in rows[view+'_train'] if r['unit_id'] in fit]
        result[view+'_audit']=[r for r in rows[view+'_train'] if r['unit_id'] in audit]
        result[view+'_development']=rows[view+'_development']
    return result
def state_part(part):return part if part.endswith('development') else part.split('_')[0]+'_train'
def evaluate(head,rows,states,metrics,out,part,check,sup):
    pp=[];base=[];ds=[]
    with torch.no_grad(),gzip.open(out/(part+'_traces.jsonl.gz'),'xt',encoding='utf8') as f:
        for r in rows:
            check();u=r['unit_id'];rec={k:r[k] for k in ('unit_id','subject','student_group_id','target_fraction','status')}
            old=dict(rec)
            if r['status']=='READY':
                s=states[u];z=head(s);p=float(z['prediction']);p0=float(s['prediction'])
                need(math.isfinite(p) and 0<=p<=1 and torch.equal(z['mass'],s['mass'].double()),'OUTPUT')
                rec.update(status='PASS',prediction_fraction=p,token_ids_sha256=r['token_ids_sha256'])
                old.update(status='PASS',prediction_fraction=p0,token_ids_sha256=r['token_ids_sha256'])
                y=r['target_fraction'];e=100*abs(p-y);e0=100*abs(p0-y);c=float(z['aggregate'])
                local=sup[u]['predicted' if part.startswith('pred') else 'clean'] if part.endswith('fit') else None
                d=dict(unit_id=u,token_ids_sha256=r['token_ids_sha256'],target_fraction=y,prediction=p,
                  retained_prediction=p0,error_pp=e,old_error_pp=e0,change_pp=e-e0,
                  delta_q_pp=100*float(z['delta_q']),delta_bias_pp=100*float(z['delta_bias']),
                  retained_bias=float(z['retained_bias']),corrected_bias=float(z['corrected_bias']),
                  responsibility=z['responsibility'].tolist(),reference_q=z['reference_q'].tolist(),mass=z['mass'].tolist(),
                  clipped=abs(float(z['unbounded'])-p)>1e-10,
                  outside_q_only_range=y<max(0,p0-float((z['mass']*(z['reference_q']@z['mass'].new_tensor([0.,.5,1.]))).sum()))-1e-10 or
                      y>min(1,p0+1-float((z['mass']*(z['reference_q']@z['mass'].new_tensor([0.,.5,1.]))).sum()))+1e-10,
                  local_W1=float(ordinal(z['responsibility'],local)) if local else None)
                # Test the complete decomposition, including clipping, rather than labeling the bias as responsibility.
                need(abs(max(0,min(1,c+float(z['corrected_bias'])))-p)<1e-12,'DECOMPOSITION')
                f.write(json.dumps(d,ensure_ascii=False,allow_nan=False)+'\n');ds.append(d)
            else:need(r['status']=='UPSTREAM_BLOCKED','FAILURE_CLASS')
            pp.append(rec);base.append(old)
    score=metrics(pp);baseline=metrics(base)
    write(out/(part+'_predictions.json'),pp);write(out/(part+'_metrics.json'),score)
    def group(xs):
        mean=lambda key:math.fsum(x[key] for x in xs)/len(xs) if xs else None
        return dict(n=len(xs),mean_error_pp=mean('error_pp'),mean_delta_pp=mean('change_pp'),
          mean_abs_q_shift_pp=math.fsum(abs(x['delta_q_pp']) for x in xs)/len(xs) if xs else None,
          mean_abs_bias_shift_pp=math.fsum(abs(x['delta_bias_pp']) for x in xs)/len(xs) if xs else None,
          improved=sum(x['change_pp']< -1e-9 for x in xs),worsened=sum(x['change_pp']>1e-9 for x in xs),
          severe_harm_gt5pp=sum(x['change_pp']>5 for x in xs),clipped=sum(x['clipped'] for x in xs))
    write(out/(part+'_diagnostics.json'),dict(all=group(ds),old_error_gt20=group([x for x in ds if x['old_error_pp']>20]),
      old_error_le5=group([x for x in ds if x['old_error_pp']<=5]),
      outside_q_only_range=group([x for x in ds if x['outside_q_only_range']]),
      note='Label-based groups are retrospective diagnostics only, never model inputs or sampling rules. Bias channel not a concept explanation.'))
    return score,{k:score[k]['failure_penalized_MAE_pp']-baseline[k]['failure_penalized_MAE_pp'] for k in KEYS}
def train(head,states,rows,sup,split,plan,out,metrics,check,seed,arm):
    out.mkdir();write(out/'initialization.json',dict(weights_sha256=weights_sha(head),parameters=sum(p.numel() for p in head.parameters())))
    with torch.no_grad():
        for part in states:
            for s in states[part].values():need(torch.equal(head(s)['prediction'],s['prediction'].double()),'ZERO_IDENTITY')
    sec=sections(rows,split);fit=sec['clean_fit'];opt=torch.optim.AdamW(head.parameters(),lr=plan['learning_rate'],betas=(.9,.95),eps=1e-8,weight_decay=.01)
    steps=0;history=[]
    for epoch in range(1,plan['epochs']+1):
        ep=out/('epoch'+str(epoch));ep.mkdir();order=list(range(len(fit)));random.Random(seed+epoch).shuffle(order)
        write(ep/'train_order.json',[fit[i]['unit_id'] for i in order])
        for start in range(0,len(order),plan['batch']):
            check();batch=order[start:start+plan['batch']];opt.zero_grad(set_to_none=True);terms={}
            for i in batch:
                r=fit[i];u=r['unit_id']
                loss,parts=loss_parts(head,states['clean_train'][u],states['pred_train'].get(u),r['target_fraction'],sup[u])
                need(bool(torch.isfinite(loss)),'LOSS_FINITE');(loss/len(batch)).backward()
                for k,v in parts.items():terms[k]=terms.get(k,0)+float(v.detach())/len(batch)
            norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1,error_if_nonfinite=True);opt.step();steps+=1
            need(all(bool(torch.isfinite(v).all()) for v in head.parameters()),'PARAM_FINITE')
            event=dict(event='update',arm=arm,seed=seed,epoch=epoch,step=steps,total=plan['epochs']*math.ceil(len(fit)/plan['batch']),
              batch_size=len(batch),gradient_norm=float(norm),terms=terms)
            emit(out/'events.jsonl',**event);emit(out.parent.parent/'events.jsonl',**event)
        save_file(head.state_dict(),str(ep/'bias_head.safetensors'))
        scores={};deltas={}
        for part,rr in sec.items():scores[part],deltas[part]=evaluate(head,rr,states[state_part(part)],metrics,ep,part,check,sup)
        record=dict(epoch=epoch,metrics=scores,delta=deltas,head_sha256=sha(ep/'bias_head.safetensors'))
        write(ep/'summary.json',record);history.append(record)
    result=dict(steps=steps,history=history,final=history[-1]);write(out/'summary.json',result);return result
