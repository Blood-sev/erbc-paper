"""Paired continuation: change reference targets only, not architecture."""
import math
import torch
import torch.nn.functional as F
from bias_model import ordinal,loss_parts as original_loss

ARMS=('old_reference','success_reference')
KEYS=('overall','computer_science')
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def detach_output(z):
    return {k:v.detach().clone() for k,v in z.items() if torch.is_tensor(v)}
def new_loss(head,clean,pred,y,sup,teacher_clean,teacher_pred,arm):
    need(arm in ARMS,'ARM')
    if arm=='old_reference':return original_loss(head,clean,pred,y,sup)
    c=head(clean);tc=teacher_clean
    def kl(z,t):
        q=z['responsibility'];ref=t['responsibility'].clamp_min(1e-12)
        return (z['mass']*(q*(q.clamp_min(1e-12).log()-ref.log())).sum(-1)).sum()
    terms=dict(clean_drift=.1*(c['prediction']-tc['prediction']).abs(),
      clean_local=.05*ordinal(c['responsibility'],sup['clean']),
      clean_KL=.01*kl(c,tc),clean_bias=.02*(c['delta_bias']-tc['delta_bias']).abs())
    if pred is not None:
        need(teacher_pred is not None,'TEACHER_REQUIRED')
        z=head(pred);t=teacher_pred;e=(z['prediction']-y).abs();old=(t['prediction']-y).abs()
        terms.update(MAE=e,excess=.1*F.relu(e-old),
          pred_drift=.02*(z['prediction']-t['prediction']).abs(),
          pred_local=.05*ordinal(z['responsibility'],sup['predicted']),
          pred_KL=.01*kl(z,t),pred_bias=.02*(z['delta_bias']-t['delta_bias']).abs())
    return sum(terms.values()),terms
def choose(runs,seeds):
    by={(r['arm'],r['seed']):r for r in runs}
    need(len(by)==len(runs)==len(ARMS)*len(seeds),'RUN_COUNT')
    need(set(by)=={(a,s) for a in ARMS for s in seeds},'RUN_IDS')
    checks=[]
    for seed in seeds:
        n=by['success_reference',seed];o=by['old_reference',seed]
        need(n['epoch']==o['epoch']==4,'FIXED_EPOCH')
        for rec in (n,o):
            for d in rec['delta'].values():need(set(d)==set(KEYS) and all(math.isfinite(x) for x in d.values()),'FINITE')
        audit=n['delta']['pred_audit'];dev=n['delta']['pred_development']
        checks.append(dict(seed=seed,audit_nonworse=all(x<=1e-10 for x in audit.values()),
          dev_improves=all(x<=1e-10 for x in dev.values()) and any(x< -1e-10 for x in dev.values()),
          beats_control_audit=audit['overall']<o['delta']['pred_audit']['overall']-1e-10,
          beats_control_dev=dev['overall']<o['delta']['pred_development']['overall']-1e-10))
    passed=all(all(v for k,v in c.items() if k!='seed') for c in checks)
    return dict(candidate=by['success_reference',seeds[0]] if passed else None,checks=checks,
      rule='Fixed success_reference first seed epoch4; both seeds audit nonworse, dev improves, beats paired old-reference control overall in audit and dev. Reused audit is not independent.')
