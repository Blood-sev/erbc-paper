import json,hashlib,math
from pathlib import Path
PARTS=('clean_train','pred_train','clean_development','pred_development')
ARMS=('q_only','bias_only','joint')
def need(ok,msg):
    if not ok:raise RuntimeError(msg)
def read(p):return json.loads(Path(p).read_text(encoding='utf8'))
def write(p,x):
    with Path(p).open('x',encoding='utf8') as f:json.dump(x,f,ensure_ascii=False,indent=2,allow_nan=False)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(8388608),b''):h.update(b)
    return h.hexdigest()
def safe(root,rel):
    p=Path(rel);need(not p.is_absolute() and '..' not in p.parts,'UNSAFE_PATH')
    q=(root/p).resolve();need(q.is_relative_to(root.resolve()),'OUTSIDE_ROOT');return q
def metrics(rows):
    need(len({x['unit_id'] for x in rows})==len(rows),'DUPLICATE_METRIC_ID');result={}
    for g in ('overall','computer_science'):
        rr=[x for x in rows if g=='overall' or x['subject'].startswith('01_')];need(bool(rr),'EMPTY_METRICS');e=[]
        for x in rr:
            y=x['target_fraction'];need(math.isfinite(y) and 0<=y<=1,'TARGET')
            if x['status']=='PASS':
                p=x['prediction_fraction'];need(math.isfinite(p) and 0<=p<=1,'PREDICTION');e.append(100*abs(p-y))
            else:need(x['status']=='UPSTREAM_BLOCKED','EXECUTION_NOT_SCORE');e.append(100.)
        result[g]=dict(records=len(rr),valid=sum(x['status']=='PASS' for x in rr),failure_penalized_MAE_pp=math.fsum(e)/len(e),failure_penalized_RMSE_pp=math.sqrt(math.fsum(x*x for x in e)/len(e)))
    return result
def validate_teacher(arm,seed,stage,binding):
    need(stage in (1,2),'CONTINUATION_STAGE')
    need(binding['arm']==arm and binding['seed']==seed and binding['stage']==stage-1 and binding['epoch']==4,'CROSS_ARM_OR_SEED_TEACHER')
def batch_order(n,seed,epoch):
    import random
    z=list(range(n));random.Random(seed+epoch).shuffle(z);return z
