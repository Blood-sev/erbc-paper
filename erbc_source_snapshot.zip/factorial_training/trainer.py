import copy,math,time
import torch
from safetensors.torch import save_file
from contracts import need,write,sha,metrics,validate_teacher,batch_order
from bias_model import loss_parts
from retention_objective import new_loss,detach_output
from stage1_training import sections,state_part,evaluate,weights_sha

def objective(head,clean,pred,y,sup,tc,tp,stage):
    if stage==0:return loss_parts(head,clean,pred,y,sup)
    _,terms=new_loss(head,clean,pred,y,sup,tc,tp,'success_reference');terms=dict(terms)
    if stage==2:
        for k in ('clean_bias','pred_bias'):
            if k in terms:terms[k]*=.25
    return sum(terms.values()),terms

def train_run(head,states,rows,sup,plan,out,check,seed,arm,emit):
    out.mkdir();sec=sections(rows,plan['split']);fit=sec['clean_fit'];stages=[];steps=0;previous=None
    for stage,cfg in enumerate(plan['stages']):
        dst=out/f'stage{stage+1}_{cfg["name"]}';dst.mkdir();save_file(head.state_dict(),str(dst/'initial.safetensors'))
        teachers=None;snapshot=None;teacher=None
        if stage:
            validate_teacher(arm,seed,stage,previous)
            need(sha(out/previous['relative_head'])==previous['head_sha256'],'TEACHER_FILE_HASH')
            teacher=copy.deepcopy(head).eval().requires_grad_(False)
            snapshot=weights_sha(teacher);teachers={}
            with torch.no_grad():
                for part,ss in states.items():teachers[part]={u:detach_output(teacher(s)) for u,s in ss.items()}
            need(weights_sha(head)==snapshot,'INITIAL_TEACHER_IDENTITY')
        write(dst/'initialization.json',dict(arm=arm,seed=seed,stage=stage,weights_sha256=weights_sha(head),teacher=previous))
        # Fresh optimizer at every stage, exactly the archived stage settings.
        opt=torch.optim.AdamW(head.parameters(),lr=cfg['learning_rate'],betas=(.9,.95),eps=1e-8,weight_decay=.01)
        history=[];stage_steps=0;head.train()
        for epoch in range(1,5):
            ep=dst/f'epoch{epoch}';ep.mkdir();order=batch_order(len(fit),seed,epoch);write(ep/'train_order.json',[fit[i]['unit_id'] for i in order])
            for start in range(0,len(order),plan['batch']):
                check();batch=order[start:start+plan['batch']];opt.zero_grad(set_to_none=True);terms={}
                for i in batch:
                    r=fit[i];u=r['unit_id']
                    tc=teachers['clean_train'][u] if teachers else None;tp=teachers['pred_train'].get(u) if teachers else None
                    loss,ls=objective(head,states['clean_train'][u],states['pred_train'].get(u),r['target_fraction'],sup[u],tc,tp,stage)
                    need(bool(torch.isfinite(loss)),'NONFINITE_LOSS');(loss/len(batch)).backward()
                    for k,v in ls.items():terms[k]=terms.get(k,0)+float(v.detach())/len(batch)
                norm=torch.nn.utils.clip_grad_norm_(head.parameters(),1,error_if_nonfinite=True);opt.step();steps+=1;stage_steps+=1
                need(all(bool(torch.isfinite(v).all()) for v in head.parameters()),'NONFINITE_PARAMETERS')
                emit(event='update',arm=arm,seed=seed,stage=stage+1,epoch=epoch,step=stage_steps,stage_total=356,run_steps=steps,batch_size=len(batch),gradient_norm=float(norm),terms=terms)
            save_file(head.state_dict(),str(ep/'bias_head.safetensors'));scores={};deltas={}
            for part,rr in sec.items():scores[part],deltas[part]=evaluate(head,rr,states[state_part(part)],metrics,ep,part,check,sup)
            rec=dict(epoch=epoch,metrics=scores,delta=deltas,head_sha256=sha(ep/'bias_head.safetensors'))
            write(ep/'summary.json',rec);history.append(rec)
        need(stage_steps==356,'STAGE_BUDGET')
        if teacher is not None:need(weights_sha(teacher)==snapshot,'TEACHER_MUTATED')
        previous=dict(arm=arm,seed=seed,stage=stage,epoch=4,head_sha256=history[-1]['head_sha256'],relative_head=str((dst/'epoch4/bias_head.safetensors').relative_to(out)))
        result=dict(stage=stage,steps=stage_steps,history=history,final=history[-1],binding=previous);write(dst/'summary.json',result);stages.append(result)
    need(steps==1068,'RUN_BUDGET');result=dict(arm=arm,seed=seed,steps=steps,stages=stages,final=stages[-1]['final'])
    write(out/'summary.json',result);return result
