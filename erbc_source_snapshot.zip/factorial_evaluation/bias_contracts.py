import hashlib, math
PARTS = ('clean_train', 'pred_train', 'clean_development', 'pred_development')
ARMS = ('q_only', 'bias_only', 'joint')
KEYS = ('overall', 'computer_science')

def need(ok, msg):
    if not ok:
        raise RuntimeError(msg)

def partition(rows):
    by = {r['unit_id']: r for r in rows}
    need(len(by) == len(rows), 'DUPLICATE')
    result = {'fit': [], 'audit': []}
    for r in rows:
        g = r['student_group_id']
        need(isinstance(g, str) and bool(g.strip()), 'GROUP_REQUIRED')
        bucket = int(hashlib.sha256(('C_BOUNDARY_SPLIT_V1:' + g).encode()).hexdigest(), 16) % 10
        result['fit' if bucket < 8 else 'audit'].append(r['unit_id'])
    need(all(result.values()), 'EMPTY_SPLIT')
    need(not {by[u]['student_group_id'] for u in result['fit']} & {by[u]['student_group_id'] for u in result['audit']}, 'GROUP_OVERLAP')
    return result

def selection(runs, seeds):
    by = {(r['arm'], r['seed']): r for r in runs}
    need(len(by) == len(runs) == len(ARMS) * len(seeds), 'RUN_COUNT')
    need(set(by) == {(a, s) for a in ARMS for s in seeds}, 'RUN_MEMBERSHIP')
    checks = []
    for s in seeds:
        r = by['joint', s]
        need(r['epoch'] == 4, 'FIXED_EPOCH')
        for a in ARMS:
            for d in by[a, s]['delta'].values():
                need(set(d) == set(KEYS) and all((math.isfinite(v) for v in d.values())), 'METRICS')
        ia = r['delta']['pred_audit']
        dev = r['delta']['pred_development']
        checks.append(dict(seed=s, audit_nonworse=all((v <= 1e-10 for v in ia.values())), development_improves=all((v <= 1e-10 for v in dev.values())) and any((v < -1e-10 for v in dev.values())), beats_q_control_audit=ia['overall'] < by['q_only', s]['delta']['pred_audit']['overall'] - 1e-10, beats_q_control_dev=dev['overall'] < by['q_only', s]['delta']['pred_development']['overall'] - 1e-10))
    passed = all((all((v for k, v in c.items() if k != 'seed')) for c in checks))
    return dict(candidate=by['joint', seeds[0]] if passed else None, checks=checks, rule='Joint primary, fixed epoch4 and first seed; controls never substituted. Both seeds audit nonworse and development improves, beats paired q-only overall in both. Audit already reused, not independent validation.')
