"""Generate PDF and editable-text SVG from the same vector primitives."""
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase import pdfmetrics
from xml.sax.saxutils import escape

class VectorCanvas(Canvas):
    def __init__(self,*a,svg_family='Arial',**kw):
        super().__init__(*a,**kw)
        self.svg=[];self.svg_family=svg_family;self.sf='#000000';self.ss='#000000';self.sd=[]
    def setFillColor(self,color,*a,**kw):
        super().setFillColor(color,*a,**kw)
        self.sf='#%02x%02x%02x'%tuple(round(v*255) for v in (color.red,color.green,color.blue))
    def setStrokeColor(self,color,*a,**kw):
        super().setStrokeColor(color,*a,**kw)
        self.ss='#%02x%02x%02x'%tuple(round(v*255) for v in (color.red,color.green,color.blue))
    def setDash(self,array=[],phase=0):
        super().setDash(array,phase);self.sd=array if isinstance(array,(list,tuple)) else [array]
    def drawPath(self,p,stroke=1,fill=0,fillMode=None):
        super().drawPath(p,stroke,fill,fillMode)
        nums=[];commands=[]
        for token in p.getCode().split():
            if token in ('n','m','l','c','h'):
                if token!='n':commands.append({'m':'M','l':'L','c':'C','h':'Z'}[token]+' '.join(nums))
                nums=[]
            else:nums.append(token)
        dash=' stroke-dasharray="'+' '.join(str(v) for v in self.sd)+'"' if self.sd else ''
        self.svg.append(f'<path d="{" ".join(commands)}" fill="{self.sf if fill else "none"}" stroke="{self.ss if stroke else "none"}" stroke-width="{self._lineWidth}"{dash}/>')
    def roundRect(self,x,y,w,h,radius,stroke=1,fill=0):
        p=self.beginPath();p.roundRect(x,y,w,h,radius);self.drawPath(p,stroke,fill)
    def circle(self,x,y,r,stroke=1,fill=0):
        p=self.beginPath();p.ellipse(x-r,y-r,2*r,2*r);self.drawPath(p,stroke,fill)
    def _svg_text(self,x,y,text):
        family='Cambria' if self._fontname in ('MI','Math') else self.svg_family
        bold='bold' if self._fontname=='AB' else 'normal'
        italic='italic' if self._fontname=='MI' else 'normal'
        self.svg.append(f'<text transform="translate({x:.5f},{y:.5f}) scale(1,-1)" font-family="{family}" font-size="{self._fontsize}" font-weight="{bold}" font-style="{italic}" fill="{self.sf}">{escape(str(text))}</text>')
    def drawString(self,x,y,text,*a,**kw):
        super().drawString(x,y,text,*a,**kw);self._svg_text(x,y,text)
    def drawCentredString(self,x,y,text,*a,**kw):
        super().drawCentredString(x,y,text,*a,**kw)
        self._svg_text(x-pdfmetrics.stringWidth(text,self._fontname,self._fontsize)/2,y,text)
    def save_svg(self,path):
        w,h=self._pagesize
        path.write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}pt" height="{h}pt" viewBox="0 0 {w} {h}"><title>ERBC A-B-C architecture: editable vectors and text</title><rect width="100%" height="100%" fill="white"/><g transform="translate(0,{h}) scale(1,-1)">'+''.join(self.svg)+'</g></svg>',encoding='utf8')
