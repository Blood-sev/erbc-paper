"""Generate the bilingual architecture PDF and editable SVG used by the paper."""
from pathlib import Path
import math
import argparse
from vector_canvas import VectorCanvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.colors import HexColor as _hex
import pypdfium2 as pdfium

ROOT=Path(__file__).resolve().parent.parent/'figures'
ROOT.mkdir(parents=True,exist_ok=True)
parser=argparse.ArgumentParser()
parser.add_argument('--palette',choices=['original','blue_clay','blue_teal'],default='blue_teal')
parser.add_argument('--language',choices=['en','zh'],default='en')
args=parser.parse_args()
STEM='fig_abc_'+args.language
COLOR_MAP={}
if args.palette!='original':
    COLOR_MAP={
        '#293D4B':'#27333F', '#3C7095':'#496D8C',
        '#37877D':'#496D8C', '#80709C':'#65798F', '#B48A3E':'#496D8C',
        '#C5D0D8':'#D2D9DF', '#D9E8F2':'#E4EBF1', '#ECE5F3':'#E9EDF2',
        '#E5F1EF':'#E4EBF1', '#DCEAF3':'#E4EBF1', '#F8EEDB':'#E4EBF1',
        '#EAF1F6':'#EDF2F6', '#F7F9FA':'#F8FAFB', '#E6EBEE':'#E6EBEF'}
def HexColor(value):return _hex(COLOR_MAP.get(value,value))
ACCENT={'original':'#37877D','blue_clay':'#98543B','blue_teal':'#2F7772'}[args.palette]
ACCENT_FILL={'original':'#EDF6F3','blue_clay':'#FAEEE7','blue_teal':'#EBF4F2'}[args.palette]
pdfmetrics.registerFont(TTFont('A','C:/Windows/Fonts/msyh.ttc' if args.language=='zh' else 'C:/Windows/Fonts/arial.ttf'))
pdfmetrics.registerFont(TTFont('AB','C:/Windows/Fonts/msyhbd.ttc' if args.language=='zh' else 'C:/Windows/Fonts/arialbd.ttf'))
W,H=850,560
c=VectorCanvas(str(ROOT/(STEM+'.pdf')),pagesize=(W,H),svg_family='Microsoft YaHei' if args.language=='zh' else 'Arial')
c.setTitle('ERBC architecture - symbol-linked visual candidate v4')
INK='#293D4B'; BLUE='#3C7095'; TEAL='#37877D'; PURPLE='#80709C'; GOLD='#B48A3E'; LINE='#C5D0D8'
def line(pts,col=INK,w=1.5,dash=None):
    c.setStrokeColor(HexColor(col));c.setLineWidth(w);c.setDash(dash or [])
    p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1])
    for x,y in pts[1:]:p.lineTo(x,H-y)
    c.drawPath(p);c.setDash([])
def poly(pts,fill,col=INK,w=1.5):
    c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(col));c.setLineWidth(w)
    p=c.beginPath();p.moveTo(pts[0][0],H-pts[0][1])
    for x,y in pts[1:]:p.lineTo(x,H-y)
    p.close();c.drawPath(p,fill=1,stroke=1)
def arrow(pts,col=INK,dash=None):
    line(pts,col,1.6,dash)
    x,y=pts[-1];a=math.atan2(y-pts[-2][1],x-pts[-2][0])
    poly([(x,y),(x-7*math.cos(a-.4),y-7*math.sin(a-.4)),(x-7*math.cos(a+.4),y-7*math.sin(a+.4))],col,col,.3)
def box(x,y,w,h,fill='#FFFFFF',col=LINE,r=5,lw=1):
    c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(col));c.setLineWidth(lw)
    c.roundRect(x,H-y-h,w,h,r,fill=1,stroke=1)
TRANSLATIONS={"Task materials":"任务材料","Interaction + artifacts":"交互与产物","A  Task blueprint":"A  任务知识蓝图","B  Operation evidence":"B  操作与证据","C  Estimator":"C  最终估计器","Task-linked topics":"任务关联主题","Gate":"筛选","Extract":"抽取","Reduce":"归并","Action / type":"动作／类型","Role":"责任角色","Knowledge":"知识关联","Evidence":"证据引用","Records":"操作记录","Input assembly":"输入组装","Blueprint + records":"蓝图＋操作记录","Frozen state":"冻结状态","+ role evidence":"＋角色证据","Responsibility":"责任","correction":"校正","Score":"分数","Final estimate":"最终预测","Numerical B":"数值 B","50:50 mean":"等权平均","Dashed: pipeline only":"虚线：仅流水线接入"}
def tr(s):return TRANSLATIONS.get(s,s) if args.language=='zh' else s
def text(x,y,s,size=16,b=False,col=INK):
    s=tr(s)
    c.setFillColor(HexColor(col));c.setFont('AB' if b else 'A',size);c.drawCentredString(x,H-y,s)
def circ(x,y,r,fill='#FFFFFF',col=INK,lw=1.7):
    c.setFillColor(HexColor(fill));c.setStrokeColor(HexColor(col));c.setLineWidth(lw)
    c.circle(x,H-y,r,fill=1,stroke=1)
def person(x,y,s=1):
    circ(x,y-12*s,7*s,'#D9E8F2',BLUE)
    poly([(x-15*s,y+17*s),(x-15*s,y+6*s),(x-9*s,y),(x+9*s,y),(x+15*s,y+6*s),(x+15*s,y+17*s)],'#D9E8F2',BLUE)
def robot(x,y,s=1):
    box(x-15*s,y-17*s,30*s,28*s,'#ECE5F3',PURPLE,5*s,1.7)
    line([(x,y-17*s),(x,y-23*s)],PURPLE,1.7);circ(x,y-25*s,2*s,PURPLE,PURPLE)
    circ(x-6*s,y-6*s,2*s,PURPLE,PURPLE);circ(x+6*s,y-6*s,2*s,PURPLE,PURPLE)
    line([(x-6*s,y+3*s),(x+6*s,y+3*s)],PURPLE,1.7)
    line([(x-19*s,y-9*s),(x-19*s,y+3*s)],PURPLE,2)
    line([(x+19*s,y-9*s),(x+19*s,y+3*s)],PURPLE,2)
def clipboard(x,y):
    box(x-23,y-24,46,51,'#E5F1EF',TEAL,4,1.8)
    box(x-11,y-29,22,9,'#FFFFFF',TEAL,3,1.8)
    for dy in [-12,2,16]:
        line([(x-15,y+dy),(x-11,y+dy+4),(x-5,y+dy-4)],TEAL,2)
        line([(x+1,y+dy),(x+15,y+dy)],TEAL,2)
def network(x,y):
    for a,b in [((-23,-15),(0,1)),((23,-15),(0,1)),((0,1),(-23,21)),((0,1),(23,21))]:
        line([(x+a[0],y+a[1]),(x+b[0],y+b[1])],BLUE,2)
    for dx,dy in [(-23,-15),(23,-15),(-23,21),(23,21)]:circ(x+dx,y+dy,7,'#DCEAF3',BLUE)
    circ(x,y+1,10,BLUE,BLUE)
def evidence(x,y):
    box(x-24,y-24,43,33,'#F8EEDB',GOLD,5,1.8)
    poly([(x-16,y+9),(x-16,y+18),(x-5,y+9)],'#F8EEDB',GOLD,1.6)
    box(x-7,y-7,35,33,'#FFFFFF',GOLD,4,1.8)
    text(x+10,y+13,'"',29,True,GOLD)
def sliders(x,y):
    for dy,off in [(-11,8),(0,-8),(11,4)]:
        line([(x-19,y+dy),(x+19,y+dy)],ACCENT,2)
        circ(x+off,y+dy,4,'#FFFFFF',ACCENT,1.6)



# Font-backed vector math: script letters, subscripts and explicit hats.
pdfmetrics.registerFont(TTFont('Math','C:/Windows/Fonts/cambria.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('MI','C:/Windows/Fonts/cambriai.ttf'))
def mw(parts,size=20):
    return sum(pdfmetrics.stringWidth(b,'MI' if b in ['Q','D','S','a','o','s','B','C'] else 'Math',size)+pdfmetrics.stringWidth(sub,'Math',size*.65) for b,sub,hat in parts)
def mathrun(x,y,parts,size=20):
    c.setFillColor(HexColor(INK))
    for b,sub,hat in parts:
        font='MI' if b in ['Q','D','S','a','o','s','B','C'] else 'Math'
        width=pdfmetrics.stringWidth(b,font,size)
        c.setFont(font,size);c.drawString(x,H-y,b)
        if hat:line([(x+1,y-size*.83),(x+width*.5,y-size*1.02),(x+width-1,y-size*.83)],INK,.9)
        if sub:
            c.setFont('Math',size*.65);c.drawString(x+width,H-y-size*.18,sub)
        x+=width+pdfmetrics.stringWidth(sub,'Math',size*.65)
def maths(x,y,parts,size=20):mathrun(x-mw(parts,size)/2,y,parts,size)
def pair(x,y,label,parts,size=16):
    label=tr(label)
    tw=pdfmetrics.stringWidth(label,'A',size);total=tw+9+mw(parts,20)
    c.setFillColor(HexColor(INK));c.setFont('A',size)
    c.drawString(x-total/2,H-y,label);mathrun(x-total/2+tw+9,y,parts,20)
A=[('𝒜','',False)];AO=[('𝒜, 𝒪','',False)]

pair(115,25,'Task materials',[('Q','',False)],17)
pair(395,25,'Interaction + artifacts',[('D','',False),(', ','',False),('S','',False)],17)
arrow([(115,35),(115,56)]);arrow([(395,35),(395,56)])
box(12,56,207,351,col=LINE,r=7)
box(259,56,272,351,col=LINE,r=7)
box(571,56,267,351,col=LINE,r=7)
text(115,84,'A  Task blueprint',18,True)
text(395,84,'B  Operation evidence',18,True)
text(704,84,'C  Estimator',18,True)
for x,y,w,s in [(89,142,52,'KA'),(38,220,60,'KU'),(134,220,60,'KU')]:
    box(x,y,w,29,'#EAF1F6',BLUE,3,1.2);text(x+w/2,y+21,s,17)
line([(115,171),(115,195),(68,195),(68,220)],BLUE)
line([(115,195),(164,195),(164,220)],BLUE)
for parent,leaves in [(68,[40,89]),(164,[141,190])]:
    line([(parent,249),(parent,276)],BLUE)
    for leaf in leaves:
        line([(parent,276),(leaf,276),(leaf,300)],BLUE)
        box(leaf-15,300,30,24,'#EAF1F6',BLUE,3,1.3)
        line([(leaf-8,308),(leaf+8,308)],BLUE,1.3)
        line([(leaf-8,315),(leaf+4,315)],BLUE,1.3)
text(115,358,'Task-linked topics',16)
arrow([(219,116),(274,116)])
maths(239,104,A,20)
# Use the manuscript's actual process names, not newly named modules.
for x,label in [(302,'Gate'),(392,'Extract'),(487,'Reduce')]:text(x,122,label,15,True)
arrow([(326,116),(355,116)]);arrow([(423,116),(454,116)])
for x,y in [(330,187),(460,187),(330,297),(460,297)]:
    box(x-57,y-39,114,108,'#F7F9FA','#E6EBEE',7,.7)
clipboard(330,177);person(439,183,.83);robot(479,184,.83)
network(330,287);evidence(460,287)
for x,y,label in [(330,226,'Action / type'),(460,226,'Role'),(330,336,'Knowledge'),(460,336,'Evidence')]:text(x,y,label,15,True)
maths(330,248,[('a','i',False),(', τ','i',False)])
maths(460,248,[('s','i',True)])
maths(330,358,[('𝒰','i',False)])
maths(460,358,[('ℰ','i',False)])
pair(395,394,'Records',[('𝒪 = {','',False),('o','i',False),('}','',False)],16)
arrow([(531,147),(586,147)])
box(586,115,237,63,'#FFFFFF',LINE,4,1)
text(704,139,'Input assembly',16,True)
pair(704,165,'Blueprint + records',AO,15)
arrow([(704,178),(704,199)])
box(586,199,237,59,'#EAF1F6',BLUE,4,1)
text(704,223,'Frozen state',16,True)
text(704,247,'+ role evidence',16)
arrow([(704,258),(704,279)])
box(586,279,237,108,ACCENT_FILL,ACCENT,5,1.3)
text(704,302,'ERBC',18,True,ACCENT)
line([(704,313),(704,378)],'#BDD7D2',1)
text(645,331,'Responsibility',15,True);text(645,352,'correction',15)
maths(645,377,[('Δ','q',False)])
text(764,331,'Score',15,True);text(764,352,'correction',15)
maths(764,377,[('Δ','b',False)])
line([(683,407),(725,407)],'#FFFFFF',3)
arrow([(704,387),(704,431)])
box(612,431,184,64,'#FFFFFF',INK,5,1.3)
text(704,455,'Final estimate',17,True)
maths(704,484,[('C','',True),(' ∈ [0,1]','',False)],20)
arrow([(395,407),(395,431)])
box(286,431,218,100,'#FFFFFF',BLUE,5,1)
pair(395,456,'Numerical B',[('B','ens',True)],16)
for x,label in [(298,'NTL-a'),(412,'NTL-b')]:
    box(x,466,80,26,'#EAF1F6',BLUE,4,1);text(x+40,485,label,15)
box(343,506,104,22,'#EAF1F6',BLUE,3,1)
arrow([(338,492),(338,498),(369,498),(369,506)],BLUE)
arrow([(452,492),(452,498),(421,498),(421,506)],BLUE)
text(395,523,'50:50 mean',15,True)
line([(838,138),(838,156)],'#FFFFFF',3)
line([(504,509),(504,525)],'#FFFFFF',3)
arrow([(447,517),(543,517),(543,537),(845,537),(845,147),(823,147)],BLUE,[5,4])
text(695,557,'Dashed: pipeline only',15,col=BLUE)
c.save_svg(ROOT/(STEM+'.svg'))
c.showPage();c.save()
# Encode supplementary-plane script letters correctly in the PDF text map.
# ReportLab's glyph drawing is correct, but its ToUnicode map can emit a
# five-digit code point instead of the required UTF-16 surrogate pair.
import io, re
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DecodedStreamObject, NameObject
pdf_path=ROOT/(STEM+'.pdf')
reader=PdfReader(io.BytesIO(pdf_path.read_bytes()))
writer=PdfWriter();writer.clone_document_from_reader(reader)
for page in writer.pages:
    for ref in page['/Resources']['/Font'].values():
        font=ref.get_object()
        if '/ToUnicode' not in font:continue
        raw=font['/ToUnicode'].get_data()
        fixed=re.sub(rb'<([0-9A-Fa-f]{5,6})>',lambda m:b'<'+chr(int(m[1],16)).encode('utf-16-be').hex().upper().encode('ascii')+b'>',raw)
        if fixed!=raw:
            stream=DecodedStreamObject();stream.set_data(fixed)
            font[NameObject('/ToUnicode')]=writer._add_object(stream)
with pdf_path.open('wb') as f:writer.write(f)
doc=pdfium.PdfDocument(str(ROOT/(STEM+'.pdf')))
doc[0].render(scale=2).to_pil().save(ROOT/(STEM+'.png'))
doc[0].render(scale=1008/W).to_pil().save(ROOT/(STEM+'_printcheck.png'))
print('Created architecture PDF, editable SVG, and preview images.')



